这树是在extree的基础上演变过来的.
基本上功能跟extree树一致，因为时间比较长了，也忘记做了那些修改.
eXtree.rar
