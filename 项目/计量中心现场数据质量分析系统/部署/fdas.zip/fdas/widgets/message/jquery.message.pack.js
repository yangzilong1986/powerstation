/*
 * jQuery message plug-in 1.0
 *
 * http://bassistance.de/jquery-plugins/jquery-plugin-message/
 *
 * Copyright (c) 2009 Jörn Zaefferer
 *
 * $Id: jquery.message.js 6407 2009-06-19 09:07:26Z joern.zaefferer $
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(3($){X b,5,c,d;$.y.1=3(a){a=$.M(a||j.E());9(!a){x}f(c);f(d);r();b.U("p").S(a);b.L().m({6:$.1.2.6},$.1.2.l);5=C;B=t;c=g(3(){5=t},$.1.2.h+$.1.2.s*u.W(a.V));d=g(7,$.1.2.q)};3 r(){9(!b){b=$($.1.2.o).T(Q.O);$(K).J("I H G",7)}}3 7(){9(b.k(":5")&&!b.k(":F")&&!5){b.m({6:0},$.1.2.i,3(){$(j).D()})}}$.1={};$.1.2={6:0.8,i:N,l:A,s:P,h:z,q:R,o:\'<4 e="w-1"><4 e="n"></4><p></p><4 e="n"></4></4>\'}})(v);',60,60,'|message|defaults|function|div|visible|opacity|fadeOutHelper||if|||timeout1|timeout2|class|clearTimeout|setTimeout|minDuration|fadeOutDuration|this|is|fadeInDuration|animate|round|template||totalTimeout|initHelper|displayDurationPerCharacter|false|Math|jQuery|jquery|return|fn|2500|200|active|true|hide|text|animated|keypress|click|mousemove|bind|window|show|trim|500|body|125|document|6000|html|appendTo|find|length|sqrt|var'.split('|'),0,{}))