脚本介绍
	application.js 增删改查的依赖的基本脚本
	My97DatePicker	日期控件
	rapid-validation 表单验证
	
	jquery.js 该js可选,如不需要可以删除