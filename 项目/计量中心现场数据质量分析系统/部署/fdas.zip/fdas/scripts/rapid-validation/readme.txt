具体使用请查看:http://code.google.com/p/rapid-validation/ 中的在线演示

prototype_for_validation.js
	验证框架从prototype.js抽取出来的最小依赖集.用于与jquery.js兼容.如使用prototype.js则可替换此文件

可选js lib
	为一个显示效果库
	effects.js
	
	提供类似javaeye的tooltip风格来显示错误消息,如不使用可以删除
	tooltips.js
	tooltips.css
	.