/*    */ package com.hzjbbis.fk.rtu;
/*    */ 
/*    */ public class RtuAddress
/*    */ {
/*    */   private String peerAddr;
/*    */ 
/*    */   public RtuAddress(String peerAddr)
/*    */   {
/*  8 */     this.peerAddr = peerAddr;
/*    */   }
/*    */ 
/*    */   public String getIp() {
/* 12 */     int i = this.peerAddr.indexOf(58);
/* 13 */     if (i > 0) {
/* 14 */       return this.peerAddr.substring(0, i);
/*    */     }
/* 16 */     return "";
/*    */   }
/*    */ 
/*    */   public int getPort() {
/* 20 */     int i = this.peerAddr.indexOf(58);
/* 21 */     if (i > 0) {
/* 22 */       return Integer.parseInt(this.peerAddr.substring(i + 1));
/*    */     }
/* 24 */     return 0;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 28 */     return this.peerAddr;
/*    */   }
/*    */ 
/*    */   public String getPeerAddr() {
/* 32 */     return this.peerAddr;
/*    */   }
/*    */ 
/*    */   public void setPeerAddr(String peerAddr) {
/* 36 */     this.peerAddr = peerAddr;
/*    */   }
/*    */ }