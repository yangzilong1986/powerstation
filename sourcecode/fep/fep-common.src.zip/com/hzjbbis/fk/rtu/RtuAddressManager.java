/*    */ package com.hzjbbis.fk.rtu;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RtuAddressManager
/*    */ {
/* 16 */   private static final Map<Integer, RtuAddress> map = Collections.synchronizedMap(new HashMap(51207));
/*    */ 
/*    */   public static void put(int rtu, String peerAddr) {
/* 19 */     RtuAddress addr = (RtuAddress)map.get(Integer.valueOf(rtu));
/* 20 */     if (addr != null) {
/* 21 */       addr.setPeerAddr(peerAddr);
/*    */     } else {
/* 23 */       addr = new RtuAddress(peerAddr);
/* 24 */       map.put(Integer.valueOf(rtu), addr);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static RtuAddress get(int rtua) {
/* 29 */     return ((RtuAddress)map.get(Integer.valueOf(rtua)));
/*    */   }
/*    */ }