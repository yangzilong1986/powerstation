/*   */ package com.hzjbbis.fk.exception;
/*   */ 
/*   */ public class EventQueueLockedException extends Exception
/*   */ {
/*   */   private static final long serialVersionUID = 1L;
/*   */ 
/*   */   public EventQueueLockedException()
/*   */   {
/* 6 */     super("Event queue locked"); }
/*   */ 
/*   */   public EventQueueLockedException(String info) {
/* 9 */     super(info);
/*   */   }
/*   */ }