/*    */ package com.hzjbbis.fk.exception;
/*    */ 
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class MessageParseException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -5985134647725926736L;
/*    */   private ByteBuffer buffer;
/*    */ 
/*    */   public MessageParseException(String message)
/*    */   {
/* 20 */     super(message);
/*    */   }
/*    */ 
/*    */   public MessageParseException(String message, ByteBuffer buff) {
/* 24 */     super(message);
/* 25 */     if (buff == null)
/* 26 */       return;
/* 27 */     if (buff.position() > 0)
/* 28 */       buff.rewind();
/* 29 */     this.buffer = buff.slice();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 33 */     String message = super.getMessage();
/*    */ 
/* 35 */     if (message == null) {
/* 36 */       message = "";
/*    */     }
/*    */ 
/* 39 */     if (this.buffer != null) {
/* 40 */       return message + ((message.length() > 0) ? " " : "") + "(Hexdump: " + 
/* 41 */         HexDump.hexDump(this.buffer) + ')';
/*    */     }
/* 43 */     return message;
/*    */   }
/*    */ 
/*    */   public String getLocalizedMessage()
/*    */   {
/* 49 */     return getMessage();
/*    */   }
/*    */ }