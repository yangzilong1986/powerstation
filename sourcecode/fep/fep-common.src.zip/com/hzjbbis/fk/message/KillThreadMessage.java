/*    */ package com.hzjbbis.fk.message;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.exception.MessageParseException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class KillThreadMessage
/*    */   implements IMessage
/*    */ {
/*  9 */   private static final MessageType type = MessageType.MSG_KILLTHREAD;
/*    */ 
/*    */   public long getIoTime() {
/* 12 */     return 0L;
/*    */   }
/*    */ 
/*    */   public MessageType getMessageType() {
/* 16 */     return type;
/*    */   }
/*    */ 
/*    */   public String getPeerAddr() {
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   public int getPriority() {
/* 24 */     return 5;
/*    */   }
/*    */ 
/*    */   public byte[] getRawPacket() {
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   public String getRawPacketString() {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   public IChannel getSource() {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public String getTxfs() {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   public boolean read(ByteBuffer readBuffer) throws MessageParseException {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   public void setIoTime(long time)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setPeerAddr(String peer) {
/*    */   }
/*    */ 
/*    */   public void setPriority(int priority) {
/*    */   }
/*    */ 
/*    */   public void setSource(IChannel src) {
/*    */   }
/*    */ 
/*    */   public void setTxfs(String fs) {
/*    */   }
/*    */ 
/*    */   public boolean write(ByteBuffer writeBuffer) {
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */   public Long getCmdId() {
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   public String getStatus() {
/* 72 */     return null;
/*    */   }
/*    */ 
/*    */   public String getServerAddress() {
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */   public void setServerAddress(String serverAddress) {
/*    */   }
/*    */ 
/*    */   public boolean isHeartbeat() {
/* 83 */     return false;
/*    */   }
/*    */ 
/*    */   public int getRtua() {
/* 87 */     return 0;
/*    */   }
/*    */ 
/*    */   public void setStatus(String status) {
/*    */   }
/*    */ 
/*    */   public int length() {
/* 94 */     return 0;
/*    */   }
/*    */ 
/*    */   public boolean isTask() {
/* 98 */     return false;
/*    */   }
/*    */ 
/*    */   public void setTask(boolean isTask)
/*    */   {
/*    */   }
/*    */ }