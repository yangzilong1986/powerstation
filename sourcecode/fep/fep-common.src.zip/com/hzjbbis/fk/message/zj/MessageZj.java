/*     */ package com.hzjbbis.fk.message.zj;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.exception.MessageParseException;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MessageZj
/*     */   implements IMessage
/*     */ {
/*  26 */   private static final Logger log = Logger.getLogger(MessageZj.class);
/*     */   private static final int MAX_LEN = 1024;
/*  28 */   private static final MessageType type = MessageType.MSG_ZJ;
/*     */   private IChannel source;
/*  30 */   public int rtua = 0;
/*  31 */   public MessageZjHead head = new MessageZjHead();
/*     */   public ByteBuffer data;
/*  33 */   private StringBuffer rawPacket = new StringBuffer(256);
/*  34 */   private byte[] prefix = null;
/*  35 */   private int priority = 0;
/*     */   private long ioTime;
/*     */   private String peerAddr;
/*     */   private String serverAddress;
/*  39 */   private String txfs = "";
/*     */ 
/*  41 */   private int state = -1;
/*  42 */   private byte _cs = 0;
/*     */   private static final String charset = "ISO-8859-1";
/*  47 */   public long key = 0L;
/*     */   private String status;
/*     */   private Long cmdId;
/*     */   private int msgCount;
/*     */ 
/*     */   public MessageType getMessageType()
/*     */   {
/*  55 */     return type;
/*     */   }
/*     */ 
/*     */   public int locatePacket(ByteBuffer readBuffer)
/*     */     throws MessageParseException
/*     */   {
/*  64 */     int pos = -1;
/*  65 */     int pos0 = readBuffer.position();
/*  66 */     boolean located = false;
/*  67 */     int posMark = -1;
/*  68 */     for (pos = pos0; pos + 13 <= readBuffer.limit(); ++pos) {
/*  69 */       if (104 != readBuffer.get(pos))
/*     */         continue;
/*  71 */       if (104 != readBuffer.get(pos + 7)) {
/*     */         continue;
/*     */       }
/*     */ 
/*  75 */       this.head.dlen = (short)(readBuffer.get(pos + 9) & 0xFF);
/*     */       MessageZjHead tmp68_65 = this.head; tmp68_65.dlen = (short)(tmp68_65.dlen | (0xFF & readBuffer.get(pos + 10)) << 8);
/*  77 */       if (this.head.dlen < 0)
/*     */       {
/*  79 */         pos += 6;
/*     */       }
/*     */       else {
/*  82 */         this.head.c_func = (byte)(readBuffer.get(pos + 8) & 0x3F);
/*     */ 
/*  84 */         if ((this.head.c_func != 15) && (this.head.dlen >= 1024)) {
/*  85 */           pos += 6;
/*     */         }
/*  91 */         else if ((this.head.dlen + 13 > readBuffer.limit() - pos0) && (readBuffer.limit() < readBuffer.capacity())) {
/*  92 */           posMark = pos;
/*  93 */           located = true;
/*     */ 
/*  95 */           pos += 6;
/*     */         }
/*     */         else
/*     */         {
/* 100 */           if (pos > pos0) {
/* 101 */             this.prefix = new byte[pos - pos0];
/*     */ 
/* 103 */             int lastDelimiter = -1;
/* 104 */             for (int i = 0; i < this.prefix.length; ++i) {
/* 105 */               this.prefix[i] = readBuffer.get();
/* 106 */               if (124 == this.prefix[i]) {
/* 107 */                 lastDelimiter = i;
/*     */               }
/*     */             }
/*     */ 
/* 111 */             if (this.prefix.length > 16) {
/* 112 */               byte[] iot = "iotime=".getBytes();
/* 113 */               boolean isAttr = true;
/* 114 */               for (int j = 0; j < iot.length; ++j) {
/* 115 */                 if (iot[j] != this.prefix[j]) {
/* 116 */                   isAttr = false;
/* 117 */                   break;
/*     */                 }
/*     */               }
/* 120 */               if (isAttr) {
/*     */                 String attrs;
/*     */                 try {
/* 123 */                   attrs = new String(this.prefix, 0, lastDelimiter, "ISO-8859-1");
/*     */                 } catch (UnsupportedEncodingException e) {
/* 125 */                   attrs = new String(this.prefix);
/*     */                 }
/* 127 */                 StringTokenizer st = new StringTokenizer(attrs, "|");
/* 128 */                 String token = st.nextToken().substring(7);
/* 129 */                 this.ioTime = Long.parseLong(token);
/* 130 */                 this.peerAddr = st.nextToken().substring(9);
/* 131 */                 if (st.hasMoreTokens())
/* 132 */                   this.txfs = st.nextToken().substring(5);
/* 133 */                 byte[] p = new byte[this.prefix.length - lastDelimiter - 1];
/* 134 */                 for (int i = 0; i < p.length; ++i)
/* 135 */                   p[i] = this.prefix[(lastDelimiter + 1 + i)];
/* 136 */                 this.prefix = p;
/*     */               }
/*     */             }
/* 139 */             this.rawPacket.append(HexDump.hexDumpCompact(this.prefix, 0, this.prefix.length));
/*     */           }
/* 141 */           located = true;
/* 142 */           break; }
/*     */       }
/*     */     }
/* 145 */     if (!(located))
/*     */     {
/* 147 */       for (; pos < readBuffer.limit(); ++pos) {
/* 148 */         if (104 == readBuffer.get(pos))
/*     */           continue;
/*     */       }
/* 151 */       int posEnd = Math.max(readBuffer.limit() - 13, pos);
/* 152 */       byte[] bts = new byte[posEnd - pos0];
/* 153 */       readBuffer.get(bts);
/* 154 */       String expInfo = "exp不符合浙江规约，报文被丢弃：" + HexDump.hexDumpCompact(bts, 0, bts.length);
/* 155 */       if (expInfo.length() > 1000)
/* 156 */         expInfo = expInfo.substring(0, 1000);
/* 157 */       log.warn(expInfo);
/* 158 */       throw new MessageParseException(expInfo);
/*     */     }
/*     */ 
/* 161 */     return ((posMark < 0) ? pos : posMark);
/*     */   }
/*     */ 
/*     */   public boolean read(ByteBuffer readBuffer)
/*     */     throws MessageParseException
/*     */   {
/* 169 */     if ((this.state == -1) && (readBuffer.remaining() < 13)) {
/* 170 */       if (log.isDebugEnabled())
/* 171 */         log.debug("长度不足以读取浙江规约报文头，等会儿继续读取。readBuffer.remaining=" + readBuffer.remaining());
/* 172 */       return false;
/*     */     }
/* 174 */     if (this.state == -1)
/*     */     {
/* 176 */       int pos = locatePacket(readBuffer);
/* 177 */       if (readBuffer.limit() - pos < 13) {
/* 178 */         if (log.isDebugEnabled())
/* 179 */           log.debug("经过浙江规约报文定位与过滤后，长度不足以读取报文头。readBuffer.remaining=" + readBuffer.remaining());
/* 180 */         return false;
/*     */       }
/*     */ 
/* 184 */       readBuffer.position(pos);
/* 185 */       byte[] bts = new byte[11];
/* 186 */       this._cs = 0;
/* 187 */       for (int i = 0; i < 11; ++i) {
/* 188 */         bts[i] = readBuffer.get(i + pos);
/*     */         MessageZj tmp150_149 = this; tmp150_149._cs = (byte)(tmp150_149._cs + bts[i]);
/*     */       }
/* 191 */       this.rawPacket.append(HexDump.hexDumpCompact(bts, 0, bts.length));
/*     */ 
/* 193 */       this.head.flag1 = readBuffer.get();
/* 194 */       this.head.rtua_a1 = readBuffer.get();
/* 195 */       this.head.rtua_a2 = readBuffer.get();
/* 196 */       short iTemp = 0;
/* 197 */       byte c1 = readBuffer.get();
/* 198 */       iTemp = (short)((0xFF & c1) << 8);
/* 199 */       this.head.rtua_b1b2 = (short)(0xFF & c1);
/* 200 */       c1 = readBuffer.get();
/* 201 */       iTemp = (short)(iTemp | (short)(0xFF & c1));
/*     */       MessageZjHead tmp279_276 = this.head; tmp279_276.rtua_b1b2 = (short)(tmp279_276.rtua_b1b2 | (short)((0xFF & c1) << 8));
/*     */ 
/* 204 */       this.head.rtua = ((this.head.rtua_a1 & 0xFF) << 24);
/* 205 */       this.head.rtua |= (0xFF & this.head.rtua_a2) << 16;
/* 206 */       this.head.rtua |= 0xFFFF & this.head.rtua_b1b2;
/* 207 */       this.head.rtua_b1b2 = iTemp;
/* 208 */       this.rtua = this.head.rtua;
/*     */ 
/* 210 */       iTemp = (short)(0xFF & readBuffer.get());
/* 211 */       iTemp = (short)(iTemp | (0xFF & readBuffer.get()) << 8);
/* 212 */       this.head.msta = (byte)(0x3F & iTemp);
/* 213 */       this.head.fseq = (byte)((0x1FC0 & iTemp) >> 6);
/* 214 */       this.head.iseq = (byte)((0xE000 & iTemp) >> 13);
/*     */ 
/* 216 */       this.head.flag2 = readBuffer.get();
/*     */ 
/* 218 */       c1 = readBuffer.get();
/* 219 */       this.head.c_func = (byte)(c1 & 0x3F);
/*     */ 
/* 221 */       if (this.head.msta != 0) {
/* 222 */         if (this.head.c_func != 2)
/* 223 */           this.priority = 3;
/*     */         else {
/* 225 */           this.priority = 1;
/*     */         }
/*     */       }
/* 228 */       else if (this.head.c_func == 9)
/* 229 */         this.priority = 2;
/* 230 */       else if (this.head.c_func == 2)
/* 231 */         this.priority = 0;
/*     */       else {
/* 233 */         this.priority = 1;
/*     */       }
/*     */ 
/* 236 */       this.head.c_expflag = (byte)((c1 & 0x40) >> 6);
/* 237 */       this.head.c_dir = (byte)((c1 & 0x80) >> 7);
/*     */ 
/* 239 */       this.head.dlen = (short)(readBuffer.get() & 0xFF);
/*     */       MessageZjHead tmp627_624 = this.head; tmp627_624.dlen = (short)(tmp627_624.dlen | (0xFF & readBuffer.get()) << 8);
/*     */ 
/* 242 */       this.state = 2;
/* 243 */       if (this.head.dlen + 2 > readBuffer.remaining()) {
/* 244 */         if (log.isDebugEnabled())
/* 245 */           log.debug("现有缓冲区内容长度[buflen=" + readBuffer.remaining() + "]<浙江规约数据区长度[" + this.head.dlen + 2 + "]");
/* 246 */         return false;
/*     */       }
/*     */ 
/* 249 */       return readDataSection(readBuffer);
/*     */     }
/* 251 */     if ((this.state == 2) || (this.state == 3)) {
/* 252 */       return readDataSection(readBuffer);
/*     */     }
/*     */ 
/* 256 */     log.error("消息读取状态非法,state=" + this.state);
/*     */ 
/* 258 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean readDataSection(ByteBuffer readBuffer) throws MessageParseException
/*     */   {
/* 263 */     if (this.data == null) {
/* 264 */       this.data = ByteBuffer.allocate(this.head.dlen);
/*     */     }
/* 266 */     if (this.state == 2) {
/* 267 */       while (this.data.hasRemaining()) {
/* 268 */         if (readBuffer.hasRemaining()) {
/* 269 */           this.data.put(readBuffer.get());
/*     */         }
/*     */         else {
/* 272 */           return false;
/*     */         }
/*     */       }
/* 275 */       this.data.flip();
/* 276 */       byte[] d = this.data.array();
/* 277 */       for (int i = 0; i < d.length; ++i)
/*     */       {
/*     */         MessageZj tmp88_87 = this; tmp88_87._cs = (byte)(tmp88_87._cs + d[i]);
/*     */       }
/* 280 */       this.state = 3;
/* 281 */       this.rawPacket.append(HexDump.hexDumpCompact(this.data));
/*     */     }
/* 283 */     if (readBuffer.remaining() >= 2)
/*     */     {
/*     */       String packet;
/* 284 */       this.head.cs = readBuffer.get();
/* 285 */       this.rawPacket.append(HexDump.toHex(this.head.cs));
/* 286 */       this.head.flag3 = readBuffer.get();
/* 287 */       this.rawPacket.append(HexDump.toHex(this.head.flag3));
/* 288 */       if (this._cs != this.head.cs) {
/* 289 */         this.data = null;
/* 290 */         packet = this.rawPacket.toString();
/* 291 */         this.rawPacket.delete(0, packet.length());
/* 292 */         this.state = -1;
/* 293 */         throw new MessageParseException("exp校验码不正确:" + packet);
/*     */       }
/* 295 */       if (22 != this.head.flag3)
/*     */       {
/* 297 */         this.data = null;
/* 298 */         packet = this.rawPacket.toString();
/* 299 */         this.rawPacket.delete(0, packet.length());
/* 300 */         this.state = -1;
/* 301 */         throw new MessageParseException("exp最后不是16标志符，帧格式错误。packet=" + packet);
/*     */       }
/* 303 */       this.state = 15;
/* 304 */       return true;
/*     */     }
/*     */ 
/* 307 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer writeBuffer) {
/* 311 */     synchronized (this.rawPacket) {
/* 312 */       return _write(writeBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean _write(ByteBuffer writeBuffer)
/*     */   {
/* 320 */     int prefixLen = (this.prefix == null) ? 0 : this.prefix.length;
/* 321 */     if ((this.state == -1) && (writeBuffer.remaining() < 13 + prefixLen)) {
/* 322 */       log.info("写缓冲长度不足，等会儿继续写。");
/* 323 */       return false;
/*     */     }
/* 325 */     if ((this.state == -1) || 
/* 326 */       (15 == this.state))
/*     */     {
/* 328 */       if (this.rawPacket.length() > 0) {
/* 329 */         this.rawPacket.delete(0, this.rawPacket.length());
/*     */       }
/* 331 */       if (this.prefix != null) {
/* 332 */         writeBuffer.put(this.prefix);
/* 333 */         this.rawPacket.append(HexDump.hexDumpCompact(this.prefix, 0, this.prefix.length));
/*     */       }
/*     */ 
/* 336 */       int pos0 = writeBuffer.position();
/* 337 */       byte c = 0;
/* 338 */       this._cs = 0;
/* 339 */       writeBuffer.put(104);
/*     */       MessageZj tmp148_147 = this; tmp148_147._cs = (byte)(tmp148_147._cs + 104);
/* 341 */       c = (byte)(this.head.rtua >> 24 & 0xFF);
/*     */       MessageZj tmp177_176 = this; tmp177_176._cs = (byte)(tmp177_176._cs + c);
/* 343 */       writeBuffer.put(c);
/* 344 */       c = (byte)(this.head.rtua >> 16 & 0xFF);
/*     */       MessageZj tmp213_212 = this; tmp213_212._cs = (byte)(tmp213_212._cs + c);
/* 346 */       writeBuffer.put(c);
/*     */ 
/* 348 */       c = (byte)(this.head.rtua & 0xFF);
/*     */       MessageZj tmp246_245 = this; tmp246_245._cs = (byte)(tmp246_245._cs + c);
/* 350 */       writeBuffer.put(c);
/* 351 */       c = (byte)(this.head.rtua >> 8 & 0xFF);
/*     */       MessageZj tmp282_281 = this; tmp282_281._cs = (byte)(tmp282_281._cs + c);
/* 353 */       writeBuffer.put(c);
/*     */ 
/* 355 */       short iTemp = 0;
/* 356 */       iTemp = (short)(iTemp | (short)this.head.msta);
/* 357 */       iTemp = (short)(iTemp | (short)(this.head.fseq << 6));
/* 358 */       iTemp = (short)(iTemp | (short)(this.head.iseq << 13));
/* 359 */       c = (byte)(iTemp & 0xFF);
/*     */       MessageZj tmp361_360 = this; tmp361_360._cs = (byte)(tmp361_360._cs + c);
/* 361 */       writeBuffer.put(c);
/* 362 */       c = (byte)(iTemp >> 8 & 0xFF);
/*     */       MessageZj tmp392_391 = this; tmp392_391._cs = (byte)(tmp392_391._cs + c);
/* 364 */       writeBuffer.put(c);
/*     */       MessageZj tmp411_410 = this; tmp411_410._cs = (byte)(tmp411_410._cs + 104);
/* 367 */       writeBuffer.put(104);
/*     */ 
/* 369 */       c = this.head.c_func;
/* 370 */       c = (byte)(c | 0x40 & this.head.c_expflag << 6);
/* 371 */       c = (byte)(c | 0x80 & this.head.c_dir << 7);
/*     */       MessageZj tmp478_477 = this; tmp478_477._cs = (byte)(tmp478_477._cs + c);
/* 373 */       writeBuffer.put(c);
/*     */ 
/* 375 */       if (this.data == null) {
/* 376 */         this.head.dlen = 0;
/*     */       } else {
/* 378 */         if (this.data.position() > 0)
/* 379 */           this.data.position(0);
/* 380 */         this.head.dlen = (short)this.data.remaining();
/*     */       }
/* 382 */       iTemp = this.head.dlen;
/* 383 */       c = (byte)(iTemp & 0xFF);
/*     */       MessageZj tmp567_566 = this; tmp567_566._cs = (byte)(tmp567_566._cs + c);
/* 385 */       writeBuffer.put(c);
/* 386 */       c = (byte)(iTemp >> 8 & 0xFF);
/*     */       MessageZj tmp598_597 = this; tmp598_597._cs = (byte)(tmp598_597._cs + c);
/* 388 */       writeBuffer.put(c);
/* 389 */       int pos1 = writeBuffer.position();
/* 390 */       byte[] bts = new byte[pos1 - pos0];
/* 391 */       for (int i = 0; i < bts.length; ++i) {
/* 392 */         bts[i] = writeBuffer.get(pos0 + i);
/*     */       }
/* 394 */       this.rawPacket.append(HexDump.hexDumpCompact(bts, 0, bts.length));
/*     */ 
/* 396 */       this.state = 18;
/* 397 */       return _writeDataSection(writeBuffer);
/*     */     }
/* 399 */     if (18 == this.state) {
/* 400 */       return _writeDataSection(writeBuffer);
/*     */     }
/* 402 */     return (47 != this.state);
/*     */   }
/*     */ 
/*     */   private boolean _writeDataSection(ByteBuffer writeBuffer)
/*     */   {
/* 407 */     int bufLen = writeBuffer.remaining();
/* 408 */     if (18 == this.state) {
/* 409 */       if (bufLen < this.head.dlen + 2) {
/* 410 */         log.info("缓冲区太短，不能一次把数据体发送完毕");
/* 411 */         return false;
/*     */       }
/* 413 */       if (this.head.dlen > 0) {
/* 414 */         while (this.data.hasRemaining()) {
/* 415 */           byte c = this.data.get();
/*     */           MessageZj tmp60_59 = this; tmp60_59._cs = (byte)(tmp60_59._cs + c);
/* 417 */           writeBuffer.put(c);
/*     */         }
/* 419 */         this.data.rewind();
/* 420 */         this.rawPacket.append(HexDump.hexDumpCompact(this.data));
/*     */       }
/* 422 */       this.head.cs = this._cs;
/* 423 */       writeBuffer.put(this._cs); this.rawPacket.append(HexDump.toHex(this._cs));
/* 424 */       writeBuffer.put(22); this.rawPacket.append("16");
/*     */ 
/* 426 */       this.state = 47;
/* 427 */       return true;
/*     */     }
/*     */ 
/* 430 */     this.state = 47;
/* 431 */     return true;
/*     */   }
/*     */ 
/*     */   public IChannel getSource() {
/* 435 */     return this.source;
/*     */   }
/*     */ 
/*     */   public void setSource(IChannel src) {
/* 439 */     this.source = src;
/*     */   }
/*     */ 
/*     */   public String getRawPacketString()
/*     */   {
/* 444 */     synchronized (this.rawPacket)
/*     */     {
/*     */       ByteBuffer buf;
/* 445 */       if ((-1 == this.state) || (this.rawPacket.length() == 0))
/*     */       {
/* 447 */         buf = ByteBuffer.allocate(3072);
/* 448 */         int _state = this.state;
/* 449 */         write(buf);
/* 450 */         this.state = _state;
/* 451 */         return this.rawPacket.toString();
/*     */       }
/*     */ 
/* 455 */       if ((47 == this.state) || (15 == this.state))
/* 456 */         return this.rawPacket.toString();
/* 457 */       if ((18 == this.state) || (17 == this.state) || 
/* 458 */         (19 == this.state)) {
/* 459 */         buf = ByteBuffer.allocate(3072);
/* 460 */         String old = this.rawPacket.toString();
/* 461 */         this.rawPacket.delete(0, old.length());
/* 462 */         int _state = this.state;
/* 463 */         write(buf);
/* 464 */         String raw = this.rawPacket.toString();
/* 465 */         this.rawPacket.delete(0, raw.length());
/* 466 */         this.rawPacket.append(old);
/* 467 */         this.state = _state;
/* 468 */         return raw;
/*     */       }
/*     */ 
/* 471 */       return this.rawPacket.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] getRawPacket()
/*     */   {
/*     */     byte[] ret;
/* 482 */     byte[] raw = HexDump.toByteBuffer(getRawPacketString()).array();
/* 483 */     if (this.ioTime > 0L) {
/* 484 */       StringBuffer sb = new StringBuffer(64);
/* 485 */       sb.append("iotime=").append(this.ioTime);
/* 486 */       sb.append("|peeraddr=").append(this.peerAddr).append("|txfs=");
/* 487 */       sb.append(this.txfs).append("|");
/* 488 */       byte[] att = (byte[])null;
/*     */       try {
/* 490 */         att = sb.toString().getBytes("ISO-8859-1");
/*     */       } catch (UnsupportedEncodingException e) {
/* 492 */         att = sb.toString().getBytes();
/*     */       }
/* 494 */       ret = new byte[att.length + raw.length];
/* 495 */       System.arraycopy(att, 0, ret, 0, att.length);
/* 496 */       System.arraycopy(raw, 0, ret, att.length, raw.length);
/*     */     }
/*     */     else {
/* 499 */       ret = raw; }
/* 500 */     return ret;
/*     */   }
/*     */ 
/*     */   public long getIoTime() {
/* 504 */     return this.ioTime;
/*     */   }
/*     */ 
/*     */   public void setIoTime(long ioTime) {
/* 508 */     this.ioTime = ioTime;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/* 512 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public void setPeerAddr(String peerAddr) {
/* 516 */     this.peerAddr = peerAddr;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 523 */     return getRawPacketString();
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/* 527 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority) {
/* 531 */     if (priority > 5)
/* 532 */       priority = 5;
/* 533 */     else if (priority < 0)
/* 534 */       priority = 0;
/* 535 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 539 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 543 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/* 548 */     return (13 + this.head.dlen);
/*     */   }
/*     */ 
/*     */   public void setPrefix(byte[] pre) {
/* 552 */     this.prefix = pre;
/*     */   }
/*     */ 
/*     */   public MessageZj createSendFailReply()
/*     */   {
/* 560 */     return createExtErrorReply(-14);
/*     */   }
/*     */ 
/*     */   private MessageZj createExtErrorReply(byte errcode)
/*     */   {
/* 565 */     MessageZj msg = new MessageZj();
/* 566 */     msg.setIoTime(System.currentTimeMillis());
/* 567 */     msg.setPeerAddr(getPeerAddr());
/* 568 */     msg.setTxfs(getTxfs());
/* 569 */     msg.setSource(getSource());
/*     */ 
/* 571 */     MessageZjHead h = msg.head;
/* 572 */     h.c_dir = 1;
/* 573 */     h.c_expflag = 1;
/* 574 */     h.c_func = this.head.c_func;
/* 575 */     h.dlen = 1;
/* 576 */     h.fseq = this.head.fseq;
/* 577 */     h.iseq = 0;
/* 578 */     h.msta = this.head.msta;
/* 579 */     h.rtua = this.head.rtua;
/* 580 */     h.rtua_a1 = this.head.rtua_a1;
/* 581 */     h.rtua_a2 = this.head.rtua_a2;
/* 582 */     h.rtua_b1b2 = this.head.rtua_b1b2;
/*     */ 
/* 584 */     byte[] bts = new byte[1];
/* 585 */     bts[0] = errcode;
/* 586 */     msg.data = ByteBuffer.wrap(bts);
/* 587 */     return msg;
/*     */   }
/*     */ 
/*     */   public String getStatus()
/*     */   {
/* 651 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 655 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Long getCmdId() {
/* 659 */     return this.cmdId;
/*     */   }
/*     */ 
/*     */   public void setCmdId(Long cmdId) {
/* 663 */     this.cmdId = cmdId;
/*     */   }
/*     */ 
/*     */   public int getMsgCount() {
/* 667 */     return this.msgCount;
/*     */   }
/*     */ 
/*     */   public void setMsgCount(int msgCount) {
/* 671 */     this.msgCount = msgCount;
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 675 */     return this.serverAddress;
/*     */   }
/*     */ 
/*     */   public void setServerAddress(String serverAddress) {
/* 679 */     this.serverAddress = serverAddress;
/*     */   }
/*     */ 
/*     */   public boolean isExceptionPacket() {
/* 683 */     return (this.head.c_expflag != 1);
/*     */   }
/*     */ 
/*     */   public byte getErrorCode() {
/* 687 */     if (isExceptionPacket()) {
/* 688 */       this.data.rewind();
/* 689 */       if (this.data.remaining() > 0)
/* 690 */         return this.data.get(0);
/*     */     }
/* 692 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 696 */     return (this.head.c_func != 36);
/*     */   }
/*     */ 
/*     */   public int getRtua() {
/* 700 */     return this.head.rtua;
/*     */   }
/*     */ 
/*     */   public boolean isTask() {
/* 704 */     return (this.head.c_func != 2);
/*     */   }
/*     */ 
/*     */   public void setTask(boolean isTask)
/*     */   {
/*     */   }
/*     */ }