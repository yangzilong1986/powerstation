/*    */ package com.hzjbbis.fk.message.zj;
/*    */ 
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ 
/*    */ public class MessageZjHead
/*    */ {
/*    */   public byte flag1;
/*    */   public byte rtua_a1;
/*    */   public byte rtua_a2;
/*    */   public short rtua_b1b2;
/*    */   public int rtua;
/*    */   public byte msta;
/*    */   public byte fseq;
/*    */   public byte iseq;
/*    */   public byte flag2;
/*    */   public byte c_dir;
/*    */   public byte c_expflag;
/*    */   public byte c_func;
/*    */   public short dlen;
/*    */   public byte cs;
/*    */   public byte flag3;
/*    */ 
/*    */   public MessageZjHead()
/*    */   {
/* 46 */     this.flag1 = 104;
/* 47 */     this.flag2 = 104;
/* 48 */     this.flag3 = 22;
/* 49 */     this.iseq = 0;
/* 50 */     this.c_dir = 0;
/* 51 */     this.c_expflag = 0;
/* 52 */     this.c_func = 0;
/* 53 */     this.dlen = 0;
/* 54 */     this.cs = 0;
/* 55 */     this.fseq = 0;
/* 56 */     this.msta = 1;
/* 57 */     this.rtua = 0;
/* 58 */     this.rtua_a1 = (this.rtua_a2 = 0);
/* 59 */     this.rtua_b1b2 = 0;
/*    */   }
/*    */ 
/*    */   public void parseRtua() {
/* 63 */     if (this.rtua != 0) {
/* 64 */       return;
/*    */     }
/* 66 */     this.rtua |= (0xFF & this.rtua_a1) << 24;
/* 67 */     this.rtua |= (0xFF & this.rtua_a2) << 16;
/* 68 */     this.rtua |= (0xFF & this.rtua_b1b2) << 8;
/* 69 */     this.rtua |= 0xFF & this.rtua_b1b2 >> 8;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 74 */     StringBuffer sb = new StringBuffer();
/* 75 */     sb.append("[");
/* 76 */     sb.append("[rtua=").append(HexDump.toHex(this.rtua));
/*    */ 
/* 80 */     sb.append(",msta=").append(HexDump.toHex(this.msta));
/* 81 */     sb.append(",fseq=").append(HexDump.toHex(this.fseq));
/* 82 */     sb.append(",iseq=").append(HexDump.toHex(this.iseq));
/*    */ 
/* 84 */     sb.append(",c_dir=").append(HexDump.toHex(this.c_dir));
/* 85 */     sb.append(",c_expflag=").append(HexDump.toHex(this.c_expflag));
/* 86 */     sb.append(",c_func=").append(HexDump.toHex(this.c_func));
/* 87 */     sb.append(",datalen=").append(HexDump.toHex(this.dlen));
/* 88 */     sb.append("]");
/* 89 */     return sb.toString();
/*    */   }
/*    */ }