/*    */ package com.hzjbbis.fk.message.zj;
/*    */ 
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.MessageLoader;
/*    */ import com.hzjbbis.fk.message.MessageType;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MessageLoader4Zj
/*    */   implements MessageLoader
/*    */ {
/* 20 */   private static final Logger log = Logger.getLogger(MessageLoader4Zj.class);
/*    */ 
/*    */   public MessageZj loadMessage(String serializedString) {
/* 23 */     StringTokenizer st = new StringTokenizer(serializedString, "|");
/* 24 */     MessageZj msg = new MessageZj();
/*    */ 
/* 26 */     boolean stop = false;
/*    */     try {
/* 28 */       String token = st.nextToken();
/* 29 */       if (token.equals(MessageZj.class.getName()))
/*    */       {
/* 31 */         token = st.nextToken().substring(12);
/* 32 */         stop = true;
/*    */       }
/* 34 */       if (!(msg.read(HexDump.toByteBuffer(token)))) {
/* 35 */         log.info("从缓存加载的信息，非浙江规约消息：" + serializedString);
/* 36 */         return null;
/*    */       }
/* 38 */       if (stop)
/* 39 */         return msg;
/*    */       do {
/* 41 */         String item = st.nextToken();
/* 42 */         if ("ioti".equalsIgnoreCase(item.substring(0, 4))) {
/* 43 */           token = item.substring(7);
/* 44 */           msg.setIoTime(Long.parseLong(token));
/*    */         }
/* 46 */         else if ("peer".equalsIgnoreCase(item.substring(0, 4))) {
/* 47 */           token = item.substring(9);
/* 48 */           msg.setPeerAddr(token);
/*    */         }
/* 50 */         else if ("txfs".equalsIgnoreCase(item.substring(0, 4))) {
/* 51 */           token = item.substring(5);
/* 52 */           msg.setTxfs(token);
/*    */         }
/*    */       }
/* 40 */       while (st.hasMoreTokens());
/*    */ 
/* 55 */       msg.setPriority(0);
/* 56 */       return msg;
/*    */     } catch (Exception exp) {
/* 58 */       log.warn("缓存加载错误：buf=" + serializedString + ",exp=" + exp.getLocalizedMessage());
/*    */     }
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   public String serializeMessage(IMessage message) {
/* 64 */     if (message.getMessageType() != MessageType.MSG_ZJ)
/* 65 */       return null;
/* 66 */     MessageZj msg = (MessageZj)message;
/* 67 */     StringBuffer sb = new StringBuffer(512);
/* 68 */     sb.append(msg.getRawPacketString()).append("|iotime=");
/* 69 */     sb.append(msg.getIoTime()).append("|peeraddr=").append(msg.getPeerAddr());
/* 70 */     sb.append("|txfs=").append(msg.getTxfs());
/* 71 */     return sb.toString();
/*    */   }
/*    */ }