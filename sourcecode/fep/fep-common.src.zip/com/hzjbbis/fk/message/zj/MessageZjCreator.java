/*    */ package com.hzjbbis.fk.message.zj;
/*    */ 
/*    */ import com.hzjbbis.fk.message.IMessageCreator;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class MessageZjCreator
/*    */   implements IMessageCreator
/*    */ {
/*    */   public MessageZj createHeartBeat(int reqNum)
/*    */   {
/* 14 */     MessageZj msg = new MessageZj();
/* 15 */     msg.head.rtua = reqNum;
/* 16 */     msg.head.c_dir = 0;
/* 17 */     msg.head.c_func = 36;
/* 18 */     msg.head.fseq = 1;
/* 19 */     return msg;
/*    */   }
/*    */ 
/*    */   public MessageZj createUserDefine(int rtua, byte manuCode, byte[] data) {
/* 23 */     MessageZj msg = new MessageZj();
/* 24 */     msg.head.rtua = rtua;
/* 25 */     msg.head.c_dir = 0;
/* 26 */     msg.head.c_func = 15;
/* 27 */     msg.head.msta = manuCode;
/* 28 */     msg.head.fseq = 2;
/* 29 */     byte[] d = new byte[data.length + 1];
/* 30 */     d[0] = manuCode;
/* 31 */     for (int i = 0; i < data.length; ++i) {
/* 32 */       d[(i + 1)] = data[i];
/*    */     }
/* 34 */     msg.data = ByteBuffer.wrap(d);
/* 35 */     return msg;
/*    */   }
/*    */ 
/*    */   public MessageZj create() {
/* 39 */     return new MessageZj();
/*    */   }
/*    */ }