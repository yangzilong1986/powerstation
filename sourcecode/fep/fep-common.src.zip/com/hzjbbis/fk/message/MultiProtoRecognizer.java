/*     */ package com.hzjbbis.fk.message;
/*     */ 
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MultiProtoRecognizer
/*     */   implements IMessageCreator
/*     */ {
/*  13 */   private static final Logger log = Logger.getLogger(MultiProtoRecognizer.class);
/*  14 */   private static final byte[] gateFlag = "JBBS".getBytes();
/*     */ 
/*     */   public static IMessage recognize(ByteBuffer buf)
/*     */   {
/*  23 */     if (buf.remaining() < 13) {
/*  24 */       return null;
/*     */     }
/*  26 */     int flen = gateFlag.length;
/*  27 */     boolean matched = true;
/*  28 */     for (int pos = buf.position(); pos + flen < buf.limit(); ++pos) {
/*  29 */       matched = true;
/*  30 */       for (int i = 0; i < flen; ++i) {
/*  31 */         if (buf.get(pos + i) != gateFlag[i]) {
/*  32 */           matched = false;
/*  33 */           break;
/*     */         }
/*     */       }
/*  36 */       if (matched)
/*     */         break;
/*     */     }
/*  39 */     if (matched) {
/*  40 */       return new MessageGate();
/*     */     }
/*  42 */     int last68 = -1;
/*  43 */     for (int pos = buf.position(); pos + 13 < buf.limit(); ++pos)
/*     */     {
/*  45 */       if (104 != buf.get(pos))
/*     */         continue;
/*  47 */       last68 = pos;
/*     */ 
/*  49 */       if (104 == buf.get(pos + 5))
/*     */       {
/*  51 */         short len1 = buf.getShort(pos + 1);
/*  52 */         short len2 = buf.getShort(pos + 3);
/*  53 */         if (len1 == len2) {
/*  54 */           return new MessageGw();
/*     */         }
/*     */       }
/*  57 */       if (104 == buf.get(pos + 7)) {
/*  58 */         return new MessageZj();
/*     */       }
/*     */     }
/*     */ 
/*  62 */     byte[] dump = (byte[])null;
/*  63 */     if (last68 == -1) {
/*  64 */       dump = new byte[(buf.remaining() > 200) ? 200 : buf.remaining()];
/*  65 */       for (int i = 0; i < dump.length; ++i) {
/*  66 */         dump[i] = buf.get(buf.position() + i);
/*     */       }
/*  68 */       buf.position(0); buf.limit(0);
/*     */     }
/*     */     else
/*     */     {
/*  72 */       int len = buf.limit() - last68;
/*  73 */       if (len == 0)
/*     */       {
/*  75 */         dump = new byte[(buf.remaining() > 200) ? 200 : buf.remaining()];
/*  76 */         for (int i = 0; i < dump.length; ++i) {
/*  77 */           dump[i] = buf.get(buf.position() + i);
/*     */         }
/*  79 */         buf.position(0); buf.limit(0);
/*     */       }
/*     */       else
/*     */       {
/*  83 */         int rem = last68 - buf.position();
/*  84 */         dump = new byte[(rem > 200) ? 200 : rem];
/*  85 */         for (int i = 0; i < dump.length; ++i)
/*  86 */           dump[i] = buf.get(buf.position() + i);
/*  87 */         for (i = 0; i < len; ++i)
/*  88 */           buf.put(i, buf.get(last68 + i));
/*  89 */         buf.position(0);
/*  90 */         buf.limit(len);
/*     */       }
/*     */     }
/*  93 */     if (log.isDebugEnabled()) {
/*  94 */       log.debug("多规约识别器丢弃无效数据：" + HexDump.hexDumpCompact(dump, 0, dump.length));
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   public IMessage create() {
/* 100 */     return null; }
/*     */ 
/*     */   public IMessage createHeartBeat(int reqNum) {
/* 103 */     return null;
/*     */   }
/*     */ }