/*     */ package com.hzjbbis.fk.message.gate;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.exception.MessageParseException;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.MultiProtoRecognizer;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MessageGate
/*     */   implements IMessage
/*     */ {
/*  22 */   private static final Logger log = Logger.getLogger(MessageGate.class);
/*  23 */   private static final byte[] zeroPacket = new byte[0];
/*  24 */   private static final ByteBuffer emptyData = ByteBuffer.wrap(zeroPacket);
/*  25 */   protected MessageType type = MessageType.MSG_GATE;
/*  26 */   private long ioTime = System.currentTimeMillis();
/*     */   private String peerAddr;
/*     */   private String txfs;
/*     */   private String status;
/*     */   private Long cmdId;
/*     */   private IChannel source;
/*  35 */   protected GateHead head = new GateHead();
/*  36 */   protected ByteBuffer data = emptyData;
/*  37 */   private ByteBuffer rawPacket = null;
/*     */ 
/*  39 */   private int state = -1;
/*  40 */   private int priority = 0;
/*     */ 
/*  42 */   private IMessage innerMessage = null;
/*     */   private String serverAddress;
/*     */   public static final short CMD_WRAP = 0;
/*     */   public static final short CMD_GATE_HREQ = 17;
/*     */   public static final short CMD_GATE_HREPLY = 18;
/*     */   public static final short CMD_GATE_PARAMS = 32;
/*     */   public static final short CMD_GATE_REQUEST = 33;
/*     */   public static final short CMD_GATE_REPLY = 34;
/*     */   public static final short CMD_GATE_CONFIRM = 35;
/*     */   public static final short CMD_GATE_SENDFAIL = 36;
/*     */   public static final short REQ_MONITOR_RELAY_PROFILE = 49;
/*     */   public static final short REP_MONITOR_RELAY_PROFILE = 50;
/*     */ 
/*     */   public long getIoTime()
/*     */   {
/*  73 */     return this.ioTime;
/*     */   }
/*     */ 
/*     */   public MessageType getMessageType() {
/*  77 */     return MessageType.MSG_GATE;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/*  81 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/*  85 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public byte[] getRawPacket() {
/*  89 */     if (this.rawPacket != null) {
/*  90 */       return this.rawPacket.array();
/*     */     }
/*  92 */     return zeroPacket;
/*     */   }
/*     */ 
/*     */   public String getRawPacketString() {
/*  96 */     if (this.rawPacket != null) {
/*  97 */       return HexDump.hexDumpCompact(this.rawPacket);
/*     */     }
/*  99 */     return "";
/*     */   }
/*     */ 
/*     */   public IChannel getSource() {
/* 103 */     return this.source;
/*     */   }
/*     */ 
/*     */   public boolean read(ByteBuffer readBuffer) throws MessageParseException {
/* 107 */     synchronized (this) {
/* 108 */       return _read(readBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean _read(ByteBuffer readBuffer)
/*     */     throws MessageParseException
/*     */   {
/*     */     boolean ret;
/* 113 */     if ((this.state == -1) && (readBuffer.remaining() < 13)) {
/* 114 */       if (log.isDebugEnabled())
/* 115 */         log.debug("长度不足读取网关报文头，等会儿继续读取。readBuffer.remaining=" + readBuffer.remaining());
/* 116 */       return false;
/*     */     }
/* 118 */     if ((this.type != MessageType.MSG_GATE) && (this.type != MessageType.MSG_WEB) && (this.type != MessageType.MSG_INVAL))
/*     */     {
/* 120 */       ret = this.innerMessage.read(readBuffer);
/* 121 */       if (ret)
/* 122 */         onReadFinished();
/* 123 */       return ret;
/*     */     }
/*     */ 
/* 126 */     if ((-1 == this.state) || (15 == this.state)) {
/* 127 */       this.innerMessage = MultiProtoRecognizer.recognize(readBuffer);
/* 128 */       if (this.innerMessage == null)
/* 129 */         return false;
/* 130 */       if (!(this.innerMessage instanceof MessageGate)) {
/* 131 */         this.type = this.innerMessage.getMessageType();
/* 132 */         this.head.setCommand(0);
/* 133 */         ret = this.innerMessage.read(readBuffer);
/* 134 */         if (ret)
/*     */         {
/* 136 */           onReadFinished();
/* 137 */           this.rawPacket = HexDump.toByteBuffer(this.innerMessage.getRawPacketString());
/*     */         }
/* 139 */         return ret;
/*     */       }
/*     */ 
/* 142 */       this.innerMessage = null;
/* 143 */       if (readBuffer.remaining() < 13) {
/* 144 */         if (log.isDebugEnabled())
/* 145 */           log.debug("网关对报文进行分析后，长度不足以读取网关报文头。readBuffer.remaining=" + readBuffer.remaining());
/* 146 */         return false;
/*     */       }
/* 148 */       this.state = 1;
/* 149 */       ret = this.head.read(readBuffer);
/* 150 */       if (!(ret))
/* 151 */         return false;
/* 152 */       this.state = 2;
/* 153 */       return readDataSection(readBuffer);
/*     */     }
/* 155 */     if (1 == this.state) {
/* 156 */       ret = this.head.read(readBuffer);
/* 157 */       if (!(ret))
/* 158 */         return false;
/* 159 */       this.state = 2;
/* 160 */       return readDataSection(readBuffer);
/*     */     }
/* 162 */     if (2 == this.state) {
/* 163 */       return readDataSection(readBuffer);
/*     */     }
/* 165 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean readDataSection(ByteBuffer buffer) throws MessageParseException {
/* 169 */     if (this.state == 2) {
/* 170 */       if ((emptyData == this.data) && (this.head.getIntBodylen() > 0)) {
/* 171 */         this.data = ByteBuffer.wrap(new byte[this.head.getIntBodylen()]);
/*     */       }
/* 173 */       if (this.data.remaining() >= buffer.remaining()) {
/* 174 */         this.data.put(buffer);
/*     */       } else {
/* 176 */         buffer.get(this.data.array(), this.data.position(), this.data.remaining());
/* 177 */         this.data.position(this.data.limit());
/*     */       }
/* 179 */       if (this.data.remaining() == 0) {
/* 180 */         this.data.flip();
/* 181 */         this.rawPacket = ByteBuffer.allocate(this.data.remaining() + this.head.getHeadLen());
/* 182 */         this.rawPacket.put(this.head.getRawHead()).put(this.data);
/* 183 */         this.rawPacket.rewind();
/* 184 */         this.data.rewind();
/* 185 */         this.state = 15;
/* 186 */         this.ioTime = System.currentTimeMillis();
/* 187 */         onReadFinished();
/* 188 */         return true;
/*     */       }
/* 190 */       if (log.isDebugEnabled())
/* 191 */         log.debug("readDataSection，长度不足。网关数据区还缺的数据长度=" + this.data.remaining());
/* 192 */       return false;
/*     */     }
/* 194 */     buffer.position(buffer.limit());
/* 195 */     if (log.isInfoEnabled())
/* 196 */       log.info("readDataSection,非法状态，把数据全部清空。");
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   private void onReadFinished()
/*     */     throws MessageParseException
/*     */   {
/*     */     String peer;
/* 204 */     if ((this.type == MessageType.MSG_ZJ) || (this.type == MessageType.MSG_GW))
/*     */     {
/* 206 */       if (this.innerMessage.getIoTime() == 0L)
/* 207 */         this.innerMessage.setIoTime(System.currentTimeMillis());
/* 208 */       peer = this.innerMessage.getPeerAddr();
/* 209 */       if (peer == null)
/* 210 */         this.innerMessage.setPeerAddr("");
/* 211 */       this.innerMessage.setSource(getSource());
/*     */     }
/* 213 */     if (this.type == MessageType.MSG_GATE) {
/* 214 */       if (this.head.getCommand() == 34)
/*     */       {
/* 216 */         this.innerMessage = MultiProtoRecognizer.recognize(this.data);
/* 217 */         if (this.innerMessage == null) {
/* 218 */           log.warn("上行网关报文数据区不能识别:" + HexDump.hexDumpCompact(this.data));
/* 219 */           return;
/*     */         }
/* 221 */         this.innerMessage.read(this.data);
/* 222 */         this.data.rewind();
/* 223 */         if (this.innerMessage.getIoTime() == 0L)
/*     */         {
/* 225 */           this.innerMessage.setIoTime(System.currentTimeMillis());
/* 226 */           peer = this.head.getAttributeAsString(9);
/* 227 */           if (peer.length() == 0)
/* 228 */             this.innerMessage.setPeerAddr(this.source.toString());
/*     */           else
/* 230 */             this.innerMessage.setPeerAddr(peer);
/*     */         }
/* 232 */         String _txfs = this.head.getAttributeAsString(10);
/* 233 */         if (_txfs.length() != 0)
/* 234 */           this.innerMessage.setTxfs(_txfs);
/* 235 */         String serverAddress = this.head.getAttributeAsString(17);
/* 236 */         if (serverAddress.length() > 0) {
/* 237 */           setServerAddress(serverAddress);
/* 238 */           this.innerMessage.setServerAddress(serverAddress);
/*     */         }
/*     */       }
/* 241 */       else if (this.head.getCommand() == 33)
/*     */       {
/* 243 */         this.innerMessage = MultiProtoRecognizer.recognize(this.data);
/* 244 */         if (this.innerMessage == null) {
/* 245 */           log.warn("下行网关报文数据区不能识别:" + HexDump.hexDumpCompact(this.data));
/* 246 */           return;
/*     */         }
/* 248 */         this.innerMessage.read(this.data);
/* 249 */         this.data.rewind();
/*     */       }
/* 251 */       if (this.innerMessage != null)
/* 252 */         this.innerMessage.setSource(getSource());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setIoTime(long time) {
/* 257 */     this.ioTime = time;
/*     */   }
/*     */ 
/*     */   public void setPeerAddr(String peer) {
/* 261 */     this.peerAddr = peer;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority) {
/* 265 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public void setSource(IChannel src) {
/* 269 */     this.source = src;
/* 270 */     if (this.innerMessage != null)
/* 271 */       this.innerMessage.setSource(src);
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer writeBuffer)
/*     */   {
/* 278 */     synchronized (this) {
/* 279 */       return _write(writeBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean _write(ByteBuffer writeBuffer) {
/* 284 */     if (47 == this.state)
/* 285 */       return true;
/* 286 */     if (15 == this.state)
/* 287 */       this.state = -1;
/* 288 */     if (-1 == this.state) {
/* 289 */       if (this.data == null)
/* 290 */         this.head.setIntBodylen(0);
/*     */       else
/* 292 */         this.head.setIntBodylen(this.data.remaining());
/* 293 */       this.state = 17;
/* 294 */       if (!(this.head.write(writeBuffer)))
/* 295 */         return false;
/* 296 */       this.state = 18;
/* 297 */       return _writeDataSection(writeBuffer);
/*     */     }
/* 299 */     if (17 == this.state) {
/* 300 */       if (!(this.head.write(writeBuffer)))
/* 301 */         return false;
/* 302 */       this.state = 18;
/* 303 */       return _writeDataSection(writeBuffer);
/*     */     }
/* 305 */     if (18 == this.state) {
/* 306 */       return _writeDataSection(writeBuffer);
/*     */     }
/* 308 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean _writeDataSection(ByteBuffer buffer) {
/* 312 */     if (buffer.remaining() >= this.data.remaining()) {
/* 313 */       buffer.put(this.data);
/* 314 */       this.data.rewind();
/* 315 */       this.ioTime = System.currentTimeMillis();
/* 316 */       this.rawPacket = ByteBuffer.allocate(this.head.getHeadLen() + this.data.remaining());
/* 317 */       this.rawPacket.put(this.head.getRawHead()).put(this.data);
/* 318 */       this.data.rewind(); this.rawPacket.flip();
/* 319 */       this.state = -1;
/* 320 */       return true;
/*     */     }
/*     */ 
/* 324 */     int limit = this.data.limit();
/* 325 */     this.data.limit(this.data.position() + buffer.remaining());
/* 326 */     buffer.put(this.data);
/* 327 */     this.data.limit(limit);
/* 328 */     return false;
/*     */   }
/*     */ 
/*     */   public String getTxfs()
/*     */   {
/* 333 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 337 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public IMessage getInnerMessage()
/*     */   {
/* 345 */     return this.innerMessage;
/*     */   }
/*     */ 
/*     */   public void setDownInnerMessage(IMessage innerMessage)
/*     */   {
/* 352 */     this.innerMessage = innerMessage;
/* 353 */     this.innerMessage.setSource(getSource());
/* 354 */     this.head.setCommand(33);
/* 355 */     this.data = ByteBuffer.wrap(innerMessage.getRawPacket());
/* 356 */     this.head.setIntBodylen(this.data.remaining());
/* 357 */     String innerMsg = innerMessage.getRawPacketString();
/* 358 */     this.rawPacket = ByteBuffer.allocate(this.head.getHeadLen() + innerMsg.length() / 2);
/* 359 */     this.rawPacket.put(this.head.getRawHead()).put(HexDump.toByteBuffer(innerMsg));
/* 360 */     this.rawPacket.flip();
/*     */   }
/*     */ 
/*     */   public void setUpInnerMessage(IMessage innerMessage)
/*     */   {
/* 367 */     this.innerMessage = innerMessage;
/* 368 */     this.head.setCommand(34);
/*     */ 
/* 370 */     if (innerMessage.getServerAddress() != null) {
/* 371 */       this.head.setAttribute(17, innerMessage.getServerAddress());
/*     */     }
/*     */ 
/* 374 */     this.data = ByteBuffer.wrap(innerMessage.getRawPacket());
/* 375 */     this.head.setIntBodylen(this.data.remaining());
/* 376 */     String innerMsg = innerMessage.getRawPacketString();
/* 377 */     this.rawPacket = ByteBuffer.allocate(this.head.getHeadLen() + innerMsg.length() / 2);
/* 378 */     this.rawPacket.put(this.head.getRawHead()).put(HexDump.toByteBuffer(innerMsg));
/* 379 */     this.rawPacket.flip();
/*     */   }
/*     */ 
/*     */   public GateHead getHead() {
/* 383 */     return this.head;
/*     */   }
/*     */ 
/*     */   public ByteBuffer getData() {
/* 387 */     return this.data;
/*     */   }
/*     */ 
/*     */   public void setData(ByteBuffer data) {
/* 391 */     this.data = data;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 396 */     return getRawPacketString();
/*     */   }
/*     */ 
/*     */   public static MessageGate createHRequest(int numPackets) {
/* 400 */     MessageGate msg = new MessageGate();
/* 401 */     msg.head.setCommand(17);
/* 402 */     msg.data = ByteBuffer.allocate(8);
/* 403 */     msg.data.putInt(numPackets).flip();
/* 404 */     return msg;
/*     */   }
/*     */ 
/*     */   public static MessageGate createHReply() {
/* 408 */     MessageGate msg = new MessageGate();
/* 409 */     msg.head.setCommand(18);
/* 410 */     return msg;
/*     */   }
/*     */ 
/*     */   public static final MessageGate createMoniteProfileRequest() {
/* 414 */     MessageGate msg = new MessageGate();
/* 415 */     msg.head.setCommand(49);
/* 416 */     return msg;
/*     */   }
/*     */ 
/*     */   public static final MessageGate createMoniteProfileReply(String profile) {
/* 420 */     MessageGate msg = new MessageGate();
/* 421 */     msg.head.setCommand(50);
/* 422 */     msg.setPriority(3);
/* 423 */     if ((profile != null) && (profile.length() > 0)) {
/* 424 */       byte[] bts = profile.getBytes();
/* 425 */       msg.data = ByteBuffer.wrap(bts);
/*     */     }
/* 427 */     return msg;
/*     */   }
/*     */ 
/*     */   public static MessageGate createHReply(ByteBuffer carriedMsgs)
/*     */   {
/* 436 */     MessageGate msg = new MessageGate();
/* 437 */     msg.head.setCommand(18);
/* 438 */     msg.data = carriedMsgs;
/* 439 */     return msg;
/*     */   }
/*     */ 
/*     */   public Long getCmdId() {
/* 443 */     return this.cmdId;
/*     */   }
/*     */ 
/*     */   public void setCmdId(Long id) {
/* 447 */     this.cmdId = id;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 451 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String str) {
/* 455 */     this.status = str;
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 459 */     return this.serverAddress;
/*     */   }
/*     */ 
/*     */   public void setServerAddress(String serverAddress) {
/* 463 */     this.serverAddress = serverAddress;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 467 */     return ((this.head.getCommand() != 18) && (this.head.getCommand() != 17));
/*     */   }
/*     */ 
/*     */   public int getRtua() {
/* 471 */     if (this.innerMessage != null)
/* 472 */       return this.innerMessage.getRtua();
/* 473 */     return 0;
/*     */   }
/*     */ 
/*     */   public int length() {
/* 477 */     int len = 0;
/* 478 */     if (getRawPacket().length == 0) {
/* 479 */       if (this.innerMessage != null)
/* 480 */         len = this.innerMessage.length();
/*     */     }
/*     */     else
/* 483 */       len = getRawPacket().length;
/* 484 */     return len;
/*     */   }
/*     */ 
/*     */   public boolean isTask() {
/* 488 */     return false;
/*     */   }
/*     */ 
/*     */   public void setTask(boolean isTask)
/*     */   {
/*     */   }
/*     */ }