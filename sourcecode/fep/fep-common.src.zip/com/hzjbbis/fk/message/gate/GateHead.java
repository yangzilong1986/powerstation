/*     */ package com.hzjbbis.fk.message.gate;
/*     */ 
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class GateHead
/*     */ {
/*     */   private static final Logger log;
/*     */   public static final byte ATT_VERSION = 1;
/*     */   public static final byte ATT_ENCRIPT = 2;
/*     */   public static final byte ATT_DESTID = 3;
/*     */   public static final byte ATT_PRIVATE = 4;
/*     */   public static final byte ATT_CPYATT = 5;
/*     */   public static final byte ATT_LOGTYPE = 6;
/*     */   public static final byte ATT_FILEPATH = 7;
/*     */   public static final byte ATT_SRCADDR = 8;
/*     */   public static final byte ATT_DESTADDR = 9;
/*     */   public static final byte ATT_TXFS = 10;
/*     */   public static final byte ATT_TXSJ = 11;
/*     */   public static final byte ATT_MSGTYPE = 12;
/*     */   public static final byte ATT_MSGSEQ = 16;
/*     */   public static final byte ATT_SERVERADDR = 17;
/*  27 */   private final String flag = "JBBS";
/*  28 */   private byte src = 2;
/*     */   private short cmd;
/*     */   private int intBodyLen;
/*     */   private short headAttrLen;
/*  32 */   private HashMap<Byte, HeadAttribute> hmAttr = new HashMap();
/*  33 */   private byte[] rawHead = null;
/*     */ 
/*     */   static
/*     */   {
/*  11 */     log = Logger.getLogger(GateHead.class);
/*     */   }
/*     */ 
/*     */   public GateHead()
/*     */   {
/*  36 */     this.cmd = 0;
/*  37 */     this.intBodyLen = 0;
/*  38 */     this.headAttrLen = 0;
/*     */   }
/*     */ 
/*     */   public boolean isValid() {
/*  42 */     return (this.cmd == 0);
/*     */   }
/*     */ 
/*     */   public boolean read(ByteBuffer buffer)
/*     */   {
/*  51 */     if (buffer.remaining() < 13) {
/*  52 */       return false;
/*     */     }
/*  54 */     buffer.mark();
/*  55 */     int posOld = buffer.position();
/*  56 */     int index = 0;
/*     */ 
/*  58 */     for (index = 0; index < 4; ++index)
/*  59 */       buffer.get();
/*  60 */     this.src = buffer.get();
/*  61 */     this.cmd = buffer.getShort();
/*  62 */     this.intBodyLen = buffer.getInt();
/*  63 */     this.headAttrLen = buffer.getShort();
/*  64 */     if ((this.headAttrLen < 0) || (this.headAttrLen > 4096) || (this.intBodyLen < 0)) {
/*  65 */       log.warn("报文格式错误。headAttrLen=" + this.headAttrLen + ",intBodyLen=" + this.intBodyLen);
/*  66 */       buffer.position(buffer.limit());
/*  67 */       return false;
/*     */     }
/*     */ 
/*  70 */     if (this.headAttrLen > buffer.remaining()) {
/*  71 */       log.info("缓冲区长度不足以读取网关报文头。");
/*  72 */       buffer.reset();
/*  73 */       return false;
/*     */     }
/*  75 */     index = 0;
/*  76 */     while (index < this.headAttrLen) {
/*  77 */       byte id = buffer.get();
/*  78 */       short attlen = buffer.getShort();
/*  79 */       setAttribute(id, buffer, attlen);
/*  80 */       index += attlen + 3;
/*     */     }
/*  82 */     int headLen = 13 + index;
/*  83 */     this.rawHead = new byte[headLen];
/*  84 */     buffer.position(posOld);
/*  85 */     buffer.get(this.rawHead);
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   public int getHeadLen() {
/*  90 */     if (this.headAttrLen == 0)
/*  91 */       this.headAttrLen = getHeadAttrLen();
/*  92 */     return (13 + this.headAttrLen);
/*     */   }
/*     */ 
/*     */   public int getTotalLen() {
/*  96 */     return (getHeadLen() + this.intBodyLen);
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer buffer)
/*     */   {
/* 105 */     short attrLen = getHeadAttrLen();
/* 106 */     if (buffer.remaining() < 13 + attrLen)
/* 107 */       return false;
/* 108 */     int posOld = buffer.position();
/* 109 */     buffer.put("JBBS".getBytes());
/* 110 */     buffer.put(this.src);
/* 111 */     buffer.putShort(this.cmd);
/* 112 */     buffer.putInt(this.intBodyLen);
/* 113 */     buffer.putShort(attrLen);
/* 114 */     for (HeadAttribute attr : this.hmAttr.values()) {
/* 115 */       buffer.put(attr.id).putShort(attr.len).put(attr.attr);
/*     */     }
/* 117 */     this.rawHead = new byte[getHeadLen()];
/* 118 */     buffer.position(posOld);
/* 119 */     int limitOld = buffer.limit();
/* 120 */     buffer.limit(posOld + this.rawHead.length);
/* 121 */     buffer.get(this.rawHead, 0, this.rawHead.length);
/* 122 */     buffer.limit(limitOld);
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   public void setCommand(short command) {
/* 127 */     this.cmd = command;
/*     */   }
/*     */ 
/*     */   public void setCommand(int command) {
/* 131 */     this.cmd = (short)command;
/*     */   }
/*     */ 
/*     */   public short getCommand() {
/* 135 */     return this.cmd;
/*     */   }
/*     */ 
/*     */   public int getIntBodylen() {
/* 139 */     return this.intBodyLen;
/*     */   }
/*     */ 
/*     */   public void setIntBodylen(int bodylen) {
/* 143 */     this.intBodyLen = bodylen;
/*     */   }
/*     */ 
/*     */   public short getHeadAttrLen() {
/* 147 */     short hlen = 0;
/* 148 */     for (HeadAttribute attr : this.hmAttr.values()) {
/* 149 */       hlen = (short)(hlen + attr.len + 3);
/*     */     }
/* 151 */     return hlen;
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, ByteBuffer buf, short len) {
/* 155 */     if ((!($assertionsDisabled)) && (buf.remaining() < len)) throw new AssertionError();
/*     */ 
/* 157 */     HeadAttribute attr = new HeadAttribute();
/* 158 */     attr.id = id;
/* 159 */     attr.len = len;
/* 160 */     attr.attr = new byte[len];
/* 161 */     for (int i = 0; i < len; ++i)
/* 162 */       attr.attr[i] = buf.get();
/* 163 */     this.hmAttr.put(Byte.valueOf(id), attr);
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, byte[] attr, int pos, int len) {
/* 167 */     if ((!($assertionsDisabled)) && (attr == null)) throw new AssertionError();
/* 168 */     if ((!($assertionsDisabled)) && (((len >= 1024) || (len <= 0) || (pos + len >= attr.length)))) throw new AssertionError();
/*     */ 
/* 170 */     HeadAttribute attrObj = new HeadAttribute();
/* 171 */     attrObj.id = id;
/* 172 */     attrObj.len = (short)len;
/* 173 */     attrObj.attr = new byte[len];
/* 174 */     System.arraycopy(attr, pos, attrObj.attr, 0, len);
/* 175 */     this.hmAttr.put(new Byte(id), attrObj);
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, byte[] attr) {
/* 179 */     if ((!($assertionsDisabled)) && (attr == null)) throw new AssertionError();
/* 180 */     setAttribute(id, attr, 0, attr.length);
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, int data) {
/* 184 */     byte[] val = new byte[4];
/* 185 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 186 */     bf.putInt(data);
/* 187 */     bf.flip();
/* 188 */     setAttribute(id, bf.array());
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, long data) {
/* 192 */     byte[] val = new byte[8];
/* 193 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 194 */     bf.putLong(data);
/* 195 */     bf.flip();
/* 196 */     setAttribute(id, bf.array());
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, short data) {
/* 200 */     byte[] val = new byte[2];
/* 201 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 202 */     bf.putShort(data);
/* 203 */     bf.flip();
/* 204 */     setAttribute(id, bf.array());
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, byte data) {
/* 208 */     byte[] val = new byte[1];
/* 209 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 210 */     bf.put(data);
/* 211 */     bf.flip();
/* 212 */     setAttribute(id, bf.array());
/*     */   }
/*     */ 
/*     */   public void setAttribute(byte id, String data) {
/* 216 */     byte[] val = data.getBytes();
/* 217 */     setAttribute(id, val);
/*     */   }
/*     */ 
/*     */   public byte[] getAttribute(byte id) {
/* 221 */     HeadAttribute attr = (HeadAttribute)this.hmAttr.get(new Byte(id));
/* 222 */     if (attr == null)
/* 223 */       return null;
/* 224 */     return attr.attr;
/*     */   }
/*     */ 
/*     */   public int getAttributeAsInt(byte id) {
/* 228 */     byte[] val = getAttribute(id);
/* 229 */     if ((val == null) || (val.length != 4))
/* 230 */       return 0;
/* 231 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 232 */     return bf.getInt();
/*     */   }
/*     */ 
/*     */   public long getAttributeAsLong(byte id) {
/* 236 */     byte[] val = getAttribute(id);
/* 237 */     if ((val == null) || (val.length != 8))
/* 238 */       return 0L;
/* 239 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 240 */     return bf.getLong();
/*     */   }
/*     */ 
/*     */   public short getAttributeAsShort(byte id) {
/* 244 */     byte[] val = getAttribute(id);
/* 245 */     if ((val == null) || (val.length != 2))
/* 246 */       return 0;
/* 247 */     ByteBuffer bf = ByteBuffer.wrap(val);
/* 248 */     return bf.getShort();
/*     */   }
/*     */ 
/*     */   public String getAttributeAsString(byte id) {
/* 252 */     byte[] val = getAttribute(id);
/* 253 */     if (val == null)
/* 254 */       return "";
/*     */     try {
/* 256 */       return new String(val); } catch (Exception exp) {
/*     */     }
/* 258 */     return HexDump.hexDumpCompact(val, 0, val.length);
/*     */   }
/*     */ 
/*     */   public byte getAttributeAsByte(byte id)
/*     */   {
/* 263 */     byte[] val = getAttribute(id);
/* 264 */     if (val == null)
/* 265 */       return 0;
/* 266 */     return val[0];
/*     */   }
/*     */ 
/*     */   public byte[] getRawHead() {
/* 270 */     if (this.rawHead == null) {
/* 271 */       this.rawHead = new byte[13];
/* 272 */       ByteBuffer headBuffer = ByteBuffer.wrap(this.rawHead);
/* 273 */       write(headBuffer);
/*     */     }
/* 275 */     return this.rawHead;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 279 */     StringBuffer sb = new StringBuffer();
/* 280 */     sb.append("|source=").append(HexDump.toHex(this.src));
/* 281 */     sb.append(",cmd=").append(HexDump.toHex(this.cmd));
/* 282 */     sb.append(",bodylen=").append(getIntBodylen());
/* 283 */     sb.append(",attrlen=").append(getHeadAttrLen());
/* 284 */     if (this.hmAttr.size() > 0) {
/* 285 */       sb.append(",attributes:");
/* 286 */       for (HeadAttribute attr : this.hmAttr.values()) {
/* 287 */         sb.append(attr);
/*     */       }
/*     */     }
/* 290 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   class HeadAttribute {
/*     */     public byte id;
/*     */     public short len;
/*     */     public byte[] attr;
/*     */ 
/*     */     public String toString() {
/* 299 */       StringBuffer sb = new StringBuffer();
/* 300 */       sb.append(";att.id=").append(HexDump.toHex(this.id));
/* 301 */       sb.append(",att.len=").append(this.len);
/* 302 */       String str = "";
/*     */       try {
/* 304 */         str = new String(this.attr);
/*     */       } catch (Exception exp) {
/* 306 */         str = HexDump.hexDumpCompact(this.attr, 0, this.attr.length);
/*     */       }
/* 308 */       sb.append(",att.str=").append(str);
/* 309 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }