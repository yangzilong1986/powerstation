/*    */ package com.hzjbbis.fk.message.gw;
/*    */ 
/*    */ public class MessageGwHead
/*    */ {
/*  4 */   public byte flag1 = 104;
/*  5 */   public byte flag2 = 104;
/*  6 */   public short dlen = 0;
/*  7 */   public byte proto_flag = 2;
/*  8 */   public int rtua = 0;
/*  9 */   public byte a3_d0 = 0;
/* 10 */   public byte a3_msa = 1;
/* 11 */   public byte c_dir = 0;
/* 12 */   public byte c_prm = 1;
/* 13 */   public byte c_acd = 0;
/* 14 */   public byte c_fcv = 0;
/* 15 */   protected byte c_func = 0;
/*    */ 
/* 17 */   protected byte app_func = 0;
/* 18 */   public byte seq_tpv = 0;
/* 19 */   public byte seq_fir = 1;
/* 20 */   public byte seq_fin = 1;
/* 21 */   protected byte seq_con = 0;
/* 22 */   protected byte seq_pseq = 0;
/*    */ 
/*    */   public void decodeL(short L)
/*    */   {
/* 26 */     this.proto_flag = (byte)(L & 0x3);
/* 27 */     this.dlen = (short)(L >>> 2);
/*    */   }
/*    */ 
/*    */   public short encodeL() {
/* 31 */     int len = (this.dlen & 0xFFFF) << 2 | this.proto_flag;
/* 32 */     len = len << 8 & 0xFF00 | len >>> 8 & 0xFF;
/* 33 */     return (short)len;
/*    */   }
/*    */ 
/*    */   public void decodeC(byte C)
/*    */   {
/* 39 */     this.c_dir = (byte)((0x80 & C) >>> 7);
/* 40 */     this.c_prm = (byte)((0x40 & C) >>> 6);
/* 41 */     this.c_acd = (byte)((0x20 & C) >>> 5);
/* 42 */     this.c_fcv = (byte)((0x10 & C) >>> 4);
/* 43 */     this.c_func = (byte)(0xF & C);
/*    */   }
/*    */ 
/*    */   public byte encodeC() {
/* 47 */     int c = this.c_dir << 7;
/* 48 */     c |= this.c_prm << 6;
/* 49 */     c |= this.c_acd << 5;
/* 50 */     c |= this.c_fcv << 4;
/* 51 */     c |= this.c_func;
/* 52 */     return (byte)c;
/*    */   }
/*    */ 
/*    */   public void decodeA3(byte A3) {
/* 56 */     this.a3_d0 = (byte)(0x1 & A3);
/* 57 */     this.a3_msa = (byte)(A3 >>> 1);
/*    */   }
/*    */ 
/*    */   public byte encodeA3() {
/* 61 */     return (byte)(this.a3_msa << 1 | this.a3_d0);
/*    */   }
/*    */ 
/*    */   public void decodeSEQ(byte SEQ) {
/* 65 */     this.seq_tpv = (byte)((0x80 & SEQ) >>> 7);
/* 66 */     this.seq_fir = (byte)((0x40 & SEQ) >>> 6);
/* 67 */     this.seq_fin = (byte)((0x20 & SEQ) >>> 5);
/* 68 */     this.seq_con = (byte)((0x10 & SEQ) >>> 4);
/* 69 */     this.seq_pseq = (byte)(0xF & SEQ);
/*    */   }
/*    */ 
/*    */   public byte encodeSEQ() {
/* 73 */     int c = this.seq_tpv << 7;
/* 74 */     c |= this.seq_fir << 6;
/* 75 */     c |= this.seq_fin << 5;
/* 76 */     c |= this.seq_con << 4;
/* 77 */     c |= this.seq_pseq;
/* 78 */     return (byte)c;
/*    */   }
/*    */ }