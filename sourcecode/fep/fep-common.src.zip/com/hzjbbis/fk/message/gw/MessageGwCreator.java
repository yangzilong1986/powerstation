/*    */ package com.hzjbbis.fk.message.gw;
/*    */ 
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.IMessageCreator;
/*    */ 
/*    */ public class MessageGwCreator
/*    */   implements IMessageCreator
/*    */ {
/*    */   public IMessage create()
/*    */   {
/* 10 */     return new MessageGw();
/*    */   }
/*    */ 
/*    */   public IMessage createHeartBeat(int reqNum) {
/* 14 */     MessageGw heart = new MessageGw();
/* 15 */     heart.head.app_func = 2;
/* 16 */     heart.head.c_func = 9;
/* 17 */     heart.head.rtua = reqNum;
/* 18 */     return heart;
/*    */   }
/*    */ }