/*    */ package com.hzjbbis.fk.message;
/*    */ 
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MultiProtoMessageLoader
/*    */   implements MessageLoader
/*    */ {
/* 16 */   private static final Logger log = Logger.getLogger(MultiProtoMessageLoader.class);
/*    */ 
/*    */   public IMessage loadMessage(String serializedString) {
/* 19 */     StringTokenizer st = new StringTokenizer(serializedString, "|");
/* 20 */     IMessage msg = null;
/*    */     try
/*    */     {
/* 23 */       String token = st.nextToken();
/* 24 */       ByteBuffer buf = HexDump.toByteBuffer(token);
/* 25 */       msg = MultiProtoRecognizer.recognize(buf);
/* 26 */       if ((msg == null) || (!(msg.read(buf)))) {
/* 27 */         log.info("从缓存加载的信息，非终端规约消息：" + serializedString);
/* 28 */         return null;
/*    */       }
/*    */       do {
/* 31 */         String item = st.nextToken();
/* 32 */         if ("ioti".equalsIgnoreCase(item.substring(0, 4))) {
/* 33 */           token = item.substring(7);
/* 34 */           msg.setIoTime(Long.parseLong(token));
/*    */         }
/* 36 */         else if ("peer".equalsIgnoreCase(item.substring(0, 4))) {
/* 37 */           token = item.substring(9);
/* 38 */           msg.setPeerAddr(token);
/*    */         }
/* 40 */         else if ("txfs".equalsIgnoreCase(item.substring(0, 4))) {
/* 41 */           token = item.substring(5);
/* 42 */           msg.setTxfs(token);
/*    */         }
/*    */       }
/* 30 */       while (st.hasMoreTokens());
/*    */ 
/* 45 */       msg.setPriority(0);
/* 46 */       return msg;
/*    */     } catch (Exception exp) {
/* 48 */       log.warn("缓存加载错误：buf=" + serializedString + ",exp=" + exp.getLocalizedMessage());
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   public String serializeMessage(IMessage message) {
/* 54 */     StringBuffer sb = new StringBuffer(512);
/* 55 */     sb.append(message.getRawPacketString()).append("|iotime=");
/* 56 */     sb.append(message.getIoTime()).append("|peeraddr=").append(message.getPeerAddr());
/* 57 */     sb.append("|txfs=").append(message.getTxfs());
/* 58 */     return sb.toString();
/*    */   }
/*    */ }