/*     */ package com.hzjbbis.fk.tracelog;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TraceLog
/*     */ {
/*  23 */   private static final Map<String, TraceLog> logMap = new HashMap();
/*     */   private static final String PROP_MAX_FILE_SIZE = "traceLog.maxFileSize";
/*     */   private static final String PROP_FILE_COUNT = "traceLog.fileCount";
/*     */   private static final String PROP_TRACE_ENABLED = "traceLog.enabled";
/*  27 */   private static int MAX_FILE_SIZE = 50;
/*  28 */   private static int FILE_COUNT = 1;
/*  29 */   private static boolean TRACE_ENABLED = false;
/*     */   private static String rootPath;
/*  31 */   private static String defaultKey = "trace";
/*     */ 
/*  33 */   private static PropFileMonitor monitor = null;
/*     */   private static String propFilePath;
/*  35 */   private static Properties g_props = null;
/*  36 */   private static long propFileLastModified = 0L;
/*  37 */   private static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  38 */   private boolean enabled = false;
/*  39 */   private String key = defaultKey;
/*     */   private String filePath;
/*     */   private PrintStream out;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  46 */       File f = new File("traceLog.properties");
/*  47 */       if (!(f.exists()))
/*  48 */         f = new File("bin" + File.separatorChar + "traceLog.properties");
/*  49 */       if (!(f.exists()))
/*  50 */         f = new File("config" + File.separatorChar + "traceLog.properties");
/*  51 */       if (f.exists()) {
/*  52 */         propFilePath = f.getCanonicalPath();
/*  53 */         propFileLastModified = f.lastModified();
/*  54 */         g_props = new Properties();
/*  55 */         g_props.load(new FileInputStream(f));
/*  56 */         String strMaxFileSize = g_props.getProperty("traceLog.maxFileSize");
/*  57 */         if (strMaxFileSize == null)
/*  58 */           strMaxFileSize = System.getProperty("traceLog.maxFileSize");
/*  59 */         if (strMaxFileSize != null)
/*  60 */           strMaxFileSize = strMaxFileSize.trim();
/*  61 */         if ((strMaxFileSize != null) && (strMaxFileSize.length() > 0)) {
/*  62 */           if (strMaxFileSize.substring(strMaxFileSize.length() - 1).toUpperCase().equals("M"))
/*  63 */             strMaxFileSize = strMaxFileSize.substring(0, strMaxFileSize.length() - 1);
/*  64 */           MAX_FILE_SIZE = Integer.parseInt(strMaxFileSize);
/*  65 */           if ((MAX_FILE_SIZE <= 0) || (MAX_FILE_SIZE > 50000))
/*  66 */             MAX_FILE_SIZE = 50;
/*     */         }
/*  68 */         String strFileCount = g_props.getProperty("traceLog.fileCount");
/*  69 */         if (strFileCount == null)
/*  70 */           strFileCount = System.getProperty("traceLog.fileCount");
/*  71 */         if (strFileCount != null)
/*  72 */           strFileCount = strFileCount.trim();
/*  73 */         if ((strFileCount != null) && (strFileCount.length() > 0)) {
/*  74 */           FILE_COUNT = Integer.parseInt(strFileCount);
/*  75 */           if ((FILE_COUNT <= 0) && (FILE_COUNT > 1000))
/*  76 */             FILE_COUNT = 1;
/*     */         }
/*  78 */         String strEnabled = g_props.getProperty("traceLog.enabled");
/*  79 */         if (strEnabled == null)
/*  80 */           strEnabled = System.getProperty("traceLog.enabled");
/*  81 */         if ((strEnabled != null) && (strEnabled.length() > 0)) {
/*     */           try {
/*  83 */             TRACE_ENABLED = Boolean.parseBoolean(strEnabled);
/*     */           } catch (Exception e1) {
/*     */             try {
/*  86 */               int iEnabled = Integer.parseInt(strEnabled);
/*  87 */               if (iEnabled != 0) {
/*  88 */                 TRACE_ENABLED = true; break label415:
/*     */               }
/*  90 */               TRACE_ENABLED = false;
/*     */             }
/*     */             catch (Exception localException1)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*  97 */         label415: monitor = new PropFileMonitor();
/*  98 */         monitor.start();
/*     */       }
/*     */     }
/*     */     catch (Exception localException2)
/*     */     {
/*     */     }
/*     */     try {
/* 105 */       File file = new File("trace");
/* 106 */       file.mkdirs();
/* 107 */       rootPath = file.getAbsolutePath() + File.separatorChar;
/*     */     } catch (Exception localException3) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static TraceLog getTracer() {
/* 113 */     return getTracer(defaultKey);
/*     */   }
/*     */ 
/*     */   public static TraceLog getTracer(String myKey) {
/* 117 */     if (myKey == null)
/* 118 */       myKey = defaultKey;
/* 119 */     TraceLog log = (TraceLog)logMap.get(myKey);
/* 120 */     if (log == null) {
/* 121 */       log = new TraceLog(myKey);
/* 122 */       logMap.put(log.key, log);
/* 123 */       if (g_props != null) {
/* 124 */         String suffix = ".traceLog.enabled";
/* 125 */         String propKey = null;
/* 126 */         Iterator iter2 = g_props.keySet().iterator();
/* 127 */         while (iter2.hasNext()) {
/* 128 */           String pkey = (String)iter2.next();
/* 129 */           int kindex = pkey.indexOf(suffix);
/* 130 */           if (kindex > 0) {
/* 131 */             String prefix = pkey.substring(0, kindex);
/* 132 */             if ((prefix.equals(log.key)) || (log.key.indexOf(prefix) == 0)) {
/* 133 */               propKey = pkey;
/* 134 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 138 */         if (propKey != null) {
/* 139 */           String strEnabled = g_props.getProperty(propKey);
/* 140 */           if ((strEnabled != null) && (strEnabled.length() > 0))
/*     */             try {
/* 142 */               log.enabled = Boolean.parseBoolean(strEnabled);
/*     */             } catch (Exception localException) {
/*     */             }
/*     */         }
/*     */         else {
/* 147 */           log.enabled = TRACE_ENABLED; }
/*     */       }
/*     */     }
/* 150 */     return log;
/*     */   }
/*     */ 
/*     */   public static TraceLog getTracer(Class<? extends Object> clz) {
/* 154 */     return getTracer(clz.getCanonicalName());
/*     */   }
/*     */ 
/*     */   private TraceLog(String fName) {
/* 158 */     this.key = fName;
/*     */   }
/*     */ 
/*     */   private synchronized void createPrintStream() {
/* 162 */     this.filePath = makeFilePath();
/*     */     try {
/* 164 */       this.out = new PrintStream(new BufferedOutputStream(new FileOutputStream(this.filePath, true)));
/*     */     } catch (Exception e) {
/* 166 */       e.printStackTrace(System.err);
/* 167 */       System.err.println();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String makeFilePath() {
/* 172 */     String name = this.key;
/* 173 */     int index = name.lastIndexOf(File.separatorChar);
/* 174 */     if (index >= 0)
/* 175 */       name = name.substring(index + 1);
/* 176 */     index = name.lastIndexOf(".");
/* 177 */     if (index >= 0) {
/* 178 */       name = name.substring(index + 1);
/*     */     }
/*     */ 
/* 181 */     String fpathMark = null;
/* 182 */     long lastModified = 0L;
/*     */ 
/* 184 */     for (int i = 1; i <= FILE_COUNT; ++i) {
/* 185 */       String fpath = rootPath + name + "-" + i + ".log";
/* 186 */       f = new File(fpath);
/* 187 */       int flen = (int)(f.length() >>> 20);
/* 188 */       if (flen < MAX_FILE_SIZE) {
/* 189 */         return fpath;
/*     */       }
/* 191 */       if ((0L == lastModified) || (f.lastModified() - lastModified < 0L)) {
/* 192 */         lastModified = f.lastModified();
/* 193 */         fpathMark = fpath;
/*     */       }
/*     */     }
/* 196 */     File f = new File(fpathMark);
/* 197 */     f.delete();
/* 198 */     return fpathMark;
/*     */   }
/*     */ 
/*     */   public void trace(String info) {
/* 202 */     if (this.enabled)
/* 203 */       write2File(info);
/*     */   }
/*     */ 
/*     */   public void trace(String info, Exception e) {
/* 207 */     if (!(this.enabled))
/* 208 */       return;
/* 209 */     synchronized (this) {
/* 210 */       write2File(info);
/* 211 */       if ((this.out != null) && (e != null)) {
/* 212 */         e.printStackTrace(this.out);
/* 213 */         this.out.println();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void trace(Object obj) {
/* 219 */     if (!(this.enabled))
/* 220 */       return;
/* 221 */     write2File(obj.toString());
/*     */   }
/*     */ 
/*     */   private void checkOutput() {
/* 225 */     if (this.out == null)
/* 226 */       createPrintStream();
/* 227 */     File f = new File(this.filePath);
/* 228 */     if ((int)(f.length() >>> 20) >= MAX_FILE_SIZE)
/* 229 */       createPrintStream();
/*     */   }
/*     */ 
/*     */   private synchronized void write2File(String info) {
/* 233 */     checkOutput();
/* 234 */     if (this.out == null)
/* 235 */       return;
/* 236 */     StringBuilder sb = new StringBuilder(512);
/* 237 */     Calendar ca = Calendar.getInstance();
/*     */ 
/* 265 */     sb.append(df.format(Long.valueOf(ca.getTime().getTime()))).append(" ");
/*     */ 
/* 268 */     Thread t = Thread.currentThread();
/* 269 */     sb.append("[").append(t.getName()).append("] ");
/* 270 */     StackTraceElement[] ste = t.getStackTrace();
/*     */ 
/* 273 */     if ((ste != null) && (ste.length > 4)) {
/* 274 */       sb.append(ste[3].getFileName()).append(":").append(ste[3].getLineNumber());
/*     */     }
/* 276 */     sb.append(" - ").append(info);
/* 277 */     this.out.println(sb.toString());
/* 278 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public final boolean isEnabled()
/*     */   {
/* 376 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   static class PropFileMonitor extends Thread
/*     */   {
/*     */     public PropFileMonitor()
/*     */     {
/* 283 */       super("TraceLogCfgMonitor");
/* 284 */       setDaemon(true);
/* 285 */       start(); }
/*     */ 
/*     */     public void run() {
/*     */       try {
/*     */         File f;
/*     */         do {
/* 291 */           Thread.sleep(2000L);
/* 292 */           f = new File(TraceLog.propFilePath); }
/* 293 */         while (f.lastModified() - TraceLog.propFileLastModified <= 0L);
/* 294 */         TraceLog.propFileLastModified = f.lastModified();
/* 295 */         Properties props = new Properties();
/* 296 */         props.load(new FileInputStream(f));
/* 297 */         String strMaxFileSize = props.getProperty("traceLog.maxFileSize");
/* 298 */         if (strMaxFileSize != null)
/* 299 */           strMaxFileSize = strMaxFileSize.trim();
/* 300 */         if ((strMaxFileSize != null) && (strMaxFileSize.length() > 0)) {
/* 301 */           if (strMaxFileSize.substring(strMaxFileSize.length() - 1).toUpperCase().equals("M"))
/* 302 */             strMaxFileSize = strMaxFileSize.substring(0, strMaxFileSize.length() - 1);
/* 303 */           TraceLog.MAX_FILE_SIZE = Integer.parseInt(strMaxFileSize);
/* 304 */           if ((TraceLog.MAX_FILE_SIZE <= 0) || (TraceLog.MAX_FILE_SIZE > 50000))
/* 305 */             TraceLog.MAX_FILE_SIZE = 50;
/*     */         }
/* 307 */         String strFileCount = props.getProperty("traceLog.fileCount");
/* 308 */         if (strFileCount != null)
/* 309 */           strFileCount = strFileCount.trim();
/* 310 */         if ((strFileCount != null) && (strFileCount.length() > 0)) {
/* 311 */           TraceLog.FILE_COUNT = Integer.parseInt(strFileCount);
/* 312 */           if ((TraceLog.FILE_COUNT <= 0) && (TraceLog.FILE_COUNT > 1000))
/* 313 */             TraceLog.FILE_COUNT = 1;
/*     */         }
/* 315 */         String strEnabled = props.getProperty("traceLog.enabled");
/* 316 */         if ((strEnabled != null) && (strEnabled.length() > 0))
/*     */           try {
/* 318 */             TraceLog.TRACE_ENABLED = Boolean.parseBoolean(strEnabled);
/*     */           } catch (Exception e1) {
/*     */             try {
/* 321 */               int iEnabled = Integer.parseInt(strEnabled);
/* 322 */               if (iEnabled != 0) {
/* 323 */                 TraceLog.TRACE_ENABLED = true; break label265:
/*     */               }
/* 325 */               TraceLog.TRACE_ENABLED = false;
/*     */             }
/*     */             catch (Exception localException1)
/*     */             {
/*     */             }
/*     */           }
/* 331 */         label265: Iterator iter = TraceLog.logMap.entrySet().iterator();
/* 332 */         String suffix = ".traceLog.enabled";
/* 333 */         while (iter.hasNext()) {
/* 334 */           Map.Entry entry = (Map.Entry)iter.next();
/*     */ 
/* 336 */           String propKey = null;
/* 337 */           Iterator iter2 = props.keySet().iterator();
/* 338 */           while (iter2.hasNext()) {
/* 339 */             String pkey = (String)iter2.next();
/* 340 */             int kindex = pkey.indexOf(suffix);
/* 341 */             if (kindex > 0) {
/* 342 */               String prefix = pkey.substring(0, kindex);
/* 343 */               if ((prefix.equals(((TraceLog)entry.getValue()).key)) || (((TraceLog)entry.getValue()).key.indexOf(prefix) == 0)) {
/* 344 */                 propKey = pkey;
/* 345 */                 break;
/*     */               }
/*     */             }
/*     */           }
/* 349 */           if (propKey != null) {
/* 350 */             strEnabled = props.getProperty(propKey);
/* 351 */             if ((strEnabled != null) && (strEnabled.length() > 0))
/*     */               try {
/* 353 */                 ((TraceLog)entry.getValue()).enabled = Boolean.parseBoolean(strEnabled);
/*     */               } catch (Exception localException2) {
/*     */               }
/*     */           }
/*     */           else {
/* 358 */             ((TraceLog)entry.getValue()).enabled = TraceLog.TRACE_ENABLED;
/*     */           }
/* 360 */           if (!(((TraceLog)entry.getValue()).enabled)) {
/* 361 */             synchronized ((TraceLog)entry.getValue()) {
/* 362 */               if (((TraceLog)entry.getValue()).out != null)
/* 363 */                 ((TraceLog)entry.getValue()).out.close();
/* 364 */               ((TraceLog)entry.getValue()).out = null;
/*     */             }
/*     */           }
/*     */         }
/* 368 */         TraceLog.g_props = props;
/*     */       }
/*     */       catch (Exception localException3)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }