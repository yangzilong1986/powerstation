/*     */ package com.hzjbbis.fk;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.events.event.MemoryProfileEvent;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IClientModule;
/*     */ import com.hzjbbis.fk.common.spi.IEventHook;
/*     */ import com.hzjbbis.fk.common.spi.IModule;
/*     */ import com.hzjbbis.fk.common.spi.IProfile;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.impl.StdSchedulerFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ 
/*     */ public class FasSystem
/*     */ {
/*  35 */   private static FasSystem fasSystem = null;
/*     */   public static final String name = "fasSystem";
/*  37 */   private static final Logger log = Logger.getLogger(FasSystem.class);
/*     */   private List<IModule> modules;
/*     */   private List<IModule> unMonitoredModules;
/*     */   private List<IEventHook> eventHooks;
/*  41 */   private boolean testMode = false;
/*     */   private List<Object> globalObjects;
/*  44 */   private MemoryProfileEvent memProfile = new MemoryProfileEvent();
/*     */   private List<IProfile> profileObjects;
/*  46 */   private boolean dbAvailable = false;
/*     */ 
/*  48 */   private Map<String, String> systemsProfile = new HashMap();
/*  49 */   private int waitCount = -1;
/*  50 */   private String osProfile = null;
/*     */ 
/*  53 */   private final List<Runnable> shutdownHooks = new ArrayList();
/*     */   private ApplicationContext applicationContext;
/*  57 */   private boolean running = false;
/*     */ 
/*     */   public boolean isTestMode() {
/*  60 */     return this.testMode;
/*     */   }
/*     */ 
/*     */   public void setTestMode(boolean testMode) {
/*  64 */     this.testMode = testMode;
/*     */   }
/*     */ 
/*     */   public static FasSystem getFasSystem()
/*     */   {
/*  69 */     if (fasSystem == null)
/*  70 */       fasSystem = new FasSystem();
/*  71 */     return fasSystem;
/*     */   }
/*     */ 
/*     */   public FasSystem()
/*     */   {
/*  76 */     fasSystem = this;
/*     */   }
/*     */ 
/*     */   public void initialize() {
/*  80 */     Runtime.getRuntime().addShutdownHook(new Thread()
/*     */     {
/*     */       public void run() {
/*  83 */         FasSystem.log.info("Run shutdownHooks");
/*  84 */         for (Runnable runIt : FasSystem.this.shutdownHooks)
/*     */           try {
/*  86 */             runIt.run();
/*     */           } catch (Exception e) {
/*  88 */             FasSystem.log.warn("shutdownHook exception:" + e.getLocalizedMessage(), e);
/*     */           }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void showProfile()
/*     */   {
/*  96 */     if (!(this.running))
/*  97 */       return;
/*  98 */     TraceLog.getTracer().trace(this.memProfile.profile());
/*  99 */     for (IModule module : this.modules)
/*     */       try {
/* 101 */         TraceLog.getTracer().trace(module.profile());
/*     */       }
/*     */       catch (Exception localException) {
/*     */       }
/* 105 */     for (IEventHook hook : this.eventHooks)
/*     */       try {
/* 107 */         TraceLog.getTracer().trace(hook.profile());
/*     */       }
/*     */       catch (Exception localException1) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public List<IModule> getModules() {
/* 114 */     return this.modules;
/*     */   }
/*     */ 
/*     */   public void setModules(List<IModule> modules)
/*     */   {
/* 119 */     this.modules = modules;
/*     */   }
/*     */ 
/*     */   public List<IEventHook> getEventHooks()
/*     */   {
/* 124 */     return this.eventHooks;
/*     */   }
/*     */ 
/*     */   public void setEventHooks(List<IEventHook> eventHooks)
/*     */   {
/* 129 */     this.eventHooks = eventHooks;
/*     */   }
/*     */ 
/*     */   public void addModule(IModule module)
/*     */   {
/* 134 */     if (this.modules == null)
/* 135 */       this.modules = new ArrayList();
/* 136 */     this.modules.remove(module);
/* 137 */     this.modules.add(module);
/*     */   }
/*     */ 
/*     */   public void addEventHook(IEventHook hook)
/*     */   {
/* 142 */     if (this.eventHooks == null)
/* 143 */       this.eventHooks = new ArrayList();
/* 144 */     this.eventHooks.remove(hook);
/* 145 */     this.eventHooks.add(hook);
/*     */   }
/*     */ 
/*     */   public boolean startModule(String name)
/*     */   {
/* 150 */     if (this.modules == null)
/* 151 */       return false;
/* 152 */     for (IModule module : this.modules) {
/* 153 */       if (module.getName().equalsIgnoreCase(name))
/* 154 */         return module.start();
/*     */     }
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean stopModule(String name)
/*     */   {
/* 161 */     if (this.modules == null)
/* 162 */       return false;
/* 163 */     for (IModule module : this.modules) {
/* 164 */       if (module.getName().equalsIgnoreCase(name)) {
/* 165 */         module.stop();
/* 166 */         return true;
/*     */       }
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   public void startSystem()
/*     */   {
/*     */     IModule module;
/*     */     Iterator localIterator;
/* 174 */     if ((this.modules == null) || (this.eventHooks == null))
/*     */     {
/* 176 */       log.fatal("系统没有配置任何模块或者事件处理模块。死翘翘！");
/* 177 */       stopSystem();
/* 178 */       return;
/*     */     }
/* 180 */     if (this.unMonitoredModules != null) {
/* 181 */       for (localIterator = this.unMonitoredModules.iterator(); localIterator.hasNext(); ) { module = (IModule)localIterator.next();
/*     */         try {
/* 183 */           module.start();
/*     */         }
/*     */         catch (Exception e) {
/* 186 */           log.warn("unMonitoredModules start exception:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 190 */     if (this.eventHooks != null) {
/* 191 */       for (IEventHook hook : this.eventHooks) {
/*     */         try {
/* 193 */           hook.start();
/*     */         } catch (Exception e) {
/* 195 */           log.warn("eventHooks start exception:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 200 */     if (this.modules != null) {
/* 201 */       for (localIterator = this.modules.iterator(); localIterator.hasNext(); ) { module = (IModule)localIterator.next();
/*     */         try {
/* 203 */           module.start();
/*     */         } catch (Exception e) {
/* 205 */           log.warn("modules start exception:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 209 */     this.running = true;
/* 210 */     log.info("startSystem successfully!");
/*     */   }
/*     */ 
/*     */   public void stopSystem() {
/*     */     IModule module;
/*     */     Iterator localIterator;
/*     */     try {
/* 217 */       Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
/* 218 */       scheduler.shutdown();
/*     */     } catch (Exception e) {
/* 220 */       log.warn("Quartz default schedule shutdown error:" + e.getLocalizedMessage(), e);
/*     */     }
/*     */ 
/* 224 */     log.info("stopSystem() is called.");
/* 225 */     if (this.modules != null) {
/* 226 */       for (localIterator = this.modules.iterator(); localIterator.hasNext(); ) { module = (IModule)localIterator.next();
/*     */         try {
/* 228 */           module.stop();
/*     */         } catch (Exception e) {
/* 230 */           log.warn("modules stop exception:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 235 */     if (this.eventHooks != null) {
/* 236 */       for (IEventHook hook : this.eventHooks) {
/*     */         try {
/* 238 */           hook.stop();
/*     */         } catch (Exception e) {
/* 240 */           log.warn("event hook stop exception: " + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 245 */     if (this.unMonitoredModules != null) {
/* 246 */       for (localIterator = this.unMonitoredModules.iterator(); localIterator.hasNext(); ) { module = (IModule)localIterator.next();
/*     */         try {
/* 248 */           module.stop();
/*     */         } catch (Exception e) {
/* 250 */           log.warn("unMonitoredModules stop exception: " + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 258 */       Thread.sleep(1000L);
/*     */     }
/*     */     catch (Exception localException1) {
/*     */     }
/*     */     try {
/* 263 */       TimerScheduler.getScheduler().destroy();
/* 264 */       GlobalEventHandler.getInstance().destroy();
/*     */     } catch (Exception localException1) {
/* 266 */       log.warn("shutdown timerScheduler or global event handler exception:" + e.getLocalizedMessage(), e);
/*     */     }
/*     */ 
/* 269 */     this.running = false;
/* 270 */     log.info("System stopped successfully !");
/*     */   }
/*     */ 
/*     */   public String getProfile(String type)
/*     */   {
/* 275 */     if ("module".equalsIgnoreCase(type))
/* 276 */       return getModuleProfile();
/* 277 */     if ("eventhook".equalsIgnoreCase(type))
/* 278 */       return getEventHookProfile();
/* 279 */     if ("gather".equalsIgnoreCase(type)) {
/* 280 */       return gatherSystemsProfile();
/*     */     }
/* 282 */     return getProfile();
/*     */   }
/*     */ 
/*     */   public String getProfile()
/*     */   {
/* 287 */     StringBuffer sb = new StringBuffer(2048);
/* 288 */     sb.append("<?xml version=\"1.0\" encoding=\"");
/* 289 */     sb.append(Charset.defaultCharset().name()).append("\"?>\r\n");
/* 290 */     sb.append("<root>");
/* 291 */     if (this.osProfile != null) {
/* 292 */       sb.append("\r\n    ").append(this.osProfile);
/*     */     }
/*     */     else {
/* 295 */       sb.append("\r\n    ").append(this.memProfile.profile());
/*     */     }
/* 297 */     if (this.profileObjects != null) {
/* 298 */       for (IProfile profile : this.profileObjects) {
/* 299 */         sb.append("\r\n    ").append(profile.profile());
/*     */       }
/*     */     }
/* 302 */     for (IModule mod : this.modules) {
/* 303 */       sb.append("\r\n    ").append(mod.profile());
/*     */     }
/* 305 */     for (IEventHook hook : this.eventHooks)
/* 306 */       sb.append("\r\n    ").append(hook.profile());
/* 307 */     sb.append("\r\n    <dbAvailable>").append(this.dbAvailable).append("</dbAvailable>");
/* 308 */     sb.append("\r\n").append("</root>");
/* 309 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getModuleProfile()
/*     */   {
/* 314 */     StringBuffer sb = new StringBuffer(2048);
/* 315 */     sb.append("<root>");
/* 316 */     for (IModule mod : this.modules) {
/* 317 */       sb.append("\r\n    ").append(mod.profile());
/*     */     }
/* 319 */     sb.append("\r\n    ").append(this.memProfile.profile());
/* 320 */     sb.append("\r\n").append("</root>");
/* 321 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getEventHookProfile()
/*     */   {
/* 326 */     StringBuffer sb = new StringBuffer(2048);
/* 327 */     sb.append("<root>");
/* 328 */     for (IEventHook hook : this.eventHooks)
/* 329 */       sb.append("\r\n    ").append(hook.profile());
/* 330 */     sb.append("\r\n").append("</root>");
/* 331 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public List<Object> getGlobalObjects() {
/* 335 */     return this.globalObjects;
/*     */   }
/*     */ 
/*     */   public void setGlobalObjects(List<Object> globalObjects) {
/* 339 */     this.globalObjects = globalObjects;
/*     */   }
/*     */ 
/*     */   public ApplicationContext getApplicationContext() {
/* 343 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext context) {
/* 347 */     this.applicationContext = context;
/*     */   }
/*     */ 
/*     */   public List<IModule> getUnMonitoredModules() {
/* 351 */     return this.unMonitoredModules;
/*     */   }
/*     */ 
/*     */   public void setUnMonitoredModules(List<IModule> unMonitoredModules) {
/* 355 */     if (this.unMonitoredModules != null) {
/* 356 */       this.unMonitoredModules.addAll(unMonitoredModules);
/*     */     }
/*     */     else
/* 359 */       this.unMonitoredModules = unMonitoredModules;
/*     */   }
/*     */ 
/*     */   public void addUnMonitoredModules(IModule module) {
/* 363 */     if (this.unMonitoredModules == null) {
/* 364 */       this.unMonitoredModules = new ArrayList();
/*     */     }
/* 366 */     this.unMonitoredModules.add(module);
/*     */   }
/*     */ 
/*     */   public synchronized String gatherSystemsProfile()
/*     */   {
/* 375 */     if (this.waitCount != -1)
/* 376 */       return null;
/* 377 */     synchronized (this.systemsProfile) {
/* 378 */       this.systemsProfile.clear();
/* 379 */       this.waitCount = 0;
/*     */     }
/* 381 */     for (IModule mod : this.modules) {
/* 382 */       if ((mod.getModuleType().equals("gprsClient")) && 
/* 383 */         (mod instanceof IClientModule)) {
/*     */         try {
/* 385 */           IClientModule gprsClient = (IClientModule)mod;
/* 386 */           if (gprsClient.sendMessage(MessageGate.createMoniteProfileRequest()))
/* 387 */             this.waitCount += 1;
/*     */         } catch (Exception e) {
/* 389 */           log.warn(e.getLocalizedMessage(), e);
/*     */         }
/*     */       } else {
/* 392 */         if ((!(mod.getModuleType().equals("businessProcessor"))) || 
/* 393 */           (!(mod instanceof ISocketServer))) continue;
/* 394 */         for (IServerSideChannel client : ((ISocketServer)mod).getClients()) {
/* 395 */           if (client.send(MessageGate.createMoniteProfileRequest())) {
/* 396 */             this.waitCount += 1;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 401 */     int sleepCount = 20;
/* 402 */     while ((this.systemsProfile.size() < this.waitCount) && (sleepCount > 0))
/*     */       try {
/* 404 */         Thread.sleep(100L);
/* 405 */         --sleepCount; } catch (Exception e) {
/* 406 */         break label261:
/*     */       }
/* 408 */     label261: addFrontEndProfile(getProfile());
/* 409 */     StringBuffer sb = new StringBuffer(30720);
/* 410 */     sb.append("<?xml version=\"1.0\" encoding=\"");
/* 411 */     sb.append(Charset.defaultCharset().name()); sb.append("\"?>\r\n");
/* 412 */     sb.append("<multi-system>\r\n");
/* 413 */     synchronized (this.systemsProfile) {
/* 414 */       Iterator iter = this.systemsProfile.values().iterator();
/* 415 */       while (iter.hasNext()) {
/* 416 */         String prof = (String)iter.next();
/* 417 */         sb.append(prof);
/*     */       }
/*     */     }
/* 420 */     sb.append("</multi-system>");
/* 421 */     this.waitCount = -1;
/* 422 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private void addSystemProfile(String sysType, String sysId, String profile) {
/* 426 */     if (this.waitCount == -1)
/* 427 */       return;
/* 428 */     int pos0 = profile.indexOf("<root>\r\n");
/* 429 */     if (pos0 < 0)
/* 430 */       return;
/* 431 */     pos0 += 8;
/* 432 */     int pos1 = profile.indexOf("</root>");
/* 433 */     if (pos1 < 0)
/* 434 */       return;
/* 435 */     profile = profile.substring(pos0, pos1);
/* 436 */     StringBuffer sb = new StringBuffer(10240);
/* 437 */     sb.append("    <system type=\"").append(sysType).append("\" id=\"").append(sysId).append("\">\r\n");
/* 438 */     String[] lines = profile.split("\r\n");
/* 439 */     for (String line : lines) {
/* 440 */       if (line.length() > 7)
/* 441 */         sb.append("      ").append(line).append("\r\n");
/*     */     }
/* 443 */     sb.append("    </system>\r\n");
/* 444 */     synchronized (this.systemsProfile) {
/* 445 */       this.systemsProfile.put(sysId, sb.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addGprsGateProfile(String systemId, String profile) {
/* 450 */     addSystemProfile("gprsGate", systemId, profile);
/*     */   }
/*     */ 
/*     */   public void addBizProcessorProfile(String systemId, String profile) {
/* 454 */     addSystemProfile("bp", systemId, profile);
/*     */   }
/*     */ 
/*     */   private void addFrontEndProfile(String profile) {
/* 458 */     addSystemProfile("frontEnd", "fe", profile);
/*     */   }
/*     */ 
/*     */   public final synchronized void setOsProfile(String osProfile) {
/* 462 */     this.osProfile = osProfile;
/*     */   }
/*     */ 
/*     */   public final void setProfileObjects(List<IProfile> profileObjects) {
/* 466 */     this.profileObjects = profileObjects;
/*     */   }
/*     */ 
/*     */   public final void addProfileObject(IProfile profileObject) {
/* 470 */     if (this.profileObjects == null) {
/* 471 */       this.profileObjects = new ArrayList();
/*     */     }
/* 473 */     this.profileObjects.add(profileObject);
/*     */   }
/*     */ 
/*     */   public final boolean isDbAvailable() {
/* 477 */     return this.dbAvailable;
/*     */   }
/*     */ 
/*     */   public final void setDbAvailable(boolean dbAvailable) {
/* 481 */     this.dbAvailable = dbAvailable;
/*     */   }
/*     */ 
/*     */   public final void addShutdownHook(Runnable runIt) {
/* 485 */     this.shutdownHooks.remove(runIt);
/* 486 */     this.shutdownHooks.add(runIt);
/*     */   }
/*     */ }