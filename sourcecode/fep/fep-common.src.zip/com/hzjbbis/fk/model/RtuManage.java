/*     */ package com.hzjbbis.fk.model;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class RtuManage
/*     */ {
/*  18 */   private static final Log log = LogFactory.getLog(RtuManage.class);
/*     */   private static RtuManage instance;
/*  23 */   private static String defaultRtuProtocol = "01";
/*     */   private static SysConfig sysConfig;
/*  28 */   private static Map<Integer, ComRtu> comRtuMap = new HashMap(102400);
/*     */ 
/*  31 */   private static Map<String, Integer> bizRtuaIdMap = new HashMap(102400);
/*     */ 
/*  33 */   private static Map<Integer, BizRtu> bizRtuMap = new HashMap(102400);
/*     */ 
/*  35 */   private static Map<Integer, TaskTemplate> taskPlateMap = new HashMap();
/*     */ 
/*  37 */   private static Map<Integer, RtuAlertCode> alertCodeMap = new HashMap();
/*     */ 
/*  39 */   private static Map<String, TaskDbConfig> taskDbConfigMap = new HashMap();
/*     */ 
/*  41 */   private static Map<Integer, Boolean> rtuRemoteUpdateMap = new HashMap();
/*     */ 
/*     */   public static RtuManage getInstance()
/*     */   {
/*  58 */     if (instance == null) {
/*  59 */       synchronized (RtuManage.class) {
/*  60 */         if (instance == null) {
/*  61 */           instance = new RtuManage();
/*     */         }
/*     */       }
/*     */     }
/*  65 */     return instance;
/*     */   }
/*     */ 
/*     */   private static void checkProtocol(BizRtu rtu)
/*     */   {
/*  75 */     if (rtu.getRtuProtocol() == null)
/*  76 */       rtu.setRtuProtocol(defaultRtuProtocol);
/*     */   }
/*     */ 
/*     */   public ComRtu getComRtuInCache(int rtua)
/*     */   {
/*  89 */     return ((ComRtu)comRtuMap.get(new Integer(rtua)));
/*     */   }
/*     */ 
/*     */   public Collection<ComRtu> getAllComRtu() {
/*  93 */     return comRtuMap.values();
/*     */   }
/*     */ 
/*     */   public Map<Integer, ComRtu> getComRtuMap() {
/*  97 */     return comRtuMap;
/*     */   }
/*     */ 
/*     */   public BizRtu getBizRtuInCache(int rtua)
/*     */   {
/* 107 */     return ((BizRtu)bizRtuMap.get(new Integer(rtua)));
/*     */   }
/*     */ 
/*     */   public BizRtu getBizRtuInCache(String rtuId)
/*     */   {
/* 117 */     return ((BizRtu)bizRtuMap.get(bizRtuaIdMap.get(rtuId)));
/*     */   }
/*     */ 
/*     */   public synchronized void putBizRtuToCache(BizRtu bizRtu)
/*     */   {
/*     */     try
/*     */     {
/* 126 */       checkProtocol(bizRtu);
/* 127 */       bizRtu.setRtua((int)Long.parseLong(bizRtu.getLogicAddress(), 16));
/* 128 */       bizRtuaIdMap.put(bizRtu.getRtuId(), new Integer(bizRtu.getRtua()));
/* 129 */       bizRtuMap.put(new Integer(bizRtu.getRtua()), bizRtu);
/*     */     } catch (Exception ex) {
/* 131 */       log.debug("Error to put BizRtu: " + bizRtu.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putComRtuToCache(ComRtu comRtu)
/*     */   {
/*     */     try
/*     */     {
/* 141 */       comRtu.setRtua((int)Long.parseLong(comRtu.getLogicAddress(), 16));
/* 142 */       comRtuMap.put(new Integer(comRtu.getRtua()), comRtu);
/*     */     } catch (Exception ex) {
/* 144 */       log.debug("Error to put ComRtu: " + comRtu.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putMeasuredPointToCache(MeasuredPoint mp)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       BizRtu bizRtu = getBizRtuInCache(mp.getRtuId());
/* 155 */       if (bizRtu == null) {
/* 156 */         log.debug("Can't find busRtu when loading MeasuredPoint: " + 
/* 157 */           mp.toString());
/* 158 */         return;
/*     */       }
/* 160 */       bizRtu.addMeasuredPoint(mp);
/*     */     } catch (Exception ex) {
/* 162 */       log.debug("Error to put MeasuredPoint: " + mp.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putRtuTaskToCache(RtuTask rt)
/*     */   {
/*     */     try
/*     */     {
/* 172 */       BizRtu bizRtu = getBizRtuInCache(rt.getRtuId());
/* 173 */       if (bizRtu == null) {
/* 174 */         log.debug("Can't find busRtu when loading RtuTask: " + 
/* 175 */           rt.toString());
/* 176 */         return;
/*     */       }
/* 178 */       bizRtu.addRtuTask(rt);
/*     */     } catch (Exception ex) {
/* 180 */       log.debug("Error to put RtuTask: " + rt.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskPlateInCache(String taskPlateID)
/*     */   {
/* 191 */     return ((TaskTemplate)taskPlateMap.get(new Integer(taskPlateID)));
/*     */   }
/*     */ 
/*     */   public RtuAlertCode getRtuAlertCode(int code)
/*     */   {
/* 201 */     return ((RtuAlertCode)alertCodeMap.get(new Integer(code)));
/*     */   }
/*     */ 
/*     */   public synchronized void putTaskTemplateToCache(TaskTemplate tp)
/*     */   {
/*     */     try
/*     */     {
/* 210 */       taskPlateMap.put(new Integer(tp.getTaskTemplateID()), tp);
/*     */     } catch (Exception ex) {
/* 212 */       log.debug("Error to put TaskPlate: " + tp.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putTaskTemplateItemToCache(TaskTemplateItem tpi)
/*     */   {
/*     */     try
/*     */     {
/* 222 */       TaskTemplate tp = (TaskTemplate)taskPlateMap.get(new Integer(tpi.getTaskTemplateID()));
/* 223 */       if (tp == null) {
/* 224 */         log.debug("Can't find TaskPlate when loading TaskPlateItem: " + 
/* 225 */           tpi.toString());
/* 226 */         return;
/*     */       }
/* 228 */       tp.addDataCode(tpi.getCode());
/*     */     } catch (Exception ex) {
/* 230 */       log.debug("Error to put TaskPlateItem: " + tpi.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskDbConfig getTaskDbConfigInCache(String key)
/*     */   {
/* 241 */     return ((TaskDbConfig)taskDbConfigMap.get(key));
/*     */   }
/*     */ 
/*     */   public synchronized void putTaskDbConfigToCache(TaskDbConfig tsi)
/*     */   {
/*     */     try
/*     */     {
/* 250 */       tsi.setDbConfigStr(tsi.getDbConfigStr());
/* 251 */       taskDbConfigMap.put(tsi.getCode(), tsi);
/*     */     } catch (Exception ex) {
/* 253 */       log.debug("Error to put TaskDbConfig: " + tsi.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putAlertCodeToCache(RtuAlertCode rac)
/*     */   {
/*     */     try
/*     */     {
/* 264 */       alertCodeMap.put(new Integer(Integer.parseInt(rac.getCode(), 16)), rac);
/*     */     } catch (Exception ex) {
/* 266 */       log.debug("Error to put RtuAlertCode: " + rac.toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void putRemoteUpateRtuaToCache(String rtua)
/*     */   {
/*     */     try
/*     */     {
/* 276 */       rtuRemoteUpdateMap.put(new Integer((int)Long.parseLong(rtua, 16)), Boolean.valueOf(true));
/*     */     } catch (Exception ex) {
/* 278 */       log.debug("Error to put RemoteUpateRtua: " + rtua, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getRemoteUpateRtuaTag(String rtua)
/*     */   {
/* 287 */     if (rtuRemoteUpdateMap.get(new Integer((int)Long.parseLong(rtua, 16))) != null) {
/* 288 */       return ((Boolean)rtuRemoteUpdateMap.get(new Integer((int)Long.parseLong(rtua, 16)))).booleanValue();
/*     */     }
/* 290 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean getRemoteUpateRtuaTag(int rtua)
/*     */   {
/* 298 */     if (rtuRemoteUpdateMap.get(new Integer(rtua)) != null) {
/* 299 */       return ((Boolean)rtuRemoteUpdateMap.get(new Integer(rtua))).booleanValue();
/*     */     }
/* 301 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized void clearRtuRemoteUpdateMap()
/*     */   {
/* 309 */     rtuRemoteUpdateMap.clear(); }
/*     */ 
/*     */   public SysConfig getSysConfig() {
/* 312 */     return sysConfig;
/*     */   }
/*     */ 
/*     */   public void setSysConfig(SysConfig sysConfig) {
/* 316 */     sysConfig = sysConfig;
/*     */   }
/*     */ }