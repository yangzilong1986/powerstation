/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RtuAlertCodeArg
/*    */ {
/*    */   private String code;
/*    */   private String sjx;
/*  6 */   private int xh = 0;
/*    */ 
/*    */   public String getCode() {
/*  9 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code) {
/* 13 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public String getSjx() {
/* 17 */     return this.sjx;
/*    */   }
/*    */ 
/*    */   public void setSjx(String sjx) {
/* 21 */     this.sjx = sjx;
/*    */   }
/*    */ 
/*    */   public int getXh() {
/* 25 */     return this.xh;
/*    */   }
/*    */ 
/*    */   public void setXh(int xh) {
/* 29 */     this.xh = xh;
/*    */   }
/*    */ }