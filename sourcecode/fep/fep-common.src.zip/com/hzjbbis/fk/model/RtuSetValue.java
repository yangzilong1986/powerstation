/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RtuSetValue
/*    */ {
/*    */   private long cmdId;
/*    */   private int cldh;
/*    */   private String sjxzt;
/*    */ 
/*    */   public long getCmdId()
/*    */   {
/* 12 */     return this.cmdId; }
/*    */ 
/*    */   public void setCmdId(long cmdId) {
/* 15 */     this.cmdId = cmdId; }
/*    */ 
/*    */   public int getCldh() {
/* 18 */     return this.cldh; }
/*    */ 
/*    */   public void setCldh(int cldh) {
/* 21 */     this.cldh = cldh; }
/*    */ 
/*    */   public String getSjxzt() {
/* 24 */     return this.sjxzt; }
/*    */ 
/*    */   public void setSjxzt(String sjxzt) {
/* 27 */     this.sjxzt = sjxzt;
/*    */   }
/*    */ }