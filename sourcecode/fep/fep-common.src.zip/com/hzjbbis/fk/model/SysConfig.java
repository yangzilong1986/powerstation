/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class SysConfig
/*    */ {
/*    */   private String pzz;
/*    */   private String bj10;
/*    */   private String bj11;
/*    */ 
/*    */   public String getPzz()
/*    */   {
/* 13 */     return this.pzz; }
/*    */ 
/*    */   public void setPzz(String pzz) {
/* 16 */     this.pzz = pzz; }
/*    */ 
/*    */   public String getBj10() {
/* 19 */     return this.bj10; }
/*    */ 
/*    */   public void setBj10(String bj10) {
/* 22 */     this.bj10 = bj10; }
/*    */ 
/*    */   public String getBj11() {
/* 25 */     return this.bj11; }
/*    */ 
/*    */   public void setBj11(String bj11) {
/* 28 */     this.bj11 = bj11;
/*    */   }
/*    */ }