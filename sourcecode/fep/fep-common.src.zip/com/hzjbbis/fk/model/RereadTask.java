/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RereadTask
/*    */ {
/*    */   private String rtuId;
/*    */   private String taskNum;
/*    */   private String taskInterval;
/*    */   private Integer rereadPolicyID;
/* 20 */   private Map<Long, RereadInfo> datemaps = new HashMap();
/*    */ 
/*    */   public String getRtuId() {
/* 23 */     return this.rtuId; }
/*    */ 
/*    */   public void setRtuId(String rtuId) {
/* 26 */     this.rtuId = rtuId; }
/*    */ 
/*    */   public String getTaskNum() {
/* 29 */     return this.taskNum; }
/*    */ 
/*    */   public void setTaskNum(String taskNum) {
/* 32 */     this.taskNum = taskNum; }
/*    */ 
/*    */   public String getTaskInterval() {
/* 35 */     return this.taskInterval; }
/*    */ 
/*    */   public void setTaskInterval(String taskInterval) {
/* 38 */     this.taskInterval = taskInterval; }
/*    */ 
/*    */   public Integer getRereadPolicyID() {
/* 41 */     return this.rereadPolicyID; }
/*    */ 
/*    */   public void setRereadPolicyID(Integer rereadPolicyID) {
/* 44 */     this.rereadPolicyID = rereadPolicyID; }
/*    */ 
/*    */   public Map<Long, RereadInfo> getDatemaps() {
/* 47 */     return this.datemaps; }
/*    */ 
/*    */   public void setDatemaps(Map<Long, RereadInfo> datemaps) {
/* 50 */     this.datemaps = datemaps;
/*    */   }
/*    */ }