/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RtuTask
/*    */ {
/*    */   private String rtuId;
/*    */   private String taskTemplateID;
/*    */   private String taskTemplateProperty;
/*    */   private int rtuTaskNum;
/*    */   private String tn;
/*    */ 
/*    */   public String getRtuId()
/*    */   {
/* 23 */     return this.rtuId;
/*    */   }
/*    */ 
/*    */   public void setRtuId(String rtuId)
/*    */   {
/* 29 */     this.rtuId = rtuId;
/*    */   }
/*    */ 
/*    */   public int getRtuTaskNum()
/*    */   {
/* 35 */     return this.rtuTaskNum;
/*    */   }
/*    */ 
/*    */   public void setRtuTaskNum(int rtuaTaskNum)
/*    */   {
/* 41 */     this.rtuTaskNum = rtuaTaskNum;
/*    */   }
/*    */ 
/*    */   public String getTaskTemplateID()
/*    */   {
/* 47 */     return this.taskTemplateID;
/*    */   }
/*    */ 
/*    */   public void setTaskTemplateID(String taskTemplateID)
/*    */   {
/* 53 */     this.taskTemplateID = taskTemplateID;
/*    */   }
/*    */ 
/*    */   public String getTaskTemplateProperty()
/*    */   {
/* 58 */     return this.taskTemplateProperty; }
/*    */ 
/*    */   public void setTaskTemplateProperty(String taskTemplateProperty) {
/* 61 */     this.taskTemplateProperty = taskTemplateProperty;
/*    */   }
/*    */ 
/*    */   public String getTn()
/*    */   {
/* 67 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String tn)
/*    */   {
/* 73 */     this.tn = tn;
/*    */   }
/*    */ }