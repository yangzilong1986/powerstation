/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RtuCmdItem
/*    */ {
/*    */   private long cmdId;
/*    */   private int bwsl;
/*    */   private int zdzjbz;
/*    */ 
/*    */   public int getBwsl()
/*    */   {
/* 12 */     return this.bwsl; }
/*    */ 
/*    */   public void setBwsl(int bwsl) {
/* 15 */     this.bwsl = bwsl; }
/*    */ 
/*    */   public long getCmdId() {
/* 18 */     return this.cmdId; }
/*    */ 
/*    */   public void setCmdId(long cmdId) {
/* 21 */     this.cmdId = cmdId; }
/*    */ 
/*    */   public int getZdzjbz() {
/* 24 */     return this.zdzjbz; }
/*    */ 
/*    */   public void setZdzjbz(int zdzjbz) {
/* 27 */     this.zdzjbz = zdzjbz;
/*    */   }
/*    */ }