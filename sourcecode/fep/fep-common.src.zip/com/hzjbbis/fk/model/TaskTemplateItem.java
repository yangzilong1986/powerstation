/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class TaskTemplateItem
/*    */ {
/*    */   private String taskTemplateID;
/*    */   private String code;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 14 */     return "[taskPlateID=" + this.taskTemplateID + ", code=" + this.code + "]";
/*    */   }
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 21 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code)
/*    */   {
/* 27 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public String getTaskTemplateID()
/*    */   {
/* 34 */     return this.taskTemplateID;
/*    */   }
/*    */ 
/*    */   public void setTaskTemplateID(String taskTemplateID)
/*    */   {
/* 41 */     this.taskTemplateID = taskTemplateID;
/*    */   }
/*    */ }