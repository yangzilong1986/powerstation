/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RereadRtu
/*    */ {
/*    */   private String rtuId;
/* 15 */   private Map<Integer, RereadTask> rereadTasksMap = new HashMap();
/*    */ 
/*    */   public String getRtuId() {
/* 18 */     return this.rtuId; }
/*    */ 
/*    */   public void setRtuId(String rtuId) {
/* 21 */     this.rtuId = rtuId; }
/*    */ 
/*    */   public Map<Integer, RereadTask> getRereadTasksMap() {
/* 24 */     return this.rereadTasksMap; }
/*    */ 
/*    */   public void setRereadTasksMap(Map<Integer, RereadTask> rereadTasksMap) {
/* 27 */     this.rereadTasksMap = rereadTasksMap;
/*    */   }
/*    */ }