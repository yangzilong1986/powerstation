/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RereadInfo
/*    */ {
/*    */   private int rereadTag;
/*    */   private int rereadCount;
/*    */ 
/*    */   public int getRereadTag()
/*    */   {
/* 14 */     return this.rereadTag; }
/*    */ 
/*    */   public void setRereadTag(int rereadTag) {
/* 17 */     this.rereadTag = rereadTag; }
/*    */ 
/*    */   public int getRereadCount() {
/* 20 */     return this.rereadCount; }
/*    */ 
/*    */   public void setRereadCount(int rereadCount) {
/* 23 */     this.rereadCount = rereadCount;
/*    */   }
/*    */ }