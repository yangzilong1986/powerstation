/*     */ package com.hzjbbis.fk.model;
/*     */ 
/*     */ public class MeasuredPoint
/*     */ {
/*     */   private static final String TYPE_METER = "01";
/*     */   private static final int DEFAULT_CT_PT = 1;
/*     */   private String rtuId;
/*     */   private String customerNo;
/*     */   private String tn;
/*     */   private String stationNo;
/*     */   private String stationType;
/*     */   private String atrAddress;
/*     */   private String atrPort;
/*     */   private String atrProtocol;
/*  33 */   private int ct = 1;
/*     */ 
/*  35 */   private int pt = 1;
/*     */   private String dataSaveID;
/*     */ 
/*     */   public boolean isMeterType()
/*     */   {
/*  44 */     return "01".equals(this.stationType);
/*     */   }
/*     */ 
/*     */   public void setCtStr(String ctStr)
/*     */   {
/*  52 */     if (ctStr == null)
/*  53 */       this.ct = 1;
/*     */     else
/*     */       try
/*     */       {
/*  57 */         this.ct = Integer.parseInt(ctStr);
/*     */       }
/*     */       catch (Exception ex) {
/*  60 */         this.ct = 1;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setPtStr(String ptStr)
/*     */   {
/*  70 */     if (ptStr == null)
/*  71 */       this.pt = 1;
/*     */     else
/*     */       try
/*     */       {
/*  75 */         this.pt = Integer.parseInt(ptStr);
/*     */       }
/*     */       catch (Exception ex) {
/*  78 */         this.pt = 1;
/*     */       }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  84 */     StringBuffer sb = new StringBuffer();
/*  85 */     sb.append("[rtuId=").append(this.rtuId)
/*  86 */       .append(", tn=").append(this.tn)
/*  87 */       .append(", stationNo=").append(this.stationNo)
/*  88 */       .append(", type=").append(this.stationType)
/*  89 */       .append(", address=").append(this.atrAddress)
/*  90 */       .append(", port=").append(this.atrPort)
/*  91 */       .append(", protocol=").append(this.atrProtocol).append("]");
/*  92 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getRtuId()
/*     */   {
/*  99 */     return this.rtuId;
/*     */   }
/*     */ 
/*     */   public void setRtuId(String rtuId)
/*     */   {
/* 105 */     this.rtuId = rtuId;
/*     */   }
/*     */ 
/*     */   public String getTn()
/*     */   {
/* 111 */     return this.tn;
/*     */   }
/*     */ 
/*     */   public void setTn(String tn)
/*     */   {
/* 117 */     this.tn = tn;
/*     */   }
/*     */ 
/*     */   public String getAtrAddress()
/*     */   {
/* 124 */     return this.atrAddress;
/*     */   }
/*     */ 
/*     */   public void setAtrAddress(String atrAddress)
/*     */   {
/* 131 */     this.atrAddress = atrAddress;
/*     */   }
/*     */ 
/*     */   public String getAtrPort()
/*     */   {
/* 138 */     return this.atrPort;
/*     */   }
/*     */ 
/*     */   public void setAtrPort(String atrPort)
/*     */   {
/* 145 */     this.atrPort = atrPort;
/*     */   }
/*     */ 
/*     */   public String getAtrProtocol()
/*     */   {
/* 152 */     return this.atrProtocol;
/*     */   }
/*     */ 
/*     */   public void setAtrProtocol(String atrProtocol)
/*     */   {
/* 159 */     this.atrProtocol = atrProtocol;
/*     */   }
/*     */ 
/*     */   public String getCustomerNo()
/*     */   {
/* 166 */     return this.customerNo;
/*     */   }
/*     */ 
/*     */   public void setCustomerNo(String customerNo)
/*     */   {
/* 173 */     this.customerNo = customerNo;
/*     */   }
/*     */ 
/*     */   public String getDataSaveID()
/*     */   {
/* 180 */     return this.dataSaveID;
/*     */   }
/*     */ 
/*     */   public void setDataSaveID(String dataSaveID)
/*     */   {
/* 187 */     this.dataSaveID = dataSaveID;
/*     */   }
/*     */ 
/*     */   public String getStationType()
/*     */   {
/* 194 */     return this.stationType;
/*     */   }
/*     */ 
/*     */   public void setStationType(String stationType)
/*     */   {
/* 201 */     this.stationType = stationType;
/*     */   }
/*     */ 
/*     */   public String getStationNo()
/*     */   {
/* 208 */     return this.stationNo;
/*     */   }
/*     */ 
/*     */   public void setStationNo(String stationNo)
/*     */   {
/* 214 */     this.stationNo = stationNo;
/*     */   }
/*     */ 
/*     */   public int getCt()
/*     */   {
/* 220 */     return this.ct;
/*     */   }
/*     */ 
/*     */   public void setCt(int ct)
/*     */   {
/* 226 */     this.ct = ct;
/*     */   }
/*     */ 
/*     */   public int getPt()
/*     */   {
/* 232 */     return this.pt;
/*     */   }
/*     */ 
/*     */   public void setPt(int pt)
/*     */   {
/* 238 */     this.pt = pt;
/*     */   }
/*     */ }