/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RtuSynchronizeItem
/*    */ {
/*    */   private String rtuId;
/*    */   private int SycType;
/*    */   private String SycTime;
/*    */ 
/*    */   public String getRtuId()
/*    */   {
/* 12 */     return this.rtuId; }
/*    */ 
/*    */   public void setRtuId(String rtuId) {
/* 15 */     this.rtuId = rtuId; }
/*    */ 
/*    */   public int getSycType() {
/* 18 */     return this.SycType; }
/*    */ 
/*    */   public void setSycType(int sycType) {
/* 21 */     this.SycType = sycType; }
/*    */ 
/*    */   public String getSycTime() {
/* 24 */     return this.SycTime; }
/*    */ 
/*    */   public void setSycTime(String sycTime) {
/* 27 */     this.SycTime = sycTime;
/*    */   }
/*    */ }