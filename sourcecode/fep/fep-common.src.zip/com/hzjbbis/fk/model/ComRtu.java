/*     */ package com.hzjbbis.fk.model;
/*     */ 
/*     */ import com.hzjbbis.fk.utils.CalendarUtil;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class ComRtu
/*     */ {
/*     */   private String rtuId;
/*  16 */   private String deptCode = "";
/*     */   private String rtuProtocol;
/*     */   private int rtua;
/*     */   private String logicAddress;
/*     */   private String manufacturer;
/*     */   private String simNum;
/*     */   private String commType;
/*     */   private String commAddress;
/*     */   private String b1CommType;
/*     */   private String b1CommAddress;
/*     */   private String b2CommType;
/*     */   private String b2CommAddress;
/*     */   private String activeGprs;
/*     */   private String activeUms;
/*     */   private int upGprsFlowmeter;
/*     */   private int upSmsCount;
/*     */   private int downGprsFlowmeter;
/*     */   private int downSmsCount;
/*     */   private String upMobile;
/*     */   private long lastGprsTime;
/*     */   private long lastSmsTime;
/*     */   private int taskCount;
/*     */   private int upGprsCount;
/*     */   private int downGprsCount;
/*     */   private String misSmsAddress;
/*     */   private String misGprsAddress;
/*     */   private String rtuIpAddr;
/*     */   private String activeSubAppId;
/*  65 */   private int heartbeatCount = 0;
/*  66 */   private long lastHeartbeat = 0L;
/*     */ 
/*  69 */   private int heartSavePosition = -1;
/*  70 */   private int flowSavePosition = -1;
/*  71 */   private int rtuSavePosition = -1;
/*     */   private long lastIoTime;
/*  77 */   private long lastReqTime = 0L;
/*     */ 
/*     */   public String getActiveGprs()
/*     */   {
/*  82 */     return this.activeGprs;
/*     */   }
/*     */ 
/*     */   public void setActiveGprs(String activeGprs)
/*     */   {
/*  88 */     this.activeGprs = activeGprs;
/*     */   }
/*     */ 
/*     */   public String getActiveUms()
/*     */   {
/*  94 */     return this.activeUms;
/*     */   }
/*     */ 
/*     */   public void setActiveUms(String activeUms)
/*     */   {
/* 100 */     this.activeUms = activeUms;
/*     */   }
/*     */ 
/*     */   public String getB1CommAddress()
/*     */   {
/* 106 */     return this.b1CommAddress;
/*     */   }
/*     */ 
/*     */   public void setB1CommAddress(String commAddress)
/*     */   {
/* 112 */     this.b1CommAddress = commAddress;
/*     */   }
/*     */ 
/*     */   public String getB1CommType()
/*     */   {
/* 118 */     return this.b1CommType;
/*     */   }
/*     */ 
/*     */   public void setB1CommType(String commType)
/*     */   {
/* 124 */     this.b1CommType = commType;
/*     */   }
/*     */ 
/*     */   public String getB2CommAddress()
/*     */   {
/* 130 */     return this.b2CommAddress;
/*     */   }
/*     */ 
/*     */   public void setB2CommAddress(String commAddress)
/*     */   {
/* 136 */     this.b2CommAddress = commAddress;
/*     */   }
/*     */ 
/*     */   public String getB2CommType()
/*     */   {
/* 142 */     return this.b2CommType;
/*     */   }
/*     */ 
/*     */   public void setB2CommType(String commType)
/*     */   {
/* 148 */     this.b2CommType = commType;
/*     */   }
/*     */ 
/*     */   public String getCommAddress()
/*     */   {
/* 154 */     return this.commAddress;
/*     */   }
/*     */ 
/*     */   public void setCommAddress(String commAddress)
/*     */   {
/* 160 */     this.commAddress = commAddress;
/*     */   }
/*     */ 
/*     */   public String getCommType()
/*     */   {
/* 166 */     return this.commType;
/*     */   }
/*     */ 
/*     */   public void setCommType(String commType)
/*     */   {
/* 172 */     this.commType = commType;
/*     */   }
/*     */ 
/*     */   public int getUpGprsFlowmeter()
/*     */   {
/* 178 */     return this.upGprsFlowmeter;
/*     */   }
/*     */ 
/*     */   public void setUpGprsFlowmeter(int curGprsFlowmeter)
/*     */   {
/* 184 */     this.upGprsFlowmeter = curGprsFlowmeter;
/*     */   }
/*     */ 
/*     */   public void addUpGprsFlowmeter(int flow) {
/* 188 */     this.upGprsFlowmeter += flow;
/*     */   }
/*     */ 
/*     */   public void incUpSmsCount() {
/* 192 */     this.upSmsCount += 1;
/*     */   }
/*     */ 
/*     */   public int getUpSmsCount() {
/* 196 */     return this.upSmsCount; }
/*     */ 
/*     */   public void setUpSmsCount(int count) {
/* 199 */     this.upSmsCount = count;
/*     */   }
/*     */ 
/*     */   public String getDeptCode()
/*     */   {
/* 205 */     return this.deptCode;
/*     */   }
/*     */ 
/*     */   public void setDeptCode(String deptCode)
/*     */   {
/* 211 */     this.deptCode = deptCode;
/*     */   }
/*     */ 
/*     */   public long getLastIoTime()
/*     */   {
/* 217 */     return this.lastIoTime;
/*     */   }
/*     */ 
/*     */   public void setLastIoTime(long lastIoTime)
/*     */   {
/* 223 */     this.lastIoTime = lastIoTime;
/*     */   }
/*     */ 
/*     */   public String getLogicAddress()
/*     */   {
/* 229 */     return this.logicAddress;
/*     */   }
/*     */ 
/*     */   public void setLogicAddress(String logicAddress)
/*     */   {
/* 235 */     this.logicAddress = logicAddress;
/*     */   }
/*     */ 
/*     */   public String getManufacturer()
/*     */   {
/* 241 */     return this.manufacturer;
/*     */   }
/*     */ 
/*     */   public void setManufacturer(String manufacturer)
/*     */   {
/* 247 */     this.manufacturer = manufacturer;
/*     */   }
/*     */ 
/*     */   public int getRtua()
/*     */   {
/* 253 */     return this.rtua;
/*     */   }
/*     */ 
/*     */   public void setRtua(int rtua)
/*     */   {
/* 259 */     this.rtua = rtua;
/*     */   }
/*     */ 
/*     */   public String getRtuId()
/*     */   {
/* 265 */     return this.rtuId;
/*     */   }
/*     */ 
/*     */   public void setRtuId(String rtuId)
/*     */   {
/* 271 */     this.rtuId = rtuId;
/*     */   }
/*     */ 
/*     */   public String getRtuProtocol()
/*     */   {
/* 277 */     return this.rtuProtocol;
/*     */   }
/*     */ 
/*     */   public void setRtuProtocol(String rtuProtocol)
/*     */   {
/* 283 */     this.rtuProtocol = rtuProtocol;
/*     */   }
/*     */ 
/*     */   public String getSimNum()
/*     */   {
/* 289 */     if ((this.upMobile != null) && (this.upMobile.length() >= 11))
/* 290 */       return this.upMobile;
/* 291 */     return this.simNum;
/*     */   }
/*     */ 
/*     */   public void setSimNum(String simNum)
/*     */   {
/* 297 */     this.simNum = simNum; }
/*     */ 
/*     */   public int getDownGprsFlowmeter() {
/* 300 */     return this.downGprsFlowmeter; }
/*     */ 
/*     */   public void setDownGprsFlowmeter(int downGprsFlowmeter) {
/* 303 */     this.downGprsFlowmeter = downGprsFlowmeter;
/*     */   }
/*     */ 
/*     */   public void addDownGprsFlowmeter(int flow) {
/* 307 */     this.downGprsFlowmeter += flow;
/*     */   }
/*     */ 
/*     */   public int getDownSmsCount() {
/* 311 */     return this.downSmsCount; }
/*     */ 
/*     */   public void setDownSmsCount(int downSmsCounter) {
/* 314 */     this.downSmsCount = downSmsCounter; }
/*     */ 
/*     */   public void incDownSmsCount() {
/* 317 */     this.downSmsCount += 1;
/*     */   }
/*     */ 
/*     */   public String getUpMobile() {
/* 321 */     if ((this.upMobile != null) && (this.upMobile.length() > 0)) {
/* 322 */       return this.upMobile;
/*     */     }
/* 324 */     return this.simNum;
/*     */   }
/*     */ 
/*     */   public void setUpMobile(String upMobile) {
/* 328 */     this.upMobile = upMobile;
/*     */   }
/*     */ 
/*     */   public long getLastGprsTime() {
/* 332 */     return this.lastGprsTime;
/*     */   }
/*     */ 
/*     */   public void setLastGprsTime(long lastGprsTime) {
/* 336 */     this.lastGprsTime = lastGprsTime;
/*     */   }
/*     */ 
/*     */   public long getLastSmsTime() {
/* 340 */     return this.lastSmsTime;
/*     */   }
/*     */ 
/*     */   public void setLastSmsTime(long lastSmsTime) {
/* 344 */     this.lastSmsTime = lastSmsTime;
/*     */   }
/*     */ 
/*     */   public int getTaskCount() {
/* 348 */     return this.taskCount;
/*     */   }
/*     */ 
/*     */   public int getHasTask() {
/* 352 */     return ((this.taskCount != 0) ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public String getTaskCountString() {
/* 356 */     return String.valueOf(this.taskCount);
/*     */   }
/*     */ 
/*     */   public void setTaskCount(int taskCount) {
/* 360 */     this.taskCount = taskCount;
/*     */   }
/*     */ 
/*     */   public void incTaskCount() {
/* 364 */     this.taskCount += 1;
/*     */   }
/*     */ 
/*     */   public int getUpGprsCount() {
/* 368 */     return this.upGprsCount; }
/*     */ 
/*     */   public void setUpGprsCount(int upGprsCount) {
/* 371 */     this.upGprsCount = upGprsCount;
/*     */   }
/*     */ 
/*     */   public void incUpGprsCount() {
/* 375 */     this.upGprsCount += 1;
/*     */   }
/*     */ 
/*     */   public int getDownGprsCount() {
/* 379 */     return this.downGprsCount;
/*     */   }
/*     */ 
/*     */   public void setDownGprsCount(int downGprsCount) {
/* 383 */     this.downGprsCount = downGprsCount; }
/*     */ 
/*     */   public void incDownGprsCount() {
/* 386 */     this.downGprsCount += 1; }
/*     */ 
/*     */   public String getMisSmsAddress() {
/* 389 */     return this.misSmsAddress; }
/*     */ 
/*     */   public void setMisSmsAddress(String misSmsAddress) {
/* 392 */     this.misSmsAddress = misSmsAddress; }
/*     */ 
/*     */   public String getMisGprsAddress() {
/* 395 */     return this.misGprsAddress; }
/*     */ 
/*     */   public void setMisGprsAddress(String misGprsAddress) {
/* 398 */     this.misGprsAddress = misGprsAddress;
/*     */   }
/*     */ 
/*     */   public void clearStatus() {
/* 402 */     this.upGprsFlowmeter = 0;
/* 403 */     this.upSmsCount = 0;
/* 404 */     this.downGprsFlowmeter = 0;
/* 405 */     this.downSmsCount = 0;
/* 406 */     this.upMobile = null;
/* 407 */     this.lastGprsTime = 0L;
/* 408 */     this.lastSmsTime = 0L;
/* 409 */     this.taskCount = 0;
/* 410 */     this.upGprsCount = 0;
/* 411 */     this.downGprsCount = 0;
/*     */ 
/* 413 */     this.misSmsAddress = null;
/* 414 */     this.misGprsAddress = null;
/* 415 */     this.heartbeatCount = 0;
/* 416 */     this.lastHeartbeat = 0L;
/*     */   }
/*     */ 
/*     */   public void setLastReqTime(long lastReqTime) {
/* 420 */     this.lastReqTime = lastReqTime; }
/*     */ 
/*     */   public long getLastReqTime() {
/* 423 */     return this.lastReqTime;
/*     */   }
/*     */ 
/*     */   public Date getLastGprsRecvTime() {
/* 427 */     if (0L != this.lastGprsTime) {
/* 428 */       return new Date(this.lastGprsTime);
/*     */     }
/* 430 */     return null;
/*     */   }
/*     */ 
/*     */   public Date getLastSmsRecvTime() {
/* 434 */     if (0L != this.lastSmsTime) {
/* 435 */       return new Date(this.lastSmsTime);
/*     */     }
/* 437 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDateString() {
/* 441 */     return CalendarUtil.getDateString(System.currentTimeMillis()); }
/*     */ 
/*     */   public String getRtuIpAddr() {
/* 444 */     return this.rtuIpAddr; }
/*     */ 
/*     */   public void setRtuIpAddr(String rtuIpAddr) {
/* 447 */     this.rtuIpAddr = rtuIpAddr; }
/*     */ 
/*     */   public String getActiveSubAppId() {
/* 450 */     return this.activeSubAppId; }
/*     */ 
/*     */   public void setActiveSubAppId(String activeSubAppId) {
/* 453 */     this.activeSubAppId = activeSubAppId;
/*     */   }
/*     */ 
/*     */   public final int getHeartbeatCount() {
/* 457 */     return this.heartbeatCount; }
/*     */ 
/*     */   public final void setHeartbeatCount(int heartbeatCount) {
/* 460 */     this.heartbeatCount = heartbeatCount; }
/*     */ 
/*     */   public final void incHeartbeat() {
/* 463 */     this.heartbeatCount += 1;
/*     */   }
/*     */ 
/*     */   public final long getLastHeartbeat() {
/* 467 */     return this.lastHeartbeat;
/*     */   }
/*     */ 
/*     */   public Date getLastHeartbeatTime() {
/* 471 */     if (0L != this.lastHeartbeat) {
/* 472 */       return new Date(this.lastHeartbeat);
/*     */     }
/* 474 */     return null;
/*     */   }
/*     */ 
/*     */   public final void setLastHeartbeat(long lastHeartbeat) {
/* 478 */     this.lastHeartbeat = lastHeartbeat; }
/*     */ 
/*     */   public final int getHeartSavePosition() {
/* 481 */     return this.heartSavePosition; }
/*     */ 
/*     */   public final void setHeartSavePosition(int heartSavePosition) {
/* 484 */     this.heartSavePosition = heartSavePosition; }
/*     */ 
/*     */   public final int getFlowSavePosition() {
/* 487 */     return this.flowSavePosition; }
/*     */ 
/*     */   public final void setFlowSavePosition(int flowSavePosition) {
/* 490 */     this.flowSavePosition = flowSavePosition; }
/*     */ 
/*     */   public final int getRtuSavePosition() {
/* 493 */     return this.rtuSavePosition; }
/*     */ 
/*     */   public final void setRtuSavePosition(int rtuSavePosition) {
/* 496 */     this.rtuSavePosition = rtuSavePosition;
/*     */   }
/*     */ }