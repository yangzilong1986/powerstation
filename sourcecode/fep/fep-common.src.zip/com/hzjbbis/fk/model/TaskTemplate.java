/*     */ package com.hzjbbis.fk.model;
/*     */ 
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TaskTemplate
/*     */ {
/*     */   public static final String TASK_TYPE_NORMAL = "01";
/*     */   public static final String TASK_TYPE_FORWARD = "02";
/*     */   private static final String DELIM = ",";
/*     */   private String taskTemplateID;
/*     */   private String taskType;
/*     */   private int sampleStartTime;
/*     */   private String sampleStartTimeUnit;
/*     */   private int sampleInterval;
/*     */   private String sampleIntervalUnit;
/*     */   private int uploadStartTime;
/*     */   private String uploadStartTimeUnit;
/*     */   private int uploadInterval;
/*     */   private String uploadIntervalUnit;
/*     */   private int frequence;
/*     */   private int savepts;
/*     */   private int donums;
/*     */   private String dataCodesStr;
/*  50 */   private List<String> dataCodes = new ArrayList();
/*     */   private String tn;
/*     */ 
/*     */   public static TaskTemplate parse(String s)
/*     */   {
/*  75 */     if (s == null) {
/*  76 */       throw new IllegalArgumentException("The task setting could not be null");
/*     */     }
/*     */ 
/*  79 */     String[] values = s.split(",");
/*  80 */     String tt = values[0];
/*  81 */     if ((!(tt.equals("01"))) && 
/*  82 */       (!(tt.equals("02")))) {
/*  83 */       throw new IllegalArgumentException("Invalid task type: " + tt);
/*     */     }
/*     */ 
/*  86 */     TaskTemplate task = new TaskTemplate();
/*  87 */     task.setTaskType(tt);
/*  88 */     if (tt.equals("01")) {
/*  89 */       setTaskSchedule(task, values);
/*  90 */       task.setTn(values[10]);
/*  91 */       int diCount = Integer.parseInt(values[13]);
/*  92 */       for (int i = 0; i < diCount; ++i) {
/*  93 */         task.addDataCode(values[(14 + i)]);
/*     */       }
/*     */     }
/*  96 */     else if (tt.equals("02")) {
/*  97 */       setTaskSchedule(task, values);
/*     */     }
/*  99 */     return task;
/*     */   }
/*     */ 
/*     */   private static void setTaskSchedule(TaskTemplate task, String[] values)
/*     */   {
/* 108 */     task.setSampleStartTime(Integer.parseInt(values[1]));
/* 109 */     task.setSampleStartTimeUnit(values[2]);
/* 110 */     task.setSampleInterval(Integer.parseInt(values[3]));
/* 111 */     task.setSampleIntervalUnit(values[4]);
/* 112 */     task.setUploadStartTime(Integer.parseInt(values[5]));
/* 113 */     task.setUploadStartTimeUnit(values[6]);
/* 114 */     task.setUploadInterval(Integer.parseInt(values[7]));
/* 115 */     task.setUploadIntervalUnit(values[8]);
/* 116 */     task.setFrequence(Integer.parseInt(values[9]));
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 120 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 122 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void addDataCode(String code)
/*     */   {
/* 130 */     this.dataCodes.add(code);
/*     */   }
/*     */ 
/*     */   public String getDataCodesAsString()
/*     */   {
/* 138 */     if ((this.dataCodesStr == null) && (this.dataCodes != null)) {
/* 139 */       StringBuffer sb = new StringBuffer();
/* 140 */       for (int i = 0; i < this.dataCodes.size(); ++i) {
/* 141 */         if (sb.length() > 0) {
/* 142 */           sb.append(",");
/*     */         }
/* 144 */         sb.append((String)this.dataCodes.get(i));
/*     */       }
/*     */     }
/* 147 */     return this.dataCodesStr;
/*     */   }
/*     */ 
/*     */   public String getTaskType()
/*     */   {
/* 155 */     return this.taskType;
/*     */   }
/*     */ 
/*     */   public void setTaskType(String taskType)
/*     */   {
/* 161 */     this.taskType = taskType;
/*     */   }
/*     */ 
/*     */   public String getTn()
/*     */   {
/* 168 */     return this.tn;
/*     */   }
/*     */ 
/*     */   public void setTn(String tn)
/*     */   {
/* 174 */     this.tn = tn;
/*     */   }
/*     */ 
/*     */   public int getSampleStartTime()
/*     */   {
/* 181 */     return this.sampleStartTime;
/*     */   }
/*     */ 
/*     */   public void setSampleStartTime(int sampleStartTime)
/*     */   {
/* 187 */     this.sampleStartTime = sampleStartTime;
/*     */   }
/*     */ 
/*     */   public String getSampleStartTimeUnit()
/*     */   {
/* 193 */     return this.sampleStartTimeUnit;
/*     */   }
/*     */ 
/*     */   public void setSampleStartTimeUnit(String sampleStartTimeUnit)
/*     */   {
/* 199 */     this.sampleStartTimeUnit = sampleStartTimeUnit;
/*     */   }
/*     */ 
/*     */   public int getSampleInterval()
/*     */   {
/* 205 */     return this.sampleInterval;
/*     */   }
/*     */ 
/*     */   public void setSampleInterval(int sampleInterval)
/*     */   {
/* 211 */     this.sampleInterval = sampleInterval;
/*     */   }
/*     */ 
/*     */   public String getSampleIntervalUnit()
/*     */   {
/* 217 */     return this.sampleIntervalUnit;
/*     */   }
/*     */ 
/*     */   public void setSampleIntervalUnit(String sampleIntervalUnit)
/*     */   {
/* 223 */     this.sampleIntervalUnit = sampleIntervalUnit;
/*     */   }
/*     */ 
/*     */   public int getUploadStartTime()
/*     */   {
/* 229 */     return this.uploadStartTime;
/*     */   }
/*     */ 
/*     */   public void setUploadStartTime(int uploadStartTime)
/*     */   {
/* 235 */     this.uploadStartTime = uploadStartTime;
/*     */   }
/*     */ 
/*     */   public String getUploadStartTimeUnit()
/*     */   {
/* 241 */     return this.uploadStartTimeUnit;
/*     */   }
/*     */ 
/*     */   public void setUploadStartTimeUnit(String uploadStartTimeUnit)
/*     */   {
/* 247 */     this.uploadStartTimeUnit = uploadStartTimeUnit;
/*     */   }
/*     */ 
/*     */   public int getUploadInterval()
/*     */   {
/* 253 */     return this.uploadInterval;
/*     */   }
/*     */ 
/*     */   public void setUploadInterval(int uploadInterval)
/*     */   {
/* 259 */     this.uploadInterval = uploadInterval;
/*     */   }
/*     */ 
/*     */   public String getUploadIntervalUnit()
/*     */   {
/* 265 */     return this.uploadIntervalUnit;
/*     */   }
/*     */ 
/*     */   public void setUploadIntervalUnit(String uploadIntervalUnit)
/*     */   {
/* 271 */     this.uploadIntervalUnit = uploadIntervalUnit;
/*     */   }
/*     */ 
/*     */   public int getFrequence()
/*     */   {
/* 277 */     return this.frequence;
/*     */   }
/*     */ 
/*     */   public void setFrequence(int frequence)
/*     */   {
/* 283 */     this.frequence = frequence;
/*     */   }
/*     */ 
/*     */   public List<String> getDataCodes()
/*     */   {
/* 290 */     return this.dataCodes;
/*     */   }
/*     */ 
/*     */   public void setDataCodes(List<String> dataCodes)
/*     */   {
/* 296 */     this.dataCodes = dataCodes;
/* 297 */     this.dataCodesStr = null;
/*     */   }
/*     */ 
/*     */   public int getDonums()
/*     */   {
/* 304 */     return this.donums;
/*     */   }
/*     */ 
/*     */   public int getSavepts() {
/* 308 */     return this.savepts;
/*     */   }
/*     */ 
/*     */   public void setDonums(int donums)
/*     */   {
/* 313 */     this.donums = donums;
/*     */   }
/*     */ 
/*     */   public void setSavepts(int savepts) {
/* 317 */     this.savepts = savepts;
/*     */   }
/*     */ 
/*     */   public String toCodeValue()
/*     */   {
/* 323 */     String desc = null;
/*     */     try {
/* 325 */       StringBuffer sb = new StringBuffer();
/* 326 */       if (this.taskType.equalsIgnoreCase("01")) {
/* 327 */         sb.append(this.taskType);
/* 328 */         sb.append(",");
/* 329 */         sb.append(this.sampleStartTimeUnit);
/* 330 */         sb.append(",");
/* 331 */         sb.append(HexDump.toHex((byte)this.sampleStartTime));
/* 332 */         sb.append(",");
/* 333 */         sb.append(this.sampleIntervalUnit);
/* 334 */         sb.append(",");
/* 335 */         sb.append(HexDump.toHex((byte)this.sampleInterval));
/* 336 */         sb.append(",");
/* 337 */         sb.append(this.uploadStartTimeUnit);
/* 338 */         sb.append(",");
/* 339 */         sb.append(HexDump.toHex((byte)this.uploadStartTime));
/* 340 */         sb.append(",");
/* 341 */         sb.append(this.uploadIntervalUnit);
/* 342 */         sb.append(",");
/* 343 */         sb.append(HexDump.toHex((byte)this.uploadInterval));
/* 344 */         sb.append(",");
/* 345 */         sb.append(HexDump.toHex((byte)this.frequence));
/* 346 */         sb.append(",");
/* 347 */         sb.append(this.tn);
/* 348 */         sb.append(",");
/* 349 */         sb.append(HexDump.toHex((byte)this.savepts));
/* 350 */         sb.append(",");
/* 351 */         sb.append(HexDump.toHex((byte)this.donums));
/* 352 */         sb.append(",");
/* 353 */         sb.append(HexDump.toHex((byte)this.dataCodes.size()));
/* 354 */         sb.append(",");
/* 355 */         sb.append(getDataCodesAsString());
/*     */       }
/* 357 */       desc = sb.toString();
/*     */     } catch (Exception localException) {
/*     */     }
/* 360 */     return desc;
/*     */   }
/*     */ 
/*     */   public String getDataCodesStr()
/*     */   {
/* 367 */     return this.dataCodesStr;
/*     */   }
/*     */ 
/*     */   public void setDataCodesStr(String dataCodesStr)
/*     */   {
/* 374 */     this.dataCodesStr = dataCodesStr;
/*     */   }
/*     */ 
/*     */   public String getTaskTemplateID() {
/* 378 */     return this.taskTemplateID;
/*     */   }
/*     */ 
/*     */   public void setTaskTemplateID(String taskTemplateID) {
/* 382 */     this.taskTemplateID = taskTemplateID;
/*     */   }
/*     */ }