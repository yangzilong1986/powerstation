/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RtuAlertCode
/*    */ {
/*    */   private String code;
/* 15 */   private List<String> args = new ArrayList();
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 21 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code)
/*    */   {
/* 27 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public List<String> getArgs()
/*    */   {
/* 33 */     return this.args;
/*    */   }
/*    */ 
/*    */   public void setArgs(List<String> args)
/*    */   {
/* 39 */     if (args != null)
/* 40 */       this.args = args;
/*    */   }
/*    */ }