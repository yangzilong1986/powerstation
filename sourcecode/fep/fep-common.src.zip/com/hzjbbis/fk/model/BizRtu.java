/*     */ package com.hzjbbis.fk.model;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BizRtu
/*     */ {
/*     */   private String rtuId;
/*     */   private String deptCode;
/*     */   private String rtuProtocol;
/*     */   private String rtuType;
/*     */   private int rtua;
/*     */   private String logicAddress;
/*     */   private String manufacturer;
/*     */   private String hiAuthPassword;
/*     */   private String loAuthPassword;
/*  32 */   private Map<String, MeasuredPoint> measuredPoints = new HashMap();
/*     */ 
/*  34 */   private Map<Integer, RtuTask> tasksMap = new HashMap();
/*     */ 
/*     */   public String getRtuType()
/*     */   {
/*  40 */     return this.rtuType;
/*     */   }
/*     */ 
/*     */   public void setRtuType(String rtuType) {
/*  44 */     this.rtuType = rtuType;
/*     */   }
/*     */ 
/*     */   public MeasuredPoint getMeasuredPoint(String tn)
/*     */   {
/*  53 */     return ((MeasuredPoint)this.measuredPoints.get(tn));
/*     */   }
/*     */ 
/*     */   public void addMeasuredPoint(MeasuredPoint mp)
/*     */   {
/*  61 */     this.measuredPoints.put(mp.getTn(), mp);
/*     */   }
/*     */ 
/*     */   public void addRtuTask(RtuTask rt)
/*     */   {
/*  68 */     this.tasksMap.put(new Integer(rt.getRtuTaskNum()), rt);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  72 */     StringBuffer sb = new StringBuffer();
/*  73 */     sb.append("[id=").append(this.rtuId)
/*  74 */       .append(", logicAddress=").append(this.logicAddress)
/*  75 */       .append(", protocol=").append(this.rtuProtocol)
/*  76 */       .append(", manufacturer=").append(this.manufacturer).append(", ... ]");
/*  77 */     return sb.toString(); }
/*     */ 
/*     */   public RtuTask getRtuTask(String taskNum) {
/*  80 */     if ((this.tasksMap == null) || (taskNum == null)) {
/*  81 */       return null;
/*     */     }
/*  83 */     return ((RtuTask)this.tasksMap.get(new Integer(taskNum)));
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplate(String taskNum)
/*     */   {
/*  91 */     if ((this.tasksMap == null) || (taskNum == null)) {
/*  92 */       return null;
/*     */     }
/*  94 */     RtuTask rt = (RtuTask)this.tasksMap.get(new Integer(taskNum));
/*  95 */     if (rt != null) {
/*  96 */       return RtuManage.getInstance().getTaskPlateInCache(rt.getTaskTemplateID());
/*     */     }
/*     */ 
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   public String getTaskNum(List<String> dataCodes)
/*     */   {
/* 116 */     String taskNum = null; String codeStr = "";
/* 117 */     for (int i = 0; i < dataCodes.size(); ++i)
/* 118 */       codeStr = codeStr + ((String)dataCodes.get(i)) + ",";
/* 119 */     Iterator it = this.tasksMap.entrySet().iterator();
/* 120 */     while (it.hasNext()) {
/* 121 */       int icount = 0;
/* 122 */       Map.Entry entry = (Map.Entry)it.next();
/* 123 */       RtuTask rt = (RtuTask)entry.getValue();
/* 124 */       TaskTemplate ttp = RtuManage.getInstance().getTaskPlateInCache(rt.getTaskTemplateID());
/* 125 */       List codes = ttp.getDataCodes();
/* 126 */       if (dataCodes.size() >= codes.size()) {
/* 127 */         for (int i = 0; i < codes.size(); ++i)
/*     */         {
/* 129 */           if (codeStr.indexOf((String)codes.get(i)) < 0) {
/*     */             break;
/*     */           }
/* 132 */           ++icount;
/*     */         }
/* 134 */         if (codes.size() == icount)
/* 135 */           return entry.getKey();
/*     */       }
/*     */     }
/* 138 */     return taskNum;
/*     */   }
/*     */ 
/*     */   public String getRtuId()
/*     */   {
/* 146 */     return this.rtuId;
/*     */   }
/*     */ 
/*     */   public void setRtuId(String rtuId)
/*     */   {
/* 152 */     this.rtuId = rtuId;
/*     */   }
/*     */ 
/*     */   public String getRtuProtocol()
/*     */   {
/* 159 */     return this.rtuProtocol;
/*     */   }
/*     */ 
/*     */   public void setRtuProtocol(String rtuProtocol)
/*     */   {
/* 166 */     this.rtuProtocol = rtuProtocol;
/*     */   }
/*     */ 
/*     */   public int getRtua()
/*     */   {
/* 173 */     return this.rtua;
/*     */   }
/*     */ 
/*     */   public void setRtua(int rtua)
/*     */   {
/* 179 */     this.rtua = rtua;
/*     */   }
/*     */ 
/*     */   public String getLogicAddress()
/*     */   {
/* 185 */     return this.logicAddress;
/*     */   }
/*     */ 
/*     */   public void setLogicAddress(String logicAddress)
/*     */   {
/* 191 */     this.logicAddress = logicAddress;
/*     */   }
/*     */ 
/*     */   public String getManufacturer()
/*     */   {
/* 199 */     return this.manufacturer;
/*     */   }
/*     */ 
/*     */   public void setManufacturer(String manufacturer)
/*     */   {
/* 205 */     this.manufacturer = manufacturer;
/*     */   }
/*     */ 
/*     */   public String getHiAuthPassword()
/*     */   {
/* 212 */     return this.hiAuthPassword;
/*     */   }
/*     */ 
/*     */   public void setHiAuthPassword(String hiAuthPassword)
/*     */   {
/* 218 */     this.hiAuthPassword = hiAuthPassword;
/*     */   }
/*     */ 
/*     */   public String getLoAuthPassword()
/*     */   {
/* 224 */     return this.loAuthPassword;
/*     */   }
/*     */ 
/*     */   public void setLoAuthPassword(String loAuthPassword)
/*     */   {
/* 230 */     this.loAuthPassword = loAuthPassword;
/*     */   }
/*     */ 
/*     */   public String getDeptCode()
/*     */   {
/* 235 */     return this.deptCode; }
/*     */ 
/*     */   public void setDeptCode(String deptCode) {
/* 238 */     this.deptCode = deptCode;
/*     */   }
/*     */ }