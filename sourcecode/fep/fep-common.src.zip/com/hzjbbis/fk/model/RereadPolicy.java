/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class RereadPolicy
/*    */ {
/*    */   private Integer rereadPolicyID;
/*    */   private int rereadInterval;
/*    */   private int rereadRange;
/*    */   private int rereadStartTime;
/*    */   private int rereadAdvanceTime;
/*    */   private boolean rereadStartTag;
/*    */ 
/*    */   public Integer getRereadPolicyID()
/*    */   {
/* 22 */     return this.rereadPolicyID; }
/*    */ 
/*    */   public void setRereadPolicyID(Integer rereadPolicyID) {
/* 25 */     this.rereadPolicyID = rereadPolicyID; }
/*    */ 
/*    */   public int getRereadInterval() {
/* 28 */     return this.rereadInterval; }
/*    */ 
/*    */   public void setRereadInterval(int rereadInterval) {
/* 31 */     this.rereadInterval = rereadInterval; }
/*    */ 
/*    */   public int getRereadRange() {
/* 34 */     return this.rereadRange; }
/*    */ 
/*    */   public void setRereadRange(int rereadRange) {
/* 37 */     this.rereadRange = rereadRange; }
/*    */ 
/*    */   public int getRereadStartTime() {
/* 40 */     return this.rereadStartTime; }
/*    */ 
/*    */   public void setRereadStartTime(int rereadStartTime) {
/* 43 */     this.rereadStartTime = rereadStartTime; }
/*    */ 
/*    */   public int getRereadAdvanceTime() {
/* 46 */     return this.rereadAdvanceTime; }
/*    */ 
/*    */   public void setRereadAdvanceTime(int rereadAdvanceTime) {
/* 49 */     this.rereadAdvanceTime = rereadAdvanceTime; }
/*    */ 
/*    */   public boolean isRereadStartTag() {
/* 52 */     return this.rereadStartTag; }
/*    */ 
/*    */   public void setRereadStartTag(boolean rereadStartTag) {
/* 55 */     this.rereadStartTag = rereadStartTag;
/*    */   }
/*    */ }