/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ public class TaskDbConfigItem
/*    */ {
/*    */   private String tableName;
/*    */   private String fieldName;
/*    */   private String tag;
/*    */   private String taskPropertyStr;
/*    */ 
/*    */   public String getFieldName()
/*    */   {
/* 16 */     return this.fieldName; }
/*    */ 
/*    */   public void setFieldName(String fieldName) {
/* 19 */     this.fieldName = fieldName; }
/*    */ 
/*    */   public String getTableName() {
/* 22 */     return this.tableName; }
/*    */ 
/*    */   public void setTableName(String tableName) {
/* 25 */     this.tableName = tableName; }
/*    */ 
/*    */   public String getTag() {
/* 28 */     return this.tag; }
/*    */ 
/*    */   public void setTag(String tag) {
/* 31 */     this.tag = tag; }
/*    */ 
/*    */   public String getTaskPropertyStr() {
/* 34 */     return this.taskPropertyStr; }
/*    */ 
/*    */   public void setTaskPropertyStr(String taskPropertyStr) {
/* 37 */     this.taskPropertyStr = taskPropertyStr;
/*    */   }
/*    */ 
/*    */   public boolean taskPropertyContains(String taskProperty) {
/* 41 */     return (this.taskPropertyStr.indexOf(taskProperty) <= -1);
/*    */   }
/*    */ }