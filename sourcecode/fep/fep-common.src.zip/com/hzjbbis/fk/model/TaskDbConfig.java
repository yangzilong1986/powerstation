/*    */ package com.hzjbbis.fk.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class TaskDbConfig
/*    */ {
/*    */   private String code;
/*    */   private String dbConfigStr;
/* 15 */   private ArrayList<TaskDbConfigItem> taskDbConfigItemList = new ArrayList();
/*    */ 
/*    */   public String getCode() {
/* 18 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code) {
/* 22 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public void addTaskDbConfigItemList(String[] s) {
/* 26 */     TaskDbConfigItem tsti = new TaskDbConfigItem();
/* 27 */     if (s.length == 4) {
/* 28 */       tsti.setTableName(s[0]);
/* 29 */       tsti.setFieldName(s[1]);
/* 30 */       tsti.setTag(s[2]);
/* 31 */       tsti.setTaskPropertyStr(s[3]);
/* 32 */       this.taskDbConfigItemList.add(tsti);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setTaskDbConfigItemList(String dbConfigStr) {
/* 37 */     String[] s = dbConfigStr.split("/");
/* 38 */     for (int i = 0; i < s.length; ++i) {
/* 39 */       String[] ss = s[i].split(";");
/* 40 */       addTaskDbConfigItemList(ss);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getDbConfigStr() {
/* 45 */     return this.dbConfigStr;
/*    */   }
/*    */ 
/*    */   public void setDbConfigStr(String dbConfigStr) {
/* 49 */     this.dbConfigStr = dbConfigStr;
/* 50 */     setTaskDbConfigItemList(dbConfigStr);
/*    */   }
/*    */ 
/*    */   public ArrayList<TaskDbConfigItem> getTaskDbConfigItemList() {
/* 54 */     return this.taskDbConfigItemList;
/*    */   }
/*    */ }