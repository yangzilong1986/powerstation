/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ArraysUtil
/*     */ {
/*     */   public static boolean contains(Object[] elements, Object element)
/*     */   {
/*  18 */     return (indexOf(elements, element) <= -1);
/*     */   }
/*     */ 
/*     */   public static int indexOf(Object[] elements, Object element)
/*     */   {
/*  28 */     if ((elements == null) || (element == null)) {
/*  29 */       return -1;
/*     */     }
/*     */ 
/*  32 */     int index = -1;
/*  33 */     for (int i = 0; i < elements.length; ++i) {
/*  34 */       if (elements[i] == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*  38 */       if (elements[i].equals(element)) {
/*  39 */         index = i;
/*  40 */         break;
/*     */       }
/*     */     }
/*     */ 
/*  44 */     return index;
/*     */   }
/*     */ 
/*     */   public static List<Object> asList(Object[] elements)
/*     */   {
/*  53 */     return asList(elements, 0, elements.length);
/*     */   }
/*     */ 
/*     */   public static List<Object> asList(Object[] elements, int offset, int length)
/*     */   {
/*  65 */     int size = length;
/*  66 */     if (offset + length >= elements.length) {
/*  67 */       size = elements.length - offset;
/*     */     }
/*     */ 
/*  70 */     List l = new ArrayList(size);
/*  71 */     for (int i = 0; i < length; ++i) {
/*  72 */       int index = offset + i;
/*  73 */       if (index >= elements.length) {
/*     */         break;
/*     */       }
/*  76 */       l.add(elements[index]);
/*     */     }
/*     */ 
/*  79 */     return l;
/*     */   }
/*     */ 
/*     */   public static String asString(Object[] elements)
/*     */   {
/*  88 */     if (elements == null) {
/*  89 */       return "null";
/*     */     }
/*     */ 
/*  92 */     StringBuffer sb = new StringBuffer();
/*  93 */     sb.append("[");
/*  94 */     for (int i = 0; i < elements.length; ++i) {
/*  95 */       if (i > 0) {
/*  96 */         sb.append(", ");
/*     */       }
/*  98 */       sb.append(elements[i].toString());
/*     */     }
/* 100 */     sb.append("]");
/*     */ 
/* 102 */     return sb.toString();
/*     */   }
/*     */ }