/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import sun.misc.Launcher;
/*     */ import sun.misc.URLClassPath;
/*     */ 
/*     */ public class ClassLoaderUtil
/*     */ {
/*     */   private static Field classes;
/*     */   private static Method addURL;
/*     */   private static URLClassLoader system;
/*     */   private static URLClassLoader ext;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  33 */       classes = ClassLoader.class.getDeclaredField("classes");
/*  34 */       addURL = URLClassLoader.class.getDeclaredMethod("addURL", 
/*  35 */         new Class[] { URL.class });
/*     */     }
/*     */     catch (Exception e) {
/*  38 */       throw new RuntimeException(e);
/*     */     }
/*  40 */     classes.setAccessible(true);
/*  41 */     addURL.setAccessible(true);
/*     */ 
/*  44 */     system = (URLClassLoader)getSystemClassLoader();
/*     */ 
/*  46 */     ext = (URLClassLoader)getExtClassLoader();
/*     */   }
/*     */ 
/*     */   public static ClassLoader getSystemClassLoader() {
/*  50 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */ 
/*     */   public static ClassLoader getExtClassLoader() {
/*  54 */     return getSystemClassLoader().getParent();
/*     */   }
/*     */ 
/*     */   public static List<Class<?>> getClassesLoadedBySystemClassLoader()
/*     */   {
/*  63 */     return getClassesLoadedByClassLoader(getSystemClassLoader());
/*     */   }
/*     */ 
/*     */   public static List<Class<?>> getClassesLoadedByExtClassLoader() {
/*  67 */     return getClassesLoadedByClassLoader(getExtClassLoader());
/*     */   }
/*     */ 
/*     */   public static List<Class<?>> getClassesLoadedByClassLoader(ClassLoader cl)
/*     */   {
/*     */     try {
/*  73 */       return ((List)classes.get(cl));
/*     */     } catch (Exception e) {
/*  75 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static URL[] getBootstrapURLs() {
/*  80 */     return Launcher.getBootstrapClassPath().getURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getSystemURLs() {
/*  84 */     return system.getURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getExtURLs() {
/*  88 */     return ext.getURLs();
/*     */   }
/*     */ 
/*     */   private static void list(PrintStream ps, URL[] classPath) {
/*  92 */     for (int i = 0; i < classPath.length; ++i)
/*  93 */       ps.println(classPath[i]);
/*     */   }
/*     */ 
/*     */   public static void listBootstrapClassPath()
/*     */   {
/*  98 */     listBootstrapClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listBootstrapClassPath(PrintStream ps) {
/* 102 */     ps.println("BootstrapClassPath:");
/* 103 */     list(ps, getBootstrapClassPath());
/*     */   }
/*     */ 
/*     */   public static void listSystemClassPath() {
/* 107 */     listSystemClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listSystemClassPath(PrintStream ps) {
/* 111 */     ps.println("SystemClassPath:");
/* 112 */     list(ps, getSystemClassPath());
/*     */   }
/*     */ 
/*     */   public static void listExtClassPath() {
/* 116 */     listExtClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listExtClassPath(PrintStream ps) {
/* 120 */     ps.println("ExtClassPath:");
/* 121 */     list(ps, getExtClassPath());
/*     */   }
/*     */ 
/*     */   public static URL[] getBootstrapClassPath() {
/* 125 */     return getBootstrapURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getSystemClassPath() {
/* 129 */     return getSystemURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getExtClassPath() {
/* 133 */     return getExtURLs();
/*     */   }
/*     */ 
/*     */   public static void addURL2SystemClassLoader(URL url) {
/*     */     try {
/* 138 */       addURL.invoke(system, new Object[] { url });
/*     */     } catch (Exception e) {
/* 140 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addURL2ExtClassLoader(URL url) {
/*     */     try {
/* 146 */       addURL.invoke(ext, new Object[] { url });
/*     */     } catch (Exception e) {
/* 148 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addClassPath(String path) {
/* 153 */     addClassPath(new File(path));
/*     */   }
/*     */ 
/*     */   public static void addExtClassPath(String path) {
/* 157 */     addExtClassPath(new File(path));
/*     */   }
/*     */ 
/*     */   public static void addClassPath(File dirOrJar) {
/*     */     try {
/* 162 */       addURL2SystemClassLoader(dirOrJar.toURL());
/*     */     } catch (MalformedURLException e) {
/* 164 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addExtClassPath(File dirOrJar) {
/*     */     try {
/* 170 */       addURL2ExtClassLoader(dirOrJar.toURL());
/*     */     } catch (MalformedURLException e) {
/* 172 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initializeClassPath() {
/* 177 */     String workDir = System.getProperty("user.dir");
/* 178 */     String classRootPath = PathUtil.getRootPath(ClassLoaderUtil.class);
/*     */ 
/* 180 */     int cnt = 1;
/* 181 */     if ((classRootPath != null) && (cnt-- > 0)) {
/*     */       try
/*     */       {
/* 184 */         File froot = new File(classRootPath);
/* 185 */         File fwork = new File(workDir);
/* 186 */         boolean same = froot.getCanonicalPath().equalsIgnoreCase(fwork.getCanonicalPath());
/* 187 */         if (!(same))
/*     */         {
/* 190 */           File fup = froot.getParentFile();
/* 191 */           boolean upsame = fup.getCanonicalPath().equalsIgnoreCase(fwork.getCanonicalPath());
/* 192 */           if (!(upsame))
/*     */           {
/* 196 */             boolean rootIsPlugins = froot.getName().equalsIgnoreCase("plugins");
/* 197 */             if (rootIsPlugins) {
/* 198 */               System.setProperty("user.dir", fup.getCanonicalPath());
/* 199 */               workDir = fup.getCanonicalPath();
/*     */             }
/* 204 */             else if ((froot.getName().equalsIgnoreCase("lib")) || 
/* 205 */               (froot.getName().equalsIgnoreCase("libs"))) {
/* 206 */               addDir2ClassPath(froot.getAbsolutePath(), true);
/* 207 */               addClassPath(fup.getAbsolutePath());
/*     */ 
/* 209 */               System.setProperty("user.dir", fup.getCanonicalPath());
/* 210 */               workDir = fup.getCanonicalPath();
/*     */             }
/* 214 */             else if ((fup.getName().equalsIgnoreCase("lib")) || 
/* 215 */               (fup.getName().equalsIgnoreCase("libs"))) {
/* 216 */               File fupup = fup.getParentFile();
/*     */ 
/* 218 */               addDir2ClassPath(fup.getAbsolutePath(), true);
/* 219 */               addClassPath(fupup.getAbsolutePath());
/*     */ 
/* 221 */               System.setProperty("user.dir", fupup.getCanonicalPath());
/* 222 */               workDir = fupup.getCanonicalPath();
/*     */             }
/*     */             else
/*     */             {
/* 227 */               boolean upIsPlugins = fup.getName().equalsIgnoreCase("plugins");
/* 228 */               if (upIsPlugins) {
/* 229 */                 System.setProperty("user.dir", fup.getParentFile().getCanonicalPath());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception exp)
/*     */       {
/* 237 */         exp.printStackTrace();
/* 238 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 242 */     File file = new File("log");
/* 243 */     if ((file != null) && 
/* 245 */       (!(file.isDirectory()))) {
/* 246 */       file.mkdir();
/*     */     }
/*     */ 
/* 249 */     addDir2ClassPath(".", false);
/* 250 */     addDir2ClassPath(workDir + File.separator + "classess", false);
/* 251 */     addDir2ClassPath(workDir + File.separator + "lib", true);
/* 252 */     addDir2ClassPath(workDir + File.separator + "libs", true);
/* 253 */     addDir2ClassPath(workDir + File.separator + "config", false);
/* 254 */     addDir2ClassPath(workDir + File.separator + "images", false);
/* 255 */     addDir2ClassPath(workDir + File.separator + "icons", false);
/* 256 */     addDir2ClassPath(workDir + File.separator + "configuration", false);
/* 257 */     addDir2ClassPath(workDir + File.separator + "cfg", false);
/* 258 */     listSystemClassPath();
/* 259 */     loadPropertieFile2SystemProperties();
/*     */   }
/*     */ 
/*     */   private static void addFile2ClassPath(String filename) {
/* 263 */     File file = new File(filename);
/* 264 */     if (!(file.isFile()))
/* 265 */       return;
/* 266 */     if (filename.toLowerCase().endsWith(".jar")) {
/* 267 */       addClassPath(file);
/*     */     }
/* 269 */     if (filename.toLowerCase().endsWith(".zip"))
/* 270 */       addClassPath(file);
/*     */   }
/*     */ 
/*     */   private static void addDir2ClassPath(String dir, boolean includeSub)
/*     */   {
/* 275 */     File file = new File(dir);
/* 276 */     if ((!(file.exists())) || (!(file.isDirectory()))) {
/* 277 */       return;
/*     */     }
/* 279 */     if (dir.equalsIgnoreCase("."))
/*     */     {
/* 281 */       classPath = null;
/*     */       try {
/* 283 */         classPath = file.getCanonicalPath();
/*     */       }
/*     */       catch (Exception exp) {
/* 286 */         return;
/*     */       }
/* 288 */       addClassPath(classPath);
/* 289 */       return;
/*     */     }
/*     */ 
/* 292 */     dir = file.getName();
/* 293 */     String classPath = null;
/*     */     try {
/* 295 */       classPath = file.getCanonicalPath();
/*     */     }
/*     */     catch (Exception exp) {
/* 298 */       return;
/*     */     }
/*     */ 
/* 301 */     if ((dir.equalsIgnoreCase("com")) || 
/* 302 */       (dir.equalsIgnoreCase("org")))
/*     */     {
/* 304 */       addClassPath(file.getParent());
/* 305 */       return;
/*     */     }
/* 307 */     if ((dir.equalsIgnoreCase("config")) || 
/* 308 */       (dir.equalsIgnoreCase("configuration")) || 
/* 309 */       (dir.equalsIgnoreCase("classes")) || 
/* 310 */       (dir.equalsIgnoreCase("cfg")))
/*     */     {
/* 312 */       addClassPath(classPath);
/* 313 */       return;
/*     */     }
/*     */ 
/* 324 */     if (!(includeSub)) {
/* 325 */       return;
/*     */     }
/* 327 */     File[] files = file.listFiles();
/* 328 */     for (int i = 0; i < files.length; ++i)
/* 329 */       if (files[i].isFile()) {
/* 330 */         addFile2ClassPath(files[i].getPath()); } else {
/* 331 */         if (!(files[i].isDirectory()))
/*     */           continue;
/* 333 */         addDir2ClassPath(files[i].getPath(), includeSub);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static final void loadPropertieFile2SystemProperties()
/*     */   {
/* 343 */     String curPath = System.getProperty("user.dir");
/* 344 */     String propFilePattern = ".*\\.properties";
/* 345 */     Pattern pattern = Pattern.compile(propFilePattern);
/* 346 */     FilenameFilter filter = new FilenameFilter(pattern) {
/*     */       public boolean accept(File dir, String name) {
/* 348 */         return ClassLoaderUtil.this.matcher(name).matches();
/*     */       }
/*     */     };
/* 351 */     searchPropertiesFile(curPath, filter);
/* 352 */     searchPropertiesFile(curPath + File.separator + "cfg", filter);
/* 353 */     searchPropertiesFile(curPath + File.separator + "config", filter);
/* 354 */     searchPropertiesFile(curPath + File.separator + "configuration", filter);
/* 355 */     searchPropertiesFile(curPath + File.separator + "bin", filter);
/* 356 */     searchPropertiesFile(curPath + File.separator + "classess", filter);
/*     */   }
/*     */ 
/*     */   private static final void searchPropertiesFile(String dirPath, FilenameFilter filter) {
/*     */     try {
/* 361 */       File f = new File(dirPath);
/* 362 */       if ((!(f.exists())) || (!(f.isDirectory()))) {
/* 363 */         return;
/*     */       }
/* 365 */       File[] pfs = f.listFiles(filter);
/* 366 */       for (File pf : pfs) {
/* 367 */         Properties props = new Properties();
/* 368 */         props.load(new FileInputStream(pf));
/* 369 */         Enumeration pnames = props.propertyNames();
/* 370 */         while (pnames.hasMoreElements()) {
/* 371 */           String propName = (String)pnames.nextElement();
/* 372 */           String propValue = props.getProperty(propName);
/* 373 */           System.setProperty("app." + propName, propValue);
/* 374 */           System.out.println("add sys propertie:(app." + propName + "," + propValue + ")");
/*     */         }
/*     */       }
/*     */     } catch (Exception exp) {
/* 378 */       exp.printStackTrace();
/*     */     }
/*     */   }
/*     */ }