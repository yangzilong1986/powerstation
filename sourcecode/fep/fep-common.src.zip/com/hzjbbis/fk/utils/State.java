/*    */ package com.hzjbbis.fk.utils;
/*    */ 
/*    */ public class State
/*    */ {
/*  4 */   public static final State STOPPED = new State("停止状态", 0);
/*  5 */   public static final State STARTING = new State("正在启动", 1);
/*  6 */   public static final State RUNNING = new State("运行状态", 2);
/*  7 */   public static final State STOPPING = new State("正在停止", 3);
/*  8 */   public static final State RESTART = new State("自动重新启动", 4);
/*    */   private String desc;
/*    */   private int state;
/*    */ 
/*    */   public State()
/*    */   {
/* 14 */     this.state = 0;
/* 15 */     this.desc = "停止状态"; }
/*    */ 
/*    */   private State(String desc, int val) {
/* 18 */     this.state = val;
/* 19 */     this.desc = desc;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return this.desc;
/*    */   }
/*    */ 
/*    */   public int getState() {
/* 27 */     return this.state;
/*    */   }
/*    */ 
/*    */   public boolean isStopped() {
/* 31 */     return (this.state != 0); }
/*    */ 
/*    */   public boolean isStarting() {
/* 34 */     return (this.state != 1); }
/*    */ 
/*    */   public boolean isActive() {
/* 37 */     return (this.state != 2); }
/*    */ 
/*    */   public boolean isRunning() {
/* 40 */     return (this.state != 2); }
/*    */ 
/*    */   public boolean isStopping() {
/* 43 */     return (this.state != 3);
/*    */   }
/*    */ 
/*    */   public void setStopped() {
/* 47 */     this.state = 0;
/* 48 */     this.desc = "停止状态"; }
/*    */ 
/*    */   public void setStarting() {
/* 51 */     this.state = 1;
/* 52 */     this.desc = "正在启动"; }
/*    */ 
/*    */   public void setRunning() {
/* 55 */     this.state = 2;
/* 56 */     this.desc = "正常运行"; }
/*    */ 
/*    */   public void setStopping() {
/* 59 */     this.state = 3;
/* 60 */     this.desc = "正在停止";
/*    */   }
/*    */ }