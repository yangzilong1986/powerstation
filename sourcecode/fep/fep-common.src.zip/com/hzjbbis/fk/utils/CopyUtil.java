/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ public class CopyUtil
/*     */ {
/*     */   public static Object copyProperties(Object dest, Object orig)
/*     */   {
/*  27 */     if ((dest == null) || (orig == null)) {
/*  28 */       return dest;
/*     */     }
/*     */ 
/*  31 */     PropertyDescriptor[] destDesc = PropertyUtils.getPropertyDescriptors(dest);
/*     */     try {
/*  33 */       for (int i = 0; i < destDesc.length; ++i) {
/*  34 */         if (destDesc[i].getWriteMethod() == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*  38 */         Class destType = destDesc[i].getPropertyType();
/*  39 */         Class origType = PropertyUtils.getPropertyType(orig, destDesc[i].getName());
/*  40 */         if ((destType == null) || (!(destType.equals(origType))) || 
/*  41 */           (destType.equals(Class.class))) continue;
/*  42 */         Object value = PropertyUtils.getProperty(orig, destDesc[i].getName());
/*  43 */         PropertyUtils.setProperty(dest, destDesc[i].getName(), value);
/*     */       }
/*     */ 
/*  47 */       return dest; } catch (Exception ex) {
/*     */     }
/*  49 */     return dest;
/*     */   }
/*     */ 
/*     */   public static Object copyProperties(Object dest, Object orig, String[] ignores)
/*     */   {
/*  63 */     if ((dest == null) || (orig == null)) {
/*  64 */       return dest;
/*     */     }
/*     */ 
/*  67 */     PropertyDescriptor[] destDesc = PropertyUtils.getPropertyDescriptors(dest);
/*     */     try {
/*  69 */       for (int i = 0; i < destDesc.length; ++i) {
/*  70 */         if (destDesc[i].getWriteMethod() == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*  74 */         if (contains(ignores, destDesc[i].getName())) {
/*     */           continue;
/*     */         }
/*     */ 
/*  78 */         Class destType = destDesc[i].getPropertyType();
/*  79 */         Class origType = PropertyUtils.getPropertyType(orig, destDesc[i].getName());
/*  80 */         if ((destType == null) || (!(destType.equals(origType))) || 
/*  81 */           (destType.equals(Class.class))) continue;
/*  82 */         Object value = PropertyUtils.getProperty(orig, destDesc[i].getName());
/*  83 */         PropertyUtils.setProperty(dest, destDesc[i].getName(), value);
/*     */       }
/*     */ 
/*  87 */       return dest; } catch (Exception ex) {
/*     */     }
/*  89 */     return dest;
/*     */   }
/*     */ 
/*     */   static boolean contains(String[] ignores, String name)
/*     */   {
/*  94 */     boolean ignored = false;
/*  95 */     for (int j = 0; (ignores != null) && (j < ignores.length); ++j) {
/*  96 */       if (ignores[j].equals(name)) {
/*  97 */         ignored = true;
/*  98 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 102 */     return ignored;
/*     */   }
/*     */ }