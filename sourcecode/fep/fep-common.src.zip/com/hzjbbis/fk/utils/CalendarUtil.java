/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class CalendarUtil
/*     */ {
/*  14 */   private static final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  15 */   private static final SimpleDateFormat shortDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*  16 */   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  17 */   private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
/*  18 */   private static final SimpleDateFormat shortTimeFormat = new SimpleDateFormat("HH:mm");
/*  19 */   private static final SimpleDateFormat fullFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss S");
/*  20 */   private static final SimpleDateFormat milliFormat = new SimpleDateFormat("HH:mm:ss.SSS");
/*     */ 
/*     */   public static Calendar getBeginOfToday()
/*     */   {
/*  27 */     Calendar date = Calendar.getInstance();
/*  28 */     clearTimePart(date);
/*  29 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getEndOfToday()
/*     */   {
/*  37 */     Calendar date = Calendar.getInstance();
/*  38 */     setLastTimeOfDay(date);
/*  39 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar clearTimePart(Calendar date)
/*     */   {
/*  49 */     date.set(11, 0);
/*  50 */     date.set(12, 0);
/*  51 */     date.set(13, 0);
/*  52 */     date.set(14, 0);
/*     */ 
/*  54 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar setLastTimeOfDay(Calendar date)
/*     */   {
/*  63 */     date.set(9, 1);
/*  64 */     date.set(11, 23);
/*  65 */     date.set(12, 59);
/*  66 */     date.set(13, 59);
/*  67 */     date.set(14, 999);
/*  68 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getFirstDayOfYear(int year)
/*     */   {
/*  77 */     Calendar date = Calendar.getInstance();
/*  78 */     date.set(1, year);
/*  79 */     date.set(2, 0);
/*  80 */     date.set(5, 1);
/*  81 */     clearTimePart(date);
/*     */ 
/*  83 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getLastDayOfYear(int year)
/*     */   {
/*  92 */     Calendar date = Calendar.getInstance();
/*  93 */     date.set(1, year);
/*  94 */     date.set(2, 11);
/*  95 */     date.set(5, 31);
/*  96 */     date.set(10, 11);
/*  97 */     setLastTimeOfDay(date);
/*     */ 
/*  99 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar parse(String val)
/*     */   {
/* 109 */     if (val == null) {
/* 110 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 114 */       Date date = null;
/* 115 */       String s = val.trim();
/* 116 */       int indexOfDateDelim = s.indexOf("-");
/* 117 */       int indexOfTimeDelim = s.indexOf(":");
/* 118 */       int indexOfTimeDelim2 = s.indexOf(":", indexOfTimeDelim + 1);
/* 119 */       if ((indexOfDateDelim < 0) && (indexOfTimeDelim > 0)) {
/* 120 */         if (indexOfTimeDelim2 > 0) {
/* 121 */           date = timeFormat.parse(s);
/*     */         }
/*     */         else {
/* 124 */           date = shortTimeFormat.parse(s);
/*     */         }
/*     */       }
/* 127 */       else if ((indexOfDateDelim > 0) && (indexOfTimeDelim < 0)) {
/* 128 */         date = dateFormat.parse(s);
/*     */       }
/* 131 */       else if (indexOfTimeDelim2 > 0) {
/* 132 */         date = dateTimeFormat.parse(s);
/*     */       }
/*     */       else {
/* 135 */         date = shortDateTimeFormat.parse(s);
/*     */       }
/*     */ 
/* 139 */       Calendar cal = Calendar.getInstance();
/* 140 */       cal.setTime(date);
/* 141 */       return cal;
/*     */     }
/*     */     catch (ParseException ex) {
/* 144 */       throw new IllegalArgumentException(val + " is invalid date format");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static long getTimeMillis(Calendar time)
/*     */   {
/* 154 */     if (time == null) {
/* 155 */       return 0L;
/*     */     }
/*     */ 
/* 158 */     return (time.get(11) * 3600000L + 
/* 159 */       time.get(12) * 60000L + 
/* 160 */       time.get(13) * 1000L + 
/* 161 */       time.get(14));
/*     */   }
/*     */ 
/*     */   public static int compareTime(Calendar time1, Calendar time2)
/*     */   {
/* 171 */     long ms1 = getTimeMillis(time1);
/* 172 */     long ms2 = getTimeMillis(time2);
/* 173 */     if (ms1 == ms2) {
/* 174 */       return 0;
/*     */     }
/* 176 */     if (ms1 > ms2) {
/* 177 */       return 1;
/*     */     }
/*     */ 
/* 180 */     return -1;
/*     */   }
/*     */ 
/*     */   public static Calendar parse(String val, Calendar defaultValue)
/*     */   {
/*     */     try
/*     */     {
/* 193 */       return parse(val);
/*     */     } catch (Exception ex) {
/*     */     }
/* 196 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   public static String getTimeString(long milliseconds)
/*     */   {
/* 201 */     Date date = new Date(milliseconds);
/* 202 */     return timeFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static String getDateTimeString(long milliseconds) {
/* 206 */     Date date = new Date(milliseconds);
/* 207 */     return dateTimeFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static String getDateString(long milliseconds) {
/* 211 */     Date date = new Date(milliseconds);
/* 212 */     return dateFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static String getFullDateTimeString(long milliseconds) {
/* 216 */     Date date = new Date(milliseconds);
/* 217 */     return fullFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static String getMilliDateTimeString(long milliseconds) {
/* 221 */     Date date = new Date(milliseconds);
/* 222 */     return milliFormat.format(date);
/*     */   }
/*     */ }