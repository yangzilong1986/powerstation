/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class HexDump
/*     */ {
/*     */   private static final byte[] highDigits;
/*     */   private static final byte[] lowDigits;
/*     */ 
/*     */   static
/*     */   {
/*  20 */     byte[] digits = 
/*  21 */       { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*     */ 
/*  24 */     byte[] high = new byte[256];
/*  25 */     byte[] low = new byte[256];
/*     */ 
/*  27 */     for (int i = 0; i < 256; ++i) {
/*  28 */       high[i] = digits[(i >>> 4)];
/*  29 */       low[i] = digits[(i & 0xF)];
/*     */     }
/*     */ 
/*  32 */     highDigits = high;
/*  33 */     lowDigits = low;
/*     */   }
/*     */ 
/*     */   public static String hexDump(ByteBuffer in) {
/*  37 */     if (in == null)
/*  38 */       return "null";
/*  39 */     int size = in.remaining();
/*     */ 
/*  41 */     if (size == 0) {
/*  42 */       return "empty";
/*     */     }
/*     */ 
/*  45 */     StringBuffer out = new StringBuffer(in.remaining() * 3 - 1);
/*     */ 
/*  48 */     int i = in.position();
/*     */ 
/*  51 */     int byteValue = in.get(i) & 0xFF;
/*  52 */     out.append((char)highDigits[byteValue]);
/*  53 */     out.append((char)lowDigits[byteValue]);
/*  54 */     --size;
/*  55 */     ++i;
/*     */ 
/*  57 */     for (; size > 0; --size) {
/*  58 */       out.append(' ');
/*  59 */       byteValue = in.get(i) & 0xFF;
/*  60 */       out.append((char)highDigits[byteValue]);
/*  61 */       out.append((char)lowDigits[byteValue]);
/*  62 */       ++i;
/*     */     }
/*     */ 
/*  67 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompact(ByteBuffer in) {
/*  71 */     if (in == null)
/*  72 */       return "";
/*  73 */     int size = in.remaining();
/*     */ 
/*  75 */     if (size == 0) {
/*  76 */       return "";
/*     */     }
/*     */ 
/*  79 */     StringBuffer out = new StringBuffer(in.remaining() * 2);
/*     */ 
/*  81 */     int i = in.position();
/*     */ 
/*  87 */     for (; size > 0; --size) {
/*  88 */       int byteValue = in.get(i) & 0xFF;
/*  89 */       out.append((char)highDigits[byteValue]);
/*  90 */       out.append((char)lowDigits[byteValue]);
/*  91 */       ++i;
/*     */     }
/*     */ 
/*  96 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompactSilent(ByteBuffer in) {
/* 100 */     if (in == null)
/* 101 */       return "";
/* 102 */     int size = in.remaining();
/*     */ 
/* 104 */     if (size == 0) {
/* 105 */       return "";
/*     */     }
/*     */ 
/* 108 */     StringBuffer out = new StringBuffer(in.remaining() * 2);
/*     */ 
/* 112 */     int i = in.position();
/* 113 */     for (; size > 0; --size) {
/* 114 */       int byteValue = in.get(i) & 0xFF;
/* 115 */       out.append((char)highDigits[byteValue]);
/* 116 */       out.append((char)lowDigits[byteValue]);
/* 117 */       ++i;
/*     */     }
/*     */ 
/* 120 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDump(byte[] in, int offset, int length) {
/* 124 */     int size = in.length;
/* 125 */     if ((size == 0) || (length < 0) || (length > size) || (offset < 0) || (offset > size)) {
/* 126 */       return "empty";
/*     */     }
/* 128 */     if (offset + length > size) {
/* 129 */       return "empty";
/*     */     }
/*     */ 
/* 132 */     StringBuffer out = new StringBuffer(length * 3 - 1);
/*     */ 
/* 135 */     int byteValue = in[(offset++)] & 0xFF;
/* 136 */     out.append((char)highDigits[byteValue]);
/* 137 */     out.append((char)lowDigits[byteValue]);
/* 138 */     --length;
/*     */ 
/* 141 */     for (; length > 0; --length) {
/* 142 */       out.append(' ');
/* 143 */       byteValue = in[(offset++)] & 0xFF;
/* 144 */       out.append((char)highDigits[byteValue]);
/* 145 */       out.append((char)lowDigits[byteValue]);
/*     */     }
/*     */ 
/* 148 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompact(byte[] in, int offset, int length) {
/* 152 */     if (in == null)
/* 153 */       return "";
/* 154 */     int size = in.length;
/* 155 */     if ((size == 0) || (length < 0) || (length > size) || (offset < 0) || (offset > size)) {
/* 156 */       return "";
/*     */     }
/* 158 */     if (offset + length > size) {
/* 159 */       return "";
/*     */     }
/*     */ 
/* 162 */     StringBuffer out = new StringBuffer(length * 2);
/*     */ 
/* 167 */     for (; length > 0; --length) {
/* 168 */       int byteValue = in[(offset++)] & 0xFF;
/* 169 */       out.append((char)highDigits[byteValue]);
/* 170 */       out.append((char)lowDigits[byteValue]);
/*     */     }
/*     */ 
/* 173 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(byte byteValue) {
/* 177 */     StringBuffer out = new StringBuffer(2);
/* 178 */     int index = byteValue & 0xFF;
/* 179 */     out.append((char)highDigits[index]);
/* 180 */     out.append((char)lowDigits[index]);
/* 181 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(short shortValue) {
/* 185 */     StringBuffer out = new StringBuffer(5);
/* 186 */     int index = shortValue >> 8 & 0xFF;
/* 187 */     out.append((char)highDigits[index]);
/* 188 */     out.append((char)lowDigits[index]);
/* 189 */     index = shortValue & 0xFF;
/* 190 */     out.append((char)highDigits[index]);
/* 191 */     out.append((char)lowDigits[index]);
/* 192 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(int i)
/*     */   {
/* 197 */     StringBuffer out = new StringBuffer(8);
/*     */ 
/* 200 */     int index = i >> 24 & 0xFF;
/* 201 */     out.append((char)highDigits[index]);
/* 202 */     out.append((char)lowDigits[index]);
/* 203 */     index = i >> 16 & 0xFF;
/* 204 */     out.append((char)highDigits[index]);
/* 205 */     out.append((char)lowDigits[index]);
/* 206 */     index = i >> 8 & 0xFF;
/* 207 */     out.append((char)highDigits[index]);
/* 208 */     out.append((char)lowDigits[index]);
/* 209 */     index = i & 0xFF;
/* 210 */     out.append((char)highDigits[index]);
/* 211 */     out.append((char)lowDigits[index]);
/* 212 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static ByteBuffer toByteBuffer(String str) {
/* 216 */     ByteBuffer buff = ByteBuffer.wrap(new byte[str.length() / 2]);
/*     */ 
/* 219 */     for (int i = 0; i < str.length() - 1; i += 2) {
/* 220 */       char c1 = str.charAt(i);
/* 221 */       char c2 = str.charAt(i + 1);
/* 222 */       byte b1 = (byte)(char2byte(c1) << 4 | 0xF & char2byte(c2));
/* 223 */       buff.put(b1);
/*     */     }
/* 225 */     buff.flip();
/* 226 */     return buff;
/*     */   }
/*     */ 
/*     */   public static ByteBuffer toByteBuffer(ByteBuffer dest, String str) {
/* 230 */     if ((str == null) || (str.length() == 0)) {
/* 231 */       return dest;
/*     */     }
/*     */ 
/* 234 */     for (int i = 0; i < str.length() - 1; i += 2) {
/* 235 */       char c1 = str.charAt(i);
/* 236 */       char c2 = str.charAt(i + 1);
/* 237 */       byte b1 = (byte)(char2byte(c1) << 4 | 0xF & char2byte(c2));
/* 238 */       dest.put(b1);
/*     */     }
/* 240 */     return dest;
/*     */   }
/*     */ 
/*     */   private static byte char2byte(char c) {
/* 244 */     if ((c >= '0') && (c <= '9'))
/* 245 */       return (byte)(c - '0');
/* 246 */     if ((c >= 'A') && (c <= 'F'))
/* 247 */       return (byte)(c - 'A' + 10);
/* 248 */     if ((c >= 'a') && (c <= 'f'))
/* 249 */       return (byte)(c - 'a' + 10);
/* 250 */     return 0;
/*     */   }
/*     */ }