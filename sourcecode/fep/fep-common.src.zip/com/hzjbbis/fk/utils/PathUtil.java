/*     */ package com.hzjbbis.fk.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ 
/*     */ public class PathUtil
/*     */ {
/*     */   public static String getPathFromClass(Class<?> cls)
/*     */     throws IOException
/*     */   {
/*  46 */     String path = null;
/*  47 */     if (cls == null) {
/*  48 */       throw new NullPointerException();
/*     */     }
/*  50 */     URL url = getClassLocationURL(cls);
/*  51 */     if (url != null) {
/*  52 */       path = url.getPath();
/*  53 */       if ("jar".equalsIgnoreCase(url.getProtocol())) {
/*     */         try {
/*  55 */           path = new URL(path).getPath();
/*     */         } catch (MalformedURLException localMalformedURLException) {
/*     */         }
/*  58 */         int location = path.indexOf("!/");
/*  59 */         if (location != -1) {
/*  60 */           path = path.substring(0, location);
/*     */         }
/*     */       }
/*  63 */       File file = new File(path);
/*  64 */       path = file.getCanonicalPath();
/*     */     }
/*  66 */     return path;
/*     */   }
/*     */ 
/*     */   public static String getFullPathRelateClass(String relatedPath, Class<?> cls)
/*     */     throws IOException
/*     */   {
/*  86 */     String path = null;
/*  87 */     if (relatedPath == null) {
/*  88 */       throw new NullPointerException();
/*     */     }
/*  90 */     String clsPath = getPathFromClass(cls);
/*  91 */     File clsFile = new File(clsPath);
/*  92 */     String tempPath = clsFile.getParent() + File.separator + relatedPath;
/*  93 */     File file = new File(tempPath);
/*  94 */     path = file.getCanonicalPath();
/*  95 */     return path;
/*     */   }
/*     */ 
/*     */   private static URL getClassLocationURL(Class<?> cls)
/*     */   {
/* 102 */     if (cls == null)
/* 103 */       throw new IllegalArgumentException("null input: cls");
/* 104 */     URL result = null;
/* 105 */     String clsAsResource = cls.getName().replace('.', '/').concat(
/* 106 */       ".class");
/* 107 */     ProtectionDomain pd = cls.getProtectionDomain();
/*     */ 
/* 113 */     if (pd != null) {
/* 114 */       CodeSource cs = pd.getCodeSource();
/*     */ 
/* 117 */       if (cs != null) {
/* 118 */         result = cs.getLocation();
/*     */       }
/* 120 */       if ((result != null) && 
/* 124 */         ("file".equals(result.getProtocol()))) {
/*     */         try {
/* 126 */           if ((result.toExternalForm().endsWith(".jar")) || 
/* 127 */             (result.toExternalForm().endsWith(".zip"))) {
/* 128 */             result = new URL("jar:".concat(
/* 129 */               result.toExternalForm()).concat("!/")
/* 130 */               .concat(clsAsResource));
/*     */ 
/* 128 */             break label160:
/*     */           }
/*     */ 
/* 131 */           if (new File(result.getFile()).isDirectory())
/* 132 */             result = new URL(result, clsAsResource);
/*     */         }
/*     */         catch (MalformedURLException localMalformedURLException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/* 139 */     if (result == null)
/*     */     {
/* 144 */       label160: ClassLoader clsLoader = cls.getClassLoader();
/* 145 */       result = (clsLoader != null) ? clsLoader.getResource(clsAsResource) : 
/* 146 */         ClassLoader.getSystemResource(clsAsResource);
/*     */     }
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getRootPath(Class<?> cls) {
/*     */     try {
/* 153 */       if (cls == null)
/* 154 */         cls = PathUtil.class;
/* 155 */       String classPath = getPathFromClass(cls);
/* 156 */       if (classPath == null)
/* 157 */         return null;
/* 158 */       String lowClassPath = classPath.toLowerCase();
/* 159 */       if ((lowClassPath.endsWith(".jar")) || 
/* 160 */         (lowClassPath.endsWith(".zip"))) {
/* 161 */         File file = new File(classPath);
/* 162 */         return file.getParent();
/*     */       }
/*     */ 
/* 165 */       String className = cls.getName().replace('.', File.separatorChar);
/* 166 */       int index = classPath.lastIndexOf(className);
/* 167 */       if (index < 0)
/* 168 */         return null;
/* 169 */       return classPath.substring(0, index);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 173 */       e.printStackTrace();
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getConfigFilePath(String filename)
/*     */   {
/*     */     try {
/* 181 */       File file = new File(filename);
/* 182 */       if (file.exists()) {
/* 183 */         return file.getCanonicalPath();
/*     */       }
/*     */ 
/* 186 */       String curPath = System.getProperty("user.dir") + File.separator;
/* 187 */       file = new File(curPath + "config" + File.separator + filename);
/* 188 */       if (file.exists())
/* 189 */         return file.getCanonicalPath();
/* 190 */       file = new File(curPath + "configuration" + File.separator + filename);
/* 191 */       if (file.exists())
/* 192 */         return file.getCanonicalPath();
/* 193 */       file = new File(curPath + "cfg" + File.separator + filename);
/* 194 */       if (file.exists()) {
/* 195 */         return file.getCanonicalPath();
/*     */       }
/*     */ 
/* 198 */       String rootPath = getRootPath(null);
/* 199 */       if (rootPath == null)
/* 200 */         return null;
/* 201 */       if (rootPath.charAt(rootPath.length() - 1) != File.separatorChar)
/* 202 */         rootPath = rootPath + File.separator;
/* 203 */       String path = rootPath + filename;
/* 204 */       file = new File(path);
/* 205 */       if (file.exists()) {
/* 206 */         return file.getCanonicalPath();
/*     */       }
/* 208 */       file = new File(rootPath + "config" + File.separator + filename);
/* 209 */       if (file.exists())
/* 210 */         return file.getCanonicalPath();
/* 211 */       file = new File(rootPath + "configuration" + File.separator + filename);
/* 212 */       if (file.exists())
/* 213 */         return file.getCanonicalPath();
/* 214 */       file = new File(rootPath + "cfg" + File.separator + filename);
/* 215 */       if (file.exists()) {
/* 216 */         return file.getCanonicalPath();
/*     */       }
/*     */ 
/* 219 */       file = new File(rootPath);
/* 220 */       rootPath = file.getParent() + File.separator;
/* 221 */       file = new File(rootPath + filename);
/* 222 */       if (file.exists()) {
/* 223 */         return file.getCanonicalPath();
/*     */       }
/*     */ 
/* 226 */       file = new File(rootPath + "config" + File.separator + filename);
/* 227 */       if (file.exists())
/* 228 */         return file.getCanonicalPath();
/* 229 */       file = new File(rootPath + "configuration" + File.separator + filename);
/* 230 */       if (file.exists())
/* 231 */         return file.getCanonicalPath();
/* 232 */       file = new File(rootPath + "cfg" + File.separator + filename);
/* 233 */       if (!(file.exists())) break label653;
/* 234 */       return file.getCanonicalPath();
/*     */     }
/*     */     catch (Exception e) {
/* 237 */       e.printStackTrace();
/*     */     }
/* 239 */     label653: return null;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*     */     try {
/* 244 */       System.out.println("path from class 'PathUtil.class'=" + getPathFromClass(PathUtil.class));
/* 245 */       System.out.println("PathUtil's class root path=" + getRootPath(PathUtil.class));
/*     */ 
/* 247 */       System.out.println(getConfigFilePath("fas.properties"));
/*     */     } catch (Exception e) {
/* 249 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }