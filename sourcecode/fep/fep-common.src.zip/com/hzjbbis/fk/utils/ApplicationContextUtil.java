/*    */ package com.hzjbbis.fk.utils;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class ApplicationContextUtil
/*    */ {
/*  6 */   private static ApplicationContext context = null;
/*    */ 
/*    */   public static void setContext(ApplicationContext contextInput) {
/*  9 */     context = contextInput;
/*    */   }
/*    */ 
/*    */   public static ApplicationContext getContext() {
/* 13 */     return context;
/*    */   }
/*    */ 
/*    */   public static Object getBean(String id) {
/* 17 */     return context.getBean(id);
/*    */   }
/*    */ }