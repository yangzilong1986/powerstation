/*    */ package com.hzjbbis.fk.utils;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class Counter
/*    */ {
/* 12 */   private static final Log log = LogFactory.getLog(Counter.class);
/*    */   public static final long DEFAULT_LIMIT_VAL = 1000L;
/*    */   private long count;
/*    */   private long limit;
/*    */   private long time;
/*    */   private long guard;
/*    */   private long speed;
/*    */   private String name;
/*    */ 
/*    */   public Counter()
/*    */   {
/* 22 */     this(1000L, "");
/*    */   }
/*    */ 
/*    */   public Counter(long limit, String name) {
/* 26 */     this.time = System.currentTimeMillis();
/* 27 */     this.count = 0L;
/* 28 */     this.limit = limit;
/* 29 */     this.guard = 0L;
/* 30 */     this.speed = 0L;
/* 31 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public synchronized void add() {
/*    */     try {
/* 36 */       this.count += 1L;
/* 37 */       this.guard += 1L;
/* 38 */       if (this.guard >= this.limit) {
/* 39 */         this.speed = (this.guard * 60000L / (System.currentTimeMillis() - this.time));
/* 40 */         this.time = System.currentTimeMillis();
/* 41 */         this.guard = 0L;
/* 42 */         log.info(" counter--" + this.name + "'s speed is:" + this.speed + "/min , sum is " + this.count);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 46 */       this.count = 0L;
/* 47 */       this.guard = 0L;
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void add(long cc) {
/*    */     try {
/* 53 */       this.count += cc;
/* 54 */       this.guard += cc;
/* 55 */       if (this.guard >= this.limit) {
/* 56 */         long speed = this.guard * 60000L / (System.currentTimeMillis() - this.time);
/* 57 */         this.time = System.currentTimeMillis();
/* 58 */         this.guard = 0L;
/* 59 */         log.info(" counter--" + this.name + "'s speed is:" + speed + "/min , sum is " + this.count);
/*    */       }
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getSpeed()
/*    */   {
/* 70 */     return this.speed;
/*    */   }
/*    */ 
/*    */   public void setSpeed(long speed)
/*    */   {
/* 77 */     this.speed = speed;
/*    */   }
/*    */ 
/*    */   public long getCount()
/*    */   {
/* 84 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setCount(long count)
/*    */   {
/* 91 */     this.count = count;
/*    */   }
/*    */ }