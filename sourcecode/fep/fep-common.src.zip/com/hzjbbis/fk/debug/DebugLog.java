/*    */ package com.hzjbbis.fk.debug;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DebugLog
/*    */   implements IDebugLog
/*    */ {
/*  6 */   private String name = DebugLog.class.getCanonicalName();
/*    */ 
/*    */   public Logger getLogger() { return Logger.getLogger(this.name);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 12 */     this.name = name;
/*    */   }
/*    */ }