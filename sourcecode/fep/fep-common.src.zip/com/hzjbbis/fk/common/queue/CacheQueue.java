/*     */ package com.hzjbbis.fk.common.queue;
/*     */ 
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageLoader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class CacheQueue
/*     */ {
/*     */   private static String s_cachePath;
/*  36 */   private int maxSize = 10000;
/*  37 */   private int minSize = 2000;
/*  38 */   private int maxFileSize = 20;
/*  39 */   private int fileCount = 20;
/*  40 */   private String key = "undefine";
/*     */   private MessageLoader messageLoader;
/*     */   private String cachePath;
/*     */   private static final Logger log;
/*  46 */   private final ArrayList<LinkedList<IMessage>> queue = new ArrayList(6);
/*  47 */   private final ArrayList<IMessage> tempQueue = new ArrayList(this.maxSize);
/*  48 */   private final Object fileLock = new Object();
/*  49 */   private long minInterval = 10000L;
/*  50 */   private long lastCacheRead = System.currentTimeMillis() - this.minInterval;
/*  51 */   private long lastCacheWrite = System.currentTimeMillis() - this.minInterval;
/*     */ 
/*     */   static
/*     */   {
/*  28 */     String workDir = System.getProperty("user.dir");
/*  29 */     s_cachePath = workDir + File.separator + "cache";
/*  30 */     File f = new File(s_cachePath);
/*  31 */     if (!(f.exists())) {
/*  32 */       f.mkdir();
/*     */     }
/*     */ 
/*  45 */     log = Logger.getLogger(CacheQueue.class);
/*     */   }
/*     */ 
/*     */   public CacheQueue()
/*     */   {
/*  55 */     for (int i = 0; i < 6; ++i) {
/*  56 */       LinkedList list = new LinkedList();
/*  57 */       this.queue.add(list);
/*     */     }
/*     */     try {
/*  60 */       Class clz = Class.forName(MessageLoader.class.getPackage().getName() + ".MultiProtoMessageLoader");
/*  61 */       this.messageLoader = ((MessageLoader)clz.newInstance());
/*     */     } catch (ClassNotFoundException notFoundExp) {
/*  63 */       log.error(notFoundExp.getLocalizedMessage(), notFoundExp);
/*     */     } catch (Exception e) {
/*  65 */       log.error(e.getLocalizedMessage(), e);
/*     */     }
/*  67 */     this.cachePath = s_cachePath;
/*     */   }
/*     */ 
/*     */   public void offer(IMessage message)
/*     */   {
/*  75 */     if ((message.getPriority() < 0) || (message.getPriority() > 5))
/*  76 */       message.setPriority(1);
/*  77 */     synchronized (this.queue) {
/*  78 */       if (size() >= this.maxSize)
/*     */       {
/*  80 */         asyncSaveQueue();
/*     */       }
/*  82 */       ((LinkedList)this.queue.get(message.getPriority())).add(message);
/*  83 */       this.queue.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMessage poll()
/*     */   {
/*  92 */     synchronized (this.queue)
/*     */     {
/*     */       do {
/*  95 */         for (int i = 5; i >= 0; --i) {
/*  96 */           LinkedList list = (LinkedList)this.queue.get(i);
/*  97 */           if (list.size() > 0)
/*  98 */             return ((IMessage)list.remove());
/*     */         }
/*     */       }
/* 101 */       while (_loadFromFile());
/*     */ 
/* 103 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMessage peek()
/*     */   {
/* 113 */     synchronized (this.queue)
/*     */     {
/*     */       do {
/* 116 */         for (int i = 5; i >= 0; --i) {
/* 117 */           LinkedList list = (LinkedList)this.queue.get(i);
/* 118 */           if (list.size() > 0)
/* 119 */             return ((IMessage)list.getFirst());
/*     */         }
/*     */       }
/* 122 */       while (_loadFromFile());
/*     */ 
/* 124 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMessage take()
/*     */   {
/* 134 */     synchronized (this.queue)
/*     */     {
/*     */       while (true) {
/* 137 */         for (int i = 5; i >= 0; --i) {
/* 138 */           LinkedList list = (LinkedList)this.queue.get(i);
/* 139 */           if (list.size() > 0) {
/* 140 */             return ((IMessage)list.remove());
/*     */           }
/*     */         }
/* 143 */         if (_loadFromFile())
/*     */           continue;
/*     */         try {
/* 146 */           this.queue.wait();
/*     */         } catch (InterruptedException e) {
/* 148 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size() {
/* 155 */     int size = 0;
/* 156 */     for (int i = 5; i >= 0; --i) {
/* 157 */       LinkedList list = (LinkedList)this.queue.get(i);
/* 158 */       size += list.size();
/*     */     }
/* 160 */     return size;
/*     */   }
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 165 */     log.info("cacheQueue disposed. key=" + this.key);
/* 166 */     synchronized (this.tempQueue) {
/* 167 */       for (int i = 0; i <= 5; ++i) {
/* 168 */         LinkedList ar = (LinkedList)this.queue.get(i);
/* 169 */         this.tempQueue.addAll(ar);
/* 170 */         ar.clear();
/*     */       }
/* 172 */       this.lastCacheWrite = System.currentTimeMillis();
/* 173 */       __saveToFile();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void asyncSaveQueue()
/*     */   {
/* 181 */     int count = this.maxSize - this.minSize;
/* 182 */     synchronized (this.tempQueue) {
/* 183 */       long now = System.currentTimeMillis();
/* 184 */       if (now - this.lastCacheWrite < this.minInterval) {
/* 185 */         return;
/*     */       }
/* 187 */       for (int i = 0; i <= 5; ++i) {
/* 188 */         LinkedList ar = (LinkedList)this.queue.get(i);
/* 189 */         this.tempQueue.addAll(ar);
/* 190 */         count -= ar.size();
/* 191 */         ar.clear();
/* 192 */         if (count <= 0) {
/*     */           break;
/*     */         }
/*     */       }
/* 196 */       this.lastCacheWrite = System.currentTimeMillis();
/* 197 */       CacheFileWriteThread t = new CacheFileWriteThread();
/* 198 */       t.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void __saveToFile() {
/* 203 */     synchronized (this.fileLock)
/*     */     {
/* 205 */       String filename = _findWriteCacheFileName();
/*     */       try
/*     */       {
/* 208 */         PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(filename, true)));
/* 209 */         _saveMessages(out);
/* 210 */         out.close();
/* 211 */         out = null;
/*     */       }
/*     */       catch (Exception exp)
/*     */       {
/* 215 */         StringBuffer sb = new StringBuffer();
/* 216 */         sb.append("消息队列保存异常,filename=").append(filename);
/* 217 */         sb.append(",异常原因：").append(exp.getLocalizedMessage());
/* 218 */         log.error(sb.toString(), exp);
/* 219 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean _loadFromFile()
/*     */   {
/*     */     RandomAccessFile raf;
/*     */     String filename;
/* 225 */     long now = System.currentTimeMillis();
/* 226 */     if (now - this.lastCacheRead < this.minInterval)
/* 227 */       return false;
/* 228 */     this.lastCacheRead = System.currentTimeMillis();
/*     */ 
/* 230 */     synchronized (this.fileLock) {
/* 231 */       raf = null;
/* 232 */       filename = _findReadCacheFileName();
/* 233 */       if (filename != null) break label52;
/* 234 */       return false;
/* 235 */       label52: if (!(log.isDebugEnabled())) break label85;
/* 236 */       label85: log.debug("begin read cache file(开始加载缓存文件):" + filename);
/*     */     }
/*     */ 
/* 296 */     label467: return false;
/*     */   }
/*     */ 
/*     */   private void _saveMessages(PrintWriter out) {
/* 300 */     synchronized (this.tempQueue) {
/* 301 */       String strMsg = null;
/* 302 */       for (IMessage msg : this.tempQueue) {
/* 303 */         strMsg = this.messageLoader.serializeMessage(msg);
/* 304 */         if ((strMsg != null) && (strMsg.length() > 0))
/* 305 */           out.println(strMsg);
/*     */       }
/* 307 */       this.tempQueue.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String _findWriteCacheFileName()
/*     */   {
/* 316 */     String fname0 = "cache-" + this.key + "-";
/* 317 */     File f = new File(this.cachePath);
/* 318 */     File[] list = f.listFiles();
/* 319 */     if (list == null) {
/* 320 */       list = new File[0];
/*     */     }
/* 322 */     File oldestFile = null;
/* 323 */     Date oldDate = new Date(0L); Date curDate = new Date(0L);
/*     */ 
/* 325 */     for (int i = 0; i < this.fileCount; ++i) {
/* 326 */       String cname = fname0 + i + ".txt";
/* 327 */       boolean found = false;
/* 328 */       for (int j = 0; j < list.length; ++j)
/* 329 */         if (list[j].isFile()) {
/* 330 */           if (list[j].getName().indexOf(fname0) < 0) {
/*     */             continue;
/*     */           }
/* 333 */           if (oldestFile == null) {
/* 334 */             oldestFile = list[j];
/* 335 */             oldDate.setTime(oldestFile.lastModified());
/*     */           }
/*     */           else {
/* 338 */             curDate.setTime(list[j].lastModified());
/* 339 */             if (curDate.before(oldDate)) {
/* 340 */               oldDate.setTime(curDate.getTime());
/* 341 */               oldestFile = list[j];
/*     */             }
/*     */           }
/* 344 */           if (cname.equals(list[j].getName())) {
/* 345 */             found = true;
/* 346 */             File file = new File(this.cachePath + File.separator + cname);
/* 347 */             if (file.length() < this.maxFileSize * 1024 * 1024)
/*     */             {
/* 350 */               return file.getPath(); }
/*     */           }
/*     */         }
/* 353 */       if (!(found)) {
/* 354 */         return this.cachePath + File.separator + cname;
/*     */       }
/*     */     }
/* 357 */     if (oldestFile != null) {
/* 358 */       String opath = oldestFile.getPath();
/* 359 */       oldestFile.delete();
/* 360 */       return opath;
/*     */     }
/* 362 */     return this.cachePath + File.separator + fname0 + "exp.txt";
/*     */   }
/*     */ 
/*     */   public String _findReadCacheFileName()
/*     */   {
/* 370 */     String fname0 = "cache-" + this.key + "-";
/* 371 */     File f = new File(this.cachePath);
/* 372 */     File[] list = f.listFiles();
/* 373 */     if (list == null) {
/* 374 */       log.warn(f.getPath() + ":列表错误。null==list");
/* 375 */       return null;
/*     */     }
/*     */ 
/* 379 */     for (int j = 0; j < list.length; ++j) {
/* 380 */       File file = list[j];
/* 381 */       if (!(file.isFile())) continue; if (file.length() <= 0L)
/*     */         continue;
/* 383 */       String s = file.getName();
/* 384 */       if (s.indexOf(fname0) == 0)
/* 385 */         return file.getPath();
/*     */     }
/* 387 */     if (log.isDebugEnabled())
/* 388 */       log.debug(f.getPath() + ":目录下无缓存文件。");
/* 389 */     return null;
/*     */   }
/*     */ 
/*     */   public int getMaxSize() {
/* 393 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   public void setMaxSize(int maxSize) {
/* 397 */     if (maxSize <= 100)
/* 398 */       maxSize = 100;
/* 399 */     else if (maxSize > 200000)
/* 400 */       maxSize = 200000;
/* 401 */     this.maxSize = maxSize;
/* 402 */     _adjustMinSize();
/*     */   }
/*     */ 
/*     */   private void _adjustMinSize() {
/* 406 */     if ((this.minSize <= this.maxSize >> 4) || (this.minSize > this.maxSize >> 2))
/* 407 */       this.minSize = (this.maxSize >> 4);
/*     */   }
/*     */ 
/*     */   public int getMinSize() {
/* 411 */     return this.minSize;
/*     */   }
/*     */ 
/*     */   public void setMinSize(int minSize) {
/* 415 */     this.minSize = minSize;
/* 416 */     _adjustMinSize();
/*     */   }
/*     */ 
/*     */   public int getMaxFileSize() {
/* 420 */     return this.maxFileSize;
/*     */   }
/*     */ 
/*     */   public void setMaxFileSize(int maxFileSize) {
/* 424 */     if ((maxFileSize <= 0) || (maxFileSize > 500))
/* 425 */       maxFileSize = 500;
/* 426 */     this.maxFileSize = maxFileSize;
/*     */   }
/*     */ 
/*     */   public String getKey() {
/* 430 */     return this.key;
/*     */   }
/*     */ 
/*     */   public void setKey(String key) {
/* 434 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public MessageLoader getMessageLoader() {
/* 438 */     return this.messageLoader;
/*     */   }
/*     */ 
/*     */   public void setMessageLoader(MessageLoader messageLoader) {
/* 442 */     this.messageLoader = messageLoader;
/*     */   }
/*     */ 
/*     */   public void setCachePath(String cachePath)
/*     */   {
/* 461 */     this.cachePath = cachePath;
/*     */   }
/*     */ 
/*     */   public void setFileCount(int fileCount) {
/* 465 */     this.fileCount = fileCount;
/*     */   }
/*     */ 
/*     */   class CacheFileWriteThread extends Thread
/*     */   {
/*     */     public CacheFileWriteThread()
/*     */     {
/* 452 */       super("cacheWrite-" + CacheQueue.this.key);
/*     */     }
/*     */ 
/*     */     public void run() {
/* 456 */       CacheQueue.this.__saveToFile();
/*     */     }
/*     */   }
/*     */ }