/*     */ package com.hzjbbis.fk.common.events.event;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class EventHandleTimeoutAlarm
/*     */   implements IEvent
/*     */ {
/*  20 */   private final EventType type = EventType.SYS_EVENT_PROCESS_TIMEOUT;
/*     */   private Object source;
/*     */   private IEvent event;
/*     */   private String threadName;
/*     */   private long beginTime;
/*     */   private long endTime;
/*  25 */   private List<StackTraceElement> stackTraces = new ArrayList();
/*     */ 
/*     */   public long getBeginTime() {
/*  28 */     return this.beginTime;
/*     */   }
/*     */ 
/*     */   public void setBeginTime(long beginTime) {
/*  32 */     this.beginTime = beginTime;
/*     */   }
/*     */ 
/*     */   public long getEndTime() {
/*  36 */     return this.endTime;
/*     */   }
/*     */ 
/*     */   public void setEndTime(long endTime) {
/*  40 */     this.endTime = endTime;
/*     */   }
/*     */ 
/*     */   public EventHandleTimeoutAlarm(IEvent ev) {
/*  44 */     this.event = ev;
/*  45 */     this.threadName = Thread.currentThread().getName();
/*     */   }
/*     */ 
/*     */   public Object getSource() {
/*  49 */     return this.source;
/*     */   }
/*     */ 
/*     */   public EventType getType() {
/*  53 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setSource(Object src) {
/*  57 */     this.source = src;
/*     */   }
/*     */ 
/*     */   public void setType(EventType type)
/*     */   {
/*     */   }
/*     */ 
/*     */   public IEvent getTimeoutEvent()
/*     */   {
/*  68 */     return this.event;
/*     */   }
/*     */ 
/*     */   public IMessage getMessage() {
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  76 */     StringBuffer sb = new StringBuffer(1024);
/*  77 */     sb.append("事件处理超时。类型：").append(this.event.getType());
/*  78 */     sb.append(",thread=").append(this.threadName);
/*  79 */     sb.append(",begin=");
/*  80 */     Date date = new Date(getBeginTime());
/*  81 */     SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss S");
/*  82 */     sb.append(format.format(date)).append(",end=");
/*  83 */     sb.append(format.format(new Date(getEndTime()))).append("。事件内容：");
/*  84 */     sb.append(this.event.toString());
/*  85 */     sb.append("。StackTraceElement:");
/*  86 */     for (StackTraceElement st : this.stackTraces) {
/*  87 */       sb.append("\r\n\t").append(st.toString());
/*     */     }
/*  89 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getThreadName() {
/*  93 */     return this.threadName;
/*     */   }
/*     */ 
/*     */   public void setThreadName(String threadName) {
/*  97 */     this.threadName = threadName;
/*     */   }
/*     */ 
/*     */   public void setStackTraceElement(StackTraceElement[] trace) {
/* 101 */     if ((trace == null) || (trace.length == 0))
/* 102 */       return;
/* 103 */     for (StackTraceElement st : trace)
/* 104 */       this.stackTraces.add(st);
/*     */   }
/*     */ }