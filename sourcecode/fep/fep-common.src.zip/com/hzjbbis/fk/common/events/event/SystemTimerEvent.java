/*     */ package com.hzjbbis.fk.common.events.event;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SystemTimerEvent
/*     */   implements IEvent
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(SystemTimerEvent.class);
/*  22 */   private static final EventType type = EventType.SYS_TIMER;
/*     */ 
/*  24 */   private static final ArrayList<SystemTimerEvent> events = new ArrayList(128);
/*     */ 
/*  31 */   protected String name = "";
/*  32 */   protected IMessage message = null;
/*  33 */   protected Object source = null;
/*  34 */   protected int delay = 1;
/*  35 */   private long beginTime = System.currentTimeMillis();
/*     */ 
/*     */   static
/*     */   {
/*  26 */     SysTimerThread timerThread = new SysTimerThread();
/*  27 */     timerThread.start();
/*     */   }
/*     */ 
/*     */   public SystemTimerEvent(String name, Object source, IMessage msg, int delay)
/*     */   {
/*  38 */     this.name = name;
/*  39 */     this.source = source;
/*  40 */     this.message = msg;
/*  41 */     this.delay = (delay * 1000);
/*     */   }
/*     */ 
/*     */   public IMessage getMessage() {
/*  45 */     return this.message;
/*     */   }
/*     */ 
/*     */   public Object getSource() {
/*  49 */     return this.source;
/*     */   }
/*     */ 
/*     */   public EventType getType() {
/*  53 */     return type;
/*     */   }
/*     */ 
/*     */   public void setSource(Object src) {
/*  57 */     this.source = src;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  61 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  65 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public static void schedule(SystemTimerEvent event) {
/*  69 */     if (event == null)
/*  70 */       return;
/*  71 */     long now = System.currentTimeMillis();
/*  72 */     event.beginTime = now;
/*  73 */     synchronized (events)
/*     */     {
/*  75 */       for (int i = 0; i < events.size(); ++i) {
/*  76 */         SystemTimerEvent e = (SystemTimerEvent)events.get(i);
/*  77 */         long remain = e.beginTime + e.delay - now;
/*  78 */         if (event.delay < remain) {
/*  79 */           events.add(i, event);
/*  80 */           events.notifyAll();
/*     */ 
/*  82 */           return;
/*     */         }
/*     */       }
/*  85 */       events.add(event);
/*  86 */       events.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class SysTimerThread extends Thread
/*     */   {
/*     */     public SysTimerThread()
/*     */     {
/*  98 */       super("SysTimerThread");
/*  99 */       setDaemon(true);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 107 */       int cnt = 0;
/* 108 */       long checkTime = 0L;
/* 109 */       SystemTimerEvent.log.info("系统定时器守护线程开始运行...");
/*     */ 
/* 111 */       synchronized (SystemTimerEvent.events) {
/*     */         try {
/* 113 */           if (0L == checkTime)
/* 114 */             checkTime = System.currentTimeMillis();
/* 115 */           dealList();
/* 116 */           ++cnt;
/*     */         }
/*     */         catch (InterruptedException localInterruptedException) {
/*     */         }
/*     */         catch (Exception e) {
/* 121 */           SystemTimerEvent.log.warn(e.getLocalizedMessage(), e);
/*     */         }
/* 123 */         if (cnt > 1024) {
/* 124 */           cnt = 0;
/* 125 */           long now = System.currentTimeMillis();
/* 126 */           if (now - checkTime < 200L) {
/* 127 */             SystemTimerEvent.log.error("系统定时器估计进入死循环。");
/*     */           }
/* 129 */           checkTime = now;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private void dealList() throws InterruptedException
/*     */     {
/* 136 */       while (SystemTimerEvent.events.size() == 0)
/* 137 */         SystemTimerEvent.events.wait(1000L);
/* 138 */       long now = System.currentTimeMillis();
/* 139 */       SystemTimerEvent ev = (SystemTimerEvent)SystemTimerEvent.events.get(0);
/*     */ 
/* 141 */       long dif = now - ev.beginTime;
/* 142 */       if (dif >= ev.delay) {
/* 143 */         SystemTimerEvent.events.remove(0);
/* 144 */         GlobalEventHandler.postEvent(ev);
/* 145 */         return;
/*     */       }
/* 147 */       if (dif < 0L)
/* 148 */         return;
/* 149 */       if (dif < 100L)
/* 150 */         dif = 100L;
/* 151 */       SystemTimerEvent.events.wait(dif);
/*     */     }
/*     */   }
/*     */ }