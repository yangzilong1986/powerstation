/*    */ package com.hzjbbis.fk.common.events.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.events.event.EventHandleTimeoutAlarm;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class EventHandleTimeoutAdapt
/*    */   implements IEventHandler
/*    */ {
/* 20 */   private static final Logger log = Logger.getLogger(EventHandleTimeoutAdapt.class);
/*    */   private EventHandleTimeoutAlarm event;
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 24 */     this.event = ((EventHandleTimeoutAlarm)event);
/* 25 */     process();
/*    */   }
/*    */ 
/*    */   protected void process() {
/* 29 */     if (log.isInfoEnabled()) {
/* 30 */       StringBuffer sb = new StringBuffer(1024);
/* 31 */       sb.append("事件处理超时。事件类型：").append(this.event.getTimeoutEvent().getType());
/* 32 */       sb.append(",begin=");
/* 33 */       Date date = new Date(this.event.getBeginTime());
/* 34 */       SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss S");
/* 35 */       sb.append(format.format(date)).append(",end=");
/* 36 */       sb.append(format.format(new Date(this.event.getEndTime()))).append("。事件内容：");
/* 37 */       sb.append(this.event.getTimeoutEvent().toString());
/* 38 */       log.info(sb.toString());
/*    */     }
/*    */   }
/*    */ }