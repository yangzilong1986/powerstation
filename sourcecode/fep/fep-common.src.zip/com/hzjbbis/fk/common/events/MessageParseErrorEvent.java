/*    */ package com.hzjbbis.fk.common.events;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class MessageParseErrorEvent
/*    */   implements IEvent
/*    */ {
/* 16 */   private final EventType type = EventType.MSG_PARSE_ERROR;
/*    */   private IMessage message;
/*    */   private Object source;
/*    */   private String info;
/*    */ 
/*    */   public MessageParseErrorEvent(IMessage msg)
/*    */   {
/* 22 */     this.message = msg;
/* 23 */     this.source = msg.getSource();
/*    */   }
/*    */ 
/*    */   public MessageParseErrorEvent(IMessage msg, String info) {
/* 27 */     this.message = msg;
/* 28 */     this.source = msg.getSource();
/* 29 */     this.info = info;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 33 */     return this.message;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 37 */     return this.source;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 41 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/* 45 */     this.source = src;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 49 */     StringBuffer sb = new StringBuffer(512);
/* 50 */     sb.append("MessageParseErrorEvent,source=").append(this.source);
/* 51 */     sb.append(",packet=").append(this.message.getRawPacketString());
/* 52 */     if (this.info != null)
/* 53 */       sb.append(",info=").append(this.info);
/* 54 */     return sb.toString();
/*    */   }
/*    */ }