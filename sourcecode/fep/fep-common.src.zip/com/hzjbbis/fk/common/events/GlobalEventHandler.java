/*     */ package com.hzjbbis.fk.common.events;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.IEventHook;
/*     */ import com.hzjbbis.fk.common.spi.IEventPump;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public final class GlobalEventHandler
/*     */   implements IEventPump
/*     */ {
/*  27 */   private final EventQueue queue = new EventQueue();
/*     */ 
/*  31 */   private static final Object hookLock = new Object();
/*  32 */   private static ArrayList<IEventHook>[] hooks = (ArrayList[])Array.newInstance(ArrayList.class, 512);
/*     */   private static ArrayList<IEventHandler>[] handlers;
/*  39 */   private volatile State state = State.STOPPED;
/*  40 */   private static Logger log = Logger.getLogger(GlobalEventHandler.class);
/*  41 */   private static TraceLog tracer = TraceLog.getTracer();
/*     */ 
/*  43 */   private static GlobalEventHandler gHandler = null;
/*  44 */   private EventPumpThread pump = null;
/*     */ 
/*     */   static {
/*  47 */     gHandler = getInstance();
/*     */   }
/*     */ 
/*     */   private GlobalEventHandler() {
/*  51 */     this.pump = new EventPumpThread();
/*  52 */     this.pump.start();
/*     */   }
/*     */ 
/*     */   public static final GlobalEventHandler getInstance() {
/*  56 */     if (gHandler == null)
/*  57 */       gHandler = new GlobalEventHandler();
/*  58 */     return gHandler;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  62 */     this.state = State.STOPPING;
/*  63 */     this.pump.interrupt();
/*     */   }
/*     */ 
/*     */   public static final void registerHook(IEventHook hook, EventType type)
/*     */   {
/*  71 */     synchronized (hookLock) {
/*  72 */       if (hooks == null) {
/*  73 */         hooks = new ArrayList[128];
/*  74 */         Arrays.fill(hooks, null);
/*     */       }
/*  76 */       if (hooks.length < EventType.getMaxIndex()) {
/*  77 */         ArrayList[] temp = new ArrayList[EventType.getMaxIndex()];
/*  78 */         Arrays.fill(temp, null);
/*  79 */         System.arraycopy(hooks, 0, temp, 0, hooks.length);
/*  80 */         hooks = temp;
/*     */       }
/*  82 */       if (hooks[type.toInt()] == null) {
/*  83 */         hooks[type.toInt()] = new ArrayList();
/*     */       }
/*  85 */       hooks[type.toInt()].add(hook);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final void registerHandler(IEventHandler handler, EventType type)
/*     */   {
/*  96 */     synchronized (hookLock) {
/*  97 */       if (handlers == null) {
/*  98 */         handlers = new ArrayList[128];
/*  99 */         Arrays.fill(handlers, null);
/*     */       }
/* 101 */       if (handlers.length < EventType.getMaxIndex()) {
/* 102 */         ArrayList[] temp = new ArrayList[EventType.getMaxIndex()];
/* 103 */         Arrays.fill(temp, null);
/* 104 */         System.arraycopy(handlers, 0, temp, 0, handlers.length);
/* 105 */         handlers = temp;
/*     */       }
/* 107 */       if (handlers[type.toInt()] == null) {
/* 108 */         handlers[type.toInt()] = new ArrayList();
/*     */       }
/* 110 */       handlers[type.toInt()].add(handler);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final void deregisterHook(IEventHook hook, EventType type)
/*     */   {
/* 119 */     synchronized (hookLock) {
/*     */       try {
/* 121 */         hooks[type.toInt()].remove(hook);
/*     */       } catch (Exception e) {
/* 123 */         log.error("deregisterHook: " + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final void deregisterHandler(IEventHandler handler, EventType type) {
/* 129 */     synchronized (hookLock) {
/*     */       try {
/* 131 */         handlers[type.toInt()].remove(handler);
/*     */       } catch (Exception e) {
/* 133 */         log.error("deregisterHandler: " + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void handleEvent(IEvent e) {
/* 139 */     if (EventType.SYS_MEMORY_PROFILE == e.getType()) {
/* 140 */       log.info("profile事件: " + e);
/*     */     }
/*     */     else
/* 143 */       log.debug("全局事件处理器:" + e);
/*     */   }
/*     */ 
/*     */   public static void postEvent(IEvent e) {
/* 147 */     gHandler.post(e);
/*     */   }
/*     */ 
/*     */   public final void post(IEvent e) {
/* 151 */     boolean hooked = false;
/* 152 */     ArrayList list = hooks[e.getType().toInt()];
/* 153 */     if ((list != null) && (list.size() > 0)) {
/*     */       try {
/* 155 */         for (IEventHook hook : list) {
/* 156 */           hook.postEvent(e);
/*     */         }
/* 158 */         hooked = true;
/*     */       } catch (Exception exp) {
/* 160 */         log.error("hook.postEvent:" + exp.getLocalizedMessage(), exp);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 165 */     if ((handlers != null) && (handlers.length > e.getType().toInt())) {
/* 166 */       ArrayList arHandlers = handlers[e.getType().toInt()];
/* 167 */       if ((arHandlers != null) && (arHandlers.size() > 0)) {
/* 168 */         hooked = true;
/* 169 */         for (IEventHandler handler : arHandlers) {
/*     */           try {
/* 171 */             handler.handleEvent(e);
/*     */           } catch (Exception exp) {
/* 173 */             log.error("handler.handleEvent: " + exp.getLocalizedMessage(), exp);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 180 */     if (hooked) return;
/*     */     try {
/* 182 */       this.queue.offer(e);
/*     */     } catch (Exception arHandlers) {
/* 184 */       String info = "全局事件队列插入失败。event=" + e.toString();
/* 185 */       tracer.trace(info, exp);
/* 186 */       log.error(info, exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EventPumpThread extends Thread
/*     */   {
/*     */     public EventPumpThread() {
/* 193 */       super("GlobalEventPumpThread");
/* 194 */       setDaemon(true); }
/*     */ 
/*     */     public void run() {
/* 197 */       GlobalEventHandler.this.state = State.RUNNING;
/* 198 */       GlobalEventHandler.log.info("Global event handler thread running");
/* 199 */       long pre = System.currentTimeMillis();
/* 200 */       int cnt = 0;
/* 201 */       label129: while (GlobalEventHandler.this.state != State.STOPPING) {
/*     */         try {
/* 203 */           IEvent e = GlobalEventHandler.this.queue.take();
/* 204 */           if (e == null)
/*     */           {
/* 206 */             ++cnt;
/* 207 */             if (cnt >= 20) {
/* 208 */               long now = System.currentTimeMillis();
/* 209 */               if (Math.abs(now - pre) < 1000L) {
/* 210 */                 GlobalEventHandler.log.warn("检测到死循环。");
/*     */               }
/* 212 */               pre = System.currentTimeMillis();
/* 213 */               cnt = 0;
/*     */ 
/* 215 */               break label129: }
/*     */           }
/* 217 */           GlobalEventHandler.this.handleEvent(e);
/*     */         }
/*     */         catch (Exception e) {
/* 220 */           GlobalEventHandler.log.warn("Global event handler event pump catch exception:" + e.getLocalizedMessage());
/*     */         }
/*     */       }
/* 223 */       GlobalEventHandler.this.state = State.STOPPED;
/*     */     }
/*     */   }
/*     */ }