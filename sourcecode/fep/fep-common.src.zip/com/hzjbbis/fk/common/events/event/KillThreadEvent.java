/*    */ package com.hzjbbis.fk.common.events.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class KillThreadEvent
/*    */   implements IEvent
/*    */ {
/*  8 */   private final EventType type = EventType.SYS_KILLTHREAD;
/*    */ 
/*    */   public Object getSource() {
/* 11 */     return null;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 15 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 25 */     return null;
/*    */   }
/*    */ }