/*     */ package com.hzjbbis.fk.common.events;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.exception.EventQueueFullException;
/*     */ import com.hzjbbis.fk.exception.EventQueueLockedException;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class EventQueue
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 200603141443L;
/*  25 */   private static final TraceLog tracer = TraceLog.getTracer();
/*     */   private static final int DEFAULT_QUEUE_SIZE = 1024;
/*  28 */   private int capacity = 102400;
/*  29 */   private final Object lock = new Object();
/*     */   private IEvent[] events;
/*  32 */   private int first = 0;
/*  33 */   private int last = 0;
/*  34 */   private int size = 0;
/*  35 */   private int waiting = 0;
/*     */ 
/*  37 */   private boolean writable = true;
/*  38 */   private boolean readable = true;
/*     */ 
/*     */   public EventQueue(int initialCapacity)
/*     */   {
/*  45 */     this.events = new IEvent[initialCapacity];
/*     */   }
/*     */ 
/*     */   public EventQueue()
/*     */   {
/*  53 */     this.events = new IEvent[1024];
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  60 */     synchronized (this.lock) {
/*  61 */       Arrays.fill(this.events, null);
/*  62 */       this.first = 0;
/*  63 */       this.last = 0;
/*  64 */       this.size = 0;
/*  65 */       this.lock.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IEvent take()
/*     */     throws InterruptedException
/*     */   {
/*  75 */     synchronized (this.lock) {
/*  76 */       IEvent e = null;
/*  77 */       this.waiting += 1;
/*  78 */       while ((e = poll()) == null) {
/*  79 */         this.lock.wait();
/*     */       }
/*  81 */       this.waiting -= 1;
/*  82 */       return e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void put(IEvent evt)
/*     */     throws InterruptedException
/*     */   {
/*  95 */     if (evt == null)
/*  96 */       throw new NullPointerException();
/*  97 */     throw new RuntimeException("暂未实现该功能。");
/*     */   }
/*     */ 
/*     */   public boolean addFirst(IEvent evt)
/*     */     throws EventQueueLockedException, EventQueueFullException
/*     */   {
/* 106 */     if (evt == null)
/* 107 */       return false;
/* 108 */     synchronized (this.lock) {
/* 109 */       if ((evt.getType() != EventType.SYS_KILLTHREAD) && (!(this.writable)))
/* 110 */         throw new EventQueueLockedException("Invalid offer while eventQueue disable put into.");
/* 111 */       if (this.size == this.events.length)
/*     */       {
/* 113 */         if (this.size >= this.capacity)
/*     */         {
/* 115 */           String info = "超过队列允许的最大值，不能插入到队列中。size=" + this.size;
/* 116 */           tracer.trace(info);
/* 117 */           throw new EventQueueFullException(info);
/*     */         }
/* 119 */         int oldLen = this.events.length;
/* 120 */         IEvent[] newEvents = new IEvent[oldLen * 2];
/*     */ 
/* 122 */         if (this.first < this.last) {
/* 123 */           System.arraycopy(this.events, this.first, newEvents, 0, this.last - this.first);
/*     */         } else {
/* 125 */           System.arraycopy(this.events, this.first, newEvents, 0, oldLen - this.first);
/* 126 */           System.arraycopy(this.events, 0, newEvents, oldLen - this.first, this.last);
/*     */         }
/*     */ 
/* 129 */         this.first = 0;
/* 130 */         this.last = oldLen;
/* 131 */         this.events = newEvents;
/*     */       }
/*     */ 
/* 135 */       if (--this.first < 0) {
/* 136 */         this.first = (this.events.length - 1);
/*     */       }
/* 138 */       this.events[this.first] = evt;
/* 139 */       this.size += 1;
/*     */ 
/* 141 */       if (this.waiting > 0) {
/* 142 */         this.lock.notifyAll();
/*     */       }
/* 144 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IEvent poll()
/*     */   {
/* 153 */     synchronized (this.lock) {
/* 154 */       if (this.size == 0) {
/* 155 */         return null;
/*     */       }
/* 157 */       if ((!(this.readable)) && 
/* 159 */         (this.events[this.first].getType() != EventType.SYS_KILLTHREAD)) {
/* 160 */         return null;
/*     */       }
/* 162 */       IEvent event = this.events[this.first];
/* 163 */       this.events[this.first] = null;
/* 164 */       this.first += 1;
/*     */ 
/* 166 */       if (this.first == this.events.length) {
/* 167 */         this.first = 0;
/*     */       }
/*     */ 
/* 170 */       this.size -= 1;
/* 171 */       return event;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int drainTo(Collection<IEvent> c, int maxElements, long timeout)
/*     */   {
/* 182 */     if (timeout < 0L)
/* 183 */       timeout = 0L;
/* 184 */     synchronized (this.lock) {
/* 185 */       long mark = System.currentTimeMillis();
/* 186 */       if (maxElements <= 0)
/* 187 */         maxElements = this.size;
/* 188 */       int i = 0; break label145:
/*     */ 
/* 190 */       if (System.currentTimeMillis() - mark >= timeout)
/* 191 */         return i;
/*     */       try {
/* 193 */         if (timeout > 0L)
/* 194 */           this.lock.wait(timeout);
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/*     */       }
/*     */       do
/*     */       {
/* 189 */         if (this.size != 0);
/* 198 */         c.add(this.events[this.first]);
/* 199 */         this.events[this.first] = null;
/* 200 */         this.first += 1;
/* 201 */         if (this.first == this.events.length) {
/* 202 */           this.first = 0;
/*     */         }
/* 204 */         this.size -= 1;
/*     */ 
/* 188 */         label145: ++i; } while (i < maxElements);
/*     */ 
/* 206 */       return maxElements;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean offer(IEvent evt)
/*     */     throws EventQueueLockedException, EventQueueFullException, NullPointerException
/*     */   {
/* 218 */     if (evt == null)
/* 219 */       throw new NullPointerException();
/* 220 */     synchronized (this.lock) {
/* 221 */       if ((evt.getType() != EventType.SYS_KILLTHREAD) && (!(this.writable)))
/* 222 */         throw new EventQueueLockedException("Invalid offer while eventQueue disable put into.");
/* 223 */       if (this.size == this.events.length)
/*     */       {
/* 225 */         if (this.size >= this.capacity)
/*     */         {
/* 227 */           String info = "超过队列允许的最大值，不能插入到队列中。size=" + this.size;
/* 228 */           tracer.trace(info);
/* 229 */           throw new EventQueueFullException(info);
/*     */         }
/* 231 */         int oldLen = this.events.length;
/* 232 */         IEvent[] newEvents = new IEvent[oldLen * 2];
/*     */ 
/* 234 */         if (this.first < this.last) {
/* 235 */           System.arraycopy(this.events, this.first, newEvents, 0, this.last - this.first);
/*     */         } else {
/* 237 */           System.arraycopy(this.events, this.first, newEvents, 0, oldLen - this.first);
/* 238 */           System.arraycopy(this.events, 0, newEvents, oldLen - this.first, this.last);
/*     */         }
/*     */ 
/* 241 */         this.first = 0;
/* 242 */         this.last = oldLen;
/* 243 */         this.events = newEvents;
/*     */       }
/*     */ 
/* 246 */       this.events[(this.last++)] = evt;
/*     */ 
/* 248 */       if (this.last == this.events.length) {
/* 249 */         this.last = 0;
/*     */       }
/*     */ 
/* 252 */       this.size += 1;
/*     */ 
/* 254 */       if (this.waiting > 0) {
/* 255 */         this.lock.notifyAll();
/*     */       }
/* 257 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 266 */     return (this.size != 0);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 273 */     return this.size;
/*     */   }
/*     */ 
/*     */   public void setCapacity(int capacity) {
/* 277 */     this.capacity = capacity;
/*     */   }
/*     */ 
/*     */   public int capacity() {
/* 281 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   public void enableOffer(boolean putable)
/*     */   {
/* 289 */     synchronized (this.lock) {
/* 290 */       this.writable = putable;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean enableOffer() {
/* 295 */     return this.writable;
/*     */   }
/*     */ 
/*     */   public void enableTake(boolean takable)
/*     */   {
/* 302 */     synchronized (this.lock) {
/* 303 */       this.readable = takable;
/* 304 */       if ((takable) && (this.size > 0))
/* 305 */         this.lock.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean enableTake() {
/* 310 */     return this.readable;
/*     */   }
/*     */ 
/*     */   public void lockQueue() {
/* 314 */     enableOffer(false);
/* 315 */     enableTake(false);
/*     */   }
/*     */ 
/*     */   public void unlockQueue() {
/* 319 */     enableTake(true);
/* 320 */     enableOffer(true);
/*     */   }
/*     */ }