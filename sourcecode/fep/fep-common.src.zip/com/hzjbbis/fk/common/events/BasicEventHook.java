/*     */ package com.hzjbbis.fk.common.events;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.IEventHook;
/*     */ import com.hzjbbis.fk.common.spi.IEventTrace;
/*     */ import com.hzjbbis.fk.common.spi.abstra.BaseModule;
/*     */ import com.hzjbbis.fk.common.threadpool.ThreadPool;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class BasicEventHook extends BaseModule
/*     */   implements IEventHook
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger(BasicEventHook.class);
/*  33 */   private static final TraceLog tracer = TraceLog.getTracer();
/*     */ 
/*  35 */   protected int minSize = 2;
/*  36 */   protected int maxSize = 20;
/*  37 */   protected int timeoutAlarm = 2;
/*  38 */   protected String name = "evhandler";
/*     */   protected Map<EventType, IEventHandler> handlerMap;
/*  40 */   protected Object[] sources = null;
/*  41 */   protected IEventTrace eventTrace = null;
/*     */   protected Map<EventType, IEventHandler> include;
/*     */   protected List<EventType> exclude;
/*  46 */   protected int threadPriority = Math.max(8, 5);
/*  47 */   protected EventQueue queue = new EventQueue();
/*     */ 
/*  50 */   protected ThreadPool pool = null;
/*  51 */   private boolean initialized = false;
/*  52 */   protected IEventHandler[] handlers = new IEventHandler[EventType.getMaxIndex() + 1];
/*  53 */   private long lastEventTime = System.currentTimeMillis();
/*     */ 
/*     */   public String getModuleType() {
/*  56 */     return "eventHook";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  60 */     return ((this.pool == null) || (!(this.pool.isActive())));
/*     */   }
/*     */ 
/*     */   public String profile()
/*     */   {
/*  67 */     StringBuffer sb = new StringBuffer(256);
/*  68 */     sb.append("\r\n<eventhook-profile type=\"").append(getModuleType()).append("\">");
/*  69 */     sb.append("\r\n    ").append("<name>").append(this.name).append("</name>");
/*  70 */     sb.append("\r\n    ").append("<state>").append(isActive()).append("</state>");
/*  71 */     sb.append("\r\n    ").append("<queue-size>").append(this.queue.size()).append("</queue-size>");
/*  72 */     sb.append("\r\n    ").append("<source>").append(getSource()).append("</source>");
/*     */ 
/*  74 */     sb.append("\r\n    ").append("<tp-minsize>").append(this.pool.getMinSize()).append("</tp-minsize>");
/*  75 */     sb.append("\r\n    ").append("<tp-maxsize>").append(this.pool.getMaxSize()).append("</tp-maxsize>");
/*  76 */     sb.append("\r\n    ").append("<tp-size>").append(this.pool.size()).append("</tp-size>");
/*  77 */     sb.append("\r\n    ").append("<tp-timeout-alarm>").append(this.pool.getTimeoutAlarm()).append("</tp-timeout-alarm>");
/*  78 */     sb.append("\r\n    ").append("<tp-works>").append(this.pool.toString()).append("</tp-works>");
/*  79 */     sb.append("\r\n</eventhook-profile>");
/*  80 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/*     */     Iterator it;
/*  87 */     if (this.initialized)
/*  88 */       return;
/*  89 */     if (this.handlerMap == null)
/*  90 */       this.handlerMap = new HashMap();
/*  91 */     if (this.include != null) {
/*  92 */       it = this.include.entrySet().iterator();
/*  93 */       while (it.hasNext()) {
/*  94 */         Map.Entry entry = (Map.Entry)it.next();
/*  95 */         this.handlerMap.put((EventType)entry.getKey(), (IEventHandler)entry.getValue());
/*     */       }
/*     */     }
/*  98 */     if (this.exclude != null) {
/*  99 */       it = this.exclude.iterator();
/* 100 */       while (it.hasNext())
/* 101 */         this.handlerMap.remove(it.next());
/*     */     }
/* 103 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   public boolean canHook(IEvent e)
/*     */   {
/* 108 */     if (this.sources == null)
/* 109 */       return true;
/* 110 */     if (this.sources != null) {
/* 111 */       for (Object iter : this.sources) {
/* 112 */         if (iter == e.getSource()) {
/* 113 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   public void postEvent(IEvent e) {
/* 121 */     if (!(canHook(e))) {
/* 122 */       return;
/*     */     }
/*     */ 
/* 126 */     int cnt = 10;
/*     */     try
/*     */     {
/* 129 */       this.queue.offer(e);
/*     */     }
/*     */     catch (Exception exp) {
/*     */       do {
/* 133 */         String info = "BasicEventHook can not postEvent. reason is " + exp.getLocalizedMessage() + ". event is" + e.toString();
/* 134 */         log.fatal(info, exp);
/* 135 */         tracer.trace(info, exp);
/*     */         try {
/* 137 */           Thread.sleep(50L);
/*     */         }
/*     */         catch (Exception localException1)
/*     */         {
/*     */         }
/*     */       }
/* 127 */       while (cnt-- > 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createThreadPool()
/*     */   {
/* 144 */     this.pool = new ThreadPool(this, this.queue);
/* 145 */     this.pool.setThreadPriority(this.threadPriority);
/* 146 */     this.pool.setMinSize(this.minSize);
/* 147 */     this.pool.setMaxSize(this.maxSize);
/* 148 */     this.pool.setTimeoutAlarm(this.timeoutAlarm);
/* 149 */     this.pool.setName(this.name);
/*     */   }
/*     */ 
/*     */   public boolean start() {
/* 153 */     init();
/* 154 */     if ((this.pool != null) && (this.pool.isActive())) {
/* 155 */       return true;
/*     */     }
/* 157 */     for (EventType type : this.handlerMap.keySet()) {
/* 158 */       if (type.toInt() > this.handlers.length) {
/* 159 */         IEventHandler[] temp = new IEventHandler[type.toInt() * 2];
/* 160 */         System.arraycopy(this.handlers, 0, temp, 0, this.handlers.length);
/* 161 */         this.handlers = temp;
/*     */       }
/*     */ 
/* 164 */       this.handlers[type.toInt()] = ((IEventHandler)this.handlerMap.get(type));
/* 165 */       GlobalEventHandler.registerHook(this, type);
/*     */     }
/* 167 */     createThreadPool();
/* 168 */     this.pool.start();
/*     */ 
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 175 */     this.queue.enableOffer(false);
/* 176 */     int cnt = 100;
/* 177 */     while ((cnt-- > 0) && (this.queue.size() > 0) && (this.queue.enableTake()))
/*     */       try
/*     */       {
/* 180 */         Thread.sleep(50L);
/*     */       } catch (Exception localException) {
/*     */       }
/* 183 */     for (EventType type : this.handlerMap.keySet()) {
/* 184 */       GlobalEventHandler.deregisterHook(this, type);
/*     */     }
/* 186 */     if (this.pool != null)
/* 187 */       this.pool.stop();
/* 188 */     this.pool = null;
/*     */   }
/*     */ 
/*     */   public void handleEvent(IEvent event) {
/* 192 */     IEventHandler handler = this.handlers[event.getType().toInt()];
/* 193 */     if (handler != null) {
/* 194 */       handler.handleEvent(event);
/* 195 */       this.lastEventTime = System.currentTimeMillis();
/*     */ 
/* 197 */       if (this.eventTrace == null) return;
/*     */       try {
/* 199 */         this.eventTrace.traceEvent(event);
/*     */       } catch (Exception e) {
/* 201 */         log.warn("事件跟踪器执行异常:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLastEventTime()
/*     */   {
/* 212 */     return this.lastEventTime;
/*     */   }
/*     */ 
/*     */   public int getMinSize() {
/* 216 */     return this.minSize;
/*     */   }
/*     */ 
/*     */   public void setMinSize(int minSize) {
/* 220 */     this.minSize = minSize;
/*     */   }
/*     */ 
/*     */   public int getMaxSize() {
/* 224 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   public void setMaxSize(int maxSize) {
/* 228 */     this.maxSize = maxSize;
/*     */   }
/*     */ 
/*     */   public int getTimeoutAlarm() {
/* 232 */     return this.timeoutAlarm;
/*     */   }
/*     */ 
/*     */   public void setTimeoutAlarm(int timeoutAlarm) {
/* 236 */     this.timeoutAlarm = timeoutAlarm;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 240 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 244 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Map<EventType, IEventHandler> getHandlerMap() {
/* 248 */     return this.handlerMap;
/*     */   }
/*     */ 
/*     */   public void setHandlerMap(Map<EventType, IEventHandler> handlerMap) {
/* 252 */     this.handlerMap = handlerMap;
/*     */   }
/*     */ 
/*     */   public void addHandler(EventType type, IEventHandler handler) {
/* 256 */     if (this.handlerMap == null)
/* 257 */       this.handlerMap = new HashMap();
/* 258 */     this.handlerMap.put(type, handler);
/*     */   }
/*     */ 
/*     */   public int getThreadPriority() {
/* 262 */     return this.threadPriority;
/*     */   }
/*     */ 
/*     */   public void setThreadPriority(int threadPriority) {
/* 266 */     this.threadPriority = threadPriority;
/*     */   }
/*     */ 
/*     */   public Object getSource() {
/* 270 */     if ((this.sources != null) && (this.sources.length > 0)) {
/* 271 */       return this.sources[0];
/*     */     }
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */   public void setSource(Object source) {
/* 277 */     if (this.sources == null) {
/* 278 */       this.sources = new Object[1];
/* 279 */       this.sources[0] = source;
/*     */     }
/*     */     else {
/* 282 */       for (Object src : this.sources) {
/* 283 */         if (src == source)
/* 284 */           return;
/*     */       }
/* 286 */       Object[] dest = new Object[this.sources.length + 1];
/* 287 */       System.arraycopy(this.sources, 0, dest, 0, this.sources.length);
/* 288 */       dest[this.sources.length] = source;
/* 289 */       this.sources = null;
/* 290 */       this.sources = dest;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addSource(Object source) {
/* 295 */     setSource(source);
/*     */   }
/*     */ 
/*     */   public void setSource(List<Object> srcs) {
/* 299 */     if ((srcs == null) || (srcs.size() == 0))
/* 300 */       return;
/* 301 */     setSource(srcs.toArray());
/*     */   }
/*     */ 
/*     */   public void setSource(Object[] srcs) {
/* 305 */     if (this.sources == null) {
/* 306 */       this.sources = srcs;
/*     */     }
/*     */     else
/*     */     {
/* 310 */       Vector uniqs = new Vector();
/* 311 */       for (Object src : srcs) {
/* 312 */         boolean found = false;
/* 313 */         for (Object iter : this.sources) {
/* 314 */           if (iter == src) {
/* 315 */             found = true;
/* 316 */             break;
/*     */           }
/*     */         }
/* 319 */         if (!(found))
/* 320 */           uniqs.add(src);
/*     */       }
/* 322 */       Object[] srcss = uniqs.toArray();
/* 323 */       Object[] dest = new Object[this.sources.length + srcss.length];
/* 324 */       System.arraycopy(this.sources, 0, dest, 0, this.sources.length);
/* 325 */       System.arraycopy(srcss, 0, dest, this.sources.length, srcss.length);
/* 326 */       this.sources = null; srcss = (Object[])null;
/* 327 */       this.sources = dest;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addSource(Object[] srcs) {
/* 332 */     setSource(srcs);
/*     */   }
/*     */ 
/*     */   public void setExclude(List<EventType> exclude) {
/* 336 */     this.exclude = exclude;
/*     */   }
/*     */ 
/*     */   public void setInclude(Map<EventType, IEventHandler> include) {
/* 340 */     this.include = include;
/*     */   }
/*     */ 
/*     */   public void setEventTrace(IEventTrace eTrace) {
/* 344 */     this.eventTrace = eTrace;
/*     */   }
/*     */ 
/*     */   public void setQueue(EventQueue queue) {
/* 348 */     this.queue = queue;
/*     */   }
/*     */ }