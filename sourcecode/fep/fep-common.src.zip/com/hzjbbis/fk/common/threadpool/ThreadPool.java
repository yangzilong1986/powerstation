/*     */ package com.hzjbbis.fk.common.threadpool;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.events.EventQueue;
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.events.event.EventHandleTimeoutAlarm;
/*     */ import com.hzjbbis.fk.common.events.event.KillThreadEvent;
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ThreadPool
/*     */   implements ITimerFunctor
/*     */ {
/*  33 */   private static final Logger log = Logger.getLogger(ThreadPool.class);
/*  34 */   private static final TraceLog tracer = TraceLog.getTracer();
/*     */ 
/*  39 */   private String name = "threadpool";
/*  40 */   private static int poolSeq = 1;
/*  41 */   private int timeoutAlarm = 2;
/*     */ 
/*  43 */   private int minSize = 1;
/*  44 */   private int maxSize = 20;
/*  45 */   private int timeout = 200;
/*     */ 
/*  48 */   private volatile State state = new State();
/*  49 */   private IEventHandler executer = null;
/*  50 */   private List<WorkThread> works = Collections.synchronizedList(new ArrayList());
/*  51 */   private int threadPriority = 5;
/*     */   private EventQueue eventQueue;
/*     */ 
/*     */   public ThreadPool(IEventHandler exec, EventQueue queue)
/*     */   {
/*  60 */     this.executer = exec;
/*  61 */     this.eventQueue = queue;
/*     */   }
/*     */ 
/*     */   public boolean start() {
/*  65 */     if (!(this.state.isStopped()))
/*  66 */       return false;
/*  67 */     this.state = State.STARTING;
/*     */ 
/*  69 */     forkThreads(this.minSize);
/*  70 */     while (this.works.size() < this.minSize) {
/*  71 */       Thread.yield();
/*     */       try {
/*  73 */         Thread.sleep(100L);
/*     */       } catch (Exception localException) {
/*     */       }
/*     */     }
/*  77 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 30L));
/*  78 */     this.state = State.RUNNING;
/*  79 */     if (log.isDebugEnabled())
/*  80 */       log.debug("线程池【" + this.name + "】启动成功。,size=" + this.minSize);
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop() {
/*  85 */     this.state = State.STOPPING;
/*  86 */     synchronized (this.works) {
/*  87 */       for (WorkThread work : this.works) {
/*  88 */         work.interrupt();
/*     */       }
/*     */     }
/*  91 */     int cnt = 40;
/*  92 */     while ((cnt-- > 0) && (this.works.size() > 0)) {
/*  93 */       Thread.yield();
/*     */       try {
/*  95 */         Thread.sleep(50L);
/*     */       } catch (Exception localException) {
/*     */       }
/*  98 */       if (cnt < 20)
/*     */         continue;
/* 100 */       synchronized (this.works) {
/* 101 */         for (WorkThread work : this.works) {
/* 102 */           work.interrupt();
/*     */         }
/*     */       }
/*     */     }
/* 106 */     if (log.isDebugEnabled())
/* 107 */       log.debug("线程池【" + this.name + "】停止。,僵死线程数=" + this.works.size());
/* 108 */     this.works.clear();
/* 109 */     this.state = State.STOPPED;
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 113 */     StringBuffer sb = new StringBuffer(256);
/* 114 */     sb.append("<threadpool name=\"").append(this.name).append("\">");
/* 115 */     sb.append("<minSize value=\"").append(this.minSize).append("\"/>");
/* 116 */     sb.append("<maxSize value=\"").append(this.maxSize).append("\"/>");
/* 117 */     sb.append("<size value=\"").append(size()).append("\"/>");
/* 118 */     sb.append("<timeoutAlarm value=\"").append(this.timeoutAlarm).append("\"/>");
/* 119 */     sb.append("<works>").append(toString()).append("</works>");
/* 120 */     sb.append("</threadpool>");
/* 121 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/* 125 */     return this.state.isActive();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 129 */     return this.works.size();
/*     */   }
/*     */ 
/*     */   public void onTimer(int id) {
/* 133 */     if (id == 0) {
/* 134 */       ArrayList list = new ArrayList(this.works);
/* 135 */       int count = 0;
/* 136 */       for (WorkThread work : list) {
/* 137 */         if (!(work.checkTimeout()))
/*     */           continue;
/* 139 */         ++count;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void forkThreads(int delta)
/*     */   {
/* 146 */     if (delta == 0) {
/* 147 */       return;
/*     */     }
/* 149 */     if (delta > 0)
/*     */     {
/* 151 */       int maxDelta = this.maxSize - this.works.size();
/* 152 */       delta = Math.min(maxDelta, delta);
/* 153 */       if ((log.isDebugEnabled()) && (1 == delta))
/* 154 */         log.debug("调整线程池大小(+1)");
/* 155 */       for (; delta > 0; --delta)
/* 156 */         new WorkThread();
/*     */     }
/*     */     else
/*     */     {
/* 160 */       delta = -delta;
/* 161 */       int n = this.works.size() - this.minSize;
/* 162 */       delta = Math.min(delta, n);
/* 163 */       if ((log.isDebugEnabled()) && (-1 == delta))
/* 164 */         log.debug("调整线程池大小(-1)");
/* 165 */       for (; delta > 0; --delta)
/*     */         try {
/* 167 */           this.eventQueue.addFirst(new KillThreadEvent());
/*     */         } catch (Exception exp) {
/* 169 */           log.error(exp.getLocalizedMessage());
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void justThreadSize()
/*     */   {
/* 176 */     int n = this.eventQueue.size();
/* 177 */     if (n > 1000) {
/* 178 */       forkThreads(1);
/*     */     }
/* 180 */     else if (n < 2)
/* 181 */       forkThreads(-1);
/*     */   }
/*     */ 
/*     */   public void setEventQueue(EventQueue eventQueue)
/*     */   {
/* 274 */     this.eventQueue = eventQueue;
/*     */   }
/*     */ 
/*     */   public int getTimeoutAlarm() {
/* 278 */     return this.timeoutAlarm;
/*     */   }
/*     */ 
/*     */   public void setTimeoutAlarm(int timeoutAlarm) {
/* 282 */     this.timeoutAlarm = timeoutAlarm;
/*     */   }
/*     */ 
/*     */   public int getMinSize() {
/* 286 */     return this.minSize;
/*     */   }
/*     */ 
/*     */   public void setMinSize(int minSize) {
/* 290 */     this.minSize = minSize;
/*     */   }
/*     */ 
/*     */   public int getMaxSize() {
/* 294 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   public void setMaxSize(int maxSize) {
/* 298 */     this.maxSize = maxSize;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 302 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 306 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public int getThreadPriority() {
/* 310 */     return this.threadPriority;
/*     */   }
/*     */ 
/*     */   public void setThreadPriority(int threadPriority) {
/* 314 */     this.threadPriority = threadPriority;
/*     */   }
/*     */ 
/*     */   public int getTimeout() {
/* 318 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 322 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 326 */     StringBuffer sb = new StringBuffer(256);
/* 327 */     sb.append(this.name);
/*     */     try {
/* 329 */       for (WorkThread work : this.works)
/* 330 */         sb.append(work);
/*     */     }
/*     */     catch (Exception e) {
/* 333 */       return "";
/*     */     }
/* 335 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private class WorkThread extends Thread
/*     */   {
/*     */     long beginTime;
/* 187 */     boolean busy = false;
/* 188 */     IEvent currentEvent = null;
/*     */ 
/*     */     public WorkThread() { super(ThreadPool.this.name + "." + (ThreadPool.poolSeq++));
/* 191 */       super.start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 195 */       synchronized (ThreadPool.this.works) {
/* 196 */         ThreadPool.this.works.add(this);
/*     */       }
/* 198 */       setPriority(ThreadPool.this.threadPriority);
/* 199 */       int count = 0;
/* 200 */       ThreadPool.log.info("threadpool.work running:" + getName());
/* 201 */       while ((!(ThreadPool.this.state.isStopping())) && (!(ThreadPool.this.state.isStopped())))
/*     */         try {
/* 203 */           this.busy = false;
/* 204 */           this.currentEvent = ThreadPool.this.eventQueue.take();
/* 205 */           if (this.currentEvent != null)
/*     */           {
/* 207 */             if (this.currentEvent.getType() == EventType.SYS_KILLTHREAD)
/*     */               break label177;
/* 209 */             processEvent(this.currentEvent);
/*     */ 
/* 211 */             ++count;
/* 212 */             if (count > 500) {
/* 213 */               ThreadPool.this.justThreadSize();
/* 214 */               count = 0;
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception localException)
/*     */         {
/*     */         }
/* 221 */       synchronized (ThreadPool.this.works) {
/* 222 */         label177: ThreadPool.this.works.remove(this);
/*     */       }
/* 224 */       ThreadPool.log.info("线程池的工作线程退出:" + getName());
/*     */     }
/*     */ 
/*     */     private void processEvent(IEvent event)
/*     */     {
/* 232 */       this.beginTime = System.currentTimeMillis();
/* 233 */       this.busy = true;
/* 234 */       ThreadPool.this.executer.handleEvent(event);
/* 235 */       long endTime = System.currentTimeMillis();
/* 236 */       if (endTime - this.beginTime <= ThreadPool.this.timeoutAlarm * 1000)
/*     */         return;
/* 238 */       EventHandleTimeoutAlarm ev = new EventHandleTimeoutAlarm(event);
/* 239 */       ev.setBeginTime(this.beginTime);
/* 240 */       ev.setEndTime(endTime);
/* 241 */       ev.setThreadName(getName());
/* 242 */       GlobalEventHandler.postEvent(ev);
/*     */     }
/*     */ 
/*     */     public boolean checkTimeout()
/*     */     {
/* 247 */       if (!(this.busy))
/* 248 */         return false;
/* 249 */       long endTime = System.currentTimeMillis();
/* 250 */       if (endTime - this.beginTime > ThreadPool.this.timeoutAlarm * 1000)
/*     */       {
/* 252 */         EventHandleTimeoutAlarm ev = new EventHandleTimeoutAlarm(this.currentEvent);
/* 253 */         ev.setBeginTime(this.beginTime);
/* 254 */         ev.setEndTime(endTime);
/* 255 */         ev.setStackTraceElement(getStackTrace());
/* 256 */         ThreadPool.tracer.trace(ev);
/* 257 */         GlobalEventHandler.postEvent(ev);
/* 258 */         interrupt();
/*     */       }
/* 260 */       return true;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 264 */       String busyStatus = "idle";
/* 265 */       if (this.busy) {
/* 266 */         long timeConsume = System.currentTimeMillis() - this.beginTime;
/* 267 */         busyStatus = "当前处理时间(毫秒):" + timeConsume;
/*     */       }
/* 269 */       return "[" + getName() + "," + busyStatus + "];";
/*     */     }
/*     */   }
/*     */ }