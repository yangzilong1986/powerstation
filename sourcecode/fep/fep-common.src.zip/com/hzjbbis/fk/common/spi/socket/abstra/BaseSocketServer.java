/*     */ package com.hzjbbis.fk.common.spi.socket.abstra;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.message.MultiProtoRecognizer;
/*     */ import com.hzjbbis.fk.message.gate.MessageGateCreator;
/*     */ import com.hzjbbis.fk.utils.CalendarUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public abstract class BaseSocketServer
/*     */   implements ISocketServer
/*     */ {
/*  21 */   protected String name = "async tcp server";
/*  22 */   protected String ip = null;
/*  23 */   protected int port = -1;
/*  24 */   protected int bufLength = 256;
/*  25 */   protected int ioThreadSize = 2;
/*  26 */   protected IMessageCreator messageCreator = new MessageGateCreator();
/*     */ 
/*  28 */   protected IClientIO ioHandler = null;
/*     */ 
/*  34 */   protected String txfs = "02";
/*  35 */   protected int timeout = 1800;
/*     */ 
/*  37 */   private int writeFirstCount = 100;
/*  38 */   private int maxContinueRead = 100;
/*  39 */   private String serverAddress = null;
/*     */ 
/*  42 */   protected long lastReceiveTime = 0L; protected long lastSendTime = 0L;
/*  43 */   protected long totalRecvMessages = 0L; protected long totalSendMessages = 0L;
/*  44 */   protected int msgRecvPerMinute = 0; protected int msgSendPerMinute = 0;
/*  45 */   protected Object statisticsRecv = new Object(); protected Object statisticsSend = new Object();
/*     */ 
/*     */   public IMessage createMessage(ByteBuffer buf) {
/*  48 */     IMessage msg = this.messageCreator.create();
/*  49 */     if (msg == null)
/*  50 */       msg = MultiProtoRecognizer.recognize(buf);
/*  51 */     return msg;
/*     */   }
/*     */ 
/*     */   public int getBufLength() {
/*  55 */     return this.bufLength;
/*     */   }
/*     */ 
/*     */   public void setBufLength(int bufLen) {
/*  59 */     this.bufLength = bufLen;
/*     */   }
/*     */ 
/*     */   public abstract int getClientSize();
/*     */ 
/*     */   public abstract IServerSideChannel[] getClients();
/*     */ 
/*     */   public IClientIO getIoHandler() {
/*  67 */     return this.ioHandler;
/*     */   }
/*     */ 
/*     */   public void setIoHandler(IClientIO ioh) {
/*  71 */     this.ioHandler = ioh;
/*     */   }
/*     */ 
/*     */   public int getIoThreadSize() {
/*  75 */     return this.ioThreadSize;
/*     */   }
/*     */ 
/*     */   public void setIoThreadSize(int iotSize) {
/*  79 */     this.ioThreadSize = iotSize;
/*     */   }
/*     */ 
/*     */   public int getMaxContinueRead() {
/*  83 */     return this.maxContinueRead;
/*     */   }
/*     */ 
/*     */   public void setMaxContinueRead(int mcRead) {
/*  87 */     this.maxContinueRead = mcRead;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/*  91 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(int port) {
/*  95 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public void setIp(String ip) {
/*  99 */     this.ip = ip;
/*     */   }
/*     */ 
/*     */   public void setServerAddress(String serverAddress) {
/* 103 */     this.serverAddress = serverAddress;
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 107 */     if (this.serverAddress != null) {
/* 108 */       return this.serverAddress;
/*     */     }
/* 110 */     return "127.0.0.1:" + this.port;
/*     */   }
/*     */ 
/*     */   public int getWriteFirstCount() {
/* 114 */     return this.writeFirstCount;
/*     */   }
/*     */ 
/*     */   public void setWriteFirstCount(int fcount) {
/* 118 */     this.writeFirstCount = fcount;
/*     */   }
/*     */ 
/*     */   public void incRecvMessage() {
/* 122 */     synchronized (this.statisticsRecv) {
/* 123 */       this.msgRecvPerMinute += 1;
/* 124 */       this.totalRecvMessages += 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void incSendMessage() {
/* 129 */     synchronized (this.statisticsSend) {
/* 130 */       this.msgSendPerMinute += 1;
/* 131 */       this.totalSendMessages += 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeClient(IServerSideChannel client) {
/* 136 */     if (getClientSize() == 0) {
/* 137 */       synchronized (this.statisticsRecv) {
/* 138 */         this.totalRecvMessages = 0L;
/* 139 */         this.msgRecvPerMinute = 0;
/*     */       }
/* 141 */       synchronized (this.statisticsSend) {
/* 142 */         this.totalSendMessages = 0L;
/* 143 */         this.msgSendPerMinute = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLastReceiveTime(long lastRecv) {
/* 149 */     this.lastReceiveTime = lastRecv;
/*     */   }
/*     */ 
/*     */   public void setLastSendTime(long lastSend) {
/* 153 */     this.lastSendTime = lastSend;
/*     */   }
/*     */ 
/*     */   public long getLastReceiveTime() {
/* 157 */     return this.lastReceiveTime;
/*     */   }
/*     */ 
/*     */   public long getLastSendTime() {
/* 161 */     return this.lastSendTime;
/*     */   }
/*     */ 
/*     */   public int getMsgRecvPerMinute() {
/* 165 */     return this.msgRecvPerMinute;
/*     */   }
/*     */ 
/*     */   public int getMsgSendPerMinute() {
/* 169 */     return this.msgSendPerMinute;
/*     */   }
/*     */ 
/*     */   public long getTotalRecvMessages() {
/* 173 */     return this.totalRecvMessages;
/*     */   }
/*     */ 
/*     */   public long getTotalSendMessages() {
/* 177 */     return this.totalSendMessages;
/*     */   }
/*     */ 
/*     */   public String getModuleType() {
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 185 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 189 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 193 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 197 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public abstract boolean isActive();
/*     */ 
/*     */   public abstract boolean start();
/*     */ 
/*     */   public abstract void stop();
/*     */ 
/*     */   public String profile() {
/* 207 */     StringBuffer sb = new StringBuffer(1024);
/* 208 */     sb.append("\r\n<sockserver-profile type=\"").append(getModuleType()).append("\">");
/* 209 */     sb.append("\r\n    ").append("<name>").append(this.name).append("</name>");
/* 210 */     String stateDesc = (isActive()) ? "running" : "stopped";
/* 211 */     sb.append("\r\n    ").append("<state>").append(stateDesc).append("</state>");
/* 212 */     sb.append("\r\n    ").append("<port>").append(this.port).append("</port>");
/*     */ 
/* 214 */     sb.append("\r\n    ").append("<ioThreadSize>").append(this.ioThreadSize).append("</ioThreadSize>");
/* 215 */     sb.append("\r\n    ").append("<clientSize>").append(getClientSize()).append("</clientSize>");
/* 216 */     sb.append("\r\n    ").append("<timeout>").append(this.timeout).append("</timeout>");
/*     */ 
/* 218 */     sb.append("\r\n    ").append("<txfs>").append(this.txfs).append("</txfs>");
/* 219 */     sb.append("\r\n    ").append("<totalRecv>").append(this.totalRecvMessages).append("</totalRecv>");
/* 220 */     sb.append("\r\n    ").append("<totalSend>").append(this.totalSendMessages).append("</totalSend>");
/* 221 */     sb.append("\r\n    ").append("<perMinuteRecv>").append(this.msgRecvPerMinute).append("</perMinuteRecv>");
/* 222 */     sb.append("\r\n    ").append("<perMinuteSend>").append(this.msgSendPerMinute).append("</perMinuteSend>");
/*     */ 
/* 224 */     String stime = CalendarUtil.getTimeString(this.lastReceiveTime);
/* 225 */     sb.append("\r\n    ").append("<lastRecv>").append(stime).append("</lastRecv>");
/* 226 */     stime = CalendarUtil.getTimeString(this.lastSendTime);
/* 227 */     sb.append("\r\n    ").append("<lastSend>").append(stime).append("</lastSend>");
/* 228 */     sb.append("\r\n</sockserver-profile>");
/* 229 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void setMessageCreator(IMessageCreator messageCreator) {
/* 233 */     this.messageCreator = messageCreator;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 237 */     this.timeout = timeout;
/*     */   }
/*     */ }