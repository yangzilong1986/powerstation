package com.hzjbbis.fk.common.spi;

public abstract interface IEventTrace
{
  public abstract void traceEvent(IEvent paramIEvent);
}