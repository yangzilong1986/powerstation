package com.hzjbbis.fk.common.spi.socket;

public abstract interface IClientSideChannel extends IChannel
{
}