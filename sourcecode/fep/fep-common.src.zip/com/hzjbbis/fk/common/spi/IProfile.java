package com.hzjbbis.fk.common.spi;

public abstract interface IProfile
{
  public abstract String profile();
}