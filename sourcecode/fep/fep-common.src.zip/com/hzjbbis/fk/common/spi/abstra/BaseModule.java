/*    */ package com.hzjbbis.fk.common.spi.abstra;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IModule;
/*    */ 
/*    */ public abstract class BaseModule
/*    */   implements IModule
/*    */ {
/*    */   public String getName()
/*    */   {
/* 15 */     return "undefine";
/*    */   }
/*    */ 
/*    */   public String getTxfs() {
/* 19 */     return "??";
/*    */   }
/*    */ 
/*    */   public boolean isActive() {
/* 23 */     return true;
/*    */   }
/*    */ 
/*    */   public abstract boolean start();
/*    */ 
/*    */   public abstract void stop();
/*    */ 
/*    */   public long getLastReceiveTime() {
/* 31 */     return 0L;
/*    */   }
/*    */ 
/*    */   public long getLastSendTime() {
/* 35 */     return 0L;
/*    */   }
/*    */ 
/*    */   public int getMsgRecvPerMinute() {
/* 39 */     return 0;
/*    */   }
/*    */ 
/*    */   public int getMsgSendPerMinute() {
/* 43 */     return 0;
/*    */   }
/*    */ 
/*    */   public long getTotalRecvMessages() {
/* 47 */     return 0L;
/*    */   }
/*    */ 
/*    */   public long getTotalSendMessages() {
/* 51 */     return 0L;
/*    */   }
/*    */ 
/*    */   public String profile() {
/* 55 */     return "<profile>empty</profile>";
/*    */   }
/*    */ }