/*     */ package com.hzjbbis.fk.common.simpletimer;
/*     */ 
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TimerScheduler
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(TimerScheduler.class);
/*  22 */   private static final TraceLog tracer = TraceLog.getTracer(TimerScheduler.class);
/*  23 */   private List<TimerData> timers = new LinkedList();
/*  24 */   private final Object lock = new Object();
/*  25 */   private final ScheduleThread thread = new ScheduleThread();
/*  26 */   private static TimerScheduler timerScheduler = null;
/*  27 */   private volatile boolean running = false;
/*  28 */   private final Timer sysTimer = new Timer("TimerScheduler.sys", true);
/*     */ 
/*     */   private TimerScheduler() {
/*  31 */     this.running = true;
/*  32 */     this.thread.setDaemon(true);
/*  33 */     this.thread.start();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  37 */     this.running = false;
/*  38 */     this.thread.interrupt();
/*  39 */     this.sysTimer.cancel();
/*     */   }
/*     */ 
/*     */   public static final TimerScheduler getScheduler() {
/*  43 */     if (timerScheduler == null) {
/*  44 */       timerScheduler = new TimerScheduler();
/*     */     }
/*  46 */     return timerScheduler;
/*     */   }
/*     */ 
/*     */   public void schedulerOnce(TimerTask task, Date time) {
/*  50 */     this.sysTimer.schedule(task, time);
/*     */   }
/*     */ 
/*     */   public void addTimer(TimerData item) {
/*  54 */     if (!(this.running))
/*  55 */       return;
/*  56 */     synchronized (this.lock) {
/*  57 */       removeTimer(item.getFunctor(), item.getId());
/*  58 */       this.timers.add(item);
/*  59 */       this.lock.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeTimer(ITimerFunctor source, int id) {
/*  64 */     if (!(this.running))
/*  65 */       return;
/*  66 */     synchronized (this.lock) {
/*  67 */       for (TimerData item : this.timers)
/*  68 */         if ((item.getFunctor() == source) && (item.getId() == id)) {
/*  69 */           this.timers.remove(item);
/*  70 */           this.lock.notifyAll();
/*  71 */           break;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private TimerData getNearestTimer()
/*     */   {
/*  78 */     TimerData result = null;
/*  79 */     long minDistance = 9223372036854775807L;
/*  80 */     synchronized (this.lock) {
/*  81 */       for (TimerData item : this.timers) {
/*  82 */         if (item.distance() < minDistance) {
/*  83 */           result = item;
/*  84 */           minDistance = item.distance();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */   public void setTimers(List<TimerData> timers)
/*     */   {
/* 127 */     synchronized (this.lock) {
/* 128 */       this.timers = timers;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ScheduleThread extends Thread
/*     */   {
/*     */     public ScheduleThread()
/*     */     {
/*  94 */       super("gTimerThread");
/*     */     }
/*     */ 
/*     */     public void run() {
/*  98 */       while (TimerScheduler.this.running)
/*     */         try {
/* 100 */           doWork();
/*     */         } catch (InterruptedException localInterruptedException) {
/*     */         }
/*     */         catch (Exception e) {
/* 104 */           TimerScheduler.log.error(e.getLocalizedMessage(), e);
/*     */         }
/*     */     }
/*     */ 
/*     */     private void doWork() throws InterruptedException
/*     */     {
/* 110 */       synchronized (TimerScheduler.this.lock) {
/* 111 */         TimerData item = TimerScheduler.this.getNearestTimer();
/* 112 */         long waitTime = (item == null) ? 1000L : item.distance();
/* 113 */         if (waitTime <= 0L) {
/* 114 */           waitTime = 20L;
/*     */         }
/* 116 */         TimerScheduler.this.lock.wait(waitTime);
/* 117 */         if ((item != null) && (item.distance() <= 0L)) {
/* 118 */           TimerScheduler.tracer.trace("执行定时器：" + item.getFunctor());
/* 119 */           item.activate();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }