/*    */ package com.hzjbbis.fk.common.simpletimer;
/*    */ 
/*    */ public class Speedometer
/*    */   implements ITimerFunctor
/*    */ {
/* 12 */   private int pointCount = 60;
/*    */   private int[] mpoints;
/* 15 */   private final Object lock = new Object();
/* 16 */   private int curPosition = 0;
/*    */ 
/*    */   public Speedometer() {
/* 19 */     this.mpoints = new int[this.pointCount + 1];
/* 20 */     for (int i = 0; i < this.mpoints.length; ++i)
/* 21 */       this.mpoints[i] = 0;
/* 22 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 60L));
/*    */   }
/*    */ 
/*    */   public Speedometer(int pointCount) {
/* 26 */     if (pointCount < 1)
/* 27 */       pointCount = 60;
/* 28 */     this.pointCount = pointCount;
/* 29 */     this.mpoints = new int[this.pointCount + 1];
/* 30 */     for (int i = 0; i < this.mpoints.length; ++i)
/* 31 */       this.mpoints[i] = 0;
/* 32 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 60L));
/*    */   }
/*    */ 
/*    */   private void moveNext() {
/* 36 */     this.curPosition += 1;
/* 37 */     if (this.curPosition > this.pointCount)
/* 38 */       this.curPosition = 0;
/* 39 */     this.mpoints[this.curPosition] = 0;
/*    */   }
/*    */ 
/*    */   public void onTimer(int id) {
/* 43 */     synchronized (this.lock) {
/* 44 */       moveNext();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void add(int flow) {
/* 49 */     synchronized (this.lock) {
/* 50 */       this.mpoints[this.curPosition] += flow;
/*    */     }
/*    */   }
/*    */ 
/*    */   public int getSpeed() {
/* 55 */     int speed = 0;
/* 56 */     synchronized (this.lock) {
/* 57 */       for (int i = 0; i < this.mpoints.length; ++i) {
/* 58 */         if (i != this.curPosition)
/* 59 */           speed += this.mpoints[i];
/*    */       }
/*    */     }
/* 62 */     return speed; }
/*    */ 
/*    */   public int getSpeed1() {
/* 65 */     int speed = 0;
/* 66 */     speed = this.mpoints[this.curPosition];
/* 67 */     return speed;
/*    */   }
/*    */ }