/*    */ package com.hzjbbis.fk.common.simpletimer;
/*    */ 
/*    */ public class TimerData
/*    */ {
/*    */   private ITimerFunctor functor;
/* 13 */   private int id = 0;
/* 14 */   private long period = 60000L;
/*    */ 
/* 25 */   private long lastActivate = System.currentTimeMillis();
/*    */ 
/*    */   public TimerData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TimerData(ITimerFunctor src, int id, long period)
/*    */   {
/* 19 */     this.functor = src;
/* 20 */     this.id = id;
/* 21 */     this.period = (period * 1000L);
/*    */   }
/*    */ 
/*    */   public ITimerFunctor getFunctor()
/*    */   {
/* 28 */     return this.functor;
/*    */   }
/*    */ 
/*    */   public void setFunctor(ITimerFunctor functor) {
/* 32 */     this.functor = functor;
/*    */   }
/*    */ 
/*    */   public int getId() {
/* 36 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(int id) {
/* 40 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public long getPeriod() {
/* 44 */     return this.period;
/*    */   }
/*    */ 
/*    */   public void setPeriod(long period) {
/* 48 */     this.period = (period * 1000L);
/*    */   }
/*    */ 
/*    */   public void activate()
/*    */   {
/* 55 */     this.lastActivate = System.currentTimeMillis();
/* 56 */     this.functor.onTimer(this.id);
/*    */   }
/*    */ 
/*    */   public long distance()
/*    */   {
/* 64 */     return (this.lastActivate + this.period - System.currentTimeMillis());
/*    */   }
/*    */ }