package com.hzjbbis.fk.common.simpletimer;

public abstract interface ITimerFunctor
{
  public abstract void onTimer(int paramInt);
}