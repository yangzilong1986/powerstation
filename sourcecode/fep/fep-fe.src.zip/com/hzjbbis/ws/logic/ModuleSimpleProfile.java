/*    */ package com.hzjbbis.ws.logic;
/*    */ 
/*    */ public class ModuleSimpleProfile
/*    */ {
/*    */   private String moduleType;
/*    */   private String name;
/*    */   private boolean running;
/*    */   private long totalReceive;
/*    */   private long totalSend;
/*    */   private int perMinuteReceive;
/*    */   private int perMinuteSend;
/*    */   private long lastReceiveTime;
/*    */ 
/*    */   public final String getModuleType()
/*    */   {
/* 11 */     return this.moduleType; }
/*    */ 
/*    */   public final void setModuleType(String moduleType) {
/* 14 */     this.moduleType = moduleType; }
/*    */ 
/*    */   public final String getName() {
/* 17 */     return this.name; }
/*    */ 
/*    */   public final void setName(String name) {
/* 20 */     this.name = name; }
/*    */ 
/*    */   public final boolean isRunning() {
/* 23 */     return this.running; }
/*    */ 
/*    */   public final void setRunning(boolean running) {
/* 26 */     this.running = running; }
/*    */ 
/*    */   public final long getTotalReceive() {
/* 29 */     return this.totalReceive; }
/*    */ 
/*    */   public final void setTotalReceive(long totalReceive) {
/* 32 */     this.totalReceive = totalReceive; }
/*    */ 
/*    */   public final long getTotalSend() {
/* 35 */     return this.totalSend; }
/*    */ 
/*    */   public final void setTotalSend(long totalSend) {
/* 38 */     this.totalSend = totalSend; }
/*    */ 
/*    */   public final int getPerMinuteReceive() {
/* 41 */     return this.perMinuteReceive; }
/*    */ 
/*    */   public final void setPerMinuteReceive(int perMinuteReceive) {
/* 44 */     this.perMinuteReceive = perMinuteReceive; }
/*    */ 
/*    */   public final int getPerMinuteSend() {
/* 47 */     return this.perMinuteSend; }
/*    */ 
/*    */   public final void setPerMinuteSend(int perMinuteSend) {
/* 50 */     this.perMinuteSend = perMinuteSend; }
/*    */ 
/*    */   public final long getLastReceiveTime() {
/* 53 */     return this.lastReceiveTime; }
/*    */ 
/*    */   public final void setLastReceiveTime(long lastReceiveTime) {
/* 56 */     this.lastReceiveTime = lastReceiveTime;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 60 */     StringBuffer sb = new StringBuffer(512);
/* 61 */     sb.append("\r\ntype=").append(this.moduleType);
/* 62 */     sb.append("; name=").append(this.name);
/* 63 */     sb.append("; running=").append(this.running);
/* 64 */     sb.append("; totalReceive=").append(this.totalReceive);
/* 65 */     sb.append("; totalSend=").append(this.totalSend);
/* 66 */     sb.append("; perMinuteReceive=").append(this.perMinuteReceive);
/* 67 */     sb.append("; perMinuteSend=").append(this.perMinuteSend);
/* 68 */     sb.append("; lastReceiveTime=").append(this.lastReceiveTime);
/* 69 */     return sb.toString();
/*    */   }
/*    */ }