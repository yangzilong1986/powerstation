/*    */ package com.hzjbbis.ws.logic;
/*    */ 
/*    */ import com.hzjbbis.fk.FasSystem;
/*    */ import com.hzjbbis.fk.fe.config.ApplicationPropertiesConfig;
/*    */ import com.hzjbbis.fk.fe.filecache.MisparamRtuManage;
/*    */ import com.hzjbbis.fk.fe.filecache.RtuCommFlowCache;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.jws.WebService;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ @WebService(endpointInterface="com.hzjbbis.ws.logic.WsFEManage")
/*    */ public class WsFEManageImpl
/*    */   implements WsFEManage
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(WsFEManageImpl.class);
/*    */ 
/*    */   public boolean addGprsGateChannel(String ip, int port, String gateName) {
/* 22 */     return ApplicationPropertiesConfig.getInstance().addGprsGate(ip, port, gateName);
/*    */   }
/*    */ 
/*    */   public boolean addUmsChannel(String appid, String password) {
/* 26 */     return ApplicationPropertiesConfig.getInstance().addUmsClient(appid, password);
/*    */   }
/*    */ 
/*    */   public void startModule(String name) {
/* 30 */     FasSystem.getFasSystem().startModule(name);
/*    */   }
/*    */ 
/*    */   public void stopModule(String name) {
/* 34 */     FasSystem.getFasSystem().stopModule(name);
/*    */   }
/*    */ 
/*    */   public void updateFlow() {
/* 38 */     MisparamRtuManage instance = MisparamRtuManage.getInstance();
/* 39 */     RtuManage rm = RtuManage.getInstance();
/* 40 */     List allRtu = null;
/* 41 */     synchronized (rm) {
/* 42 */       allRtu = new ArrayList(rm.getAllComRtu());
/*    */     }
/*    */     try {
/* 45 */       for (ComRtu rtu : allRtu)
/*    */       {
/* 47 */         RtuCommFlowCache.getInstance().addRtu(rtu);
/*    */       }
/* 49 */       instance.saveRtuStatus2Db(allRtu);
/*    */     } catch (Exception e) {
/* 51 */       log.warn("更新流量异常:" + e.getLocalizedMessage(), e);
/*    */     }
/*    */   }
/*    */ }