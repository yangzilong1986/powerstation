/*    */ package com.hzjbbis.ws.logic;
/*    */ 
/*    */ import com.hzjbbis.fk.fe.filecache.HeartbeatPersist;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import javax.jws.WebService;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ @WebService(endpointInterface="com.hzjbbis.ws.logic.WsHeartbeatQuery")
/*    */ public class WsHeartbeatQueryImpl
/*    */   implements WsHeartbeatQuery
/*    */ {
/* 18 */   private static final Logger log = Logger.getLogger(WsHeartbeatQueryImpl.class);
/*    */ 
/*    */   public int heartCount(int rtua)
/*    */   {
/*    */     try {
/* 23 */       ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/* 24 */       return ((rtu == null) ? -1 : rtu.getHeartbeatCount());
/*    */     } catch (Exception ex) {
/* 26 */       log.error("heartCount,error:" + ex.getLocalizedMessage(), ex); }
/* 27 */     return -1;
/*    */   }
/*    */ 
/*    */   public long lastHeartbeatTime(int rtua)
/*    */   {
/* 33 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/* 34 */     return ((rtu == null) ? 0L : rtu.getLastHeartbeat());
/*    */   }
/*    */ 
/*    */   public int totalRtuWithHeartByA1(byte a1)
/*    */   {
/* 39 */     int sum = 0;
/*    */     try {
/* 41 */       List list = new ArrayList(RtuManage.getInstance().getAllComRtu());
/* 42 */       for (ComRtu rtu : list) {
/* 43 */         int rtua = rtu.getRtua() & 0xFF000000;
/* 44 */         int ia1 = a1 << 24 & 0xFF000000;
/* 45 */         if ((rtua == ia1) && (rtu.getHeartbeatCount() > 0))
/* 46 */           ++sum;
/*    */       }
/*    */     } catch (Exception ex) {
/* 49 */       log.error("totalRtuWithHeartByA1:a1=" + HexDump.toHex(a1) + ",error:" + ex.getLocalizedMessage(), ex);
/* 50 */       return (sum = -1);
/*    */     }
/* 52 */     return sum;
/*    */   }
/*    */ 
/*    */   public int totalRtuWithHeartByA1Time(byte a1, Date beginTime)
/*    */   {
/* 57 */     int sum = 0;
/*    */     try {
/* 59 */       List list = new ArrayList(RtuManage.getInstance().getAllComRtu());
/* 60 */       for (ComRtu rtu : list) {
/* 61 */         int rtua = rtu.getRtua() & 0xFF000000;
/* 62 */         int ia1 = a1 << 24 & 0xFF000000;
/* 63 */         if (rtu.getLastHeartbeatTime() == null)
/*    */           continue;
/* 65 */         if ((rtua == ia1) && (rtu.getHeartbeatCount() > 0) && (beginTime.before(rtu.getLastHeartbeatTime())))
/* 66 */           ++sum;
/*    */       }
/*    */     } catch (Exception ex) {
/* 69 */       log.error("totalRtuWithHeartByA1Time:a1=" + HexDump.toHex(a1) + ",error:" + ex.getLocalizedMessage(), ex);
/* 70 */       return (sum = -1);
/*    */     }
/* 72 */     return sum;
/*    */   }
/*    */ 
/*    */   public String queryHeartbeatInfo(int rtua) {
/* 76 */     return HeartbeatPersist.getInstance().queryHeartbeatInfo(rtua);
/*    */   }
/*    */ 
/*    */   public String queryHeartbeatInfoByDate(int rtua, int date) {
/* 80 */     return HeartbeatPersist.getInstance().queryHeartbeatInfo(rtua, date);
/*    */   }
/*    */ }