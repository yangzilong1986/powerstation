/*    */ package com.hzjbbis.ws.logic;
/*    */ 
/*    */ import com.hzjbbis.fk.FasSystem;
/*    */ import com.hzjbbis.fk.common.spi.IModule;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import com.hzjbbis.fk.tracelog.TraceLog;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.jws.WebService;
/*    */ 
/*    */ @WebService(endpointInterface="com.hzjbbis.ws.logic.WsProfile")
/*    */ public class WsProfileImpl
/*    */   implements WsProfile
/*    */ {
/* 16 */   private static final TraceLog tracer = TraceLog.getTracer(WsProfileImpl.class);
/*    */ 
/*    */   public String allProfile() {
/* 19 */     return FasSystem.getFasSystem().gatherSystemsProfile();
/*    */   }
/*    */ 
/*    */   public String modulesProfile() {
/* 23 */     return FasSystem.getFasSystem().getModuleProfile();
/*    */   }
/*    */ 
/*    */   public ModuleSimpleProfile[] getAllModuleProfile() {
/* 27 */     List list = new ArrayList();
/* 28 */     for (IModule mod : FasSystem.getFasSystem().getModules()) {
/* 29 */       ModuleSimpleProfile mp = new ModuleSimpleProfile();
/* 30 */       mp.setLastReceiveTime(mod.getLastReceiveTime());
/* 31 */       mp.setModuleType(mod.getModuleType());
/* 32 */       mp.setName(mod.getName());
/* 33 */       mp.setPerMinuteReceive(mod.getMsgRecvPerMinute());
/* 34 */       mp.setPerMinuteSend(mod.getMsgSendPerMinute());
/* 35 */       mp.setRunning(mod.isActive());
/* 36 */       mp.setTotalReceive(mod.getTotalRecvMessages());
/* 37 */       mp.setTotalSend(mod.getTotalSendMessages());
/* 38 */       list.add(mp);
/*    */     }
/* 40 */     return ((ModuleSimpleProfile[])list.toArray(new ModuleSimpleProfile[list.size()]));
/*    */   }
/*    */ 
/*    */   public boolean updateRtuSimNum(String rtuSimList) {
/*    */     try {
/* 45 */       if ((rtuSimList != null) && (rtuSimList.length() > 0)) {
/* 46 */         tracer.trace("rtuSimList:" + rtuSimList);
/* 47 */         String[] rtuSims = rtuSimList.trim().split(";");
/* 48 */         for (int i = 0; i < rtuSims.length; ++i) {
/* 49 */           String[] rtuSim = rtuSims[i].trim().split(",");
/* 50 */           if (rtuSim.length == 2) {
/* 51 */             String logicAddress = rtuSim[0].trim();
/* 52 */             String simNum = rtuSim[1].trim();
/* 53 */             ComRtu rtu = RtuManage.getInstance().getComRtuInCache((int)Long.parseLong(logicAddress, 16));
/* 54 */             if (rtu != null)
/* 55 */               rtu.setSimNum(simNum);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 61 */       tracer.trace("update rtu simnum error:" + ex.getLocalizedMessage());
/* 62 */       return false;
/*    */     }
/* 64 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean updateRemoteUpdateRtuaList(String rtuaList) {
/*    */     try {
/* 69 */       if ((rtuaList != null) && (rtuaList.length() > 0)) {
/* 70 */         tracer.trace("remoteUpdateRtuaList:" + rtuaList);
/* 71 */         String[] rtuSims = rtuaList.trim().split(",");
/* 72 */         RtuManage.getInstance().clearRtuRemoteUpdateMap();
/* 73 */         for (int i = 0; i < rtuSims.length; ++i)
/* 74 */           RtuManage.getInstance().putRemoteUpateRtuaToCache(rtuSims[i].trim());
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 78 */       tracer.trace("update remote update rtua list error:" + ex.getLocalizedMessage());
/* 79 */       return false;
/*    */     }
/* 81 */     return true;
/*    */   }
/*    */ }