/*     */ package com.hzjbbis.ws;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.IModule;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.mortbay.jetty.Connector;
/*     */ import org.mortbay.jetty.Handler;
/*     */ import org.mortbay.jetty.Server;
/*     */ import org.mortbay.jetty.handler.DefaultHandler;
/*     */ import org.mortbay.jetty.handler.HandlerCollection;
/*     */ import org.mortbay.jetty.nio.SelectChannelConnector;
/*     */ import org.mortbay.jetty.webapp.WebAppContext;
/*     */ 
/*     */ public class WebServiceServer
/*     */   implements IModule
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(WebServiceServer.class);
/*  22 */   private int wsPort = 9002;
/*     */ 
/*  24 */   Server server = null;
/*     */ 
/*     */   public String getModuleType() {
/*  27 */     return "webService";
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  31 */     return "webService";
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/*  35 */     return "ws";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  39 */     return ((this.server == null) || (!(this.server.isRunning())));
/*     */   }
/*     */ 
/*     */   public boolean start() {
/*  43 */     this.server = new Server();
/*  44 */     SelectChannelConnector connector = new SelectChannelConnector();
/*  45 */     connector.setPort(this.wsPort);
/*  46 */     this.server.setConnectors(new Connector[] { connector });
/*     */ 
/*  48 */     WebAppContext webappcontext = new WebAppContext();
/*  49 */     webappcontext.setContextPath("/");
/*     */ 
/*  51 */     webappcontext.setWar("webapp");
/*     */ 
/*  53 */     HandlerCollection handlers = new HandlerCollection();
/*  54 */     handlers.setHandlers(new Handler[] { webappcontext, new DefaultHandler() });
/*     */ 
/*  56 */     this.server.setHandler(handlers);
/*     */ 
/*  58 */     boolean ret = false;
/*     */     try {
/*  60 */       this.server.start();
/*  61 */       ret = true;
/*     */     } catch (Exception e) {
/*  63 */       log.warn("sever start exception:" + e.getLocalizedMessage(), e);
/*     */     }
/*  65 */     log.info("WebService Server started，port=" + this.wsPort);
/*  66 */     return ret;
/*     */   }
/*     */ 
/*     */   public void stop() {
/*  70 */     if (!(isActive()))
/*  71 */       return;
/*     */     try {
/*  73 */       this.server.stop();
/*     */     } catch (Exception e) {
/*  75 */       log.error(e.getLocalizedMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLastReceiveTime() {
/*  80 */     return 0L;
/*     */   }
/*     */ 
/*     */   public long getLastSendTime() {
/*  84 */     return 0L;
/*     */   }
/*     */ 
/*     */   public int getMsgRecvPerMinute() {
/*  88 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getMsgSendPerMinute() {
/*  92 */     return 0;
/*     */   }
/*     */ 
/*     */   public long getTotalRecvMessages() {
/*  96 */     return 0L;
/*     */   }
/*     */ 
/*     */   public long getTotalSendMessages() {
/* 100 */     return 0L;
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 104 */     return "";
/*     */   }
/*     */ 
/*     */   public final int getWsPort() {
/* 108 */     return this.wsPort;
/*     */   }
/*     */ 
/*     */   public final void setWsPort(int wsPort) {
/* 112 */     this.wsPort = wsPort;
/*     */   }
/*     */ }