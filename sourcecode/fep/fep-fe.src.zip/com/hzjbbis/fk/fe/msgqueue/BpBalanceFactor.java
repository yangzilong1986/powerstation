/*    */ package com.hzjbbis.fk.fe.msgqueue;
/*    */ 
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class BpBalanceFactor
/*    */ {
/* 22 */   private static final BpBalanceFactor instance = new BpBalanceFactor();
/*    */ 
/* 26 */   private final Map<Byte, DistrictFactor> factors = new HashMap();
/*    */ 
/*    */   public static final BpBalanceFactor getInstance()
/*    */   {
/* 24 */     return instance;
/*    */   }
/*    */ 
/*    */   public void travelRtus()
/*    */   {
/* 31 */     travelRtus(RtuManage.getInstance().getAllComRtu());
/*    */   }
/*    */ 
/*    */   public void travelRtus(Collection<ComRtu> rtus)
/*    */   {
/* 37 */     this.factors.clear();
/* 38 */     for (ComRtu rtu : rtus) {
/* 39 */       byte districtCode = (byte)(rtu.getRtua() >>> 24);
/* 40 */       DistrictFactor factor = (DistrictFactor)this.factors.get(Byte.valueOf(districtCode));
/* 41 */       if (factor == null) {
/* 42 */         factor = new DistrictFactor();
/* 43 */         factor.districtCode = districtCode;
/* 44 */         this.factors.put(Byte.valueOf(factor.districtCode), factor);
/*    */       }
/* 46 */       factor.rtuCount += 1;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Collection<DistrictFactor> getAllDistricts() {
/* 51 */     List facts = new ArrayList(this.factors.values());
/* 52 */     List result = new ArrayList();
/* 53 */     while (facts.size() > 0) {
/* 54 */       result.add(removeMaxFactor(facts));
/*    */     }
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   private DistrictFactor removeMaxFactor(List<DistrictFactor> facts) {
/* 60 */     DistrictFactor max = null;
/* 61 */     int pos = -1;
/* 62 */     for (int i = 0; i < facts.size(); ++i) {
/* 63 */       if ((max == null) || (max.rtuCount < ((DistrictFactor)facts.get(i)).rtuCount)) {
/* 64 */         max = (DistrictFactor)facts.get(i);
/* 65 */         pos = i;
/*    */       }
/*    */     }
/* 68 */     if (pos >= 0)
/* 69 */       facts.remove(pos);
/* 70 */     return max;
/*    */   }
/*    */ 
/*    */   class DistrictFactor
/*    */   {
/*    */     public byte districtCode;
/*    */     public int rtuCount;
/*    */ 
/*    */     DistrictFactor() {
/* 79 */       this.districtCode = 0;
/* 80 */       this.rtuCount = 0;
/*    */     }
/*    */   }
/*    */ }