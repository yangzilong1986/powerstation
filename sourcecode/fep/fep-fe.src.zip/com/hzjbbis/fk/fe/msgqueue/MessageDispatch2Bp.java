/*     */ package com.hzjbbis.fk.fe.msgqueue;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.IProfile;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class MessageDispatch2Bp
/*     */   implements IProfile
/*     */ {
/*  26 */   private static final TraceLog tracer = TraceLog.getTracer();
/*  27 */   private static final MessageDispatch2Bp instance = new MessageDispatch2Bp();
/*  28 */   private Map<Byte, BpClient> a12ClientMap = new HashMap();
/*  29 */   private ArrayList<BpClient> clients = new ArrayList();
/*     */ 
/*     */   public static final MessageDispatch2Bp getInstance()
/*     */   {
/*  34 */     return instance;
/*     */   }
/*     */ 
/*     */   private BpClient findByChannel(IServerSideChannel bpChannel) {
/*  38 */     synchronized (this.a12ClientMap) {
/*  39 */       for (BpClient c : this.clients) {
/*  40 */         if (c.channel == bpChannel)
/*  41 */           return c;
/*     */       }
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   private boolean removeByChannel(IServerSideChannel bpChannel) {
/*  48 */     synchronized (this.a12ClientMap) {
/*  49 */       for (int i = 0; i < this.clients.size(); ++i) {
/*  50 */         if (((BpClient)this.clients.get(i)).channel == bpChannel) {
/*  51 */           this.clients.remove(i);
/*  52 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */   public void clearTimeoutChannel() {
/*  60 */     synchronized (this.a12ClientMap) {
/*  61 */       boolean removeTag = false;
/*  62 */       for (int i = 0; i < this.clients.size(); ++i) {
/*  63 */         IServerSideChannel client = ((BpClient)this.clients.get(i)).channel;
/*  64 */         if (System.currentTimeMillis() - client.getLastIoTime() > 180000L) {
/*  65 */           this.clients.remove(i);
/*  66 */           removeTag = true;
/*  67 */           if (tracer.isEnabled())
/*  68 */             tracer.trace("garbage client of MessageDispatch2Bp removed:" + client);
/*     */         }
/*     */       }
/*  71 */       if (removeTag)
/*  72 */         divideDistrict();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onBpClientConnected(IServerSideChannel bpChannel) {
/*  77 */     tracer.trace("client connected:" + bpChannel);
/*  78 */     if (findByChannel(bpChannel) != null)
/*  79 */       return;
/*  80 */     BpClient client = new BpClient(null);
/*  81 */     client.channel = bpChannel;
/*  82 */     synchronized (this.a12ClientMap) {
/*  83 */       this.clients.add(client);
/*  84 */       divideDistrict();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onBpClientClosed(IServerSideChannel bpChannel) {
/*  89 */     synchronized (this.a12ClientMap) {
/*  90 */       if (removeByChannel(bpChannel)) {
/*  91 */         tracer.trace("client closed:" + bpChannel);
/*  92 */         divideDistrict();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void divideDistrict()
/*     */   {
/* 102 */     synchronized (this.a12ClientMap)
/*     */     {
/* 104 */       for (BpClient client : this.clients) {
/* 105 */         client.a1Array.clear();
/* 106 */         client.factor = 0;
/*     */       }
/*     */ 
/* 109 */       BpClient minClient = null;
/* 110 */       for (BpBalanceFactor.DistrictFactor df : BpBalanceFactor.getInstance().getAllDistricts()) {
/* 111 */         minClient = getMinFactorClient();
/* 112 */         if (minClient != null) {
/* 113 */           minClient.a1Array.add(Byte.valueOf(df.districtCode));
/* 114 */           minClient.factor += df.rtuCount;
/*     */         }
/*     */       }
/*     */ 
/* 118 */       for (BpClient client : this.clients) {
/* 119 */         for (int i = 0; i < client.a1Array.size(); ++i)
/* 120 */           this.a12ClientMap.put((Byte)client.a1Array.get(i), client);
/*     */       }
/*     */     }
/* 123 */     if ((tracer.isEnabled()) && (!(this.clients.isEmpty())))
/* 124 */       tracer.trace("BP divided by A1. profile=" + profile());
/*     */   }
/*     */ 
/*     */   private BpClient getMinFactorClient() {
/* 128 */     BpClient minClient = null;
/* 129 */     for (BpClient c : this.clients) {
/* 130 */       if (minClient == null)
/* 131 */         minClient = c;
/* 132 */       else if (c.factor < minClient.factor)
/* 133 */         minClient = c;
/*     */     }
/* 135 */     return minClient;
/*     */   }
/*     */ 
/*     */   public IServerSideChannel getBpChannel(byte a1)
/*     */   {
/* 144 */     BpClient client = null;
/* 145 */     synchronized (this.a12ClientMap) {
/* 146 */       client = (BpClient)this.a12ClientMap.get(Byte.valueOf(a1));
/* 147 */       if (client == null)
/*     */       {
/* 149 */         BpBalanceFactor.getInstance().travelRtus();
/* 150 */         divideDistrict();
/* 151 */         client = (BpClient)this.a12ClientMap.get(Byte.valueOf(a1));
/*     */       }
/*     */     }
/* 154 */     if ((client != null) && (client.channel.sendQueueSize() == 0) && (client.channel.getRequestNum() != 0)) {
/* 155 */       return client.channel;
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   public IServerSideChannel getIdleChannel()
/*     */   {
/* 162 */     synchronized (this.a12ClientMap) {
/* 163 */       for (BpClient c : this.clients) {
/* 164 */         if ((c.channel.sendQueueSize() == 0) && (c.channel.getRequestNum() != 0))
/* 165 */           return c.channel;
/*     */       }
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public String profile()
/*     */   {
/* 178 */     StringBuffer sb = new StringBuffer(1024);
/* 179 */     sb.append("\r\n    <bp-citys>");
/* 180 */     synchronized (this.a12ClientMap) {
/* 181 */       for (BpClient c : this.clients) {
/* 182 */         sb.append("\r\n        <bp addr=\"").append(c.channel.getPeerAddr()).append("\" factor=\"");
/* 183 */         sb.append(c.factor).append("\">");
/* 184 */         boolean first = true;
/* 185 */         for (Byte B : c.a1Array)
/* 186 */           if (first) {
/* 187 */             sb.append(HexDump.toHex(B.byteValue()));
/* 188 */             first = false;
/*     */           }
/*     */           else {
/* 191 */             sb.append(",").append(HexDump.toHex(B.byteValue()));
/*     */           }
/* 193 */         sb.append("</bp>");
/*     */       }
/*     */     }
/* 196 */     sb.append("\r\n    </bp-citys>");
/* 197 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private class BpClient
/*     */   {
/*     */     IServerSideChannel channel;
/*     */     Vector<Byte> a1Array;
/*     */     int factor;
/*     */ 
/*     */     private BpClient()
/*     */     {
/* 172 */       this.channel = null;
/* 173 */       this.a1Array = new Vector();
/* 174 */       this.factor = 0;
/*     */     }
/*     */   }
/*     */ }