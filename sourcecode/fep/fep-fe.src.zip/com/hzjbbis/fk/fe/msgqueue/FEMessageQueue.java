/*     */ package com.hzjbbis.fk.fe.msgqueue;
/*     */ 
/*     */ import com.hzjbbis.db.managertu.ManageRtu;
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.queue.CacheQueue;
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IMessageQueue;
/*     */ import com.hzjbbis.fk.common.spi.IProfile;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.fe.ChannelManage;
/*     */ import com.hzjbbis.fk.fe.userdefine.UserDefineMessageQueue;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gate.GateHead;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjCreator;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class FEMessageQueue
/*     */   implements IMessageQueue, ITimerFunctor, IProfile
/*     */ {
/*  51 */   private static final Logger log = Logger.getLogger(FEMessageQueue.class);
/*     */   private CacheQueue cacheQueue;
/*     */   private ManageRtu manageRtu;
/*  54 */   private int rtuHeartbeatInterval = 900;
/*     */   private CacheQueue taskCacheQueue;
/*  58 */   private final int heartbeatTimer = 0;
/*  59 */   private TimerData td = null;
/*     */ 
/*  61 */   private long hbInterval = ???.rtuHeartbeatInterval * 1000;
/*  62 */   private MessageZjCreator messageCreator = new MessageZjCreator();
/*  63 */   private boolean dispatchRandom = true;
/*  64 */   private boolean noConvert = false;
/*     */ 
/*  67 */   private Runnable shutdownHook = new Runnable() {
/*     */     public void run() {
/*  69 */       FEMessageQueue.this.dispose();
/*     */     }
/*  67 */   };
/*     */ 
/*     */   public void setCacheQueue(CacheQueue queue)
/*     */   {
/*  74 */     this.cacheQueue = queue;
/*  75 */     if (this.td == null)
/*  76 */       initialize();
/*  77 */     FasSystem.getFasSystem().addShutdownHook(this.shutdownHook);
/*     */   }
/*     */ 
/*     */   public void setRtuHeartbeatInterval(int interval) {
/*  81 */     this.rtuHeartbeatInterval = interval;
/*  82 */     this.hbInterval = (this.rtuHeartbeatInterval * 1000);
/*  83 */     initialize();
/*     */   }
/*     */ 
/*     */   public void initialize() {
/*  87 */     if (this.td != null) {
/*  88 */       TimerScheduler.getScheduler().removeTimer(this, 0);
/*  89 */       this.td = null;
/*     */     }
/*  91 */     if (this.rtuHeartbeatInterval > 10) {
/*  92 */       this.td = new TimerData(this, 0, this.rtuHeartbeatInterval);
/*  93 */       TimerScheduler.getScheduler().addTimer(this.td);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onTimer(int timerID) {
/*  98 */     if (timerID == 0)
/*  99 */       for (ComRtu rtu : RtuManage.getInstance().getAllComRtu())
/*     */       {
/* 101 */         if (rtu.getActiveGprs() == null)
/*     */           continue;
/* 103 */         long distance = Math.abs(System.currentTimeMillis() - rtu.getLastIoTime());
/* 104 */         if (distance <= this.hbInterval) {
/*     */           continue;
/*     */         }
/* 107 */         MessageZj heartbeat = this.messageCreator.createHeartBeat(rtu.getRtua());
/* 108 */         rtu.setLastIoTime(System.currentTimeMillis());
/* 109 */         sendMessage(heartbeat);
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean sendMessage(IMessage msg)
/*     */   {
/* 117 */     if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 118 */       MessageZj zjmsg = (MessageZj)msg;
/* 119 */       IChannel channel = null;
/* 120 */       boolean result = false;
/* 121 */       if (zjmsg.head.c_func == 36)
/*     */       {
/* 123 */         channel = ChannelManage.getInstance().getGPRSChannel(zjmsg.head.rtua);
/* 124 */         if (channel != null)
/* 125 */           result = channel.send(zjmsg);
/*     */       }
/* 127 */       else if (zjmsg.head.c_func == 15) {
/* 128 */         result = UserDefineMessageQueue.getInstance().sendMessageDown(zjmsg);
/*     */       }
/*     */       else {
/* 131 */         channel = ChannelManage.getInstance().getChannel(zjmsg.head.rtua);
/* 132 */         if (channel == null) {
/* 133 */           log.warn("该终端无可用通道下行,RTUA=" + HexDump.toHex(zjmsg.head.rtua));
/* 134 */           return false;
/*     */         }
/* 136 */         result = channel.send(zjmsg);
/*     */       }
/* 138 */       return result;
/*     */     }
/* 140 */     if (msg.getMessageType() == MessageType.MSG_GATE) {
/* 141 */       MessageGate gatemsg = (MessageGate)msg;
/*     */ 
/* 143 */       String appstring = gatemsg.getHead().getAttributeAsString(9);
/* 144 */       if ((appstring != null) && (appstring.length() >= 9)) {
/* 145 */         String appid = appstring.substring(5, 9);
/* 146 */         IChannel channel = ChannelManage.getInstance().getChannel(appid);
/* 147 */         if (channel == null) {
/* 148 */           log.warn("指定短信应用号无对应通道：appid=" + appid);
/* 149 */           handleSendFail(gatemsg.getInnerMessage());
/* 150 */           return false;
/*     */         }
/* 152 */         IMessage rtuMsg = gatemsg.getInnerMessage();
/* 153 */         rtuMsg.setPeerAddr(appstring);
/* 154 */         return channel.send(rtuMsg);
/*     */       }
/*     */ 
/* 157 */       IMessage rtuMsg = gatemsg.getInnerMessage();
/* 158 */       if (rtuMsg == null) {
/* 159 */         log.error("下行的网关消息没有包含浙江或国网规约帧。gatemsg=" + gatemsg.getRawPacketString());
/* 160 */         return false;
/*     */       }
/*     */ 
/* 163 */       if (rtuMsg.getMessageType() == MessageType.MSG_ZJ) {
/* 164 */         MessageZj zjmsg = (MessageZj)rtuMsg;
/* 165 */         if (zjmsg.head.c_func == 40) {
/* 166 */           IChannel umsChannel = ChannelManage.getInstance().getActiveUmsChannel();
/* 167 */           if (umsChannel == null) {
/* 168 */             log.warn("当前没有在线的UMS短信通道，请求发送短信失败。");
/* 169 */             return false;
/*     */           }
/* 171 */           return umsChannel.send(zjmsg);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 177 */       ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtuMsg.getRtua());
/* 178 */       if (rtu == null) {
/* 179 */         boolean refreshTag = this.manageRtu.refreshComRtu(rtuMsg.getRtua());
/* 180 */         if (!(refreshTag)) {
/* 181 */           log.warn("rtu send failed,not find comRtu in db:" + HexDump.toHex(rtuMsg.getRtua()));
/* 182 */           return false;
/*     */         }
/*     */ 
/* 185 */         rtu = RtuManage.getInstance().getComRtuInCache(rtuMsg.getRtua());
/*     */       }
/* 187 */       IChannel channel = ChannelManage.getInstance().getChannel(rtuMsg.getRtua());
/* 188 */       if (channel == null) {
/* 189 */         log.warn("该终端无可用通道下行,RTUA=" + HexDump.toHex(rtuMsg.getRtua()));
/* 190 */         handleSendFail(rtuMsg);
/* 191 */         return false;
/*     */       }
/*     */ 
/* 195 */       if (rtuMsg.getMessageType() == MessageType.MSG_ZJ) {
/* 196 */         if (((MessageZj)rtuMsg).head.msta != 0)
/* 197 */           rtu.setLastReqTime(System.currentTimeMillis());
/*     */       }
/* 199 */       else if (rtuMsg.getMessageType() == MessageType.MSG_GW_10) {
/* 200 */         MessageGw gwmsg = (MessageGw)rtuMsg;
/* 201 */         if ((gwmsg.head.c_prm == 1) && (gwmsg.head.c_dir == 0)) {
/* 202 */           rtu.setLastReqTime(System.currentTimeMillis());
/*     */         }
/* 204 */         if (gwmsg.afn() == 15) {
/* 205 */           channel = ChannelManage.getInstance().getGPRSChannel(gwmsg.getRtua());
/* 206 */           boolean result = false;
/* 207 */           if (channel != null)
/* 208 */             result = UserDefineMessageQueue.getInstance().sendMessageDown(gwmsg);
/* 209 */           return result;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 216 */       rtuMsg.setStatus(rtu.getActiveGprs());
/* 217 */       return channel.send(msg);
/*     */     }
/* 219 */     log.error("FEMessageQueue只支持MessageGate,MessageZj消息下行。程序错啦！");
/* 220 */     return false;
/*     */   }
/*     */ 
/*     */   private void handleSendFail(IMessage msg) {
/*     */     try {
/* 225 */       IChannel channel = msg.getSource();
/* 226 */       if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 227 */         MessageZj zjmsg = (MessageZj)msg;
/* 228 */         MessageZj repSendFail = zjmsg.createSendFailReply();
/* 229 */         MessageGate gatemsg = new MessageGate();
/* 230 */         gatemsg.setUpInnerMessage(repSendFail);
/* 231 */         channel.send(gatemsg);
/*     */       }
/*     */     } catch (Exception exp) {
/* 234 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean sendMessageByUms(IMessage message)
/*     */   {
/* 244 */     IChannel channel = null;
/* 245 */     IMessage msg = message;
/* 246 */     if (message.getMessageType() == MessageType.MSG_ZJ) {
/* 247 */       MessageZj zjmsg = (MessageZj)message;
/* 248 */       channel = ChannelManage.getInstance().getUmsChannel(null, zjmsg.head.rtua);
/*     */     }
/* 250 */     else if (message.getMessageType() == MessageType.MSG_GATE) {
/* 251 */       MessageGate gatemsg = (MessageGate)message;
/* 252 */       msg = gatemsg.getInnerMessage();
/* 253 */       if (msg == null) {
/* 254 */         log.error("下行的网关消息没有包含规约帧。gatemsg=" + gatemsg.getRawPacketString());
/* 255 */         return false;
/*     */       }
/*     */ 
/* 258 */       String appid = msg.getPeerAddr();
/* 259 */       channel = ChannelManage.getInstance().getUmsChannel(appid, msg.getRtua());
/*     */     }
/* 261 */     if (channel == null) {
/* 262 */       log.warn("该终端无可用UMS通道下行,RTUA=" + HexDump.toHex(msg.getRtua()));
/* 263 */       return false;
/*     */     }
/* 265 */     channel.send(msg);
/* 266 */     return true;
/*     */   }
/*     */ 
/*     */   public IMessage take()
/*     */   {
/* 271 */     return this.cacheQueue.take();
/*     */   }
/*     */ 
/*     */   public IMessage poll() {
/* 275 */     return this.cacheQueue.poll();
/*     */   }
/*     */ 
/*     */   public void offer(IMessage msg0)
/*     */   {
/* 284 */     if (msg0.getMessageType() == MessageType.MSG_GATE) {
/* 285 */       RuntimeException re = new RuntimeException();
/* 286 */       log.warn("出现插入gate 消息", re);
/* 287 */       return;
/*     */     }
/* 289 */     if (msg0 instanceof MessageZj) {
/* 290 */       MessageZj zjmsg = (MessageZj)msg0;
/* 291 */       if (this.taskCacheQueue != null) {
/*     */         try {
/* 293 */           if (zjmsg.head.c_func == 2)
/* 294 */             this.taskCacheQueue.offer(zjmsg);
/*     */         }
/*     */         catch (Exception localException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/* 301 */     this.cacheQueue.offer(msg0);
/*     */ 
/* 304 */     msg0 = this.cacheQueue.poll();
/*     */ 
/* 306 */     if (msg0 == null) {
/* 307 */       return;
/*     */     }
/* 309 */     IServerSideChannel bpChannel = null;
/*     */ 
/* 311 */     if (this.dispatchRandom)
/*     */     {
/* 313 */       bpChannel = MessageDispatch2Bp.getInstance().getIdleChannel();
/*     */     }
/*     */ 
/* 319 */     if (bpChannel == null) {
/* 320 */       pushBack(msg0);
/* 321 */       return;
/*     */     }
/* 323 */     boolean success = false;
/* 324 */     if (this.noConvert) {
/* 325 */       success = bpChannel.send(msg0);
/*     */     }
/*     */     else {
/* 328 */       MessageGate gateMsg = new MessageGate();
/* 329 */       gateMsg.setUpInnerMessage(msg0);
/* 330 */       success = bpChannel.send(gateMsg);
/*     */     }
/* 332 */     if (!(success))
/* 333 */       pushBack(msg0);
/*     */   }
/*     */ 
/*     */   public void pushBack(IMessage msg)
/*     */   {
/* 342 */     this.cacheQueue.offer(msg);
/*     */   }
/*     */ 
/*     */   public int size() {
/* 346 */     return this.cacheQueue.size();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 351 */     return "FEMessageQueue";
/*     */   }
/*     */ 
/*     */   public CacheQueue getTaskCacheQueue() {
/* 355 */     return this.taskCacheQueue;
/*     */   }
/*     */ 
/*     */   public void setTaskCacheQueue(CacheQueue taskCacheQueue) {
/* 359 */     this.taskCacheQueue = taskCacheQueue;
/*     */   }
/*     */ 
/*     */   public void onBpClientConnected(IServerSideChannel bpClient) {
/* 363 */     MessageDispatch2Bp.getInstance().onBpClientConnected(bpClient);
/*     */   }
/*     */ 
/*     */   public void onBpClientClosed(IServerSideChannel bpClient) {
/* 367 */     MessageDispatch2Bp.getInstance().onBpClientClosed(bpClient);
/*     */   }
/*     */ 
/*     */   public void setDispatchRandom(boolean dispatchRandom) {
/* 371 */     this.dispatchRandom = dispatchRandom;
/*     */   }
/*     */ 
/*     */   public void setNoConvert(boolean noConvert) {
/* 375 */     this.noConvert = noConvert;
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 379 */     StringBuffer sb = new StringBuffer(256);
/* 380 */     sb.append("\r\n    <message-queue type=\"fe\">");
/* 381 */     sb.append("\r\n        <size>").append(size()).append("</size>");
/* 382 */     sb.append("\r\n    </message-queue>");
/* 383 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void dispose() {
/* 387 */     this.cacheQueue.dispose();
/*     */   }
/*     */ 
/*     */   public void setManageRtu(ManageRtu manageRtu) {
/* 391 */     this.manageRtu = manageRtu;
/*     */   }
/*     */ }