/*    */ package com.hzjbbis.fk.fe;
/*    */ 
/*    */ import com.hzjbbis.fk.utils.ClassLoaderUtil;
/*    */ 
/*    */ public class Application
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 11 */     ClassLoaderUtil.initializeClassPath();
/* 12 */     FeCommunication.main(args);
/*    */   }
/*    */ }