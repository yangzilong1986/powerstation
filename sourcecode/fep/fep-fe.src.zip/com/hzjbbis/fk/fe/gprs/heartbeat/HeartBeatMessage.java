/*     */ package com.hzjbbis.fk.fe.gprs.heartbeat;
/*     */ 
/*     */ import com.hzjbbis.db.heartbeat.HeartBeat;
/*     */ import com.hzjbbis.db.heartbeat.HeartBeatArray;
/*     */ import com.hzjbbis.db.heartbeat.HeartBeatDao;
/*     */ import com.hzjbbis.db.heartbeat.HeartBeatLog;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class HeartBeatMessage
/*     */ {
/*  18 */   private int batchSize = 1000;
/*     */ 
/*  20 */   private int weekNum = 2;
/*     */   private HeartBeatDao heartBeatDao;
/*  24 */   private static HeartBeatArray[] workList = new HeartBeatArray[35];
/*     */ 
/*  26 */   private static List<HeartBeatArray> poolList = new Vector(20);
/*     */ 
/*  28 */   private List<HeartBeatArray> batchSaveList = new Vector();
/*     */ 
/*  30 */   private String poolListLock = "";
/*     */   private Worker worker;
/*     */   private boolean working;
/*  33 */   private boolean isNeedInit = false;
/*  34 */   private static int nInitWeekNo = 0;
/*     */   private boolean stop;
/*     */ 
/*     */   public void initHeart(int weekNO)
/*     */   {
/*  43 */     nInitWeekNo = weekNO;
/*  44 */     long curTime = System.currentTimeMillis();
/*  45 */     Calendar c = Calendar.getInstance();
/*  46 */     c.setTimeInMillis(curTime);
/*  47 */     System.out.println("initial1：" + System.currentTimeMillis());
/*     */     try {
/*  49 */       List list = this.heartBeatDao.getLogResult(weekNO);
/*  50 */       if (list.size() > 0) {
/*  51 */         for (HeartBeatLog hbl : list) {
/*  52 */           int id = hbl.getId();
/*  53 */           boolean isSuccess = hbl.getIssuccess();
/*  54 */           if (!(isSuccess)) {
/*  55 */             boolean b = this.heartBeatDao.doInit(nInitWeekNo, this.weekNum);
/*  56 */             if (b) {
/*  57 */               this.isNeedInit = false;
/*     */             }
/*     */             else {
/*  60 */               this.isNeedInit = true;
/*     */             }
/*  62 */             this.heartBeatDao.updateLogResult(b, curTime, id, nInitWeekNo);
/*     */           } else {
/*  64 */             return;
/*     */           }
/*     */         }
/*  51 */         break label237:
/*     */       }
/*     */ 
/*  68 */       boolean b = this.heartBeatDao.doInit(nInitWeekNo, this.weekNum);
/*  69 */       if (b) {
/*  70 */         this.isNeedInit = false;
/*     */       }
/*     */       else {
/*  73 */         this.isNeedInit = true;
/*     */       }
/*  75 */       this.heartBeatDao.insertLogResult(nInitWeekNo, curTime);
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*  79 */       e.printStackTrace();
/*     */     }
/*  81 */     label237: System.out.println("initial2：" + System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */   public void putBeat(String rtua, long heartBeatTime, String deptCode)
/*     */   {
/*  92 */     HeartBeat heartBeat = new HeartBeat();
/*  93 */     HeartBeatArray batchSaveArray = null;
/*     */ 
/*  95 */     Calendar c = Calendar.getInstance();
/*  96 */     c.setTimeInMillis(heartBeatTime);
/*     */ 
/*  98 */     int hour = c.get(11);
/*  99 */     int minutes = c.get(12);
/* 100 */     int day = c.get(7);
/*     */ 
/* 103 */     int columNum = (day - 1) * 5 + (hour * 60 + minutes) / 315;
/*     */ 
/* 105 */     long binaryTemp = (hour * 60 + minutes) % 315;
/* 106 */     long binaryLocation = binaryTemp / 5L;
/*     */ 
/* 108 */     int weekOfYear = c.get(3);
/* 109 */     int weekFlag = weekOfYear % this.weekNum;
/* 110 */     heartBeat.setRtua(rtua);
/* 111 */     heartBeat.setWeekOfYear(weekOfYear);
/* 112 */     heartBeat.setValueOrigin(String.valueOf(heartBeatTime));
/* 113 */     heartBeat.setDeptCode(deptCode);
/* 114 */     long hearbeatvalue = 1L;
/*     */ 
/* 116 */     hearbeatvalue <<= (int)(62L - binaryLocation);
/*     */ 
/* 118 */     heartBeat.setColumnIndex(columNum + 1);
/* 119 */     heartBeat.setWeekTag(weekFlag);
/* 120 */     heartBeat.setValue(hearbeatvalue);
/*     */ 
/* 122 */     synchronized (workList) {
/* 123 */       HeartBeatArray heartBeats = workList[columNum];
/* 124 */       if (heartBeats == null) {
/* 125 */         heartBeats = getArrayFromPool(columNum + 1);
/* 126 */         workList[columNum] = heartBeats;
/*     */       }
/* 129 */       else if (heartBeats.isFull()) {
/* 130 */         batchSaveArray = heartBeats;
/* 131 */         heartBeats = getArrayFromPool(columNum + 1);
/* 132 */         workList[columNum] = heartBeats;
/*     */       }
/*     */ 
/* 135 */       heartBeats.addHeartBeat(heartBeat);
/*     */     }
/*     */ 
/* 138 */     if (batchSaveArray != null)
/* 139 */       addBatchSaveArray(batchSaveArray);
/*     */   }
/*     */ 
/*     */   private HeartBeatArray getArrayFromPool(int columnIndex) {
/* 143 */     synchronized (this.poolListLock) {
/* 144 */       if (poolList.size() > 0) {
/* 145 */         HeartBeatArray array = (HeartBeatArray)poolList.remove(0);
/* 146 */         array.setColumnIndex(columnIndex);
/* 147 */         return array;
/*     */       }
/*     */     }
/* 150 */     return new HeartBeatArray(columnIndex, this.batchSize);
/*     */   }
/*     */ 
/*     */   private void freeMap(HeartBeatArray array) {
/* 154 */     if (poolList.size() < 20) {
/* 155 */       array.initArray();
/* 156 */       poolList.add(array);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addBatchSaveArray(HeartBeatArray heartBeats) {
/* 161 */     this.batchSaveList.add(heartBeats);
/* 162 */     if (this.worker == null) {
/* 163 */       this.stop = false;
/* 164 */       this.worker = new Worker();
/* 165 */       this.worker.start();
/*     */     }
/*     */ 
/* 168 */     if (!(this.working))
/* 169 */       synchronized (this.worker) {
/* 170 */         this.worker.notify();
/*     */       }
/*     */   }
/*     */ 
/*     */   public void pleaseStop()
/*     */   {
/* 177 */     this.stop = true;
/* 178 */     if (this.worker.isAlive())
/* 179 */       synchronized (this.worker) {
/* 180 */         this.worker.notify();
/*     */       }
/*     */   }
/*     */ 
/*     */   private void doBatchSave(HeartBeatArray heartBeats)
/*     */     throws SQLException
/*     */   {
/*     */     HeartBeat heartBeat;
/* 187 */     int columnIndex = heartBeats.getColumnIndex();
/*     */ 
/* 189 */     List orHeartBeats = new ArrayList();
/* 190 */     for (int i = 0; i < heartBeats.getSize(); ++i) {
/* 191 */       orHeartBeats.add(heartBeats.getHeartBeat(i));
/*     */     }
/*     */ 
/* 194 */     List insertHeartBeats = new ArrayList();
/* 195 */     if (orHeartBeats.size() > 0) {
/* 196 */       int[] executeds = this.heartBeatDao.batchUpdate(orHeartBeats, columnIndex);
/* 197 */       int i = 0;
/* 198 */       for (Iterator localIterator = orHeartBeats.iterator(); localIterator.hasNext(); ) { heartBeat = (HeartBeat)localIterator.next();
/* 199 */         if (executeds[(i++)] == 0) {
/* 200 */           insertHeartBeats.add(heartBeat);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 205 */     if (insertHeartBeats.size() <= 0) {
/*     */       return;
/*     */     }
/* 208 */     Map map = new HashMap();
/* 209 */     for (HeartBeat temp : insertHeartBeats) {
/* 210 */       map.put(temp.getKey(), temp);
/*     */     }
/* 212 */     List tempList = new ArrayList();
/* 213 */     tempList.addAll(map.values());
/* 214 */     this.heartBeatDao.batchInsert(tempList, columnIndex);
/* 215 */     if (map.size() < this.batchSize)
/* 216 */       this.heartBeatDao.batchUpdate(insertHeartBeats, columnIndex);
/*     */   }
/*     */ 
/*     */   public int getWeekNo(long time)
/*     */   {
/* 223 */     Calendar c = Calendar.getInstance();
/* 224 */     c.setTimeInMillis(time);
/*     */ 
/* 226 */     return c.get(3);
/*     */   }
/*     */ 
/*     */   public void setBatchSize(int batchSize)
/*     */   {
/* 288 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */   public void setHeartBeatDao(HeartBeatDao heartBeatDao) {
/* 292 */     this.heartBeatDao = heartBeatDao;
/*     */   }
/*     */ 
/*     */   public void setWeekNum(int weekNum) {
/* 296 */     this.weekNum = weekNum;
/*     */   }
/*     */ 
/*     */   class Worker extends Thread
/*     */   {
/*     */     public Worker()
/*     */     {
/* 230 */       super("Work Threads");
/*     */     }
/*     */ 
/*     */     public void run() {
/* 234 */       while (!(HeartBeatMessage.this.stop)) {
/* 235 */         HeartBeatArray array = null;
/* 236 */         HeartBeatMessage.this.working = true;
/* 237 */         if (!(HeartBeatMessage.this.batchSaveList.isEmpty()))
/*     */         {
/* 239 */           array = (HeartBeatArray)HeartBeatMessage.this.batchSaveList.remove(0);
/*     */           try {
/* 241 */             HeartBeatMessage.this.doBatchSave(array);
/*     */           }
/*     */           catch (SQLException e) {
/* 244 */             e.printStackTrace();
/*     */           }
/*     */ 
/* 247 */           HeartBeatMessage.this.freeMap(array);
/*     */ 
/* 249 */           if (HeartBeatMessage.this.batchSaveList.size() > 0) {
/*     */             continue;
/*     */           }
/*     */         }
/* 253 */         if (HeartBeatMessage.this.isNeedInit) {
/* 254 */           HeartBeatMessage.this.initHeart(HeartBeatMessage.nInitWeekNo);
/*     */         }
/*     */ 
/* 257 */         long waitStart = System.currentTimeMillis();
/* 258 */         synchronized (this) {
/*     */           try {
/* 260 */             HeartBeatMessage.this.working = false;
/* 261 */             System.out.println("3:" + System.currentTimeMillis());
/* 262 */             super.wait(120000L);
/*     */           }
/*     */           catch (InterruptedException e) {
/* 265 */             e.printStackTrace();
/*     */           }
/*     */         }
/* 268 */         long waited = System.currentTimeMillis() - waitStart;
/* 269 */         if (waited > 119000L) {
/* 270 */           synchronized (HeartBeatMessage.workList) {
/* 271 */             for (int i = 0; i < HeartBeatMessage.workList.length; ++i) {
/* 272 */               HeartBeatArray a = HeartBeatMessage.workList[i];
/* 273 */               if (a.getSize() > 0) {
/* 274 */                 HeartBeatMessage.workList[i] = null;
/* 275 */                 HeartBeatMessage.this.addBatchSaveArray(a);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 283 */       HeartBeatMessage.this.worker = null;
/* 284 */       HeartBeatMessage.this.stop = true;
/*     */     }
/*     */   }
/*     */ }