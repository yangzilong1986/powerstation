/*    */ package com.hzjbbis.fk.fe.gprs.heartbeat;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class HeartQuartz
/*    */ {
/*    */   private HeartBeatMessage heartBeatMessage;
/*    */ 
/*    */   public void initHeart()
/*    */   {
/*  8 */     Calendar c = Calendar.getInstance();
/*  9 */     c.setTimeInMillis(System.currentTimeMillis());
/* 10 */     int weekNO = c.get(3);
/* 11 */     this.heartBeatMessage.initHeart(weekNO + 1); }
/*    */ 
/*    */   public void setHeartBeatMessage(HeartBeatMessage heartBeatMessage) {
/* 14 */     this.heartBeatMessage = heartBeatMessage;
/*    */   }
/*    */ }