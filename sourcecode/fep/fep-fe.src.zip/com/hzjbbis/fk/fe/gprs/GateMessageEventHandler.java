/*     */ package com.hzjbbis.fk.fe.gprs;
/*     */ 
/*     */ import com.hzjbbis.db.batch.AsyncService;
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.fe.filecache.HeartbeatPersist;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuCommFlowCache;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuParamsCache;
/*     */ import com.hzjbbis.fk.fe.msgqueue.FEMessageQueue;
/*     */ import com.hzjbbis.fk.fe.userdefine.UserDefineMessageQueue;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gate.GateHead;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class GateMessageEventHandler
/*     */   implements IEventHandler
/*     */ {
/*  36 */   private static final Logger log = Logger.getLogger(GateMessageEventHandler.class);
/*     */   private FEMessageQueue msgQueue;
/*     */   private UserDefineMessageQueue udefQueue;
/*     */   private AsyncService asyncDbService;
/*     */ 
/*     */   public void handleEvent(IEvent event)
/*     */   {
/*  45 */     if (event.getType().equals(EventType.MSG_RECV))
/*  46 */       onRecvMessage((ReceiveMessageEvent)event);
/*  47 */     else if (event.getType().equals(EventType.MSG_SENT))
/*  48 */       onSendMessage((SendMessageEvent)event);
/*     */   }
/*     */ 
/*     */   private void onRecvMessage(ReceiveMessageEvent e)
/*     */   {
/*  55 */     IMessage msg = e.getMessage();
/*  56 */     if (msg.getMessageType() == MessageType.MSG_GATE)
/*     */     {
/*     */       IMessage imsg;
/*     */       MessageZj zjmsg;
/*     */       MessageGw gwmsg;
/*  57 */       MessageGate mgate = (MessageGate)msg;
/*     */ 
/*  59 */       if (mgate.getHead().getCommand() == 18)
/*     */       {
/*  61 */         log.info(mgate);
/*  62 */         return;
/*     */       }
/*  64 */       if (mgate.getHead().getCommand() == 34) {
/*  65 */         imsg = mgate.getInnerMessage();
/*  66 */         if (imsg != null)
/*  67 */           if (imsg.getMessageType() == MessageType.MSG_ZJ) {
/*  68 */             zjmsg = (MessageZj)imsg;
/*  69 */             _handleZjMessage(zjmsg, e);
/*     */           }
/*  71 */           else if (imsg.getMessageType() == MessageType.MSG_GW_10) {
/*  72 */             gwmsg = (MessageGw)imsg;
/*  73 */             _handleGwMessage(gwmsg, e);
/*     */           }
/*     */       }
/*     */       else {
/*  77 */         if (mgate.getHead().getCommand() == 36)
/*     */         {
/*  79 */           imsg = mgate.getInnerMessage();
/*  80 */           if (imsg.getMessageType() == MessageType.MSG_ZJ) {
/*  81 */             gwmsg = (MessageZj)imsg;
/*     */ 
/*  83 */             if ((gwmsg.head.c_func == 15) || 
/*  84 */               (gwmsg.head.c_func == 36)) {
/*  85 */               return;
/*     */             }
/*     */ 
/*  88 */             if ((gwmsg != null) && (log.isDebugEnabled()))
/*  89 */               log.debug("网关下行失败报文,转短信通道:" + gwmsg);
/*  90 */             this.msgQueue.sendMessageByUms(gwmsg);
/*  91 */             return;
/*     */           }
/*  93 */           if (imsg.getMessageType() != MessageType.MSG_GW_10) return;
/*  94 */           gwmsg = (MessageGw)imsg;
/*  95 */           if ((gwmsg.afn() != 5) && 
/*  96 */             (gwmsg.afn() != 12) && 
/*  97 */             (gwmsg.afn() != 13) && 
/*  98 */             (gwmsg.afn() != 14) && 
/*  99 */             (gwmsg.afn() != 11) && 
/* 100 */             (gwmsg.afn() != 10) && 
/* 101 */             (gwmsg.afn() != 16) && 
/* 102 */             (gwmsg.afn() != 1) && 
/* 103 */             (gwmsg.afn() != 4) && 
/* 104 */             (gwmsg.afn() != 8) && 
/* 105 */             (gwmsg.afn() != 9))
/*     */             return;
/* 107 */           this.msgQueue.sendMessageByUms(gwmsg);
/* 108 */           return;
/*     */         }
/*     */ 
/* 112 */         if (mgate.getHead().getCommand() == 50) {
/* 113 */           String gateProfile = new String(mgate.getData().array());
/* 114 */           FasSystem.getFasSystem().addGprsGateProfile(e.getClient().getPeerAddr(), gateProfile);
/* 115 */           return;
/*     */         }
/*     */ 
/* 119 */         log.error("其它类型命令。");
/*     */       }
/*     */     }
/* 122 */     else if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 123 */       _handleZjMessage((MessageZj)msg, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void _handleZjMessage(MessageZj zjmsg, ReceiveMessageEvent event) {
/* 128 */     if (log.isDebugEnabled()) {
/* 129 */       log.debug("网关上行报文:" + zjmsg);
/*     */     }
/*     */ 
/* 136 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(zjmsg.head.rtua);
/* 137 */     if (rtu == null)
/*     */     {
/* 139 */       String strRtua = HexDump.toHex(zjmsg.head.rtua);
/* 140 */       log.warn("终端不在缓存中，需要重新加载。rtua=" + strRtua);
/*     */ 
/* 142 */       rtu = new ComRtu();
/* 143 */       rtu.setLogicAddress(strRtua);
/* 144 */       rtu.setRtua(zjmsg.head.rtua);
/*     */ 
/* 146 */       RtuManage.getInstance().putComRtuToCache(rtu);
/*     */     }
/*     */ 
/* 152 */     rtu.setLastGprsTime(System.currentTimeMillis());
/* 153 */     rtu.setLastIoTime(rtu.getLastGprsTime());
/*     */ 
/* 155 */     String gprsIpAddr = zjmsg.getPeerAddr();
/* 156 */     if ((gprsIpAddr != null) && (gprsIpAddr.length() > 0)) {
/* 157 */       rtu.setRtuIpAddr(gprsIpAddr);
/*     */     }
/*     */ 
/* 160 */     int flow = zjmsg.length();
/* 161 */     if ((zjmsg.head.c_func == 36) || 
/* 162 */       (zjmsg.head.c_func == 34)) {
/* 163 */       rtu.addDownGprsFlowmeter(flow); rtu.addUpGprsFlowmeter(flow);
/* 164 */       rtu.incUpGprsCount(); rtu.incDownGprsCount();
/*     */     }
/* 166 */     else if (zjmsg.head.c_func == 33) {
/* 167 */       rtu.addUpGprsFlowmeter(flow); rtu.addDownGprsFlowmeter(flow - 3);
/* 168 */       rtu.incUpGprsCount(); rtu.incDownGprsCount();
/*     */     }
/* 170 */     else if (zjmsg.head.c_func == 2) {
/* 171 */       rtu.incTaskCount();
/* 172 */       rtu.addUpGprsFlowmeter(flow);
/* 173 */       rtu.incUpGprsCount();
/*     */     }
/*     */     else {
/* 176 */       rtu.addUpGprsFlowmeter(flow);
/* 177 */       rtu.incUpGprsCount();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 182 */       String gateAddr = event.getClient().getPeerAddr();
/* 183 */       if (!(gateAddr.equals(rtu.getActiveGprs()))) {
/* 184 */         rtu.setActiveGprs(gateAddr);
/*     */ 
/* 187 */         RtuParamsCache.getInstance().addRtu(rtu);
/*     */ 
/* 190 */         String serverAddr = zjmsg.getServerAddress();
/* 191 */         if ((serverAddr != null) && (rtu.getCommAddress() != null) && 
/* 192 */           ("02".equals(rtu.getCommType())) && 
/* 193 */           (!(serverAddr.equals(rtu.getCommAddress())))) {
/* 194 */           rtu.setMisGprsAddress(serverAddr);
/* 195 */           log.warn("终端实际上行地址与资产表不一致：rtua=" + HexDump.toHex(zjmsg.head.rtua) + ",serverAddress=" + serverAddr);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception err)
/*     */     {
/* 201 */       log.error("update activeGprs exp:" + err.getLocalizedMessage(), err);
/*     */     }
/*     */ 
/* 206 */     if (zjmsg.head.c_func == 36)
/*     */     {
/* 208 */       rtu.setLastHeartbeat(System.currentTimeMillis());
/* 209 */       rtu.incHeartbeat();
/* 210 */       HeartbeatPersist.getInstance().handleHeartbeat(rtu.getRtua());
/*     */ 
/* 212 */       return;
/*     */     }
/*     */ 
/* 215 */     RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */ 
/* 218 */     if (this.asyncDbService != null) {
/* 219 */       this.asyncDbService.log2Db(zjmsg);
/*     */     }
/*     */ 
/* 222 */     if (zjmsg.head.c_func == 15)
/* 223 */       this.udefQueue.offer(zjmsg);
/*     */     else
/* 225 */       this.msgQueue.offer(zjmsg);
/*     */   }
/*     */ 
/*     */   private void _handleGwMessage(MessageGw gwmsg, ReceiveMessageEvent event) {
/* 229 */     if (log.isDebugEnabled()) {
/* 230 */       log.debug("网关上行报文:" + gwmsg);
/*     */     }
/*     */ 
/* 237 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(gwmsg.head.rtua);
/* 238 */     if (rtu == null) {
/* 239 */       String strRtua = HexDump.toHex(gwmsg.head.rtua);
/* 240 */       log.warn("终端不在缓存中，需要重新加载。rtua=" + strRtua);
/*     */ 
/* 242 */       rtu = new ComRtu();
/* 243 */       rtu.setLogicAddress(strRtua);
/* 244 */       rtu.setRtua(gwmsg.head.rtua);
/* 245 */       RtuManage.getInstance().putComRtuToCache(rtu);
/*     */     }
/*     */ 
/* 251 */     rtu.setLastGprsTime(System.currentTimeMillis());
/* 252 */     rtu.setLastIoTime(rtu.getLastGprsTime());
/*     */ 
/* 254 */     String gprsIpAddr = gwmsg.getPeerAddr();
/* 255 */     if ((gprsIpAddr != null) && (gprsIpAddr.length() > 0)) {
/* 256 */       rtu.setRtuIpAddr(gprsIpAddr);
/*     */     }
/*     */ 
/* 259 */     int flow = gwmsg.length();
/* 260 */     if (gwmsg.isNeedConfirm()) {
/* 261 */       rtu.addDownGprsFlowmeter(16); rtu.addUpGprsFlowmeter(flow);
/* 262 */       rtu.incUpGprsCount(); rtu.incDownGprsCount();
/*     */     }
/* 264 */     else if (gwmsg.afn() == 11) {
/* 265 */       rtu.incTaskCount();
/* 266 */       rtu.addUpGprsFlowmeter(flow);
/* 267 */       rtu.incUpGprsCount();
/*     */     }
/*     */     else {
/* 270 */       rtu.addUpGprsFlowmeter(flow);
/* 271 */       rtu.incUpGprsCount();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 276 */       String gateAddr = event.getClient().getPeerAddr();
/* 277 */       if (!(gateAddr.equals(rtu.getActiveGprs()))) {
/* 278 */         rtu.setActiveGprs(gateAddr);
/*     */ 
/* 281 */         RtuParamsCache.getInstance().addRtu(rtu);
/*     */ 
/* 284 */         String serverAddr = gwmsg.getServerAddress();
/* 285 */         if ((serverAddr != null) && (rtu.getCommAddress() != null) && 
/* 286 */           ("02".equals(rtu.getCommType())) && 
/* 287 */           (!(serverAddr.equals(rtu.getCommAddress())))) {
/* 288 */           rtu.setMisGprsAddress(serverAddr);
/* 289 */           log.warn("终端实际上行地址与资产表不一致：rtua=" + HexDump.toHex(gwmsg.head.rtua) + ",serverAddress=" + serverAddr);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception err)
/*     */     {
/* 295 */       log.error("update activeGprs exp:" + err.getLocalizedMessage(), err);
/*     */     }
/*     */ 
/* 299 */     if (gwmsg.afn() == 2)
/*     */     {
/* 301 */       rtu.setLastHeartbeat(System.currentTimeMillis());
/* 302 */       rtu.incHeartbeat();
/* 303 */       HeartbeatPersist.getInstance().handleHeartbeat(rtu.getRtua());
/*     */     }
/*     */ 
/* 307 */     RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */ 
/* 310 */     if (this.asyncDbService != null) {
/* 311 */       this.asyncDbService.log2Db(gwmsg);
/*     */     }
/*     */ 
/* 314 */     if (gwmsg.afn() == 15)
/* 315 */       this.udefQueue.offer(gwmsg);
/*     */     else
/* 317 */       this.msgQueue.offer(gwmsg);
/*     */   }
/*     */ 
/*     */   private void onSendMessage(SendMessageEvent e) {
/* 321 */     IMessage message = e.getMessage();
/* 322 */     IMessage rtuMsg = null;
/* 323 */     if (message.getMessageType() == MessageType.MSG_GATE) {
/* 324 */       MessageGate gateMsg = (MessageGate)message;
/*     */ 
/* 326 */       if (gateMsg.getHead().getCommand() == 17)
/*     */       {
/* 328 */         return;
/*     */       }
/* 330 */       if (gateMsg.getHead().getCommand() == 33) {
/* 331 */         rtuMsg = gateMsg.getInnerMessage();
/* 332 */         rtuMsg.setTxfs(gateMsg.getTxfs());
/* 333 */         rtuMsg.setIoTime(gateMsg.getIoTime());
/* 334 */         rtuMsg.setSource(gateMsg.getSource()); break label109:
/*     */       }
/*     */ 
/* 337 */       return;
/*     */     }
/* 339 */     if (message.getMessageType() == MessageType.MSG_ZJ) {
/* 340 */       rtuMsg = message;
/*     */     }
/* 342 */     if (rtuMsg == null) {
/* 343 */       label109: return;
/*     */     }
/*     */ 
/* 346 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtuMsg.getRtua());
/* 347 */     if (rtu == null) {
/* 348 */       return;
/*     */     }
/*     */ 
/* 351 */     int flow = rtuMsg.length();
/* 352 */     rtu.incDownGprsCount(); rtu.addDownGprsFlowmeter(flow);
/*     */ 
/* 354 */     RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */ 
/* 357 */     if (this.asyncDbService != null)
/* 358 */       this.asyncDbService.log2Db(rtuMsg);
/*     */   }
/*     */ 
/*     */   public void setMsgQueue(FEMessageQueue msgQueue) {
/* 362 */     this.msgQueue = msgQueue;
/*     */   }
/*     */ 
/*     */   public void setUdefQueue(UserDefineMessageQueue udefQueue) {
/* 366 */     this.udefQueue = udefQueue;
/*     */   }
/*     */ 
/*     */   public void setHeartBeat(Object heartBeat) {
/*     */   }
/*     */ 
/*     */   public final void setAsyncDbService(AsyncService asyncDbService) {
/* 373 */     this.asyncDbService = asyncDbService;
/*     */   }
/*     */ }