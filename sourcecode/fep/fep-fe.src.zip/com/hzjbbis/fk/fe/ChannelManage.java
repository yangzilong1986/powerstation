/*     */ package com.hzjbbis.fk.fe;
/*     */ 
/*     */ import com.hzjbbis.fk.clientmod.ClientModule;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseClientChannel;
/*     */ import com.hzjbbis.fk.fe.ums.UmsModule;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.sockclient.JSocket;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ChannelManage
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(ChannelManage.class);
/*     */ 
/*  30 */   private int rtuHeartbeatInterval = 900;
/*  31 */   private int rtuTransferInterval = 60;
/*     */ 
/*  33 */   private long hbInterval = ???.rtuHeartbeatInterval * 1000;
/*  34 */   private long tfInterval = ???.rtuTransferInterval * 1000;
/*     */ 
/*  36 */   private static ChannelManage cm = new ChannelManage();
/*     */ 
/*  44 */   private final Map<String, BaseClientChannel> mapGates = new HashMap();
/*  45 */   private final Map<String, BaseClientChannel> mapUmsClients = new HashMap();
/*  46 */   private final Map<String, BaseClientChannel> mapGprsClients = new HashMap();
/*  47 */   public boolean testMode = false;
/*     */ 
/*     */   public static ChannelManage getInstance()
/*     */   {
/*  40 */     return cm;
/*     */   }
/*     */ 
/*     */   public void setRtuHeartbeatInterval(int interval)
/*     */   {
/*  51 */     this.rtuHeartbeatInterval = interval;
/*  52 */     this.hbInterval = (this.rtuHeartbeatInterval * 1000);
/*     */   }
/*     */ 
/*     */   public void setRtuTransferInterval(int rtuTransferInterval) {
/*  56 */     this.rtuTransferInterval = rtuTransferInterval;
/*  57 */     this.tfInterval = (rtuTransferInterval * 1000);
/*     */   }
/*     */ 
/*     */   public void addGprsClient(ClientModule gprsClient)
/*     */   {
/*  65 */     this.mapGates.put(gprsClient.getSocket().getPeerAddr(), gprsClient.getSocket());
/*  66 */     this.mapGprsClients.put(gprsClient.getSocket().getPeerAddr(), gprsClient.getSocket());
/*     */   }
/*     */ 
/*     */   public void addUmsClient(UmsModule umsClient)
/*     */   {
/*  71 */     this.mapGates.put(umsClient.getPeerAddr(), umsClient);
/*  72 */     this.mapUmsClients.put(umsClient.getPeerAddr(), umsClient);
/*     */   }
/*     */ 
/*     */   public BaseClientChannel getActiveUmsChannel()
/*     */   {
/*  80 */     for (BaseClientChannel channel : this.mapUmsClients.values())
/*  81 */       if (channel.isActive())
/*  82 */         return channel;
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public BaseClientChannel getActiveGprsChannel() {
/*  87 */     for (BaseClientChannel channel : this.mapGprsClients.values())
/*  88 */       if (channel.isActive())
/*  89 */         return channel;
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   public IChannel getChannel(String key)
/*     */   {
/*  99 */     return ((IChannel)this.mapGates.get(key));
/*     */   }
/*     */ 
/*     */   private static int communicationType(String commType)
/*     */   {
/* 110 */     if (commType == null)
/* 111 */       return -1;
/* 112 */     if ((commType.equals("02")) || (commType.equals("09")) || (commType.equals("04")))
/* 113 */       return 2;
/* 114 */     if (commType.equals("01")) {
/* 115 */       return 1;
/*     */     }
/* 117 */     return 0;
/*     */   }
/*     */ 
/*     */   public IChannel getChannel(int rtua)
/*     */   {
/* 127 */     IChannel channel = getGPRSChannel(rtua);
/* 128 */     if (channel != null)
/* 129 */       return channel;
/* 130 */     channel = getUmsChannel(null, rtua);
/* 131 */     if (channel != null) {
/* 132 */       return channel;
/*     */     }
/*     */ 
/* 135 */     return getActiveUmsChannel();
/*     */   }
/*     */ 
/*     */   public IChannel getGPRSChannel(int rtua)
/*     */   {
/* 145 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/* 146 */     if (rtu == null) {
/* 147 */       log.warn("终端资料没有加载。rtua=" + HexDump.toHex(rtua));
/* 148 */       return null;
/*     */     }
/*     */ 
/* 153 */     long timeSpan = System.currentTimeMillis() - rtu.getLastGprsTime();
/* 154 */     if ((timeSpan < this.hbInterval * 2L) && (rtu.getActiveGprs() != null)) {
/* 155 */       long lastReq = rtu.getLastReqTime();
/*     */ 
/* 157 */       long tspan = Math.abs(System.currentTimeMillis() - lastReq);
/* 158 */       if ((tspan > this.tfInterval) && (rtu.getLastGprsTime() < lastReq))
/* 159 */         return null;
/* 160 */       IChannel channel = getChannel(rtu.getActiveGprs());
/* 161 */       return channel;
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   public IChannel getUmsChannel(String appid, int rtua)
/*     */   {
/* 173 */     IChannel channel = null;
/* 174 */     if ((appid != null) && (appid.length() > 0)) {
/* 175 */       channel = getChannel(appid);
/* 176 */       if (channel != null)
/* 177 */         return channel;
/*     */     }
/* 179 */     if (rtua == 0) {
/* 180 */       return channel;
/*     */     }
/*     */ 
/* 183 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/*     */ 
/* 185 */     String activeUms = rtu.getActiveUms();
/* 186 */     if ((activeUms != null) && (activeUms.length() >= 4)) {
/* 187 */       return getChannel(activeUms);
/*     */     }
/*     */ 
/* 190 */     int cType = communicationType(rtu.getCommType());
/* 191 */     if (cType == 1) {
/* 192 */       activeUms = filterUmsAppId(rtu.getCommAddress());
/* 193 */       if (activeUms.length() >= 4)
/* 194 */         channel = getChannel(activeUms.substring(0, 4));
/* 195 */       if (channel != null)
/*     */       {
/* 197 */         if ((rtu.getActiveSubAppId() == null) && (activeUms.length() == 6))
/* 198 */           rtu.setActiveSubAppId(activeUms.substring(4, 6));
/* 199 */         return channel;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 204 */     cType = communicationType(rtu.getB1CommType());
/* 205 */     if (cType == 1) {
/* 206 */       activeUms = filterUmsAppId(rtu.getB1CommAddress());
/* 207 */       if (activeUms.length() >= 4)
/* 208 */         channel = getChannel(activeUms.substring(0, 4));
/* 209 */       if (channel != null)
/*     */       {
/* 211 */         if ((rtu.getActiveSubAppId() == null) && (activeUms.length() == 6))
/* 212 */           rtu.setActiveSubAppId(activeUms.substring(4, 6));
/* 213 */         return channel;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 218 */     cType = communicationType(rtu.getB2CommType());
/* 219 */     if (cType == 1) {
/* 220 */       activeUms = filterUmsAppId(rtu.getB2CommAddress());
/* 221 */       if (activeUms.length() >= 4)
/* 222 */         channel = getChannel(activeUms.substring(0, 4));
/* 223 */       if (channel != null)
/*     */       {
/* 225 */         if ((rtu.getActiveSubAppId() == null) && (activeUms.length() == 6))
/* 226 */           rtu.setActiveSubAppId(activeUms.substring(4, 6));
/* 227 */         return channel;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 232 */     log.warn("终端短信通道配置不正确。RTUA=" + rtu.getLogicAddress());
/*     */ 
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */   public static final String filterUmsAppId(String ums) {
/* 239 */     if (ums != null) {
/* 240 */       int index = ums.indexOf("95598");
/* 241 */       if (index >= 0)
/* 242 */         ums = ums.substring(index + 5);
/*     */     }
/* 244 */     return ums;
/*     */   }
/*     */ 
/*     */   public static final String getUmsAppId(int rtua) {
/* 248 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/*     */ 
/* 250 */     int cType = communicationType(rtu.getCommType());
/* 251 */     if (cType <= 0) {
/* 252 */       log.error("终端主通道不是GPRS/CDMA，或者短信。RTUA＝" + rtu.getLogicAddress());
/* 253 */       return null;
/*     */     }
/*     */ 
/* 257 */     String activeUms = rtu.getActiveUms();
/* 258 */     if ((activeUms != null) && (activeUms.length() > 2)) {
/* 259 */       return activeUms;
/*     */     }
/*     */ 
/* 262 */     if (cType == 1)
/*     */     {
/* 264 */       activeUms = rtu.getCommAddress();
/* 265 */       if ((activeUms != null) && (activeUms.length() > 2)) {
/* 266 */         return activeUms;
/*     */       }
/*     */     }
/*     */ 
/* 270 */     cType = communicationType(rtu.getB1CommType());
/* 271 */     if (cType == 1) {
/* 272 */       activeUms = rtu.getB1CommAddress();
/* 273 */       if ((activeUms != null) && (activeUms.length() > 2)) {
/* 274 */         return activeUms;
/*     */       }
/*     */     }
/* 277 */     cType = communicationType(rtu.getB2CommType());
/* 278 */     if (cType == 1) {
/* 279 */       activeUms = rtu.getB2CommAddress();
/* 280 */       if ((activeUms != null) && (activeUms.length() > 2)) {
/* 281 */         return activeUms;
/*     */       }
/*     */     }
/* 284 */     log.warn("终端短信通道配置不正确。RTUA=" + rtu.getLogicAddress());
/* 285 */     return null;
/*     */   }
/*     */ }