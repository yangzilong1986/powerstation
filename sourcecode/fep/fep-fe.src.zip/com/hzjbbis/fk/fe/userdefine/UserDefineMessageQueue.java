/*     */ package com.hzjbbis.fk.fe.userdefine;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.fe.ChannelManage;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UserDefineMessageQueue
/*     */ {
/*  26 */   private static final Logger log = Logger.getLogger(UserDefineMessageQueue.class);
/*  27 */   private static final UserDefineMessageQueue instance = new UserDefineMessageQueue();
/*  28 */   private Map<Integer, IChannel> userMap = new HashMap();
/*     */ 
/*     */   public static final UserDefineMessageQueue getInstance()
/*     */   {
/*  32 */     return instance;
/*     */   }
/*     */ 
/*     */   public void offer(IMessage msg) {
/*  36 */     if (msg.getMessageType() == MessageType.MSG_ZJ) {
/*  37 */       MessageZj zjmsg = (MessageZj)msg;
/*     */ 
/*  40 */       byte manuCode = zjmsg.head.msta;
/*  41 */       if (((manuCode & 0xFF) == 0) && 
/*  42 */         (zjmsg.head.c_func == 15)) {
/*  43 */         manuCode = (byte)BCDToDecimal(zjmsg.data.get(0));
/*     */       }
/*     */ 
/*  46 */       log.info("收到厂家编码为" + manuCode + "的自定义上行报文:" + msg);
/*  47 */       IChannel srcChannel = (IChannel)this.userMap.get(Byte.valueOf(manuCode));
/*  48 */       if (srcChannel == null) {
/*  49 */         log.error("收到厂家自定义报文，但厂家解析模块与通信前置机的连接找不到。msg=" + msg.getRawPacketString());
/*  50 */         return;
/*     */       }
/*  52 */       srcChannel.send(msg);
/*     */ 
/*  54 */       log.info("厂家自定义报文应答：" + msg.getRawPacketString());
/*     */     }
/*  56 */     else if (msg.getMessageType() == MessageType.MSG_GW_10) {
/*  57 */       MessageGw gwmsg = (MessageGw)msg;
/*  58 */       IChannel srcChannel = (IChannel)this.userMap.get(Integer.valueOf(gwmsg.getRtua()));
/*  59 */       if (srcChannel == null) {
/*  60 */         log.error("收到厂家升级报文，但厂家升级模块与通信前置机的连接找不到。msg=" + msg.getRawPacketString());
/*  61 */         return;
/*     */       }
/*  63 */       srcChannel.send(msg);
/*     */ 
/*  65 */       log.info("厂家自定义报文应答：" + msg.getRawPacketString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean sendMessageDown(IMessage msg)
/*     */   {
/*     */     IChannel srcChannel;
/*  76 */     if (msg.getMessageType() == MessageType.MSG_ZJ) {
/*  77 */       MessageZj zjmsg = (MessageZj)msg;
/*  78 */       log.info("收到厂家编码为" + zjmsg.head.msta + "的自定义下行报文:" + msg);
/*     */ 
/*  80 */       srcChannel = msg.getSource();
/*  81 */       int msta = 0xFF & zjmsg.head.msta;
/*  82 */       this.userMap.put(Integer.valueOf(msta), srcChannel);
/*     */ 
/*  84 */       if (RtuManage.getInstance().getRemoteUpateRtuaTag(zjmsg.head.rtua))
/*     */       {
/*  86 */         IChannel channel = ChannelManage.getInstance().getChannel(zjmsg.head.rtua);
/*  87 */         if (channel == null) {
/*  88 */           return false;
/*     */         }
/*  90 */         channel.send(msg);
/*  91 */         return true;
/*     */       }
/*  93 */       return false;
/*     */     }
/*  95 */     if (msg.getMessageType() == MessageType.MSG_GW_10) {
/*  96 */       MessageGw gwmsg = (MessageGw)msg;
/*     */ 
/*  98 */       srcChannel = msg.getSource();
/*  99 */       this.userMap.put(Integer.valueOf(gwmsg.getRtua()), srcChannel);
/*     */ 
/* 101 */       if (RtuManage.getInstance().getRemoteUpateRtuaTag(gwmsg.getRtua()))
/*     */       {
/* 103 */         IChannel channel = ChannelManage.getInstance().getGPRSChannel(gwmsg.getRtua());
/* 104 */         if (channel == null) {
/* 105 */           return false;
/*     */         }
/* 107 */         channel.send(msg);
/* 108 */         return true;
/*     */       }
/* 110 */       return false;
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   public static int BCDToDecimal(byte bcd)
/*     */   {
/* 122 */     int high = (bcd & 0xF0) >>> 4;
/* 123 */     int low = bcd & 0xF;
/* 124 */     if ((high > 9) || (low > 9)) {
/* 125 */       return -1;
/*     */     }
/* 127 */     return (high * 10 + low);
/*     */   }
/*     */ }