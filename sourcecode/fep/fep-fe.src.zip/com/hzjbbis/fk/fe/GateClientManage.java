/*    */ package com.hzjbbis.fk.fe;
/*    */ 
/*    */ import com.hzjbbis.fk.clientmod.ClientModule;
/*    */ import com.hzjbbis.fk.common.spi.abstra.BaseModule;
/*    */ import com.hzjbbis.fk.fe.ums.UmsModule;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class GateClientManage extends BaseModule
/*    */ {
/* 25 */   private List<ClientModule> gprsGateClients = new ArrayList();
/*    */ 
/* 27 */   private List<UmsModule> umsClients = new ArrayList();
/*    */ 
/* 29 */   private static final GateClientManage instance = new GateClientManage();
/*    */ 
/*    */   public static final GateClientManage getInstance() {
/* 32 */     return instance;
/*    */   }
/*    */ 
/*    */   public void setGprsGateClients(List<ClientModule> gprsGates)
/*    */   {
/* 38 */     this.gprsGateClients = gprsGates;
/* 39 */     for (ClientModule gate : this.gprsGateClients) {
/* 40 */       gate.init();
/* 41 */       ChannelManage.getInstance().addGprsClient(gate);
/*    */     }
/*    */   }
/*    */ 
/*    */   public final void setUmsClients(List<UmsModule> clients) {
/* 46 */     this.umsClients = clients;
/* 47 */     for (UmsModule ums : this.umsClients)
/* 48 */       ChannelManage.getInstance().addUmsClient(ums);
/*    */   }
/*    */ 
/*    */   public boolean start()
/*    */   {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   public void stop()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getModuleType() {
/* 62 */     return "moduleContainer";
/*    */   }
/*    */ 
/*    */   public final List<ClientModule> getGprsGateClients() {
/* 66 */     return this.gprsGateClients;
/*    */   }
/*    */ 
/*    */   public final List<UmsModule> getUmsClients() {
/* 70 */     return this.umsClients;
/*    */   }
/*    */ }