/*     */ package com.hzjbbis.fk.fe.bpserver;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.events.BasicEventHook;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.fe.msgqueue.FEMessageQueue;
/*     */ import com.hzjbbis.fk.fe.msgqueue.MessageDispatch2Bp;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gate.GateHead;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.sockserver.event.AcceptEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ClientCloseEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class BPServerEventHandler extends BasicEventHook
/*     */ {
/*  43 */   private static final Logger log = Logger.getLogger(BPServerEventHandler.class);
/*  44 */   private static final TraceLog trace = TraceLog.getTracer(BPServerEventHandler.class);
/*     */   private FEMessageQueue msgQueue;
/*  46 */   private boolean noConvert = false;
/*  47 */   private boolean dispatchRandom = true;
/*     */ 
/*  50 */   private List<IServerSideChannel> bpClients = Collections.synchronizedList(new ArrayList());
/*     */ 
/*     */   public boolean start()
/*     */   {
/*  57 */     return super.start();
/*     */   }
/*     */ 
/*     */   public void setMsgQueue(FEMessageQueue queue) {
/*  61 */     this.msgQueue = queue;
/*  62 */     this.msgQueue.setDispatchRandom(this.dispatchRandom);
/*  63 */     this.msgQueue.setNoConvert(this.noConvert);
/*     */   }
/*     */ 
/*     */   public FEMessageQueue getMsgQueue() {
/*  67 */     return this.msgQueue;
/*     */   }
/*     */ 
/*     */   public void handleEvent(IEvent e)
/*     */   {
/*  74 */     if (e.getType() == EventType.MSG_RECV)
/*     */     {
/*  76 */       onRecvMessage((ReceiveMessageEvent)e);
/*     */     }
/*  78 */     else if (e.getType() == EventType.MSG_SENT)
/*     */     {
/*  80 */       onSendMessage((SendMessageEvent)e);
/*     */     }
/*  82 */     else if (e.getType() == EventType.ACCEPTCLIENT)
/*     */     {
/*  85 */       for (int i = 0; i < this.bpClients.size(); ++i) {
/*     */         try {
/*  87 */           IServerSideChannel client = (IServerSideChannel)this.bpClients.get(i);
/*  88 */           if (System.currentTimeMillis() - client.getLastIoTime() <= 1800000L) break label143;
/*  89 */           this.bpClients.remove(i);
/*  90 */           if (trace.isEnabled())
/*  91 */             trace.trace("garbage client removed:" + client);
/*     */         }
/*     */         catch (Exception exp) {
/*     */         }
/*  95 */         label143: break;
/*     */       }
/*     */ 
/*  98 */       AcceptEvent ae = (AcceptEvent)e;
/*     */ 
/* 100 */       if (ae.getClient().getChannel().isConnected()) {
/* 101 */         this.bpClients.add(ae.getClient());
/*     */       }
/* 103 */       MessageDispatch2Bp.getInstance().clearTimeoutChannel();
/* 104 */       if (trace.isEnabled()) {
/* 105 */         trace.trace("MessageDispatch2Bp.getInstance().clearTimeoutChannel()");
/*     */       }
/*     */     }
/* 108 */     else if (e.getType() == EventType.CLIENTCLOSE) {
/* 109 */       ClientCloseEvent ce = (ClientCloseEvent)e;
/* 110 */       this.bpClients.remove(ce.getClient());
/* 111 */       this.msgQueue.onBpClientClosed(ce.getClient());
/*     */     }
/* 113 */     else if (e.getType() == EventType.MSG_SEND_FAIL)
/*     */     {
/* 115 */       this.msgQueue.pushBack(e.getMessage());
/*     */     }
/*     */     else {
/* 118 */       super.handleEvent(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void onRecvMessage(ReceiveMessageEvent e)
/*     */   {
/* 127 */     IMessage msg = e.getMessage();
/* 128 */     if (msg.getMessageType() == MessageType.MSG_GATE)
/*     */     {
/*     */       IMessage rtuMsg;
/*     */       boolean success;
/* 129 */       MessageGate mgate = (MessageGate)msg;
/*     */ 
/* 131 */       if (mgate.getHead().getCommand() == 17) {
/* 132 */         IServerSideChannel client = (IServerSideChannel)msg.getSource();
/*     */ 
/* 135 */         if (this.bpClients.remove(client)) {
/* 136 */           this.msgQueue.onBpClientConnected(client);
/*     */         }
/*     */ 
/* 139 */         ByteBuffer data = mgate.getData();
/* 140 */         int numPackets = (data.remaining() < 4) ? -1 : data.getInt();
/* 141 */         synchronized (client) {
/* 142 */           client.setRequestNum(numPackets);
/*     */         }
/*     */ 
/* 145 */         MessageGate hreply = MessageGate.createHReply();
/* 146 */         client.send(hreply);
/* 147 */         return;
/*     */       }
/* 149 */       if (mgate.getHead().getCommand() == 33) {
/* 150 */         rtuMsg = mgate.getInnerMessage();
/*     */ 
/* 152 */         rtuMsg.setPeerAddr(mgate.getSource().getPeerAddr());
/* 153 */         success = this.msgQueue.sendMessage(mgate);
/* 154 */         if ((success) && (log.isDebugEnabled()))
/* 155 */           log.debug("业务处理器下行命令:" + rtuMsg);
/*     */       } else {
/* 157 */         if (mgate.getHead().getCommand() == 50) {
/* 158 */           String bpProfile = new String(mgate.getData().array());
/* 159 */           FasSystem.getFasSystem().addBizProcessorProfile(e.getClient().getPeerAddr(), bpProfile);
/* 160 */           return;
/*     */         }
/* 162 */         if (mgate.getHead().getCommand() != 0)
/*     */           return;
/* 164 */         rtuMsg = mgate.getInnerMessage();
/* 165 */         if (rtuMsg == null) {
/* 166 */           return;
/*     */         }
/* 168 */         rtuMsg.setPeerAddr(mgate.getSource().getPeerAddr());
/* 169 */         success = this.msgQueue.sendMessage(rtuMsg);
/* 170 */         if ((success) && (log.isDebugEnabled()))
/* 171 */           log.info("终端下行命令:" + rtuMsg);
/*     */       }
/*     */     }
/* 174 */     else if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 175 */       MessageZj zjmsg = (MessageZj)msg;
/* 176 */       boolean success = this.msgQueue.sendMessage(zjmsg);
/* 177 */       if ((success) && (log.isDebugEnabled()))
/* 178 */         log.debug("业务处理器下行命令:" + zjmsg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void onSendMessage(SendMessageEvent e)
/*     */   {
/* 187 */     IMessage msg = e.getMessage();
/*     */ 
/* 190 */     if (msg instanceof MessageZj) {
/* 191 */       MessageZj zjmsg = (MessageZj)msg;
/* 192 */       if (zjmsg.head.c_func == 15) {
/* 193 */         if (log.isDebugEnabled())
/* 194 */           log.debug("往厂家解析模块发送报文成功:" + zjmsg.getRawPacketString());
/* 195 */         return;
/*     */       }
/*     */     }
/* 198 */     if (log.isDebugEnabled()) {
/* 199 */       log.debug("往业务处理器发送报文成功:" + msg);
/*     */     }
/*     */ 
/* 202 */     if (this.dispatchRandom) {
/* 203 */       IServerSideChannel client = (IServerSideChannel)e.getClient();
/* 204 */       trySendNextPacket(client);
/*     */     }
/*     */     else
/*     */     {
/* 208 */       trySendNextPacketByA1();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void trySendNextPacketByA1()
/*     */   {
/* 216 */     MessageZj msg = (MessageZj)this.msgQueue.poll();
/* 217 */     if (msg == null)
/* 218 */       return;
/* 219 */     IServerSideChannel client = MessageDispatch2Bp.getInstance().getBpChannel(msg.head.rtua_a1);
/* 220 */     if (client == null) {
/* 221 */       this.msgQueue.pushBack(msg);
/* 222 */       return;
/*     */     }
/*     */ 
/* 225 */     boolean success = false;
/* 226 */     if (this.noConvert) {
/* 227 */       success = client.send(msg);
/*     */     }
/*     */     else
/*     */     {
/* 231 */       MessageGate gateMsg = new MessageGate();
/* 232 */       gateMsg.setUpInnerMessage(msg);
/* 233 */       success = client.send(gateMsg);
/*     */     }
/* 235 */     if (!(success))
/* 236 */       this.msgQueue.pushBack(msg);
/*     */   }
/*     */ 
/*     */   private void trySendNextPacket(IServerSideChannel client)
/*     */   {
/* 242 */     if (client.getRequestNum() <= 0)
/*     */     {
/* 244 */       return;
/*     */     }
/* 246 */     IMessage msg = this.msgQueue.poll();
/* 247 */     if (msg != null) {
/* 248 */       boolean success = false;
/* 249 */       if (this.noConvert) {
/* 250 */         success = client.send(msg);
/*     */       }
/*     */       else {
/* 253 */         MessageGate gateMsg = new MessageGate();
/* 254 */         gateMsg.setUpInnerMessage(msg);
/* 255 */         success = client.send(gateMsg);
/*     */       }
/* 257 */       if (!(success))
/* 258 */         this.msgQueue.pushBack(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isNoConvert()
/*     */   {
/* 264 */     return this.noConvert;
/*     */   }
/*     */ 
/*     */   public void setNoConvert(boolean noConvert) {
/* 268 */     this.noConvert = noConvert;
/* 269 */     if (this.msgQueue != null)
/* 270 */       this.msgQueue.setNoConvert(noConvert);
/*     */   }
/*     */ 
/*     */   public void setDispatchRandom(boolean dispRandom) {
/* 274 */     this.dispatchRandom = dispRandom;
/* 275 */     if (this.msgQueue != null)
/* 276 */       this.msgQueue.setDispatchRandom(this.dispatchRandom);
/*     */   }
/*     */ }