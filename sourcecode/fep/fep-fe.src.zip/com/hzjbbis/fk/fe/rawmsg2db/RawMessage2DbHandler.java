/*    */ package com.hzjbbis.fk.fe.rawmsg2db;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.db.batch.event.adapt.BaseLog2DbHandler;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.MessageType;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ import com.hzjbbis.fk.message.zj.MessageZj;
/*    */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.util.Date;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class RawMessage2DbHandler extends BaseLog2DbHandler
/*    */ {
/* 17 */   private static final Logger log = Logger.getLogger(RawMessage2DbHandler.class);
/*    */ 
/*    */   public void handleLog2Db(AsyncService service, IMessage msg)
/*    */   {
/*    */     try {
/* 22 */       MessageLog msgLog = new MessageLog();
/* 23 */       msgLog.setLogicAddress(HexDump.toHex(msg.getRtua()));
/* 24 */       msgLog.setQym(msgLog.getLogicAddress().substring(0, 2));
/* 25 */       boolean dirUp = false;
/* 26 */       byte appFunctionCode = 0;
/* 27 */       if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 28 */         MessageZj zjmsg = (MessageZj)msg;
/* 29 */         if (33 == zjmsg.head.c_func)
/* 30 */           zjmsg.head.c_dir = 1;
/* 31 */         dirUp = zjmsg.head.c_dir == 1;
/* 32 */         appFunctionCode = zjmsg.head.c_func;
/*    */       }
/* 34 */       else if (msg.getMessageType() == MessageType.MSG_GW_10) {
/* 35 */         MessageGw gwmsg = (MessageGw)msg;
/* 36 */         dirUp = gwmsg.head.c_dir == 1;
/* 37 */         appFunctionCode = gwmsg.afn();
/*    */       }
/* 39 */       msgLog.setKzm(HexDump.toHex(appFunctionCode));
/*    */ 
/* 41 */       msgLog.setTxfs(msg.getTxfs());
/* 42 */       if ("01".equals(msg.getTxfs()))
/*    */       {
/* 44 */         boolean hasServerAddr = false;
/* 45 */         if (msg.getServerAddress() != null) {
/* 46 */           int index = msg.getServerAddress().indexOf(44);
/* 47 */           if (index > 0) {
/* 48 */             msgLog.setSrcAddr(msg.getServerAddress().substring(0, index));
/* 49 */             msgLog.setDestAddr(msg.getServerAddress().substring(index + 1));
/* 50 */             hasServerAddr = true;
/*    */           }
/*    */         }
/* 53 */         if (!(hasServerAddr))
/* 54 */           msgLog.setSrcAddr(msg.getPeerAddr());
/*    */       }
/* 56 */       else if ("02".equals(msg.getTxfs()))
/*    */       {
/* 58 */         msgLog.setSrcAddr(msg.getPeerAddr());
/*    */ 
/* 61 */         if (msg.getSource() != null)
/* 62 */           msgLog.setDestAddr(msg.getSource().getPeerAddr());
/*    */       }
/*    */       else
/*    */       {
/* 66 */         log.warn("msg txfs is error:" + msg.getTxfs() + "msg=" + msg);
/* 67 */         msgLog.setSrcAddr(msg.getPeerAddr());
/*    */       }
/*    */ 
/* 71 */       msgLog.setTime(new Date(System.currentTimeMillis()));
/* 72 */       msgLog.setBody(msg.getRawPacketString());
/* 73 */       msgLog.setSize(msgLog.getBody().length());
/* 74 */       if (dirUp) {
/* 75 */         service.addToDao(msgLog, Integer.parseInt("5000")); return;
/*    */       }
/* 77 */       if ((msg.getStatus() != null) && (msg.getStatus().equals("1")))
/* 78 */         msgLog.setResult("1");
/*    */       else
/* 80 */         msgLog.setResult("0");
/* 81 */       service.addToDao(msgLog, Integer.parseInt("5001"));
/*    */     }
/*    */     catch (Exception ex) {
/* 84 */       log.error("Error to processing message log:" + msg, ex);
/*    */     }
/*    */   }
/*    */ }