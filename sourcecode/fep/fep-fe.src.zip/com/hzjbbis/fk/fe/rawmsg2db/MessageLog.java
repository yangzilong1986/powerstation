/*     */ package com.hzjbbis.fk.fe.rawmsg2db;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MessageLog
/*     */ {
/*     */   private String logicAddress;
/*     */   private String qym;
/*     */   private String kzm;
/*     */   private String srcAddr;
/*     */   private String destAddr;
/*     */   private String txfs;
/*     */   private Date time;
/*     */   private int size;
/*     */   private String body;
/*     */   private String result;
/*     */ 
/*     */   public String getBody()
/*     */   {
/*  32 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body)
/*     */   {
/*  37 */     if (body.length() >= 4000)
/*  38 */       body = body.substring(0, 3999);
/*  39 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public String getDestAddr()
/*     */   {
/*  44 */     return this.destAddr;
/*     */   }
/*     */ 
/*     */   public void setDestAddr(String destAddr)
/*     */   {
/*  49 */     this.destAddr = destAddr;
/*     */   }
/*     */ 
/*     */   public String getKzm()
/*     */   {
/*  54 */     return this.kzm;
/*     */   }
/*     */ 
/*     */   public void setKzm(String kzm)
/*     */   {
/*  59 */     this.kzm = kzm;
/*     */   }
/*     */ 
/*     */   public String getLogicAddress()
/*     */   {
/*  64 */     return this.logicAddress;
/*     */   }
/*     */ 
/*     */   public void setLogicAddress(String logicAddress)
/*     */   {
/*  69 */     this.logicAddress = logicAddress;
/*     */   }
/*     */ 
/*     */   public String getQym()
/*     */   {
/*  74 */     return this.qym;
/*     */   }
/*     */ 
/*     */   public void setQym(String qym)
/*     */   {
/*  79 */     this.qym = qym;
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */   {
/*  84 */     return this.size;
/*     */   }
/*     */ 
/*     */   public void setSize(int size)
/*     */   {
/*  89 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public String getSrcAddr()
/*     */   {
/*  94 */     return this.srcAddr;
/*     */   }
/*     */ 
/*     */   public void setSrcAddr(String srcAddr)
/*     */   {
/*  99 */     this.srcAddr = srcAddr;
/*     */   }
/*     */ 
/*     */   public Date getTime()
/*     */   {
/* 104 */     return this.time;
/*     */   }
/*     */ 
/*     */   public void setTime(Date time)
/*     */   {
/* 109 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public String getTxfs()
/*     */   {
/* 114 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs)
/*     */   {
/* 119 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     return "rtua=" + this.logicAddress + ",message=" + this.body;
/*     */   }
/*     */ 
/*     */   public String getResult()
/*     */   {
/* 129 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setResult(String result)
/*     */   {
/* 134 */     this.result = result;
/*     */   }
/*     */ }