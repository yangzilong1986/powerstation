/*     */ package com.hzjbbis.fk.fe.init;
/*     */ 
/*     */ import com.hzjbbis.db.DbMonitor;
/*     */ import com.hzjbbis.db.initrtu.dao.ComRtuDao;
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.fe.filecache.HeartbeatPersist;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuCommFlowCache;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuParamsCache;
/*     */ import com.hzjbbis.fk.fe.msgqueue.BpBalanceFactor;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Initialize
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger(Initialize.class);
/*     */   private ComRtuDao rtuDao;
/*  34 */   private boolean bpClusterTest = false;
/*     */ 
/*     */   public void setRtuDao(ComRtuDao rtuDao) {
/*  37 */     this.rtuDao = rtuDao;
/*     */   }
/*     */ 
/*     */   public void initRtus()
/*     */   {
/*     */     ComRtu rtu;
/*     */     Iterator localIterator;
/*  41 */     TraceLog.getTracer().trace("initRtus called");
/*  42 */     List rtus = null;
/*  43 */     boolean loadDbSuccess = false;
/*  44 */     if (!(this.bpClusterTest)) {
/*     */       try {
/*  46 */         if (DbMonitor.getMasterMonitor().isAvailable()) {
/*  47 */           rtus = this.rtuDao.loadComRtu();
/*  48 */           loadDbSuccess = true;
/*  49 */           if (rtus != null)
/*  50 */             for (localIterator = rtus.iterator(); localIterator.hasNext(); ) { rtu = (ComRtu)localIterator.next();
/*  51 */               RtuManage.getInstance().putComRtuToCache(rtu);
/*     */             }
/*  53 */           rtus = this.rtuDao.loadComGwRtu();
/*  54 */           if (rtus != null)
/*  55 */             for (localIterator = rtus.iterator(); localIterator.hasNext(); ) { rtu = (ComRtu)localIterator.next();
/*  56 */               RtuManage.getInstance().putComRtuToCache(rtu);
/*     */             }
/*     */         }
/*     */       } catch (Exception e) {
/*  60 */         log.warn("通信前置机RTU数据库初始化失败：" + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  65 */       loadDbSuccess = true;
/*  66 */       rtus = testCase4BpCluster();
/*  67 */       for (localIterator = rtus.iterator(); localIterator.hasNext(); ) { rtu = (ComRtu)localIterator.next();
/*  68 */         RtuManage.getInstance().putComRtuToCache(rtu);
/*     */       }
/*     */     }
/*     */ 
/*  72 */     RtuParamsCache.getInstance().initOnStartup(!(loadDbSuccess));
/*     */ 
/*  74 */     BpBalanceFactor.getInstance().travelRtus(RtuManage.getInstance().getAllComRtu());
/*     */ 
/*  77 */     HeartbeatPersist.getInstance().initOnStartup();
/*     */ 
/*  80 */     RtuCommFlowCache.getInstance().initOnStartup();
/*     */ 
/*  83 */     FasSystem.getFasSystem().addShutdownHook(new Runnable()
/*     */     {
/*     */       public void run() {
/*  86 */         Initialize.this.shutdownWork();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void shutdownWork()
/*     */   {
/*  93 */     RtuParamsCache.getInstance().dispose();
/*  94 */     RtuCommFlowCache.getInstance().dispose();
/*  95 */     HeartbeatPersist.getInstance().dispose();
/*     */   }
/*     */ 
/*     */   private List<ComRtu> testCase4BpCluster()
/*     */   {
/* 102 */     List list = new LinkedList();
/* 103 */     Map rtuMap = new HashMap();
/* 104 */     rtuMap.put(Integer.valueOf(-1862205439), Integer.valueOf(2));
/* 105 */     rtuMap.put(Integer.valueOf(-1845428223), Integer.valueOf(3));
/* 106 */     rtuMap.put(Integer.valueOf(-1828651007), Integer.valueOf(5));
/* 107 */     rtuMap.put(Integer.valueOf(-1811873791), Integer.valueOf(6));
/* 108 */     rtuMap.put(Integer.valueOf(-1795096575), Integer.valueOf(7));
/* 109 */     rtuMap.put(Integer.valueOf(-1778319359), Integer.valueOf(8));
/* 110 */     rtuMap.put(Integer.valueOf(-1761542143), Integer.valueOf(11));
/* 111 */     rtuMap.put(Integer.valueOf(-1744764927), Integer.valueOf(12));
/* 112 */     rtuMap.put(Integer.valueOf(-1727987711), Integer.valueOf(13));
/* 113 */     Iterator iter = rtuMap.entrySet().iterator();
/* 114 */     while (iter.hasNext()) {
/* 115 */       Map.Entry entry = (Map.Entry)iter.next();
/* 116 */       for (int i = 0; i < ((Integer)entry.getValue()).intValue(); ++i) {
/* 117 */         ComRtu rtu = new ComRtu();
/* 118 */         int rtua = ((Integer)entry.getKey()).intValue() + i;
/* 119 */         rtu.setRtua(rtua);
/* 120 */         rtu.setLogicAddress(HexDump.toHex(rtua));
/* 121 */         list.add(rtu);
/*     */       }
/*     */     }
/* 124 */     return list;
/*     */   }
/*     */ 
/*     */   public final void setBpClusterTest(boolean bpClusterTest) {
/* 128 */     this.bpClusterTest = bpClusterTest;
/*     */   }
/*     */ }