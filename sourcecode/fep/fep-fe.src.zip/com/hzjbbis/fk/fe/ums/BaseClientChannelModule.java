/*     */ package com.hzjbbis.fk.fe.ums;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.IModule;
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseClientChannel;
/*     */ import java.net.SocketAddress;
/*     */ 
/*     */ public abstract class BaseClientChannelModule extends BaseClientChannel
/*     */   implements IModule
/*     */ {
/*     */   protected String peerIp;
/*  16 */   protected int peerPort = 0;
/*  17 */   protected String txfs = "01";
/*  18 */   protected String name = "UMS通道";
/*     */ 
/*  21 */   protected long lastReceiveTime = 0L;
/*  22 */   protected long lastSendTime = 0L;
/*  23 */   protected long totalRecvMessages = 0L; protected long totalSendMessages = 0L;
/*  24 */   protected int msgRecvPerMinute = 0; protected int msgSendPerMinute = 0;
/*  25 */   protected String moduleType = "umsClient";
/*     */ 
/*     */   public String getPeerAddr() {
/*  28 */     return this.peerIp + ":" + this.peerPort;
/*     */   }
/*     */ 
/*     */   public String getPeerIp() {
/*  32 */     return this.peerIp;
/*     */   }
/*     */ 
/*     */   public void setPeerIp(String peerIp) {
/*  36 */     this.peerIp = peerIp;
/*     */   }
/*     */ 
/*     */   public void setHostIp(String hostIp)
/*     */   {
/*  44 */     this.peerIp = hostIp;
/*     */   }
/*     */ 
/*     */   public int getPeerPort() {
/*  48 */     return this.peerPort;
/*     */   }
/*     */ 
/*     */   public void setPeerPort(int peerPort) {
/*  52 */     this.peerPort = peerPort;
/*     */   }
/*     */ 
/*     */   public void setHostPort(int hostPort) {
/*  56 */     this.peerPort = hostPort;
/*     */   }
/*     */ 
/*     */   public SocketAddress getSocketAddress() {
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   public String getModuleType() {
/*  64 */     return this.moduleType;
/*     */   }
/*     */ 
/*     */   public void setModuleType(String type) {
/*  68 */     this.moduleType = type;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  72 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  76 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/*  80 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/*  84 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public long getLastReceiveTime() {
/*  88 */     return this.lastReceiveTime;
/*     */   }
/*     */ 
/*     */   public long getLastSendTime() {
/*  92 */     return this.lastSendTime;
/*     */   }
/*     */ 
/*     */   public int getMsgRecvPerMinute() {
/*  96 */     return this.msgRecvPerMinute;
/*     */   }
/*     */ 
/*     */   public int getMsgSendPerMinute() {
/* 100 */     return this.msgSendPerMinute;
/*     */   }
/*     */ 
/*     */   public long getTotalRecvMessages() {
/* 104 */     return this.totalRecvMessages;
/*     */   }
/*     */ 
/*     */   public long getTotalSendMessages() {
/* 108 */     return this.totalSendMessages;
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 112 */     return "";
/*     */   }
/*     */ }