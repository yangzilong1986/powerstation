/*     */ package com.hzjbbis.fk.fe.ums;
/*     */ 
/*     */ import com.hzjbbis.db.batch.AsyncService;
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.IMessageQueue;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuCommFlowCache;
/*     */ import com.hzjbbis.fk.fe.filecache.RtuParamsCache;
/*     */ import com.hzjbbis.fk.fe.userdefine.UserDefineMessageQueue;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.sockserver.event.MessageSendFailEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SmsMessageEventHandler
/*     */   implements IEventHandler
/*     */ {
/*  33 */   private static final Logger log = Logger.getLogger(SmsMessageEventHandler.class);
/*     */   private IMessageQueue msgQueue;
/*     */   private AsyncService asyncDbService;
/*     */ 
/*     */   public void handleEvent(IEvent event)
/*     */   {
/*  39 */     if (event.getType().equals(EventType.MSG_RECV))
/*  40 */       onRecvMessage((ReceiveMessageEvent)event);
/*  41 */     else if (event.getType().equals(EventType.MSG_SENT))
/*  42 */       onSendMessage((SendMessageEvent)event);
/*  43 */     else if (event.getType().equals(EventType.MSG_SEND_FAIL))
/*  44 */       onSendFailMessage((MessageSendFailEvent)event);
/*     */   }
/*     */ 
/*     */   private void onRecvMessage(ReceiveMessageEvent event)
/*     */   {
/*  52 */     IMessage msg = event.getMessage();
/*  53 */     if (log.isDebugEnabled()) {
/*  54 */       log.debug("UMS短信网关上行报文:" + msg);
/*     */     }
/*     */ 
/*  61 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(msg.getRtua());
/*  62 */     if (rtu == null) {
/*  63 */       String strRtua = HexDump.toHex(msg.getRtua());
/*  64 */       log.warn("短信通道上行，找不到对应终端。appid=" + msg.getPeerAddr() + ",msg=" + msg.getRawPacketString());
/*  65 */       rtu = new ComRtu();
/*  66 */       rtu.setLogicAddress(strRtua);
/*  67 */       rtu.setRtua(msg.getRtua());
/*  68 */       RtuManage.getInstance().putComRtuToCache(rtu);
/*     */     }
/*     */ 
/*  72 */     rtu.setLastSmsTime(System.currentTimeMillis());
/*  73 */     rtu.setLastIoTime(rtu.getLastSmsTime());
/*     */ 
/*  76 */     rtu.incUpSmsCount();
/*     */ 
/*  80 */     boolean channelChanged = false;
/*  81 */     String serverAddr = msg.getServerAddress();
/*  82 */     String appid = event.getClient().getPeerAddr();
/*  83 */     int index = serverAddr.indexOf(44);
/*     */     try {
/*  85 */       String upMobile = serverAddr.substring(0, index);
/*  86 */       String receiver = serverAddr.substring(index + 1);
/*     */ 
/*  88 */       boolean updateRtuCache = false;
/*  89 */       if (!(upMobile.equals(rtu.getSimNum()))) {
/*  90 */         rtu.setUpMobile(upMobile); rtu.setSimNum(upMobile);
/*  91 */         updateRtuCache = true;
/*     */       }
/*     */ 
/*  95 */       index = receiver.indexOf("95598");
/*  96 */       if (index >= 0)
/*  97 */         receiver = receiver.substring(index + 5);
/*  98 */       if (!(appid.equals(rtu.getActiveUms()))) {
/*  99 */         rtu.setActiveUms(appid);
/* 100 */         channelChanged = true;
/* 101 */         updateRtuCache = true;
/*     */       }
/*     */ 
/* 104 */       if (appid.startsWith("95598"))
/* 105 */         appid = appid.substring(5);
/* 106 */       String subAppId = null;
/* 107 */       if (receiver.length() > appid.length()) {
/* 108 */         subAppId = receiver.substring(appid.length());
/* 109 */         if (!(subAppId.equals(rtu.getActiveSubAppId()))) {
/* 110 */           rtu.setActiveSubAppId(subAppId);
/* 111 */           updateRtuCache = true;
/*     */         }
/*     */ 
/*     */       }
/* 115 */       else if ((rtu.getActiveSubAppId() != null) && (rtu.getActiveSubAppId().length() > 0)) {
/* 116 */         rtu.setActiveSubAppId(null);
/* 117 */         updateRtuCache = true;
/*     */       }
/*     */ 
/* 121 */       if (updateRtuCache)
/* 122 */         RtuParamsCache.getInstance().addRtu(rtu);
/*     */     } catch (Exception e) {
/* 124 */       log.error("update RTU:(simNum activeUms activeSubAppId) exception:" + e.getLocalizedMessage(), e);
/*     */     }
/*     */ 
/* 128 */     if (channelChanged) {
/*     */       try
/*     */       {
/* 131 */         ArrayList smsAddrs = new ArrayList();
/* 132 */         String addr = null;
/* 133 */         if (appid.startsWith("95598"))
/* 134 */           appid = appid.substring(5);
/* 135 */         if ("01".equals(rtu.getCommType())) {
/* 136 */           addr = rtu.getCommAddress();
/* 137 */           if (addr != null) {
/* 138 */             addr = filterUmsAppId(addr);
/* 139 */             if (addr.length() >= appid.length())
/* 140 */               addr = addr.substring(0, appid.length());
/* 141 */             smsAddrs.add(addr);
/*     */           }
/*     */         }
/* 144 */         if ("01".equals(rtu.getB1CommType())) {
/* 145 */           addr = rtu.getB1CommAddress();
/* 146 */           if (addr != null) {
/* 147 */             addr = filterUmsAppId(addr);
/* 148 */             if (addr.length() >= appid.length())
/* 149 */               addr = addr.substring(0, appid.length());
/* 150 */             smsAddrs.add(addr);
/*     */           }
/*     */         }
/* 153 */         if ("01".equals(rtu.getB2CommType())) {
/* 154 */           addr = rtu.getB2CommAddress();
/* 155 */           if (addr != null) {
/* 156 */             addr = filterUmsAppId(addr);
/* 157 */             if (addr.length() >= appid.length())
/* 158 */               addr = addr.substring(0, appid.length());
/* 159 */             smsAddrs.add(addr);
/*     */           }
/*     */         }
/* 162 */         boolean same = smsAddrs.size() == 0;
/* 163 */         for (String smsAddr : smsAddrs) {
/* 164 */           if (smsAddr.startsWith(appid)) {
/* 165 */             same = true;
/* 166 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 170 */         if (!(same))
/* 171 */           rtu.setMisSmsAddress(appid);
/*     */       } catch (Exception smsAddrs) {
/* 173 */         log.error("search discord SMS params exp:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 179 */     if (msg.isTask())
/* 180 */       rtu.incTaskCount();
/*     */     else {
/* 182 */       msg.isHeartbeat();
/*     */     }
/*     */ 
/* 187 */     RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */ 
/* 190 */     if (this.asyncDbService != null) {
/* 191 */       this.asyncDbService.log2Db(msg);
/*     */     }
/*     */ 
/* 199 */     this.msgQueue.offer(msg);
/*     */   }
/*     */ 
/*     */   public String filterUmsAppId(String ums) {
/* 203 */     if (ums != null) {
/* 204 */       int index = ums.indexOf("95598");
/* 205 */       if (index >= 0)
/* 206 */         ums = ums.substring(index + 5);
/*     */     }
/* 208 */     return ums; }
/*     */ 
/*     */   private void onSendMessage(SendMessageEvent event) {
/* 211 */     IMessage msg = event.getMessage();
/* 212 */     if (log.isDebugEnabled()) {
/* 213 */       log.debug("UMS短信网关下行报文:" + msg);
/*     */     }
/*     */ 
/* 220 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(msg.getRtua());
/*     */ 
/* 222 */     if (rtu == null) {
/* 223 */       return;
/*     */     }
/*     */ 
/* 226 */     rtu.setLastIoTime(System.currentTimeMillis());
/*     */ 
/* 229 */     rtu.incDownSmsCount();
/*     */     try
/*     */     {
/* 233 */       String appid = event.getClient().getPeerAddr();
/*     */ 
/* 235 */       if (!(appid.equals(rtu.getActiveUms())))
/* 236 */         rtu.setActiveUms(appid);
/*     */     }
/*     */     catch (Exception err) {
/* 239 */       log.error(err.getLocalizedMessage(), err);
/*     */     }
/*     */ 
/* 242 */     RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */ 
/* 245 */     if (this.asyncDbService != null)
/* 246 */       this.asyncDbService.log2Db(msg);
/*     */   }
/*     */ 
/*     */   private void onSendFailMessage(MessageSendFailEvent event)
/*     */   {
/* 256 */     IMessage msg = event.getMessage();
/* 257 */     msg.setStatus("1");
/* 258 */     if (log.isDebugEnabled()) {
/* 259 */       log.debug("UMS短信网关下行报文:" + msg);
/*     */     }
/*     */ 
/* 262 */     if (this.asyncDbService != null)
/* 263 */       this.asyncDbService.log2Db(msg);
/*     */   }
/*     */ 
/*     */   public void setMsgQueue(IMessageQueue msgQueue) {
/* 267 */     this.msgQueue = msgQueue;
/*     */   }
/*     */ 
/*     */   public void setUdefQueue(UserDefineMessageQueue udefQueue)
/*     */   {
/*     */   }
/*     */ 
/*     */   public final void setAsyncDbService(AsyncService asyncDbService) {
/* 275 */     this.asyncDbService = asyncDbService;
/*     */   }
/*     */ }