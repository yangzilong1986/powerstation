/*     */ package com.hzjbbis.fk.fe.ums.protocol;
/*     */ 
/*     */ import com.hzjbbis.fk.sockclient.SimpleSocket;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UmsCommands
/*     */ {
/*     */   private static final Logger log;
/*     */   private List<UmsField> checkPasswordFields;
/*     */   private List<UmsField> heartBeatFields;
/*     */   private List<UmsField> sendSMSFields;
/*     */   private List<UmsField> sendRtuSMSFields;
/*     */   private List<UmsField> retrieveSMSFields;
/*     */   private List<UmsField> genReplyFields;
/*     */   private List<UmsField> smsReplyFields;
/*     */   private List<UmsField> smsConfirmFields;
/*     */   private static final Map<String, UmsField> emptyParam;
/*  32 */   private final byte[] buffer = new byte[4096];
/*     */ 
/*     */   static
/*     */   {
/*  19 */     log = Logger.getLogger(UmsCommands.class);
/*     */ 
/*  31 */     emptyParam = new HashMap();
/*     */   }
/*     */ 
/*     */   private String readReply(SimpleSocket socket) {
/*  35 */     int offset = 0; int len = this.buffer.length - offset;
/*  36 */     int n = -1;
/*     */ 
/*  38 */     n = socket.read(this.buffer, offset, len);
/*  39 */     if (n <= 0)
/*  40 */       return null;
/*  41 */     offset += n; len -= n;
/*  42 */     int f1Len = ((UmsField)this.genReplyFields.get(0)).getLength();
/*  43 */     int toRead = Integer.parseInt(new String(this.buffer, 0, f1Len).trim());
/*  44 */     while ((offset < toRead + f1Len) && (n > 0)) {
/*  45 */       n = socket.read(this.buffer, offset, len);
/*  46 */       offset += n; len -= n;
/*     */     }
/*  48 */     return new String(this.buffer, 0, offset);
/*     */   }
/*     */ 
/*     */   public boolean login(SimpleSocket socket, String appid, String pwd) {
/*  52 */     Map param = new HashMap();
/*  53 */     UmsField field = new UmsField();
/*  54 */     field.setName("AppId");
/*  55 */     field.setValue(appid);
/*  56 */     param.put(field.getName(), field);
/*  57 */     field = new UmsField();
/*  58 */     field.setName("Passwd");
/*  59 */     field.setValue(pwd);
/*  60 */     param.put(field.getName(), field);
/*     */ 
/*  62 */     String strCommand = createCommand(this.checkPasswordFields, param);
/*  63 */     if (socket.write(strCommand) <= 0)
/*  64 */       return false;
/*  65 */     String strReply = readReply(socket);
/*  66 */     int f1Len = ((UmsField)this.genReplyFields.get(0)).getLength();
/*  67 */     int f2Len = ((UmsField)this.genReplyFields.get(1)).getLength();
/*  68 */     String retCode = strReply.substring(f1Len, f1Len + f2Len);
/*  69 */     if ("0000".equals(retCode)) {
/*  70 */       log.info("ums-" + appid + "login success. reply=" + strReply);
/*  71 */       return true;
/*     */     }
/*  73 */     log.warn("ums-" + appid + "登录失败，原因＝" + strReply.substring(f1Len + f2Len));
/*  74 */     socket.close();
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean heartBeat(SimpleSocket socket) {
/*  79 */     String strCommand = createCommand(this.heartBeatFields, emptyParam);
/*  80 */     if (socket.write(strCommand) <= 0)
/*  81 */       return false;
/*  82 */     String strReply = readReply(socket);
/*  83 */     int f1Len = ((UmsField)this.genReplyFields.get(0)).getLength();
/*  84 */     int f2Len = ((UmsField)this.genReplyFields.get(1)).getLength();
/*  85 */     String retCode = strReply.substring(f1Len, f1Len + f2Len);
/*  86 */     if ("0000".equals(retCode))
/*  87 */       return true;
/*  88 */     log.warn("发送心跳失败，原因＝" + strReply.substring(f1Len + f2Len));
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   public Map<String, String> retrieveSMS(SimpleSocket socket, String appid)
/*     */   {
/*  94 */     Map param = new HashMap();
/*  95 */     UmsField field = new UmsField();
/*  96 */     field.setName("SubType");
/*  97 */     field.setValue("  ");
/*  98 */     param.put(field.getName(), field);
/*  99 */     field = new UmsField();
/* 100 */     field.setName("AppId");
/* 101 */     field.setValue(appid);
/* 102 */     param.put(field.getName(), field);
/*     */ 
/* 104 */     String strCommand = createCommand(this.retrieveSMSFields, param);
/* 105 */     if (log.isDebugEnabled()) {
/* 106 */       log.debug("retrieveSMS strCommand=" + strCommand);
/*     */     }
/* 108 */     if (socket.write(strCommand) <= 0)
/* 109 */       return null;
/* 110 */     String strReply = readReply(socket);
/* 111 */     if (strReply == null)
/* 112 */       return null;
/* 113 */     if (log.isDebugEnabled())
/* 114 */       log.debug("retrieveSMS strReply=" + strReply);
/* 115 */     int f1Len = ((UmsField)this.genReplyFields.get(0)).getLength();
/* 116 */     int f2Len = ((UmsField)this.genReplyFields.get(1)).getLength();
/* 117 */     String retCode = strReply.substring(f1Len, f1Len + f2Len);
/* 118 */     if ("1162".equals(retCode))
/*     */     {
/* 120 */       return null;
/*     */     }
/* 122 */     if ("1041".equals(retCode)) {
/* 123 */       log.warn("ums-" + appid + " 短信接收异常,短信网关回应未登录");
/* 124 */       return null;
/*     */     }
/* 126 */     if ("2001".equals(retCode)) {
/* 127 */       Map smsRep = parseReply(strReply);
/* 128 */       if (log.isDebugEnabled()) {
/* 129 */         log.debug("retrieveSMS smsRep=" + smsRep);
/*     */       }
/* 131 */       Map para = new HashMap();
/* 132 */       field = new UmsField();
/* 133 */       field.setName("SerialNO");
/* 134 */       field.setValue((String)smsRep.get("SerialNO"));
/* 135 */       para.put(field.getName(), field);
/* 136 */       field = new UmsField();
/* 137 */       field.setName("BatchNO");
/* 138 */       field.setValue((String)smsRep.get("BatchNO"));
/* 139 */       para.put(field.getName(), field);
/* 140 */       String confirm = createCommand(this.smsConfirmFields, para);
/* 141 */       socket.write(confirm);
/* 142 */       return smsRep;
/*     */     }
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   public int sendUserMessage(SimpleSocket socket, String mobilePhone, String content, String appid, String subAppId, String replyAddr)
/*     */   {
/* 149 */     return sendMessage(socket, mobilePhone, content, "0", appid, subAppId, replyAddr);
/*     */   }
/*     */ 
/*     */   public int sendRtuMessage(SimpleSocket socket, String mobilePhone, String content, String appid, String subAppId, String replyAddr)
/*     */   {
/* 154 */     return sendMessage(socket, mobilePhone, content, "21", appid, subAppId, replyAddr);
/*     */   }
/*     */ 
/*     */   public int sendMessage(SimpleSocket socket, String mobilePhone, String content, String msgType, String appid, String subAppId, String replyAddr) {
/* 158 */     Map param = new HashMap();
/* 159 */     UmsField field = new UmsField();
/* 160 */     field.setName("RecvId");
/* 161 */     field.setValue(mobilePhone);
/* 162 */     param.put(field.getName(), field);
/*     */ 
/* 164 */     field = new UmsField();
/* 165 */     field.setName("AppId");
/* 166 */     field.setValue(appid);
/* 167 */     param.put(field.getName(), field);
/*     */ 
/* 169 */     field = new UmsField();
/* 170 */     field.setName("Reply");
/* 171 */     if (replyAddr == null)
/* 172 */       replyAddr = "";
/* 173 */     field.setValue(replyAddr);
/* 174 */     param.put(field.getName(), field);
/*     */ 
/* 176 */     if ((msgType == null) || (msgType.length() == 0))
/* 177 */       msgType = "21";
/* 178 */     field = new UmsField();
/* 179 */     field.setName("MessageType");
/* 180 */     field.setValue(msgType);
/* 181 */     param.put(field.getName(), field);
/*     */ 
/* 183 */     if ((subAppId != null) && (subAppId.length() > 0)) {
/* 184 */       field = new UmsField();
/* 185 */       field.setName("SubApp");
/* 186 */       field.setValue(subAppId);
/* 187 */       param.put(field.getName(), field);
/*     */     }
/* 189 */     String strCommand = null;
/* 190 */     if (msgType.equals("0")) {
/* 191 */       field = new UmsField();
/* 192 */       field.setName("Content");
/* 193 */       field.setValue(content);
/* 194 */       param.put(field.getName(), field);
/* 195 */       strCommand = createCommand(this.sendSMSFields, param);
/*     */     }
/*     */     else {
/* 198 */       field = new UmsField();
/* 199 */       field.setName("RtuContent");
/* 200 */       field.setValue(content);
/* 201 */       param.put(field.getName(), field);
/* 202 */       strCommand = createCommand(this.sendRtuSMSFields, param);
/*     */     }
/* 204 */     if (log.isDebugEnabled())
/* 205 */       log.debug("sendMessage strCommand=" + strCommand);
/* 206 */     if (socket.write(strCommand) <= 0)
/* 207 */       return -1;
/* 208 */     String strReply = readReply(socket);
/* 209 */     if ((strReply == null) || (strReply.length() < 4)) {
/* 210 */       return -1;
/*     */     }
/* 212 */     int f1Len = ((UmsField)this.genReplyFields.get(0)).getLength();
/* 213 */     int f2Len = ((UmsField)this.genReplyFields.get(1)).getLength();
/* 214 */     String retCode = strReply.substring(f1Len, f1Len + f2Len);
/*     */ 
/* 216 */     if ("0000".equals(retCode)) {
/* 217 */       log.debug("send UMS success. reply=" + strReply);
/* 218 */       return 0;
/*     */     }
/* 220 */     if ("1088".equals(retCode)) {
/* 221 */       log.info("ums-" + appid + " send UMS failed. reply=" + strReply);
/* 222 */       return 0;
/*     */     }
/* 224 */     log.warn("ums-" + appid + " 发送失败，返回码＝" + retCode + ";strReply=" + strReply);
/* 225 */     return -2;
/*     */   }
/*     */ 
/*     */   public String createCommand(List<UmsField> define, Map<String, UmsField> param)
/*     */   {
/* 236 */     int len = 0;
/*     */ 
/* 238 */     StringBuffer sb = new StringBuffer(1024);
/* 239 */     for (int i = 1; i < define.size(); ++i) {
/* 240 */       UmsField field = (UmsField)define.get(i);
/*     */ 
/* 242 */       UmsField p = (UmsField)param.get(field.getName());
/*     */ 
/* 244 */       if (field.getLength() > 0) {
/* 245 */         len += field.getLength();
/* 246 */         if (p != null)
/* 247 */           sb.append(String.format("%-" + field.getLength() + "s", new Object[] { p.getValue() }));
/*     */         else
/* 249 */           sb.append(String.format("%-" + field.getLength() + "s", new Object[] { field.getDefValue() }));
/*     */       }
/*     */       else
/*     */       {
/* 253 */         if ((!($assertionsDisabled)) && (p == null)) throw new AssertionError();
/*     */         try {
/* 255 */           len += p.getValue().getBytes("GBK").length;
/*     */         } catch (Exception e) {
/* 257 */           log.warn("getValue().getBytes(\"GBK\") exception:", e);
/*     */         }
/* 259 */         sb.append(p.getValue());
/*     */       }
/*     */     }
/* 262 */     sb.insert(0, String.format("%-" + ((UmsField)define.get(0)).getLength() + "s", new Object[] { Integer.valueOf(len) }));
/* 263 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Map<String, String> parseReply(String rep) {
/* 267 */     Map map = new HashMap();
/* 268 */     int offset = 0;
/* 269 */     for (UmsField f : this.smsReplyFields) {
/* 270 */       if (f.getLength() > 0) {
/* 271 */         map.put(f.getName(), rep.substring(offset, offset + f.getLength()).trim());
/* 272 */         offset += f.getLength();
/*     */       }
/*     */       else {
/* 275 */         map.put(f.getName(), rep.substring(offset).trim());
/* 276 */         break;
/*     */       }
/*     */     }
/* 279 */     return map;
/*     */   }
/*     */ 
/*     */   public void setCheckPasswordFields(List<UmsField> checkPassword1001) {
/* 283 */     this.checkPasswordFields = checkPassword1001; }
/*     */ 
/*     */   public void setHeartBeatFields(List<UmsField> heart1003) {
/* 286 */     this.heartBeatFields = heart1003; }
/*     */ 
/*     */   public void setSendSMSFields(List<UmsField> sendSMS3011) {
/* 289 */     this.sendSMSFields = sendSMS3011; }
/*     */ 
/*     */   public void setRetrieveSMSFields(List<UmsField> retrieveSMS3012) {
/* 292 */     this.retrieveSMSFields = retrieveSMS3012;
/*     */   }
/*     */ 
/*     */   public void setGenReplyFields(List<UmsField> genReplyFields) {
/* 296 */     this.genReplyFields = genReplyFields;
/*     */   }
/*     */ 
/*     */   public void setSmsReplyFields(List<UmsField> smsReplyFields) {
/* 300 */     this.smsReplyFields = smsReplyFields;
/*     */   }
/*     */ 
/*     */   public void setSmsConfirmFields(List<UmsField> smsConfirmFields) {
/* 304 */     this.smsConfirmFields = smsConfirmFields;
/*     */   }
/*     */ 
/*     */   public void setSendRtuSMSFields(List<UmsField> sendRtuSMS3002) {
/* 308 */     this.sendRtuSMSFields = sendRtuSMS3002;
/*     */   }
/*     */ }