/*     */ package com.hzjbbis.fk.fe.ums;
/*     */ 
/*     */ import com.hzjbbis.fk.common.simpletimer.Speedometer;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.exception.SendMessageException;
/*     */ import com.hzjbbis.fk.fe.fiber.IFiber;
/*     */ import com.hzjbbis.fk.fe.ums.protocol.UmsCommands;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.MultiProtoMessageLoader;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.sockclient.SimpleSocket;
/*     */ import com.hzjbbis.fk.sockserver.event.MessageSendFailEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.CalendarUtil;
/*     */ import com.hzjbbis.fk.utils.Counter;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UmsModule extends BaseClientChannelModule
/*     */   implements IFiber
/*     */ {
/*  45 */   private static final Logger log = Logger.getLogger(UmsModule.class);
/*  46 */   private static final TraceLog tracer = TraceLog.getTracer(UmsModule.class);
/*     */   public static final String SMS_TYPE_CH = "0";
/*     */   public static final String SMS_TYPE_PDU = "21";
/*     */   private String appid;
/*     */   private String apppwd;
/*     */   private String reply;
/*     */   private IEventHandler eventHandler;
/*     */   private UmsCommands umsProtocol;
/*  56 */   private boolean fiber = false;
/*     */ 
/*  59 */   private State state = State.STOPPED;
/*     */   private SimpleSocket client;
/*  61 */   private List<IMessage> rtuReqList = new LinkedList();
/*  62 */   private List<MessageZj> genReqList = new LinkedList();
/*  63 */   private final MultiProtoMessageLoader messageLoad = new MultiProtoMessageLoader();
/*     */   private UmsSocketThread thread;
/*  67 */   private int umsSendSpeed = 100;
/*  68 */   private int sendUserLimit = 2;
/*  69 */   private int sendRtuLimit = 10;
/*  70 */   private int retrieveMsgLimit = 10;
/*  71 */   private Speedometer speedom = new Speedometer();
/*     */   private Counter socketIOSpeed;
/*     */   private long noUpLogAlertTime;
/*     */   private List<String> simNoList;
/*     */   private String alertContent;
/*  77 */   private long sleepInterval = 10000L;
/*  78 */   private long noUpLogTime = System.currentTimeMillis() - ???.sleepInterval;
/*     */ 
/*     */   public String getPeerAddr()
/*     */   {
/*  83 */     return this.appid;
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */   }
/*     */ 
/*     */   public boolean send(IMessage msg) {
/*  90 */     if (!(sendMessage(msg)))
/*  91 */       throw new SendMessageException("发送消息异常");
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean sendMessage(IMessage message) {
/*  96 */     IMessage rtuMsg = null;
/*  97 */     if (message.getMessageType() == MessageType.MSG_GATE) {
/*  98 */       rtuMsg = ((MessageGate)message).getInnerMessage();
/*     */     }
/* 100 */     if (rtuMsg == null) {
/* 101 */       return false;
/*     */     }
/* 103 */     rtuMsg.setTxfs(this.txfs);
/* 104 */     rtuMsg.setSource(this);
/* 105 */     if (rtuMsg.getMessageType() == MessageType.MSG_ZJ) {
/* 106 */       MessageZj zjmsg = (MessageZj)rtuMsg;
/* 107 */       if (zjmsg.head.c_func == 40)
/*     */       {
/* 109 */         synchronized (this.genReqList) {
/* 110 */           this.genReqList.add(zjmsg);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 116 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtuMsg.getRtua());
/* 117 */     String simNo = rtu.getSimNum();
/* 118 */     if ((simNo != null) && (simNo.length() >= 11) && (isNumeric(simNo.trim()))) {
/* 119 */       synchronized (this.rtuReqList) {
/* 120 */         this.rtuReqList.add(rtuMsg);
/*     */       }
/*     */     }
/*     */ 
/* 124 */     log.warn("rtu=" + HexDump.toHex(rtuMsg.getRtua()) + " simNo is error:" + simNo);
/* 125 */     if (rtuMsg.getMessageType() == MessageType.MSG_ZJ) {
/* 126 */       MessageZj zjmsg = (MessageZj)rtuMsg;
/* 127 */       zjmsg = zjmsg.createSendFailReply();
/* 128 */       this.eventHandler.handleEvent(new MessageSendFailEvent(zjmsg, this));
/*     */     }
/*     */ 
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNumeric(String str) {
/* 135 */     return Pattern.matches("[0-9]*", str); }
/*     */ 
/*     */   public boolean isActive() {
/* 138 */     return ((this.client == null) || (!(this.client.isAlive())));
/*     */   }
/*     */ 
/*     */   public boolean start() {
/* 142 */     this.lastReceiveTime = System.currentTimeMillis();
/* 143 */     if (!(this.state.isStopped()))
/* 144 */       return false;
/* 145 */     this.state = State.STARTING;
/* 146 */     log.debug("ums-" + this.appid + "启动...");
/*     */ 
/* 148 */     if (this.client == null) {
/* 149 */       this.client = new SimpleSocket(this.peerIp, this.peerPort);
/*     */     }
/* 151 */     if (!(this.fiber)) {
/* 152 */       this.thread = new UmsSocketThread();
/* 153 */       this.thread.start();
/*     */     }
/* 155 */     this.socketIOSpeed = new Counter(1000L, "ums-" + this.appid);
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 160 */     if (!(this.state.isRunning()))
/* 161 */       return;
/* 162 */     this.state = State.STOPPING;
/* 163 */     this.client.close();
/* 164 */     if (!(this.fiber)) {
/* 165 */       this.thread.interrupt();
/* 166 */       Thread.yield();
/*     */     }
/*     */     try
/*     */     {
/* 170 */       Thread.sleep(100L);
/*     */     } catch (Exception localException) {
/*     */     }
/* 173 */     this.thread = null;
/* 174 */     this.client = null;
/*     */   }
/*     */ 
/*     */   protected boolean doSendGenReq(MessageZj msg)
/*     */   {
/* 184 */     if (msg.data.position() == msg.data.limit())
/* 185 */       msg.data.position(0);
/* 186 */     msg.head.dlen = (short)msg.data.remaining();
/* 187 */     byte[] mn = new byte[14];
/* 188 */     msg.data.get(mn);
/* 189 */     int pos = 0;
/* 190 */     while ((mn[pos] == 0) && (pos < 14))
/* 191 */       ++pos;
/* 192 */     if (pos >= 14) {
/* 193 */       log.warn("用户自定义短信发送失败：目标号码全0！无法发送");
/* 194 */       this.eventHandler.handleEvent(new MessageSendFailEvent(msg, this));
/* 195 */       return false;
/*     */     }
/* 197 */     String mobile = new String(mn, pos, 14 - pos);
/* 198 */     byte[] ct = new byte[msg.head.dlen - 14];
/* 199 */     msg.data.get(ct);
/*     */ 
/* 202 */     int j = ct.length - 1;
/* 203 */     pos = 0;
/*     */ 
/* 205 */     while (pos < j) {
/* 206 */       byte cc = ct[pos];
/* 207 */       ct[pos] = ct[j];
/* 208 */       ct[j] = cc;
/* 209 */       ++pos; --j;
/*     */     }
/*     */ 
/* 212 */     String contents = new String(ct);
/*     */ 
/* 215 */     if ((mobile == null) || (!(isNumeric(mobile.trim())))) {
/* 216 */       if (log.isDebugEnabled())
/* 217 */         log.debug("用户自定义短信[" + contents + "]发送失败,simNo is error:" + mobile);
/* 218 */       this.eventHandler.handleEvent(new MessageSendFailEvent(msg, this));
/* 219 */       return false;
/*     */     }
/*     */ 
/* 222 */     int ret = 0;
/* 223 */     StringBuffer msb = new StringBuffer(mobile);
/* 224 */     msb.reverse();
/*     */ 
/* 226 */     String umsAddr = msg.getPeerAddr();
/* 227 */     String subappid = "";
/* 228 */     if ((umsAddr != null) && (umsAddr.length() > 0)) {
/* 229 */       int subIndex = umsAddr.indexOf(this.appid);
/* 230 */       if (subIndex >= 0) {
/* 231 */         subappid = umsAddr.substring(subIndex + this.appid.length());
/*     */       }
/*     */     }
/*     */ 
/* 235 */     String sendCont = null;
/* 236 */     int maxlen = 600;
/*     */ 
/* 238 */     int num = 1;
/* 239 */     int nums = contents.length() / maxlen;
/* 240 */     if (contents.length() % maxlen > 0) {
/* 241 */       ++nums;
/*     */     }
/* 243 */     String tag = "";
/* 244 */     while (contents.length() > 0) {
/* 245 */       if (nums > 1)
/* 246 */         tag = "[" + num + "/" + nums + "]";
/* 247 */       if (contents.length() >= maxlen) {
/* 248 */         sendCont = tag + contents.substring(0, maxlen);
/* 249 */         ret = this.umsProtocol.sendUserMessage(this.client, msb.toString(), sendCont, this.appid, subappid, this.reply);
/* 250 */         if (ret != 0) {
/*     */           break;
/*     */         }
/* 253 */         contents = contents.substring(maxlen, contents.length());
/*     */       }
/*     */       else {
/* 256 */         if (ret == 0)
/*     */         {
/* 258 */           sendCont = tag + contents.substring(0, contents.length());
/* 259 */           ret = this.umsProtocol.sendUserMessage(this.client, msb.toString(), sendCont, this.appid, subappid, this.reply);
/*     */         }
/* 261 */         contents = "";
/*     */       }
/* 263 */       ++num;
/*     */     }
/*     */ 
/* 266 */     if (-1 == ret) {
/* 267 */       this.client.close();
/*     */     }
/* 269 */     String info = null;
/* 270 */     if (log.isDebugEnabled()) {
/* 271 */       StringBuffer sb = new StringBuffer();
/* 272 */       sb.append(getPeerAddr());
/* 273 */       if (ret == 0)
/* 274 */         sb.append("成功");
/*     */       else
/* 276 */         sb.append("失败");
/* 277 */       sb.append(" ->短信通道下行报文:[mobile=");
/* 278 */       sb.append(mobile);
/* 279 */       sb.append(",contents=").append(contents).append("],subappid=" + subappid);
/* 280 */       info = sb.toString();
/* 281 */       log.debug(info);
/*     */     }
/* 283 */     msg.setPeerAddr(getPeerAddr() + subappid);
/* 284 */     msg.setIoTime(System.currentTimeMillis());
/*     */ 
/* 286 */     msg.setServerAddress(msg.getPeerAddr() + "," + mobile);
/* 287 */     if (ret == 0) {
/* 288 */       this.eventHandler.handleEvent(new SendMessageEvent(msg, this));
/*     */     }
/*     */     else
/*     */     {
/* 292 */       this.eventHandler.handleEvent(new MessageSendFailEvent(msg, this));
/*     */     }
/* 294 */     return (ret != 0);
/*     */   }
/*     */ 
/*     */   protected boolean doSendRtuReq(IMessage rtuMsg)
/*     */   {
/* 304 */     rtuMsg.setIoTime(System.currentTimeMillis());
/*     */ 
/* 306 */     String downReqString = null;
/*     */ 
/* 308 */     downReqString = new String(rtuMsg.getRawPacketString());
/*     */ 
/* 310 */     int ret = -1;
/*     */ 
/* 312 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtuMsg.getRtua());
/* 313 */     if (rtu == null) {
/* 314 */       log.warn("终端不存在，无法发送召测命令----" + HexDump.toHex(rtuMsg.getRtua()));
/* 315 */       return false;
/*     */     }
/* 317 */     String umsAddr = rtuMsg.getPeerAddr();
/* 318 */     String subappid = "";
/* 319 */     if ((umsAddr != null) && (umsAddr.length() > 0)) {
/* 320 */       int subIndex = umsAddr.indexOf(this.appid);
/* 321 */       if (subIndex >= 0) {
/* 322 */         subappid = umsAddr.substring(subIndex + this.appid.length());
/*     */       }
/* 326 */       else if (rtu.getActiveSubAppId() != null) {
/* 327 */         subappid = rtu.getActiveSubAppId();
/*     */       }
/*     */ 
/*     */     }
/* 332 */     else if (rtu.getActiveSubAppId() != null) {
/* 333 */       subappid = rtu.getActiveSubAppId();
/*     */     }
/* 335 */     String mobilePhone = rtu.getSimNum();
/* 336 */     if ((mobilePhone == null) || (mobilePhone.length() <= 0)) {
/* 337 */       log.warn("终端SIM卡资料缺失,短信无法发送--" + HexDump.toHex(rtuMsg.getRtua()));
/* 338 */       this.eventHandler.handleEvent(new MessageSendFailEvent(rtuMsg, this));
/* 339 */       return false;
/*     */     }
/* 341 */     ret = this.umsProtocol.sendRtuMessage(this.client, mobilePhone, downReqString, this.appid, subappid, this.reply);
/* 342 */     if (ret != 0) {
/* 343 */       this.client.close();
/*     */     }
/*     */ 
/* 346 */     String info = null;
/* 347 */     if (log.isDebugEnabled()) {
/* 348 */       StringBuffer sb = new StringBuffer();
/* 349 */       sb.append(getPeerAddr());
/* 350 */       if (ret == 0)
/* 351 */         sb.append("成功");
/*     */       else
/* 353 */         sb.append("失败");
/* 354 */       sb.append(" ->短信通道下行报文:");
/* 355 */       sb.append(downReqString).append(",subappid=").append(subappid);
/* 356 */       info = sb.toString();
/* 357 */       log.debug(info);
/*     */     }
/*     */ 
/* 360 */     if (ret == 0) {
/* 361 */       rtuMsg.setPeerAddr(getPeerAddr() + subappid);
/* 362 */       rtuMsg.setIoTime(System.currentTimeMillis());
/*     */ 
/* 364 */       rtuMsg.setServerAddress("95598" + rtuMsg.getPeerAddr() + "," + mobilePhone);
/* 365 */       this.eventHandler.handleEvent(new SendMessageEvent(rtuMsg, this));
/*     */     }
/*     */     else {
/* 368 */       if (rtuMsg.getMessageType() == MessageType.MSG_ZJ) {
/* 369 */         MessageZj msgzj = (MessageZj)rtuMsg;
/* 370 */         byte msta = msgzj.head.msta;
/*     */ 
/* 372 */         if (((msta >= 10) && (msta <= 29)) || (msgzj.head.rtua == 0)) {
/* 373 */           return (ret != 0);
/*     */         }
/*     */       }
/* 376 */       rtuMsg.setPeerAddr(getPeerAddr() + subappid);
/* 377 */       rtuMsg.setIoTime(System.currentTimeMillis());
/*     */ 
/* 379 */       rtuMsg.setServerAddress("95598" + rtuMsg.getPeerAddr() + "," + mobilePhone);
/* 380 */       this.eventHandler.handleEvent(new MessageSendFailEvent(rtuMsg, this));
/*     */     }
/* 382 */     return (ret != 0);
/*     */   }
/*     */ 
/*     */   public void setAppid(String appid)
/*     */   {
/* 387 */     this.appid = appid;
/*     */   }
/*     */ 
/*     */   public void setApppwd(String apppwd) {
/* 391 */     this.apppwd = apppwd;
/*     */   }
/*     */ 
/*     */   public void setReply(String reply) {
/* 395 */     this.reply = reply;
/*     */   }
/*     */ 
/*     */   public void setEventHandler(IEventHandler eventHandler) {
/* 399 */     this.eventHandler = eventHandler;
/*     */   }
/*     */ 
/*     */   public void runOnce()
/*     */   {
/*     */     label157: String strTime;
/* 407 */     if ((this.state == State.STOPPING) || (this.state == State.STOPPED)) {
/* 408 */       this.state = State.STOPPED;
/* 409 */       return;
/*     */     }
/* 411 */     if (this.state == State.STARTING)
/* 412 */       this.state = State.RUNNING;
/* 413 */     long time0 = System.currentTimeMillis();
/*     */ 
/* 415 */     if (!(isActive())) {
/* 416 */       long delta = System.currentTimeMillis() - this.client.getLastConnectTime();
/* 417 */       if (delta > 60000L)
/*     */       {
/* 419 */         boolean ret = this.client.reConnect();
/* 420 */         log.info("ums-" + this.appid + " reConnetct...");
/* 421 */         if ((!(ret)) || 
/* 423 */           (this.umsProtocol.login(this.client, this.appid, this.apppwd))) break label157;
/* 424 */         return;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 429 */         Thread.sleep(50L); } catch (Exception localException1) {
/*     */       }
/* 431 */       return;
/*     */     }
/*     */ 
/* 435 */     int msgCount = 0;
/* 436 */     while ((this.rtuReqList.size() > 0) && (msgCount++ < this.sendRtuLimit) && (this.client.isAlive()))
/*     */     {
/*     */       IMessage rtuMsg;
/* 437 */       if (log.isDebugEnabled()) {
/* 438 */         log.debug("发送终端短信" + msgCount + ";rtuReqList=" + this.rtuReqList.size());
/*     */       }
/* 440 */       synchronized (this.rtuReqList) {
/* 441 */         rtuMsg = (IMessage)this.rtuReqList.remove(0);
/*     */       }
/* 443 */       doSendRtuReq(rtuMsg);
/* 444 */       this.totalSendMessages += 1L;
/* 445 */       this.lastSendTime = System.currentTimeMillis();
/* 446 */       this.speedom.add(1);
/* 447 */       this.socketIOSpeed.add();
/* 448 */       if (this.speedom.getSpeed1() <= this.umsSendSpeed) continue;
/*     */       try {
/* 450 */         log.info("ums-" + this.appid + " send speed > limit speed:" + this.speedom.getSpeed1());
/* 451 */         Thread.sleep(50L); } catch (Exception localException2) {
/*     */       }
/* 453 */       break;
/*     */     }
/*     */ 
/* 458 */     msgCount = 0;
/* 459 */     if (System.currentTimeMillis() - this.noUpLogTime <= this.sleepInterval)
/* 460 */       if ((this.rtuReqList.size() <= 0) && (this.genReqList.size() <= 0))
/*     */         try
/*     */         {
/* 463 */           Thread.sleep(50L);
/*     */         }
/*     */         catch (Exception localException3) {
/*     */         }
/*     */     else {
/*     */       do {
/* 469 */         if (log.isDebugEnabled())
/* 470 */           log.debug("巡测终端上行短信:" + msgCount);
/* 471 */         Map repMap = this.umsProtocol.retrieveSMS(this.client, this.appid);
/* 472 */         if (repMap == null) {
/* 473 */           this.noUpLogTime = System.currentTimeMillis();
/*     */ 
/* 475 */           break;
/*     */         }
/* 477 */         ++msgCount;
/*     */ 
/* 479 */         String rawMessage = (String)repMap.get("Content");
/* 480 */         String strDate = (String)repMap.get("ReceiveDate");
/* 481 */         strTime = (String)repMap.get("ReceiveTime");
/* 482 */         String from = (String)repMap.get("From");
/* 483 */         if (from == null)
/* 484 */           from = " ";
/* 485 */         String receiver = (String)repMap.get("Receive");
/* 486 */         if (receiver == null) {
/* 487 */           receiver = " ";
/*     */         }
/* 489 */         this.lastReceiveTime = System.currentTimeMillis();
/* 490 */         this.totalRecvMessages += 1L;
/*     */         try {
/* 492 */           IMessage msg = this.messageLoad.loadMessage(rawMessage);
/* 493 */           if (log.isDebugEnabled())
/* 494 */             log.debug(msgCount + "--retrieveSMS msg:" + msg);
/* 495 */           if (msg != null) {
/* 496 */             msg.setPeerAddr(getPeerAddr());
/* 497 */             msg.setIoTime(System.currentTimeMillis());
/* 498 */             msg.setSource(this);
/* 499 */             msg.setTxfs(this.txfs);
/* 500 */             msg.setServerAddress(from + "," + receiver);
/* 501 */             this.eventHandler.handleEvent(new ReceiveMessageEvent(msg, this)); break label880:
/*     */           }
/*     */ 
/* 505 */           log.info("ums-" + this.appid + " 非终端规约短信上行：" + rawMessage + ",from=" + from + ",datetime=" + strDate + strTime);
/*     */         }
/*     */         catch (Exception exp)
/*     */         {
/* 509 */           log.error("MultiProtoMessageLoader.loadMessage 异常,原因=" + exp.getLocalizedMessage() + ",rawpacket=" + rawMessage);
/*     */         }
/* 511 */         label880: this.speedom.add(1);
/* 512 */         this.socketIOSpeed.add();
/*     */       }
/* 468 */       while ((msgCount < this.retrieveMsgLimit) && (this.client.isAlive()));
/*     */     }
/*     */ 
/* 524 */     msgCount = 0;
/* 525 */     while ((this.genReqList.size() > 0) && (msgCount++ < this.sendUserLimit) && (this.client.isAlive()))
/*     */     {
/*     */       MessageZj msg;
/* 526 */       if (log.isDebugEnabled()) {
/* 527 */         log.debug("给普通用户发送短信" + msgCount + ";genReqList=" + this.genReqList.size());
/*     */       }
/* 529 */       synchronized (this.genReqList) {
/* 530 */         msg = (MessageZj)this.genReqList.remove(0);
/*     */       }
/* 532 */       doSendGenReq(msg);
/* 533 */       this.lastSendTime = System.currentTimeMillis();
/* 534 */       this.totalSendMessages += 1L;
/* 535 */       this.speedom.add(1);
/* 536 */       this.socketIOSpeed.add();
/* 537 */       if (this.speedom.getSpeed1() <= this.umsSendSpeed) continue;
/*     */       try {
/* 539 */         Thread.sleep(50L); } catch (Exception localException4) {
/*     */       }
/* 541 */       break;
/*     */     }
/*     */ 
/* 546 */     if ((this.client.isAlive()) && (this.noUpLogAlertTime > 0L) && (this.alertContent != null)) {
/* 547 */       long delt = System.currentTimeMillis() - this.lastReceiveTime;
/* 548 */       if (delt > this.noUpLogAlertTime) {
/* 549 */         if (this.simNoList != null) {
/* 550 */           for (String mobileNo : this.simNoList) {
/* 551 */             this.umsProtocol.sendUserMessage(this.client, mobileNo, this.alertContent, this.appid, null, this.reply);
/*     */           }
/*     */         }
/* 554 */         this.client.close();
/* 555 */         this.lastReceiveTime = System.currentTimeMillis();
/* 556 */         log.info("UMS通讯应用ID" + this.appid + "的通道在指定时间范围内无消息上报,重启链路");
/*     */       }
/*     */     }
/* 559 */     long timeTake = System.currentTimeMillis() - time0;
/* 560 */     if (timeTake > 1000L)
/* 561 */       tracer.trace("ums-" + this.appid + "socketIO takes(milliseconds):" + timeTake);
/*     */   }
/*     */ 
/*     */   public void setNoUpLogAlertTime(long noUpLogAlertTime) {
/* 565 */     this.noUpLogAlertTime = noUpLogAlertTime;
/*     */   }
/*     */ 
/*     */   public void setSimNoList(List<String> simNoList) {
/* 569 */     this.simNoList = simNoList;
/*     */   }
/*     */ 
/*     */   public void setAlertContent(String alertContent) {
/* 573 */     this.alertContent = alertContent;
/*     */   }
/*     */ 
/*     */   public final void setUmsProtocol(UmsCommands umsProtocol) {
/* 577 */     this.umsProtocol = umsProtocol;
/*     */   }
/*     */ 
/*     */   public final void setUmsSendSpeed(int umsSendSpeed) {
/* 581 */     this.umsSendSpeed = umsSendSpeed;
/*     */   }
/*     */ 
/*     */   public final void setSendUserLimit(int sendUserLimit) {
/* 585 */     this.sendUserLimit = sendUserLimit;
/*     */   }
/*     */ 
/*     */   public final void setSendRtuLimit(int sendRtuLimit) {
/* 589 */     this.sendRtuLimit = sendRtuLimit;
/*     */   }
/*     */ 
/*     */   public void setFiber(boolean isFiber) {
/* 593 */     this.fiber = isFiber;
/*     */   }
/*     */ 
/*     */   public boolean isFiber() {
/* 597 */     return this.fiber;
/*     */   }
/*     */ 
/*     */   public final void setRetrieveMsgLimit(int retrieveMsgLimit)
/*     */   {
/* 619 */     this.retrieveMsgLimit = retrieveMsgLimit;
/*     */   }
/*     */ 
/*     */   public String profile()
/*     */   {
/* 624 */     StringBuffer sb = new StringBuffer(1024);
/* 625 */     sb.append("\r\n<sockclient-profile type=\"").append(getModuleType()).append("\">");
/* 626 */     sb.append("\r\n    ").append("<name>").append(getName()).append("</name>");
/* 627 */     sb.append("\r\n    ").append("<ip>").append(getPeerIp()).append("</ip>");
/* 628 */     sb.append("\r\n    ").append("<port>").append(getPeerPort()).append("</port>");
/* 629 */     sb.append("\r\n    ").append("<state>").append(isActive()).append("</state>");
/*     */ 
/* 631 */     sb.append("\r\n    ").append("<txfs>").append(this.txfs).append("</txfs>");
/* 632 */     sb.append("\r\n    ").append("<totalRecv>").append(this.totalRecvMessages).append("</totalRecv>");
/* 633 */     sb.append("\r\n    ").append("<totalSend>").append(this.totalSendMessages).append("</totalSend>");
/* 634 */     sb.append("\r\n    ").append("<speed>").append(this.speedom.getSpeed1()).append("</speed>");
/*     */ 
/* 636 */     String stime = CalendarUtil.getTimeString(this.lastReceiveTime);
/* 637 */     sb.append("\r\n    ").append("<lastRecv>").append(stime).append("</lastRecv>");
/* 638 */     stime = CalendarUtil.getTimeString(this.lastSendTime);
/* 639 */     sb.append("\r\n    ").append("<lastSend>").append(stime).append("</lastSend>");
/* 640 */     sb.append("\r\n</sockclient-profile>");
/* 641 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getModuleType()
/*     */   {
/* 646 */     return "umsClient";
/*     */   }
/*     */ 
/*     */   public void setNoUpLogTime(long noUpLogTime) {
/* 650 */     this.noUpLogTime = noUpLogTime;
/*     */   }
/*     */ 
/*     */   public void setSleepInterval(long sleepInterval) {
/* 654 */     this.sleepInterval = sleepInterval;
/*     */   }
/*     */ 
/*     */   private class UmsSocketThread extends Thread
/*     */   {
/*     */     public UmsSocketThread()
/*     */     {
/* 602 */       super("ums.thread." + UmsModule.this.appid);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 607 */       while (UmsModule.this.state != State.STOPPED)
/*     */         try {
/* 609 */           UmsModule.this.runOnce();
/*     */         }
/*     */         catch (Exception exp) {
/* 612 */           UmsModule.log.error("UMS通信处理异常：" + exp.getLocalizedMessage(), exp);
/*     */         }
/*     */     }
/*     */   }
/*     */ }