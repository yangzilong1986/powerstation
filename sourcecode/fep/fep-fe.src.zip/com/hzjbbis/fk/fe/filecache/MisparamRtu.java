/*    */ package com.hzjbbis.fk.fe.filecache;
/*    */ 
/*    */ public class MisparamRtu
/*    */ {
/*    */   private int rtua;
/*    */   private String gprsActiveCommAddr;
/*    */   private String smsActiveCommAddr;
/*    */   private long lastUpdate;
/* 16 */   private char state = '0';
/*    */ 
/*    */   public int getRtua() {
/* 19 */     return this.rtua; }
/*    */ 
/*    */   public void setRtua(int rtua) {
/* 22 */     this.rtua = rtua;
/*    */   }
/*    */ 
/*    */   public String getGprsActiveCommAddr() {
/* 26 */     return this.gprsActiveCommAddr; }
/*    */ 
/*    */   public void setGprsActiveCommAddr(String gprsActiveCommAddr) {
/* 29 */     this.gprsActiveCommAddr = gprsActiveCommAddr;
/* 30 */     if (this.gprsActiveCommAddr == null)
/* 31 */       this.lastUpdate = 0L;
/*    */   }
/*    */ 
/*    */   public String getSmsActiveCommAddr() {
/* 35 */     return this.smsActiveCommAddr; }
/*    */ 
/*    */   public void setSmsActiveCommAddr(String smsActiveCommAddr) {
/* 38 */     this.smsActiveCommAddr = smsActiveCommAddr;
/* 39 */     if (this.smsActiveCommAddr == null)
/* 40 */       this.lastUpdate = 0L;
/*    */   }
/*    */ 
/*    */   public void setLastUpdate() {
/* 44 */     this.lastUpdate = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public void setLastUpdate(long tm) {
/* 48 */     this.lastUpdate = tm;
/*    */   }
/*    */ 
/*    */   public long getLastUpdate() {
/* 52 */     return this.lastUpdate;
/*    */   }
/*    */ 
/*    */   public char getState() {
/* 56 */     return this.state; }
/*    */ 
/*    */   public void setState(char state) {
/* 59 */     this.state = state;
/*    */   }
/*    */ 
/*    */   public boolean isDirty()
/*    */   {
/* 67 */     return ((this.gprsActiveCommAddr == null) && (this.smsActiveCommAddr == null));
/*    */   }
/*    */ }