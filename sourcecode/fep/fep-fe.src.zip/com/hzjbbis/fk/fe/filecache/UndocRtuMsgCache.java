/*     */ package com.hzjbbis.fk.fe.filecache;
/*     */ 
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UndocRtuMsgCache
/*     */ {
/*  22 */   private static final Logger log = Logger.getLogger(UndocRtuMsgCache.class);
/*     */   private static String path;
/*  24 */   private static int maxCount = 10;
/*  25 */   private static int maxSizeM = 100;
/*     */   private static final String fileName = "undocRtu.msg";
/*  28 */   private static final Object fLock = new Object();
/*     */   private static final int maxMessageSize = 100;
/*  30 */   private static final ArrayList<MessageZj> msgPool = new ArrayList(100);
/*     */ 
/*     */   static
/*     */   {
/*     */     try {
/*  35 */       File file = new File("data");
/*  36 */       file.mkdirs();
/*  37 */       path = file.getAbsolutePath();
/*  38 */       System.out.println("undocumented rtu message file path= " + path);
/*     */     } catch (Exception exp) {
/*  40 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addMessage(MessageZj msg) {
/*  45 */     synchronized (fLock) {
/*  46 */       if (msgPool.size() == 100)
/*  47 */         flush();
/*  48 */       msgPool.add(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void flush() {
/*  53 */     if (msgPool.size() == 0)
/*  54 */       return;
/*  55 */     synchronized (fLock) {
/*     */       try {
/*  57 */         _save2File();
/*  58 */         msgPool.clear();
/*     */       } catch (Exception e) {
/*  60 */         log.error("Undocument RTU message save to cache exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void _save2File() throws IOException {
/*  66 */     String nextPath = getNextFilePath();
/*  67 */     PrintWriter printer = new PrintWriter(new BufferedWriter(new FileWriter(nextPath, true), 1048576));
/*  68 */     for (int i = 0; i < msgPool.size(); ++i) {
/*  69 */       MessageZj msg = (MessageZj)msgPool.get(i);
/*  70 */       if (msg == null)
/*     */         continue;
/*  72 */       printer.println(msg.getRawPacketString());
/*     */     }
/*  74 */     printer.flush();
/*  75 */     printer.close();
/*     */   }
/*     */ 
/*     */   private static String getNextFilePath()
/*     */   {
/*  82 */     String npath = path + File.separatorChar + "undocRtu.msg";
/*  83 */     int stdNameLen = "undocRtu.msg".length();
/*  84 */     File f = new File(npath);
/*  85 */     if (!(f.exists()))
/*  86 */       return npath;
/*  87 */     if (f.length() >= maxSizeM << 20)
/*     */     {
/*  89 */       f = new File(path);
/*  90 */       File[] allFiles = new File[maxCount + 1];
/*  91 */       int maxIndex = -1;
/*  92 */       File[] files = f.listFiles();
/*  93 */       for (int i = 0; i < files.length; ++i) {
/*  94 */         if (!(files[i].isFile()))
/*     */           continue;
/*  96 */         String fn = files[i].getName();
/*  97 */         if (!(fn.startsWith("undocRtu.msg")))
/*     */           continue;
/*  99 */         String pfix = fn.substring(stdNameLen + 1);
/* 100 */         if (pfix.length() <= 0)
/*     */           continue;
/* 102 */         int appendInt = Integer.parseInt(pfix);
/* 103 */         if (appendInt >= allFiles.length)
/*     */           continue;
/* 105 */         allFiles[appendInt] = files[i];
/* 106 */         maxIndex = i;
/*     */       }
/* 108 */       for (i = maxIndex; i >= 0; --i)
/* 109 */         if (i >= maxCount) {
/* 110 */           allFiles[i].delete();
/*     */         }
/*     */         else {
/* 113 */           npath = path + File.separatorChar + "undocRtu.msg" + "." + (i + 1);
/* 114 */           allFiles[i].renameTo(new File(npath));
/*     */         }
/*     */     }
/* 117 */     return path + File.separatorChar + "undocRtu.msg";
/*     */   }
/*     */ 
/*     */   public static void setPath(String pstr) {
/*     */     try {
/* 122 */       File file = new File(pstr);
/* 123 */       if (!(file.isDirectory())) {
/* 124 */         log.error("未归档终端上行消息保存目录不存在：" + pstr);
/* 125 */         return;
/*     */       }
/* 127 */       path = file.getAbsolutePath();
/* 128 */       System.out.println("undocumented rtu message file path= " + path);
/*     */     } catch (Exception exp) {
/* 130 */       log.error(exp.getLocalizedMessage(), exp); }
/*     */   }
/*     */ 
/*     */   public static void setMaxCount(int mc) {
/* 134 */     if (mc > 0)
/* 135 */       maxCount = mc; 
/*     */   }
/*     */ 
/*     */   public static void setMaxSizeM(int sizeM) {
/* 138 */     if (sizeM > 0)
/* 139 */       maxSizeM = sizeM;
/*     */   }
/*     */ }