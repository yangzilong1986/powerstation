/*     */ package com.hzjbbis.fk.fe.filecache;
/*     */ 
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.io.File;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileChannel.MapMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class RtuParamsCache
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger(RtuParamsCache.class);
/*     */   private static final int STOPPED = 0;
/*     */   private static final int RUNNING = 1;
/*     */   private static final int STOPPING = 2;
/*  36 */   private static RtuParamsCache instance = null;
/*     */   private static String filePath;
/*     */   private static final int ONE_RTU_CACHE_LEN = 45;
/*  53 */   private int batchSize = 1000;
/*     */ 
/*  55 */   private Map<Integer, ComRtu> rtuMap = new HashMap(1024);
/*  56 */   private int _state = 0;
/*     */ 
/*  58 */   private MappedByteBuffer buffer = null;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  43 */       File file = new File("data");
/*  44 */       file.mkdirs();
/*  45 */       filePath = file.getAbsolutePath() + File.separatorChar + "rtu-params.data";
/*  46 */       instance = new RtuParamsCache();
/*     */     } catch (Exception exp) {
/*  48 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   private RtuParamsCache()
/*     */   {
/*  61 */     new RtuParamCacheThread();
/*     */   }
/*     */ 
/*     */   public static final RtuParamsCache getInstance() {
/*  65 */     return instance;
/*     */   }
/*     */ 
/*     */   public void initOnStartup(boolean create)
/*     */   {
/*     */     int i;
/*  69 */     File f = new File(filePath);
/*  70 */     if ((!(f.exists())) || (f.length() == 0L))
/*  71 */       return;
/*  72 */     synchronized (instance) {
/*  73 */       RandomAccessFile raf = null;
/*     */       try {
/*  75 */         raf = new RandomAccessFile(f, "rw");
/*  76 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, f.length());
/*     */       } catch (Exception e) {
/*  78 */         log.error("heartbeat file exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/*  81 */         if (raf != null)
/*     */           try {
/*  83 */             raf.close();
/*  84 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*  89 */     int count = this.buffer.capacity() / 45;
/*  90 */     int pos = 0; int rtua = -1;
/*  91 */     int i = 0; int successCount = 0;
/*     */ 
/*  93 */     byte[] activeGprsBytes = new byte[21];
/*  94 */     byte[] subAppIdBytes = new byte[3];
/*  95 */     for (int i = 0; i < count; ++i) {
/*  96 */       this.buffer.position(pos);
/*  97 */       rtua = this.buffer.getInt();
/*  98 */       ComRtu rtuObj = null;
/*  99 */       if (create) {
/* 100 */         rtuObj = new ComRtu();
/* 101 */         rtuObj.setRtua(rtua);
/* 102 */         rtuObj.setLogicAddress(HexDump.toHex(rtua));
/* 103 */         RtuManage.getInstance().putComRtuToCache(rtuObj);
/*     */       }
/*     */       else {
/* 106 */         rtuObj = RtuManage.getInstance().getComRtuInCache(rtua); }
/* 107 */       if (rtuObj != null) {
/* 108 */         rtuObj.setRtuSavePosition(pos);
/*     */ 
/* 110 */         byte b = this.buffer.get();
/* 111 */         if (b == 0)
/* 112 */           rtuObj.setManufacturer(null);
/*     */         else {
/* 114 */           rtuObj.setManufacturer(HexDump.toHex(b));
/*     */         }
/* 116 */         long mobile = this.buffer.getLong();
/* 117 */         if (0L != mobile) {
/* 118 */           if ((rtuObj.getSimNum() == null) || (rtuObj.getSimNum().length() == 0))
/* 119 */             rtuObj.setSimNum(String.valueOf(mobile));
/*     */         }
/*     */         else {
/* 122 */           rtuObj.setSimNum(null);
/*     */         }
/* 124 */         this.buffer.get(activeGprsBytes);
/* 125 */         int gprsLen = activeGprsBytes.length;
/* 126 */         for (int j = 0; j < activeGprsBytes.length; ++j) {
/* 127 */           if (activeGprsBytes[j] == 0) {
/* 128 */             gprsLen = j;
/* 129 */             break;
/*     */           }
/*     */         }
/* 132 */         if (gprsLen > 0)
/* 133 */           rtuObj.setActiveGprs(new String(activeGprsBytes, 0, gprsLen));
/*     */         else {
/* 135 */           rtuObj.setActiveGprs(null);
/*     */         }
/* 137 */         mobile = this.buffer.getLong();
/* 138 */         if (0L != mobile)
/* 139 */           rtuObj.setActiveUms(String.valueOf(mobile));
/*     */         else {
/* 141 */           rtuObj.setActiveUms(null);
/*     */         }
/* 143 */         this.buffer.get(subAppIdBytes);
/* 144 */         int subAppIdLen = subAppIdBytes.length;
/* 145 */         for (int j = 0; j < subAppIdBytes.length; ++j) {
/* 146 */           if (subAppIdBytes[j] == 0) {
/* 147 */             subAppIdLen = j;
/* 148 */             break;
/*     */           }
/*     */         }
/* 151 */         if (subAppIdLen > 0)
/* 152 */           rtuObj.setActiveSubAppId(new String(subAppIdBytes, 0, subAppIdLen));
/*     */         else
/* 154 */           rtuObj.setActiveSubAppId("");
/* 155 */         ++successCount;
/*     */       }
/*     */       else {
/* 158 */         ++i;
/*     */       }
/* 160 */       pos += 45;
/*     */     }
/* 162 */     if (i + successCount > 0) {
/* 163 */       double rate = i * 1.0D / (i + successCount);
/* 164 */       if (rate > 0.99D)
/* 165 */         log.warn("loading rtu params, but failedCount/total > 99%. RTU save format may be error.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addRtu(ComRtu rtu)
/*     */   {
/* 178 */     synchronized (this.rtuMap) {
/* 179 */       this.rtuMap.put(Integer.valueOf(rtu.getRtua()), rtu);
/* 180 */       if (this.rtuMap.size() >= this.batchSize)
/* 181 */         this.rtuMap.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 187 */     if (this._state != 1)
/* 188 */       return;
/* 189 */     this._state = 2;
/* 190 */     if (this.rtuMap.size() > 0) {
/* 191 */       this.rtuMap.notifyAll();
/* 192 */       int cnt = 20;
/*     */ 
/* 194 */       while ((cnt-- > 0) && (this._state != 0))
/*     */         try {
/* 196 */           Thread.sleep(100L);
/*     */         } catch (Exception localException) {
/*     */         }
/* 199 */       log.info("RtuParamsCache disposed, state=" + this._state);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addNewRtu(Collection<ComRtu> rtus) {
/* 204 */     if ((rtus == null) || (rtus.size() == 0)) {
/* 205 */       return;
/*     */     }
/* 207 */     int count = rtus.size();
/* 208 */     int expandLength = count * 45;
/*     */ 
/* 210 */     File f = new File(filePath);
/* 211 */     synchronized (instance) {
/* 212 */       RandomAccessFile raf = null;
/*     */       try {
/* 214 */         raf = new RandomAccessFile(f, "rw");
/* 215 */         int pos0 = (int)raf.length();
/* 216 */         raf.setLength(pos0 + expandLength);
/* 217 */         for (ComRtu rtu : rtus) {
/* 218 */           raf.seek(pos0);
/* 219 */           rtu.setRtuSavePosition(pos0);
/* 220 */           raf.writeInt(rtu.getRtua());
/* 221 */           pos0 += 45;
/*     */         }
/* 223 */         this.buffer = null;
/* 224 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, raf.length());
/*     */       } catch (Exception e) {
/* 226 */         log.warn("addNewRtu exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 229 */         if (raf != null)
/*     */           try {
/* 231 */             raf.close();
/* 232 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doSave2Cache() {
/* 240 */     ArrayList list = null;
/*     */ 
/* 242 */     if (this.rtuMap.size() == 0)
/* 243 */       return;
/* 244 */     synchronized (this.rtuMap) {
/* 245 */       list = new ArrayList(this.rtuMap.values());
/* 246 */       this.rtuMap.clear();
/*     */     }
/*     */ 
/* 249 */     ArrayList newRtuList = new ArrayList();
/* 250 */     Iterator iter = list.iterator();
/* 251 */     while (iter.hasNext()) {
/* 252 */       ComRtu rtu = (ComRtu)iter.next();
/* 253 */       if (rtu.getRtuSavePosition() < 0)
/* 254 */         newRtuList.add(rtu);
/*     */     }
/* 256 */     addNewRtu(newRtuList);
/* 257 */     newRtuList = null;
/*     */ 
/* 260 */     synchronized (instance) {
/* 261 */       iter = list.iterator();
/* 262 */       while (iter.hasNext()) {
/* 263 */         ComRtu rtu = (ComRtu)iter.next();
/* 264 */         this.buffer.position(rtu.getRtuSavePosition());
/* 265 */         int rtua = this.buffer.getInt();
/* 266 */         if (rtua != rtu.getRtua()) {
/* 267 */           log.warn("终端RTUA定位不一致：" + HexDump.toHex(rtua));
/*     */         }
/*     */         else {
/* 270 */           String str = null;
/*     */ 
/* 281 */           byte manuf = 0;
/* 282 */           this.buffer.put(manuf);
/*     */ 
/* 284 */           str = rtu.getSimNum();
/* 285 */           if ((str == null) || (str.length() == 0))
/* 286 */             str = "0";
/* 287 */           long longVal = 0L;
/*     */           try {
/* 289 */             longVal = Long.parseLong(str);
/*     */           } catch (Exception e) {
/* 291 */             log.warn("simNum error:" + str, e);
/*     */           }
/* 293 */           this.buffer.putLong(longVal);
/*     */ 
/* 295 */           byte[] activeGprsBytes = new byte[21];
/* 296 */           int endPos = 0;
/* 297 */           str = rtu.getActiveGprs();
/* 298 */           if ((str != null) && (str.length() > 0)) {
/* 299 */             byte[] srcObj = str.getBytes();
/* 300 */             endPos = srcObj.length;
/* 301 */             if (endPos > 21) {
/* 302 */               log.error("activeGprs>21 bytes. which is:" + str);
/* 303 */               endPos = 21;
/*     */             }
/* 305 */             for (j = 0; j < endPos; ++j)
/* 306 */               activeGprsBytes[j] = srcObj[j];
/*     */           }
/* 308 */           for (int j = endPos; j < 21; ++j)
/* 309 */             activeGprsBytes[j] = 0;
/* 310 */           this.buffer.put(activeGprsBytes);
/*     */ 
/* 312 */           longVal = 0L;
/* 313 */           str = rtu.getActiveUms();
/* 314 */           if ((str == null) || (str.length() == 0))
/* 315 */             str = "0";
/*     */           try {
/* 317 */             longVal = Long.parseLong(str);
/*     */           } catch (Exception e) {
/* 319 */             log.warn("activeUms error:" + str, e);
/*     */           }
/* 321 */           this.buffer.putLong(longVal);
/*     */ 
/* 323 */           byte[] subAppIdBytes = new byte[3];
/* 324 */           str = rtu.getActiveSubAppId();
/* 325 */           endPos = 0;
/* 326 */           if ((str != null) && (str.length() > 0)) {
/* 327 */             byte[] srcObj = str.getBytes();
/* 328 */             endPos = srcObj.length;
/* 329 */             if (endPos > 3) {
/* 330 */               log.error("activeSubAppId>3 bytes. which is:" + str);
/* 331 */               endPos = 3;
/*     */             }
/* 333 */             for (int j = 0; j < endPos; ++j)
/* 334 */               subAppIdBytes[j] = srcObj[j];
/*     */           }
/* 336 */           for (int j = endPos; j < subAppIdBytes.length; ++j)
/* 337 */             subAppIdBytes[j] = 0;
/* 338 */           this.buffer.put(subAppIdBytes); }
/*     */       }
/* 340 */       this.buffer.force();
/*     */     }
/* 342 */     list = null;
/*     */   }
/*     */ 
/*     */   class RtuParamCacheThread extends Thread {
/*     */     public RtuParamCacheThread() {
/* 347 */       super("RtuParamCacheThread");
/* 348 */       setDaemon(true);
/* 349 */       start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 353 */       RtuParamsCache.this._state = 1;
/*     */       while (true) try {
/*     */           do {
/* 356 */             synchronized (RtuParamsCache.this.rtuMap) {
/*     */               while (true) { RtuParamsCache.this.rtuMap.wait(2000L);
/* 358 */                 if (RtuParamsCache.this.rtuMap.size() != 0)
/*     */                   break;
/*     */               }
/*     */             }
/* 362 */             long t1 = System.currentTimeMillis();
/* 363 */             RtuParamsCache.this.doSave2Cache();
/* 364 */             if (RtuParamsCache.log.isInfoEnabled()) {
/* 365 */               long t2 = System.currentTimeMillis();
/* 366 */               RtuParamsCache.log.info("save rtu params takes " + (t2 - t1) + " milliseconds"); }
/*     */           }
/* 368 */           while (RtuParamsCache.this._state != 2);
/*     */         }
/*     */         catch (Exception e) {
/*     */           while (true) RtuParamsCache.log.warn(e.getLocalizedMessage(), e);
/*     */         }
/*     */ 
/* 374 */       RtuParamsCache.this._state = 0;
/*     */     }
/*     */   }
/*     */ }