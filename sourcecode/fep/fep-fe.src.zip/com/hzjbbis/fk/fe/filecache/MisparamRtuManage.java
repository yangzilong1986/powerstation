/*     */ package com.hzjbbis.fk.fe.filecache;
/*     */ 
/*     */ import com.hzjbbis.db.batch.dao.jdbc.JdbcBatchDao;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MisparamRtuManage
/*     */ {
/*  24 */   private static final Logger log = Logger.getLogger(MisparamRtuManage.class);
/*     */   private JdbcBatchDao batchDao;
/*  27 */   private Object lock = new Object();
/*  28 */   private static MisparamRtuManage instance = null;
/*     */ 
/*  30 */   private Map<Integer, MisparamRtu> disorders = new HashMap();
/*     */ 
/*     */   public static MisparamRtuManage getInstance()
/*     */   {
/*  35 */     if (instance == null)
/*  36 */       instance = new MisparamRtuManage();
/*  37 */     return instance;
/*     */   }
/*     */ 
/*     */   public void addRtuByGprs(ComRtu rtu, String actGprsAddr) {
/*  41 */     synchronized (this.lock) {
/*  42 */       MisparamRtu param = (MisparamRtu)this.disorders.get(Integer.valueOf(rtu.getRtua()));
/*  43 */       if (param == null) {
/*  44 */         param = new MisparamRtu();
/*  45 */         param.setRtua(rtu.getRtua());
/*  46 */         this.disorders.put(Integer.valueOf(param.getRtua()), param);
/*     */       }
/*  48 */       param.setGprsActiveCommAddr(actGprsAddr);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<MisparamRtu> getAll() {
/*  53 */     return this.disorders.values();
/*     */   }
/*     */ 
/*     */   public MisparamRtu get(int rtua) {
/*  57 */     return ((MisparamRtu)this.disorders.get(Integer.valueOf(rtua)));
/*     */   }
/*     */ 
/*     */   public void remove(int rtua) {
/*  61 */     synchronized (this.disorders) {
/*  62 */       this.disorders.remove(Integer.valueOf(rtua));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addRtuBySms(ComRtu rtu, String actSmsAddr) {
/*  67 */     synchronized (this.lock) {
/*  68 */       MisparamRtu param = (MisparamRtu)this.disorders.get(Integer.valueOf(rtu.getRtua()));
/*  69 */       if (param == null) {
/*  70 */         param = new MisparamRtu();
/*  71 */         param.setRtua(rtu.getRtua());
/*  72 */         this.disorders.put(Integer.valueOf(param.getRtua()), param);
/*     */       }
/*  74 */       param.setSmsActiveCommAddr(actSmsAddr);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean dirty()
/*     */   {
/*  83 */     return (this.disorders.size() <= 0);
/*     */   }
/*     */ 
/*     */   public void save()
/*     */   {
/*  90 */     if (!(dirty())) {
/*  91 */       return;
/*     */     }
/*  93 */     synchronized (this.lock)
/*     */     {
/*  95 */       ArrayList arr = new ArrayList();
/*  96 */       for (MisparamRtu param : this.disorders.values()) {
/*  97 */         if (param.getLastUpdate() != 0L) {
/*     */           continue;
/*     */         }
/*     */ 
/* 101 */         param.setLastUpdate();
/* 102 */         arr.add(param);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void merge2RtuCache()
/*     */   {
/* 115 */     synchronized (this.lock) {
/* 116 */       for (ComRtu rtu : RtuManage.getInstance().getAllComRtu()) {
/* 117 */         MisparamRtu p = (MisparamRtu)this.disorders.get(Integer.valueOf(rtu.getRtua()));
/* 118 */         String actGprs = null; String actUms = null;
/* 119 */         if (p != null) {
/* 120 */           actGprs = p.getGprsActiveCommAddr();
/* 121 */           actUms = p.getSmsActiveCommAddr();
/* 122 */           p.setLastUpdate(0L);
/*     */         }
/*     */ 
/* 125 */         rtu.setMisGprsAddress(actGprs);
/* 126 */         rtu.setMisSmsAddress(actUms);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void merge2RtuCache(Collection<ComRtu> list) {
/* 132 */     synchronized (this.lock) {
/* 133 */       for (ComRtu rtu : list) {
/* 134 */         MisparamRtu p = (MisparamRtu)this.disorders.get(Integer.valueOf(rtu.getRtua()));
/* 135 */         String actGprs = null; String actUms = null;
/* 136 */         if (p != null) {
/* 137 */           actGprs = p.getGprsActiveCommAddr();
/* 138 */           actUms = p.getSmsActiveCommAddr();
/* 139 */           p.setLastUpdate(0L);
/*     */         }
/*     */ 
/* 142 */         rtu.setMisGprsAddress(actGprs);
/* 143 */         rtu.setMisSmsAddress(actUms);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveRtuStatus2Db()
/*     */   {
/* 152 */     log.info("saveRtuStatus2Db start...");
/* 153 */     synchronized (this.lock) {
/* 154 */       merge2RtuCache();
/*     */ 
/* 156 */       RtuManage rm = RtuManage.getInstance();
/* 157 */       List list = null;
/* 158 */       synchronized (rm) {
/* 159 */         list = new ArrayList(rm.getAllComRtu());
/*     */       }
/* 161 */       for (ComRtu rtu : list)
/* 162 */         this.batchDao.add(rtu);
/* 163 */       this.batchDao.batchUpdate();
/*     */     }
/* 165 */     log.info("saveRtuStatus2Db end...");
/*     */   }
/*     */ 
/*     */   public void saveRtuStatus2Db(Collection<ComRtu> list) {
/* 169 */     log.info("saveRtuStatus2Db start...");
/* 170 */     synchronized (this.lock) {
/* 171 */       merge2RtuCache(list);
/*     */ 
/* 173 */       for (ComRtu rtu : list)
/* 174 */         this.batchDao.add(rtu);
/* 175 */       this.batchDao.batchUpdate();
/*     */     }
/* 177 */     log.info("saveRtuStatus2Db end...");
/*     */   }
/*     */ 
/*     */   public void saveRtuStatus2DbPerDay() {
/* 181 */     log.info("saveRtuStatus2DbPerDay start...");
/* 182 */     RtuManage rm = RtuManage.getInstance();
/* 183 */     Collection rtus = null;
/* 184 */     synchronized (rm) {
/* 185 */       rtus = new ArrayList(rm.getAllComRtu());
/*     */     }
/* 187 */     saveRtuStatus2Db(rtus);
/* 188 */     for (ComRtu rtu : rtus) {
/* 189 */       rtu.clearStatus();
/*     */ 
/* 191 */       RtuCommFlowCache.getInstance().addRtu(rtu);
/*     */     }
/*     */ 
/* 194 */     log.info("saveRtuStatus2DbPerDay end...");
/*     */   }
/*     */ 
/*     */   public void setBatchDao(JdbcBatchDao batchDao) {
/* 198 */     this.batchDao = batchDao;
/*     */   }
/*     */ }