/*     */ package com.hzjbbis.fk.fe.filecache;
/*     */ 
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.io.File;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileChannel.MapMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class RtuCommFlowCache
/*     */ {
/*  31 */   private static final Logger log = Logger.getLogger(RtuCommFlowCache.class);
/*  32 */   private static final TraceLog tracer = TraceLog.getTracer(RtuCommFlowCache.class);
/*     */   private static final int STOPPED = 0;
/*     */   private static final int RUNNING = 1;
/*     */   private static final int STOPPING = 2;
/*     */   private static RtuCommFlowCache instance;
/*     */   private static String filePath;
/*     */   private static final int ONE_RTU_CACHE_LEN = 48;
/*  53 */   private int batchSize = 1000;
/*     */ 
/*  55 */   private Map<Integer, ComRtu> rtuMap = new HashMap(1024);
/*  56 */   private int _state = 0;
/*     */ 
/*  58 */   private MappedByteBuffer buffer = null;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  43 */       File file = new File("data");
/*  44 */       file.mkdirs();
/*  45 */       filePath = file.getAbsolutePath() + File.separatorChar + "rtu-flow.data";
/*  46 */       instance = new RtuCommFlowCache();
/*     */     } catch (Exception exp) {
/*  48 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   private RtuCommFlowCache()
/*     */   {
/*  61 */     new RtuCommFlowCacheThread();
/*     */   }
/*     */ 
/*     */   public static final RtuCommFlowCache getInstance() {
/*  65 */     return instance;
/*     */   }
/*     */ 
/*     */   public void initOnStartup()
/*     */   {
/*     */     int i;
/*  72 */     File f = new File(filePath);
/*  73 */     if ((!(f.exists())) || (f.length() == 0L))
/*  74 */       return;
/*  75 */     synchronized (instance) {
/*  76 */       RandomAccessFile raf = null;
/*     */       try {
/*  78 */         raf = new RandomAccessFile(f, "rw");
/*  79 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, f.length());
/*     */       } catch (Exception e) {
/*  81 */         log.error("heartbeat file exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/*  84 */         if (raf != null)
/*     */           try {
/*  86 */             raf.close();
/*  87 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*  92 */     int count = this.buffer.capacity() / 48;
/*     */ 
/*  95 */     boolean checkDataLength = false;
/*  96 */     int pos = 0; int i = -1;
/*  97 */     int failedCount = 0; int successCount = 0;
/*     */ 
/*  99 */     for (int i = 0; i < count; ++i) {
/* 100 */       this.buffer.position(pos);
/* 101 */       i = this.buffer.getInt();
/* 102 */       ComRtu rtuObj = RtuManage.getInstance().getComRtuInCache(i);
/* 103 */       if (rtuObj != null) {
/* 104 */         rtuObj.setFlowSavePosition(pos);
/* 105 */         loadRtuFlowData(rtuObj);
/* 106 */         ++successCount;
/*     */       }
/*     */       else {
/* 109 */         ++failedCount;
/* 110 */         tracer.trace("can not find rtua in db when Rtu Flow init :" + HexDump.toHex(i));
/*     */ 
/* 112 */         rtuObj = new ComRtu();
/* 113 */         rtuObj.setLogicAddress(HexDump.toHex(i));
/* 114 */         rtuObj.setRtua(i);
/* 115 */         rtuObj.setFlowSavePosition(pos);
/* 116 */         loadRtuFlowData(rtuObj);
/* 117 */         RtuManage.getInstance().putComRtuToCache(rtuObj);
/*     */       }
/* 119 */       if (!(checkDataLength)) {
/* 120 */         int dataLen = this.buffer.position() - pos;
/* 121 */         if (dataLen != 48) {
/* 122 */           log.fatal("终端对象读取数据长度与每终端缓存长度不一致. ONE_RTU_CACHE_LEN＝48, readLen=" + dataLen);
/*     */         }
/*     */       }
/* 125 */       pos += 48;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadRtuFlowData(ComRtu rtuObj) {
/* 130 */     rtuObj.setUpGprsFlowmeter(this.buffer.getInt());
/* 131 */     rtuObj.setUpSmsCount(this.buffer.getInt());
/* 132 */     rtuObj.setDownGprsFlowmeter(this.buffer.getInt());
/* 133 */     rtuObj.setDownSmsCount(this.buffer.getInt());
/* 134 */     rtuObj.setUpGprsCount(this.buffer.getInt());
/* 135 */     rtuObj.setDownGprsCount(this.buffer.getInt());
/*     */ 
/* 137 */     rtuObj.setLastGprsTime(this.buffer.getLong());
/* 138 */     rtuObj.setLastSmsTime(this.buffer.getLong());
/* 139 */     rtuObj.setTaskCount(this.buffer.getShort());
/* 140 */     rtuObj.setHeartbeatCount(this.buffer.getShort());
/*     */   }
/*     */ 
/*     */   private void storeRtuFlowData(ComRtu rtu)
/*     */   {
/* 145 */     this.buffer.putInt(rtu.getUpGprsFlowmeter());
/* 146 */     this.buffer.putInt(rtu.getUpSmsCount());
/* 147 */     this.buffer.putInt(rtu.getDownGprsFlowmeter());
/* 148 */     this.buffer.putInt(rtu.getDownSmsCount());
/*     */ 
/* 150 */     this.buffer.putInt(rtu.getUpGprsCount());
/* 151 */     this.buffer.putInt(rtu.getDownGprsCount());
/*     */ 
/* 154 */     this.buffer.putLong(rtu.getLastGprsTime());
/* 155 */     this.buffer.putLong(rtu.getLastSmsTime());
/* 156 */     this.buffer.putShort((short)rtu.getTaskCount());
/* 157 */     this.buffer.putShort((short)rtu.getHeartbeatCount());
/*     */   }
/*     */ 
/*     */   public void addRtu(ComRtu rtu)
/*     */   {
/* 166 */     synchronized (this.rtuMap) {
/* 167 */       this.rtuMap.put(Integer.valueOf(rtu.getRtua()), rtu);
/* 168 */       if (this.rtuMap.size() >= this.batchSize)
/* 169 */         this.rtuMap.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 175 */     if (this._state != 1)
/* 176 */       return;
/* 177 */     this._state = 2;
/* 178 */     if (this.rtuMap.size() > 0) {
/* 179 */       this.rtuMap.notifyAll();
/* 180 */       int cnt = 20;
/*     */ 
/* 182 */       while ((cnt-- > 0) && (this._state != 0))
/*     */         try {
/* 184 */           Thread.sleep(100L);
/*     */         } catch (Exception localException) {
/*     */         }
/*     */     }
/* 188 */     log.info("RtuCommFlowCache disposed, state=" + this._state);
/*     */   }
/*     */ 
/*     */   private void addNewRtu(Collection<ComRtu> rtus)
/*     */   {
/* 196 */     if ((rtus == null) || (rtus.size() == 0)) {
/* 197 */       return;
/*     */     }
/* 199 */     int count = rtus.size();
/* 200 */     int expandLength = count * 48;
/*     */ 
/* 202 */     File f = new File(filePath);
/* 203 */     synchronized (instance) {
/* 204 */       RandomAccessFile raf = null;
/*     */       try {
/* 206 */         raf = new RandomAccessFile(f, "rw");
/* 207 */         int pos0 = (int)raf.length();
/* 208 */         raf.setLength(pos0 + expandLength);
/* 209 */         for (ComRtu rtu : rtus) {
/* 210 */           raf.seek(pos0);
/* 211 */           rtu.setFlowSavePosition(pos0);
/* 212 */           raf.writeInt(rtu.getRtua());
/* 213 */           pos0 += 48;
/*     */         }
/* 215 */         this.buffer = null;
/* 216 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, raf.length());
/*     */       } catch (Exception e) {
/* 218 */         log.warn("addNewRtu exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 221 */         if (raf != null)
/*     */           try {
/* 223 */             raf.close();
/* 224 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doSave2Cache() {
/* 232 */     ArrayList list = null;
/*     */ 
/* 234 */     if (this.rtuMap.size() == 0)
/* 235 */       return;
/* 236 */     synchronized (this.rtuMap) {
/* 237 */       list = new ArrayList(this.rtuMap.values());
/* 238 */       this.rtuMap.clear();
/*     */     }
/*     */ 
/* 241 */     ArrayList newRtuList = new ArrayList();
/* 242 */     Iterator iter = list.iterator();
/* 243 */     while (iter.hasNext()) {
/* 244 */       ComRtu rtu = (ComRtu)iter.next();
/* 245 */       if (rtu.getFlowSavePosition() < 0)
/* 246 */         newRtuList.add(rtu);
/*     */     }
/* 248 */     addNewRtu(newRtuList);
/* 249 */     newRtuList = null;
/*     */ 
/* 252 */     synchronized (instance) {
/* 253 */       iter = list.iterator();
/* 254 */       while (iter.hasNext()) {
/* 255 */         ComRtu rtu = (ComRtu)iter.next();
/* 256 */         this.buffer.position(rtu.getFlowSavePosition());
/* 257 */         int rtua = this.buffer.getInt();
/* 258 */         if (rtua != rtu.getRtua()) {
/* 259 */           log.warn("终端RTUA定位不一致：" + HexDump.toHex(rtua));
/*     */         }
/*     */         else
/* 262 */           storeRtuFlowData(rtu);
/*     */       }
/* 264 */       this.buffer.force();
/*     */     }
/* 266 */     list = null;
/*     */   }
/*     */ 
/*     */   class RtuCommFlowCacheThread extends Thread {
/*     */     public RtuCommFlowCacheThread() {
/* 271 */       super("rtuCommFlowCacheThread");
/* 272 */       setDaemon(true);
/* 273 */       start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 277 */       RtuCommFlowCache.this._state = 1;
/*     */       while (true) try {
/*     */           do {
/* 280 */             synchronized (RtuCommFlowCache.this.rtuMap) {
/*     */               while (true) { RtuCommFlowCache.this.rtuMap.wait(60000L);
/* 282 */                 if (RtuCommFlowCache.this.rtuMap.size() != 0)
/*     */                   break;
/*     */               }
/*     */             }
/* 286 */             long t1 = System.currentTimeMillis();
/* 287 */             RtuCommFlowCache.this.doSave2Cache();
/* 288 */             if (RtuCommFlowCache.log.isInfoEnabled()) {
/* 289 */               long t2 = System.currentTimeMillis();
/* 290 */               RtuCommFlowCache.log.info("save rtu params takes " + (t2 - t1) + " milliseconds"); }
/*     */           }
/* 292 */           while (RtuCommFlowCache.this._state != 2);
/*     */         }
/*     */         catch (Exception e) {
/*     */           while (true) RtuCommFlowCache.log.warn(e.getLocalizedMessage(), e);
/*     */         }
/*     */ 
/* 298 */       RtuCommFlowCache.this._state = 0;
/*     */     }
/*     */   }
/*     */ }