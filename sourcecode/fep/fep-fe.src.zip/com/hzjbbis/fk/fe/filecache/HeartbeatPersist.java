/*     */ package com.hzjbbis.fk.fe.filecache;
/*     */ 
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.io.File;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileChannel.MapMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class HeartbeatPersist
/*     */ {
/*  43 */   private static final Logger log = Logger.getLogger(HeartbeatPersist.class);
/*  44 */   private static final TraceLog trace = TraceLog.getTracer(HeartbeatPersist.class);
/*  45 */   private static HeartbeatPersist instance = null;
/*     */   private static final int STOPPED = 0;
/*     */   private static final int RUNNING = 1;
/*     */   private static final int STOPPING = 2;
/*     */   private static final int ONE_RTU_CACHE_LEN = 40;
/*  50 */   private static final byte[] EMPTY_HEARTS = new byte[36];
/*     */   private static String rootPath;
/*  52 */   private Map<Integer, Integer> mapRtuPosition = new HashMap();
/*     */ 
/*  66 */   private int batchSize = 1000;
/*     */ 
/*  68 */   private String filePath = null;
/*  69 */   private MappedByteBuffer buffer = null;
/*  70 */   private final LinkedList<HeartbeatInfo> heartList = new LinkedList();
/*     */ 
/*  73 */   private int _state = 0;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  57 */       File file = new File("data");
/*  58 */       file.mkdirs();
/*  59 */       rootPath = file.getAbsolutePath() + File.separatorChar;
/*  60 */       instance = new HeartbeatPersist();
/*     */     } catch (Exception exp) {
/*  62 */       trace.trace(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   private HeartbeatPersist()
/*     */   {
/*  76 */     new HeartbeatHandleThread();
/*  77 */     for (int i = 0; i < EMPTY_HEARTS.length; ++i)
/*  78 */       EMPTY_HEARTS[i] = 0;
/*     */   }
/*     */ 
/*     */   public static final HeartbeatPersist getInstance()
/*     */   {
/*  83 */     return instance;
/*     */   }
/*     */ 
/*     */   public void handleHeartbeat(int rtua)
/*     */   {
/* 100 */     HeartbeatInfo hi = new HeartbeatInfo();
/* 101 */     hi.rtua = rtua;
/* 102 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(hi.rtua);
/* 103 */     if ((this.mapRtuPosition.get(Integer.valueOf(hi.rtua)) != null) && (rtu.getHeartSavePosition() > 0) && 
/* 104 */       (((Integer)this.mapRtuPosition.get(Integer.valueOf(hi.rtua))).intValue() != rtu.getHeartSavePosition()))
/* 105 */       trace.trace("心跳打点时rtu：" + HexDump.toHex(hi.rtua) + 
/* 106 */         "保存位置和map不对应 map上pos:" + this.mapRtuPosition.get(Integer.valueOf(rtu.getRtua())) + 
/* 107 */         "rtu缓存地址：" + rtu.getHeartSavePosition());
/* 108 */     synchronized (this.heartList) {
/* 109 */       this.heartList.addLast(hi);
/* 110 */       if (this.heartList.size() >= this.batchSize)
/* 111 */         this.heartList.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void handleHeartbeat(int rtua, long time) {
/* 116 */     HeartbeatInfo hi = new HeartbeatInfo();
/* 117 */     hi.rtua = rtua;
/* 118 */     hi.time = time;
/* 119 */     synchronized (this.heartList) {
/* 120 */       this.heartList.addLast(hi);
/* 121 */       if (this.heartList.size() >= this.batchSize)
/* 122 */         this.heartList.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initOnStartup()
/*     */   {
/*     */     int i;
/* 130 */     trace.trace("心跳初始化initOnStartup");
/* 131 */     Calendar cl = Calendar.getInstance();
/* 132 */     cl.setTimeInMillis(System.currentTimeMillis());
/* 133 */     int dayOfMonth = cl.get(5);
/* 134 */     this.filePath = rootPath + "heartbeat-" + dayOfMonth + ".data";
/* 135 */     File f = new File(this.filePath);
/* 136 */     if ((!(f.exists())) || (f.length() == 0L))
/*     */     {
/* 138 */       trace.trace("心跳" + this.filePath + "文件不存在,初始化结束");
/* 139 */       return;
/*     */     }
/* 141 */     synchronized (instance) {
/* 142 */       RandomAccessFile raf = null;
/*     */       try {
/* 144 */         raf = new RandomAccessFile(f, "rw");
/* 145 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, f.length());
/*     */       } catch (Exception e) {
/* 147 */         trace.trace("heartbeat file exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 150 */         if (raf != null)
/*     */           try {
/* 152 */             raf.close();
/* 153 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/* 158 */     if (this.buffer == null)
/* 159 */       return;
/* 160 */     int count = this.buffer.capacity() / 40;
/* 161 */     int pos = 0; int rtua = -1;
/* 162 */     for (int i = 0; i < count; ++i) {
/* 163 */       rtua = this.buffer.getInt(pos);
/* 164 */       ComRtu rtuObj = RtuManage.getInstance().getComRtuInCache(rtua);
/* 165 */       if (rtuObj != null)
/* 166 */         rtuObj.setHeartSavePosition(pos);
/* 167 */       pos += 40;
/*     */     }
/* 169 */     trace.trace("心跳初始化initOnStartup 跑完结束");
/*     */   }
/*     */ 
/*     */   public void dispose() {
/* 173 */     if (this._state != 1)
/* 174 */       return;
/* 175 */     this._state = 2;
/* 176 */     synchronized (this.heartList) {
/* 177 */       if (this.heartList.size() > 0) {
/* 178 */         this.heartList.notifyAll();
/* 179 */         int cnt = 10;
/* 180 */         break label54:
/*     */         do {
/*     */           try { Thread.sleep(100L);
/*     */           }
/*     */           catch (Exception localException)
/*     */           {
/*     */           }
/* 180 */           label54: if (cnt-- <= 0) break;  }
/* 180 */         while (this._state != 0);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initPerDay()
/*     */   {
/* 193 */     Calendar cl = Calendar.getInstance();
/* 194 */     cl.setTimeInMillis(System.currentTimeMillis());
/* 195 */     int dayOfMonth = cl.get(5);
/*     */ 
/* 197 */     trace.trace(dayOfMonth + "号初始化");
/*     */ 
/* 199 */     this.filePath = rootPath + "heartbeat-" + dayOfMonth + ".data";
/* 200 */     File f = new File(this.filePath);
/*     */ 
/* 202 */     if (f.exists()) {
/* 203 */       trace.trace(this.filePath + "已存在");
/* 204 */       f.delete();
/* 205 */       this.buffer = null;
/*     */     }
/*     */     else {
/* 208 */       trace.trace(this.filePath + "不存在"); }
/* 209 */     synchronized (instance) {
/* 210 */       RandomAccessFile raf = null;
/*     */       try
/*     */       {
/*     */         ComRtu rtu;
/* 212 */         raf = new RandomAccessFile(f, "rw");
/* 213 */         List rtus = new ArrayList(RtuManage.getInstance().getAllComRtu());
/* 214 */         trace.trace("心跳每天初始化rtu队列大小：" + rtus.size());
/* 215 */         int maxPos = 0;
/* 216 */         for (Iterator localIterator = rtus.iterator(); localIterator.hasNext(); ) { rtu = (ComRtu)localIterator.next();
/* 217 */           if (rtu.getHeartSavePosition() > maxPos)
/* 218 */             maxPos = rtu.getHeartSavePosition();
/*     */         }
/* 220 */         raf.setLength(maxPos + 40);
/* 221 */         if (this.buffer != null) {
/* 222 */           this.buffer.force();
/* 223 */           this.buffer = null;
/*     */         }
/* 225 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, raf.length());
/* 226 */         for (localIterator = rtus.iterator(); localIterator.hasNext(); ) { rtu = (ComRtu)localIterator.next();
/* 227 */           if ((this.mapRtuPosition.get(Integer.valueOf(rtu.getRtua())) != null) && (rtu.getHeartSavePosition() > 0) && 
/* 228 */             (((Integer)this.mapRtuPosition.get(Integer.valueOf(rtu.getRtua()))).intValue() != rtu.getHeartSavePosition()))
/* 229 */             trace.trace("心跳每天初始化rtu:" + HexDump.toHex(rtu.getRtua()) + 
/* 230 */               "位置发生错误 map上pos:" + this.mapRtuPosition.get(Integer.valueOf(rtu.getRtua())) + 
/* 231 */               "rtu缓存地址：" + rtu.getHeartSavePosition());
/* 232 */           if (rtu.getHeartSavePosition() >= 0) {
/* 233 */             this.buffer.position(rtu.getHeartSavePosition());
/* 234 */             this.buffer.putInt(rtu.getRtua());
/* 235 */             this.buffer.put(EMPTY_HEARTS);
/*     */           }
/*     */         }
/* 238 */         this.buffer.force();
/*     */       } catch (Exception e) {
/* 240 */         trace.trace("heartbeat file exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 243 */         if (raf != null)
/*     */           try {
/* 245 */             raf.close();
/* 246 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String heartbeatInfo2String(byte[] heartBits) {
/* 254 */     StringBuilder sb = new StringBuilder();
/*     */     try
/*     */     {
/* 257 */       int minute = 0; int hour = 0; int totalMinutes = 0;
/* 258 */       for (int i = 0; i < heartBits.length; ++i) {
/* 259 */         byte b = heartBits[i];
/* 260 */         int sum = 0;
/* 261 */         for (int j = 7; j >= 0; --j) {
/* 262 */           int result = (j != 0) ? 1 << j & b : b & 0x1;
/* 263 */           if (result != 0) {
/* 264 */             sum = totalMinutes + 5 * (7 - j);
/* 265 */             hour = sum / 60;
/* 266 */             minute = sum % 60;
/* 267 */             sb.append(hour).append(":").append(minute).append("; ");
/*     */           }
/*     */         }
/* 270 */         totalMinutes += 40;
/*     */       }
/*     */     } catch (Exception e) {
/* 273 */       trace.trace(e.getLocalizedMessage(), e);
/* 274 */       sb.append("exception:").append(e.getLocalizedMessage());
/*     */     }
/* 276 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String queryHeartbeatInfo(int rtua) {
/* 280 */     ComRtu rtu = RtuManage.getInstance().getComRtuInCache(rtua);
/* 281 */     if ((rtu == null) || (rtu.getHeartSavePosition() < 0))
/* 282 */       return "no rtu";
/* 283 */     int pos = rtu.getHeartSavePosition() + 4;
/* 284 */     byte[] heartBits = new byte[36];
/* 285 */     this.buffer.position(pos);
/* 286 */     this.buffer.get(heartBits);
/* 287 */     return heartbeatInfo2String(heartBits);
/*     */   }
/*     */ 
/*     */   public String queryHeartbeatInfo(int rtua, int dayOfMonth) {
/* 291 */     this.filePath = rootPath + "heartbeat-" + dayOfMonth + ".data";
/* 292 */     File f = new File(this.filePath);
/* 293 */     if ((!(f.exists())) || (f.length() == 0L)) {
/* 294 */       return "file not exist:" + this.filePath;
/*     */     }
/* 296 */     String result = "rtu not found in that day";
/* 297 */     RandomAccessFile raf = null;
/*     */     try {
/* 299 */       raf = new RandomAccessFile(f, "rw");
/* 300 */       MappedByteBuffer buf = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, raf.length());
/*     */ 
/* 302 */       int end = buf.capacity() - 40;
/* 303 */       for (int pos = 0; pos < end; pos += 40) {
/* 304 */         if (buf.getInt(pos) == rtua) {
/* 305 */           buf.position(pos + 4);
/* 306 */           byte[] heartBits = new byte[36];
/* 307 */           buf.get(heartBits);
/* 308 */           result = heartbeatInfo2String(heartBits);
/* 309 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 313 */       buf = null;
/*     */     } catch (Exception e) {
/* 315 */       result = "heartbeat file exception:" + e.getLocalizedMessage();
/* 316 */       trace.trace(result, e);
/*     */     }
/*     */     finally {
/* 319 */       if (raf != null)
/*     */         try {
/* 321 */           raf.close();
/* 322 */           raf = null;
/*     */         } catch (Exception localException2) {
/*     */         }
/*     */     }
/* 326 */     return result;
/*     */   }
/*     */ 
/*     */   private void addNewRtu2File(Collection<ComRtu> rtus)
/*     */   {
/* 334 */     if ((rtus == null) || (rtus.size() == 0)) {
/* 335 */       return;
/*     */     }
/* 337 */     trace.trace("有新的rtu:" + rtus.size());
/* 338 */     int count = rtus.size();
/* 339 */     int expandLength = count * 40;
/*     */ 
/* 341 */     File f = new File(this.filePath);
/* 342 */     synchronized (instance) {
/* 343 */       RandomAccessFile raf = null;
/*     */       try {
/* 345 */         raf = new RandomAccessFile(f, "rw");
/* 346 */         int pos0 = (int)raf.length();
/* 347 */         raf.setLength(pos0 + expandLength);
/* 348 */         for (ComRtu rtu : rtus) {
/* 349 */           raf.seek(pos0);
/* 350 */           rtu.setHeartSavePosition(pos0);
/* 351 */           raf.writeInt(rtu.getRtua());
/* 352 */           raf.write(EMPTY_HEARTS);
/* 353 */           this.mapRtuPosition.put(Integer.valueOf(rtu.getRtua()), Integer.valueOf(rtu.getHeartSavePosition()));
/* 354 */           trace.trace("rtu:" + HexDump.toHex(rtu.getRtua()) + " pos:" + pos0);
/* 355 */           pos0 += 40;
/*     */         }
/* 357 */         this.buffer = null;
/* 358 */         this.buffer = raf.getChannel().map(FileChannel.MapMode.READ_WRITE, 0L, raf.length());
/*     */       } catch (Exception e) {
/* 360 */         trace.trace("addMoreRtu2File exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 363 */         if (raf != null)
/*     */           try {
/* 365 */             raf.close();
/* 366 */             raf = null;
/*     */           } catch (Exception localException2) {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processHeartInfoList() {
/* 374 */     Map uniqRtus = new HashMap();
/* 375 */     ArrayList list = null;
/* 376 */     if (this.heartList.size() == 0)
/* 377 */       return;
/* 378 */     synchronized (this.heartList) {
/* 379 */       list = new ArrayList(this.heartList);
/* 380 */       this.heartList.clear();
/*     */     }
/* 382 */     trace.trace("处理心跳，队列长度size：" + list.size());
/* 383 */     Iterator iter = list.iterator();
/* 384 */     while (iter.hasNext()) {
/* 385 */       HeartbeatInfo hi = (HeartbeatInfo)iter.next();
/* 386 */       ComRtu rtu = RtuManage.getInstance().getComRtuInCache(hi.rtua);
/* 387 */       if (rtu == null) {
/* 388 */         iter.remove();
/*     */       }
/* 391 */       else if (rtu.getHeartSavePosition() < 0) {
/* 392 */         uniqRtus.put(Integer.valueOf(rtu.getRtua()), rtu);
/*     */       }
/*     */     }
/* 395 */     addNewRtu2File(uniqRtus.values());
/* 396 */     uniqRtus = null;
/*     */ 
/* 398 */     iter = list.iterator();
/* 399 */     synchronized (instance) {
/* 400 */       while (iter.hasNext()) {
/* 401 */         HeartbeatInfo hi = (HeartbeatInfo)iter.next();
/* 402 */         ComRtu rtu = RtuManage.getInstance().getComRtuInCache(hi.rtua);
/* 403 */         int rtua = this.buffer.getInt(rtu.getHeartSavePosition());
/* 404 */         if (rtua != rtu.getRtua()) {
/* 405 */           trace.trace("终端RTUA定位不一致：" + HexDump.toHex(rtua));
/*     */         }
/*     */         else
/*     */         {
/* 409 */           Calendar cl = Calendar.getInstance();
/* 410 */           cl.setTimeInMillis(hi.time);
/* 411 */           int hour = cl.get(11);
/* 412 */           int minute = cl.get(12);
/* 413 */           int quotient = minute / 5;
/* 414 */           int bitPos = hour * 12 + quotient;
/* 415 */           int delta = minute % 5;
/*     */ 
/* 418 */           quotient = bitPos / 8;
/* 419 */           delta = 7 - (bitPos % 8);
/* 420 */           byte b = 1;
/* 421 */           if (delta > 0)
/* 422 */             b = (byte)(b << delta);
/* 423 */           int pos = rtu.getHeartSavePosition() + 4 + quotient;
/* 424 */           this.buffer.put(pos, (byte)(this.buffer.get(pos) | b)); }
/*     */       }
/* 426 */       this.buffer.force();
/*     */     }
/* 428 */     list = null;
/*     */   }
/*     */ 
/*     */   public final void setBatchSize(int batchSize)
/*     */   {
/* 470 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */   class HeartbeatHandleThread extends Thread
/*     */   {
/*     */     public HeartbeatHandleThread()
/*     */     {
/* 438 */       super("HeartbeatHandle");
/* 439 */       setDaemon(true);
/* 440 */       start();
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 445 */       HeartbeatPersist.this._state = 1;
/*     */       while (true) try {
/*     */           do {
/* 448 */             synchronized (HeartbeatPersist.this.heartList) {
/*     */               while (true) { HeartbeatPersist.this.heartList.wait(60000L);
/* 450 */                 if (HeartbeatPersist.this.heartList.size() != 0) break;
/*     */               }
/*     */             }
/* 453 */             long t1 = System.currentTimeMillis();
/* 454 */             HeartbeatPersist.this.processHeartInfoList();
/* 455 */             if (HeartbeatPersist.log.isDebugEnabled()) {
/* 456 */               long t2 = System.currentTimeMillis();
/* 457 */               HeartbeatPersist.trace.trace("save heartbeat takes " + (t2 - t1) + " milliseconds"); }
/*     */           }
/* 459 */           while (HeartbeatPersist.this._state != 2);
/*     */         }
/*     */         catch (Exception e) {
/*     */           while (true) HeartbeatPersist.trace.trace(e.getLocalizedMessage(), e);
/*     */         }
/*     */ 
/* 465 */       HeartbeatPersist.this._state = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   class HeartbeatInfo
/*     */   {
/*     */     public int rtua;
/*     */     public long time;
/*     */ 
/*     */     HeartbeatInfo()
/*     */     {
/* 432 */       this.rtua = 0;
/* 433 */       this.time = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ }