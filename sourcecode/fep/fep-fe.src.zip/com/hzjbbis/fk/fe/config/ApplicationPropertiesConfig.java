/*     */ package com.hzjbbis.fk.fe.config;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.clientmod.ClientModule;
/*     */ import com.hzjbbis.fk.common.events.BasicEventHook;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseSocketServer;
/*     */ import com.hzjbbis.fk.fe.ChannelManage;
/*     */ import com.hzjbbis.fk.fe.fiber.FiberManage;
/*     */ import com.hzjbbis.fk.fe.gprs.GateMessageEventHandler;
/*     */ import com.hzjbbis.fk.fe.ums.SmsMessageEventHandler;
/*     */ import com.hzjbbis.fk.fe.ums.UmsModule;
/*     */ import com.hzjbbis.fk.fe.ums.protocol.UmsCommands;
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.message.gate.MessageGateCreator;
/*     */ import com.hzjbbis.fk.sockserver.TcpSocketServer;
/*     */ import com.hzjbbis.fk.sockserver.io.SimpleIoHandler;
/*     */ import com.hzjbbis.fk.utils.ApplicationContextUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ApplicationPropertiesConfig
/*     */ {
/*  41 */   private static final Logger log = Logger.getLogger(ApplicationPropertiesConfig.class);
/*  42 */   private static final ApplicationPropertiesConfig config = new ApplicationPropertiesConfig();
/*     */ 
/*  45 */   private int bufLength = 10240;
/*  46 */   private int timeout = 2;
/*  47 */   private int heartInterval = 10;
/*  48 */   private int requestNum = 500;
/*     */   private String umsServerAddr;
/*  52 */   private int umsSendSpeed = 1000;
/*  53 */   private int sendUserLimit = 10;
/*  54 */   private int sendRtuLimit = 50;
/*  55 */   private int retrieveMsgLimit = 30;
/*  56 */   private long noUpLogAlertTime = 1800000L;
/*  57 */   private String noUpAlertMobiles = "";
/*  58 */   private String noUpAlertContent = "警告：30分钟没有收到短信上行";
/*  59 */   private long sleepInterval = 10000L;
/*  60 */   private String umsProtocolId = "ums.protocol";
/*     */   private String gprsGateClients;
/*     */   private String smsGateClients;
/*     */   private String bpServer;
/*     */   private String monitorServer;
/*     */   private GateMessageEventHandler gprsMessageEventHandler;
/*  68 */   private String gprsMessageEventHandlerId = "fe.event.handle.gprs";
/*     */   private SmsMessageEventHandler smsMessageEventHandler;
/*  70 */   private String smsMessageEventHandlerId = "fe.event.handle.ums";
/*     */   private BasicEventHook bpMessageEventHandler;
/*     */   private BasicEventHook monitorEventHandler;
/*  72 */   private String bpMessageEventHandlerId = "bpserver.event.hook";
/*  73 */   private String monitorEventHandlerId = "monitor.event.handler";
/*  74 */   private String monitorMessageCreator = "messageCreator.Monitor";
/*     */ 
/*  76 */   private List<ClientModule> gprsClientModules = new ArrayList();
/*  77 */   private List<UmsModule> umsClientModules = new ArrayList();
/*  78 */   private List<BaseSocketServer> socketServers = new ArrayList();
/*  79 */   private List<BasicEventHook> eventHandlers = new ArrayList();
/*     */ 
/*     */   public static final ApplicationPropertiesConfig getInstance()
/*     */   {
/*  89 */     return config;
/*     */   }
/*     */ 
/*     */   public void setGprsGateClients(String gprsClients) {
/*  93 */     this.gprsGateClients = gprsClients.trim();
/*     */   }
/*     */ 
/*     */   public boolean addGprsGates(String clientsUrl) {
/*  97 */     List gateClients = createGprsGateClients(clientsUrl);
/*  98 */     boolean result = false;
/*  99 */     for (ClientModule gate : gateClients) {
/* 100 */       gate.init();
/* 101 */       ChannelManage.getInstance().addGprsClient(gate);
/* 102 */       FasSystem.getFasSystem().addModule(gate);
/* 103 */       gate.start();
/* 104 */       result = true;
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean addGprsGate(String hostIp, int port, String gateName) {
/* 110 */     String url = hostIp + ":" + port;
/* 111 */     if ((gateName != null) && (gateName.length() >= 1)) {
/* 112 */       url = url + "?name=" + gateName;
/*     */     }
/* 114 */     return addGprsGates(url);
/*     */   }
/*     */ 
/*     */   public List<ClientModule> createGprsGateClients(String clientsUrl)
/*     */   {
/* 119 */     List clients = new ArrayList();
/*     */ 
/* 121 */     if ((clientsUrl == null) || (clientsUrl.length() < 2)) {
/* 122 */       return clients;
/*     */     }
/* 124 */     String[] urls = clientsUrl.split(";");
/* 125 */     label606: for (String url : urls) {
/* 126 */       Map result = parseUrlConfig(url);
/* 127 */       String ip = null; String param = null; String gateIpPostFix = null;
/* 128 */       int port = 0;
/*     */       try {
/* 130 */         ip = (String)result.get("ip");
/* 131 */         int index = ip.lastIndexOf(".");
/* 132 */         if (index > 0) {
/* 133 */           gateIpPostFix = ip.substring(index + 1);
/*     */         }
/*     */         else {
/* 136 */           gateIpPostFix = ip;
/*     */         }
/* 138 */         param = (String)result.get("port");
/* 139 */         if (param == null) {
/* 140 */           log.error("TCP Socket Server config miss port");
/* 141 */           break label606:
/*     */         }
/* 143 */         port = Integer.parseInt(param);
/*     */       } catch (Exception e) {
/* 145 */         log.error("gprs client config exception,port=" + param, e);
/* 146 */         break label606:
/*     */       }
/*     */ 
/* 149 */       ClientModule gprsClient = new ClientModule();
/* 150 */       gprsClient.setModuleType("gprsClient");
/* 151 */       gprsClient.setHostIp(ip);
/* 152 */       gprsClient.setHostPort(port);
/*     */ 
/* 155 */       param = (String)result.get("name");
/* 156 */       if (param == null) {
/* 157 */         param = "gprs-" + gateIpPostFix;
/*     */       }
/* 159 */       gprsClient.setName(param);
/*     */ 
/* 161 */       param = (String)result.get("bufLength");
/* 162 */       if (param != null) {
/*     */         try {
/* 164 */           this.bufLength = Integer.parseInt(param);
/*     */         } catch (Exception e) {
/* 166 */           log.error("bufLength config err:" + param);
/*     */         }
/*     */       }
/* 169 */       gprsClient.setBufLength(this.bufLength);
/*     */ 
/* 171 */       IMessageCreator messageCreator = new MessageGateCreator();
/* 172 */       param = (String)result.get("messageCreator");
/* 173 */       if (param != null)
/*     */       {
/* 175 */         IMessageCreator mc = (IMessageCreator)ApplicationContextUtil.getBean(param);
/* 176 */         if (mc == null)
/*     */           try {
/* 178 */             Class clz = Class.forName(param);
/* 179 */             mc = (IMessageCreator)clz.newInstance();
/*     */           } catch (Exception localException1) {
/*     */           }
/* 182 */         if (mc != null) {
/* 183 */           messageCreator = mc;
/*     */         }
/*     */       }
/* 186 */       gprsClient.setMessageCreator(messageCreator);
/*     */ 
/* 188 */       param = (String)result.get("txfs");
/* 189 */       if (param != null)
/* 190 */         gprsClient.setTxfs(param);
/*     */       else {
/* 192 */         gprsClient.setTxfs("02");
/*     */       }
/* 194 */       param = (String)result.get("timeout");
/* 195 */       if (param != null)
/*     */         try {
/* 197 */           this.timeout = Integer.parseInt(param);
/*     */         } catch (Exception localException2) {
/*     */         }
/* 200 */       gprsClient.setTimeout(this.timeout);
/*     */ 
/* 202 */       if (this.gprsMessageEventHandler == null)
/* 203 */         this.gprsMessageEventHandler = ((GateMessageEventHandler)ApplicationContextUtil.getBean(this.gprsMessageEventHandlerId));
/* 204 */       if (this.gprsMessageEventHandler == null) {
/* 205 */         log.error("gprsMessageEventHandler == null.");
/* 206 */         return clients;
/*     */       }
/* 208 */       gprsClient.setEventHandler(this.gprsMessageEventHandler);
/*     */ 
/* 210 */       param = (String)result.get("heartInterval");
/* 211 */       if (param != null)
/*     */         try {
/* 213 */           this.heartInterval = Integer.parseInt(param);
/*     */         } catch (Exception localException3) {
/*     */         }
/* 216 */       gprsClient.setHeartInterval(this.heartInterval);
/*     */ 
/* 219 */       gprsClient.setRequestNum(this.requestNum);
/*     */ 
/* 221 */       clients.add(gprsClient);
/*     */     }
/* 223 */     return clients;
/*     */   }
/*     */ 
/*     */   private void parseGprsGateClients() {
/* 227 */     this.gprsClientModules.addAll(createGprsGateClients(this.gprsGateClients));
/*     */   }
/*     */ 
/*     */   public void setSmsGateClients(String smsGateClients) {
/* 231 */     this.smsGateClients = smsGateClients.trim();
/*     */   }
/*     */ 
/*     */   public boolean addUmsClients(String clientsUrl) {
/* 235 */     List clients = createSmsGateClients(clientsUrl);
/* 236 */     boolean result = false;
/* 237 */     for (UmsModule ums : clients) {
/* 238 */       ChannelManage.getInstance().addUmsClient(ums);
/* 239 */       FiberManage.getInstance().schedule(ums);
/* 240 */       FasSystem.getFasSystem().addModule(ums);
/* 241 */       ums.start();
/* 242 */       result = true;
/*     */     }
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean addUmsClient(String appid, String pwd) {
/* 248 */     return addUmsClients(appid + ":" + pwd);
/*     */   }
/*     */ 
/*     */   private List<UmsModule> createSmsGateClients(String clientsUrl)
/*     */   {
/* 253 */     List clients = new ArrayList();
/* 254 */     if ((clientsUrl == null) || (clientsUrl.length() < 2)) {
/* 255 */       return clients;
/*     */     }
/*     */ 
/* 258 */     if ((this.umsServerAddr == null) || (this.umsServerAddr.length() < 5)) {
/* 259 */       log.error("UMS服务器IP:PORT没有定义");
/* 260 */       return clients;
/*     */     }
/* 262 */     int index = this.umsServerAddr.indexOf(":");
/* 263 */     if (index <= 0) {
/* 264 */       log.error("ums服务器地址错误=" + this.umsServerAddr);
/* 265 */       return clients;
/*     */     }
/*     */ 
/* 268 */     String hostIp = this.umsServerAddr.substring(0, index).trim();
/* 269 */     String hostPort = this.umsServerAddr.substring(index + 1).trim();
/* 270 */     int port = 0;
/*     */     try {
/* 272 */       port = Integer.parseInt(hostPort);
/*     */     } catch (Exception e) {
/* 274 */       log.error("hostPort=" + hostPort);
/* 275 */       return clients;
/*     */     }
/*     */ 
/* 278 */     String[] urls = clientsUrl.split(";");
/* 279 */     for (String url : urls) {
/* 280 */       Map result = parseUrlConfig(url);
/* 281 */       String appid = null; String password = null;
/* 282 */       appid = (String)result.get("ip");
/* 283 */       password = (String)result.get("port");
/* 284 */       if (appid == null) {
/* 285 */         appid = password;
/*     */       }
/*     */ 
/* 288 */       UmsModule umsClient = new UmsModule();
/* 289 */       umsClient.setHostIp(hostIp);
/* 290 */       umsClient.setHostPort(port);
/* 291 */       umsClient.setAppid(appid);
/* 292 */       umsClient.setApppwd(password);
/* 293 */       umsClient.setFiber(true);
/*     */ 
/* 295 */       umsClient.setName("ums-" + appid);
/* 296 */       umsClient.setReply("95598" + appid);
/*     */ 
/* 298 */       String param = (String)result.get("umsProtocol");
/* 299 */       if (param == null) {
/* 300 */         param = this.umsProtocolId;
/*     */       }
/*     */ 
/* 303 */       UmsCommands umsProto = null;
/*     */       try {
/* 305 */         umsProto = (UmsCommands)ApplicationContextUtil.getBean(param);
/* 306 */         if (umsProto == null) {
/* 307 */           Class clz = Class.forName(param);
/* 308 */           umsProto = (UmsCommands)clz.newInstance();
/*     */         }
/*     */       } catch (Exception e) {
/* 311 */         log.error("appid=" + appid + ",channel's umsProtocol error:" + param);
/* 312 */         return clients;
/*     */       }
/* 314 */       umsClient.setUmsProtocol(umsProto);
/*     */ 
/* 316 */       param = (String)result.get("txfs");
/* 317 */       if (param != null) {
/* 318 */         umsClient.setTxfs(param);
/*     */       }
/* 320 */       if (this.smsMessageEventHandler == null)
/* 321 */         this.smsMessageEventHandler = ((SmsMessageEventHandler)ApplicationContextUtil.getBean(this.smsMessageEventHandlerId));
/* 322 */       if (this.smsMessageEventHandler == null) {
/* 323 */         log.error("smsMessageEventHandler == null.");
/* 324 */         return clients;
/*     */       }
/* 326 */       umsClient.setEventHandler(this.smsMessageEventHandler);
/*     */ 
/* 329 */       umsClient.setUmsSendSpeed(this.umsSendSpeed);
/* 330 */       umsClient.setSendUserLimit(this.sendUserLimit);
/* 331 */       umsClient.setSendRtuLimit(this.sendRtuLimit);
/* 332 */       umsClient.setRetrieveMsgLimit(this.retrieveMsgLimit);
/* 333 */       umsClient.setNoUpLogAlertTime(this.noUpLogAlertTime);
/* 334 */       umsClient.setSleepInterval(this.sleepInterval);
/* 335 */       if ((this.noUpAlertMobiles != null) && (this.noUpAlertMobiles.length() > 0)) {
/* 336 */         List mobiles = new ArrayList();
/* 337 */         String[] mbs = this.noUpAlertMobiles.split(";");
/* 338 */         for (String m : mbs)
/* 339 */           mobiles.add(m.trim());
/* 340 */         umsClient.setSimNoList(mobiles);
/*     */       }
/*     */ 
/* 343 */       umsClient.setAlertContent("UMS Channel:" + appid + ". " + this.noUpAlertContent);
/* 344 */       clients.add(umsClient);
/*     */     }
/* 346 */     return clients;
/*     */   }
/*     */ 
/*     */   private void parseSmsGateClients() {
/* 350 */     this.umsClientModules.addAll(createSmsGateClients(this.smsGateClients));
/*     */   }
/*     */ 
/*     */   public void setBpServer(String bpServers) {
/* 354 */     this.bpServer = bpServers.trim();
/*     */   }
/*     */ 
/*     */   private void parseBpServer()
/*     */   {
/* 359 */     Map result = parseUrlConfig(this.bpServer);
/* 360 */     int port = 0; int bufLength = 10240;
/* 361 */     String param = null;
/*     */     try {
/* 363 */       param = (String)result.get("port");
/* 364 */       if (param == null) {
/* 365 */         log.error("Business Processor TCP Socket Server config miss port");
/* 366 */         return;
/*     */       }
/* 368 */       port = Integer.parseInt(param);
/*     */     } catch (Exception e) {
/* 370 */       log.error("Business Processor TCP Socket Server config exception,port=" + param, e);
/* 371 */       return;
/*     */     }
/*     */ 
/* 374 */     TcpSocketServer socketServer = new TcpSocketServer();
/* 375 */     socketServer.setPort(port);
/* 376 */     param = (String)result.get("ip");
/* 377 */     if (param != null) {
/* 378 */       socketServer.setIp(param);
/*     */     }
/* 380 */     param = (String)result.get("name");
/* 381 */     if (param == null) {
/* 382 */       param = "bp-" + port;
/*     */     }
/* 384 */     socketServer.setName(param);
/*     */ 
/* 386 */     param = (String)result.get("bufLength");
/* 387 */     if (param != null) {
/*     */       try {
/* 389 */         bufLength = Integer.parseInt(param);
/*     */       } catch (Exception e) {
/* 391 */         log.error("bufLength config err:" + param);
/*     */       }
/*     */     }
/* 394 */     socketServer.setBufLength(bufLength);
/*     */ 
/* 396 */     int ioThreadSize = 2;
/* 397 */     param = (String)result.get("ioThreadSize");
/* 398 */     if (param != null)
/*     */       try {
/* 400 */         ioThreadSize = Integer.parseInt(param);
/* 401 */         socketServer.setIoThreadSize(ioThreadSize);
/*     */       }
/*     */       catch (Exception localException1) {
/*     */       }
/* 405 */     IMessageCreator messageCreator = new MessageGateCreator();
/* 406 */     param = (String)result.get("messageCreator");
/* 407 */     if (param != null)
/*     */     {
/* 409 */       IMessageCreator mc = null;
/*     */       try {
/* 411 */         mc = (IMessageCreator)ApplicationContextUtil.getBean(param); } catch (Exception localException2) {
/*     */       }
/* 413 */       if (mc == null)
/*     */         try {
/* 415 */           Class clz = Class.forName(param);
/* 416 */           mc = (IMessageCreator)clz.newInstance();
/*     */         } catch (Exception localException3) {
/*     */         }
/* 419 */       if (mc != null) {
/* 420 */         messageCreator = mc;
/*     */       }
/*     */     }
/* 423 */     socketServer.setMessageCreator(messageCreator);
/*     */ 
/* 425 */     IClientIO ioHandler = new SimpleIoHandler();
/* 426 */     param = (String)result.get("ioHandler");
/* 427 */     if (param != null) {
/* 428 */       IClientIO ioh = null;
/*     */       try {
/* 430 */         ioh = (IClientIO)ApplicationContextUtil.getBean(param); } catch (Exception localException4) {
/*     */       }
/* 432 */       if (ioh == null)
/*     */         try {
/* 434 */           Class clz = Class.forName(param);
/* 435 */           ioh = (IClientIO)clz.newInstance();
/*     */         } catch (Exception localException5) {
/*     */         }
/* 438 */       if (ioh != null)
/* 439 */         ioHandler = ioh;
/*     */     }
/* 441 */     socketServer.setIoHandler(ioHandler);
/*     */ 
/* 443 */     param = (String)result.get("timeout");
/* 444 */     int timeout = 180;
/* 445 */     if (param != null)
/*     */       try {
/* 447 */         timeout = Integer.parseInt(param);
/*     */       } catch (Exception localException6) {
/*     */       }
/* 450 */     socketServer.setTimeout(timeout);
/*     */ 
/* 452 */     this.socketServers.add(socketServer);
/* 453 */     if (this.bpMessageEventHandler == null) {
/* 454 */       this.bpMessageEventHandler = ((BasicEventHook)ApplicationContextUtil.getBean(this.bpMessageEventHandlerId));
/*     */     }
/* 456 */     this.bpMessageEventHandler.setSource(socketServer);
/* 457 */     this.eventHandlers.add(this.bpMessageEventHandler);
/*     */   }
/*     */ 
/*     */   public void setMonitorServer(String monitorServers) {
/* 461 */     this.monitorServer = monitorServers.trim();
/*     */   }
/*     */ 
/*     */   private void parseMonitorServer()
/*     */   {
/* 466 */     if ((this.monitorServer == null) || (this.monitorServer.length() < 2))
/* 467 */       return;
/* 468 */     Map result = parseUrlConfig(this.monitorServer);
/* 469 */     int port = 0; int bufLength = 51200;
/* 470 */     String param = null;
/*     */     try {
/* 472 */       param = (String)result.get("port");
/* 473 */       if (param == null) {
/* 474 */         log.error("Monitor Socket Server config miss port");
/* 475 */         return;
/*     */       }
/* 477 */       port = Integer.parseInt(param);
/*     */     } catch (Exception e) {
/* 479 */       log.error("Monitor Socket Server config exception,port=" + param, e);
/* 480 */       return;
/*     */     }
/*     */ 
/* 483 */     TcpSocketServer mServer = new TcpSocketServer();
/* 484 */     mServer.setPort(port);
/* 485 */     param = (String)result.get("ip");
/* 486 */     if (param != null) {
/* 487 */       mServer.setIp(param);
/*     */     }
/* 489 */     param = (String)result.get("name");
/* 490 */     if (param == null) {
/* 491 */       param = "monitor-" + port;
/*     */     }
/* 493 */     mServer.setName(param);
/*     */ 
/* 495 */     param = (String)result.get("bufLength");
/* 496 */     if (param != null) {
/*     */       try {
/* 498 */         bufLength = Integer.parseInt(param);
/*     */       } catch (Exception e) {
/* 500 */         log.error("bufLength config err:" + param);
/*     */       }
/*     */     }
/* 503 */     mServer.setBufLength(bufLength);
/*     */ 
/* 505 */     int ioThreadSize = 1;
/* 506 */     param = (String)result.get("ioThreadSize");
/* 507 */     if (param != null)
/*     */       try {
/* 509 */         ioThreadSize = Integer.parseInt(param);
/* 510 */         mServer.setIoThreadSize(ioThreadSize);
/*     */       }
/*     */       catch (Exception localException1) {
/*     */       }
/* 514 */     IMessageCreator messageCreator = (IMessageCreator)ApplicationContextUtil.getBean(this.monitorMessageCreator);
/* 515 */     param = (String)result.get("messageCreator");
/* 516 */     if (param != null)
/*     */     {
/* 518 */       IMessageCreator mc = null;
/*     */       try {
/* 520 */         mc = (IMessageCreator)ApplicationContextUtil.getBean(param);
/*     */       } catch (Exception exp) {
/* 522 */         mc = null;
/*     */       }
/* 524 */       if (mc == null) {
/*     */         try {
/* 526 */           Class clz = Class.forName(param);
/* 527 */           mc = (IMessageCreator)clz.newInstance();
/*     */         } catch (Exception e) {
/* 529 */           mc = null;
/*     */         }
/*     */       }
/* 532 */       if (mc != null) {
/* 533 */         messageCreator = mc;
/*     */       }
/*     */     }
/* 536 */     mServer.setMessageCreator(messageCreator);
/*     */ 
/* 538 */     IClientIO ioHandler = new SimpleIoHandler();
/* 539 */     param = (String)result.get("ioHandler");
/* 540 */     if (param != null) {
/* 541 */       IClientIO ioh = null;
/*     */       try {
/* 543 */         ioh = (IClientIO)ApplicationContextUtil.getBean(param);
/*     */       } catch (Exception e) {
/* 545 */         ioh = null;
/*     */       }
/* 547 */       if (ioh == null)
/*     */         try {
/* 549 */           Class clz = Class.forName(param);
/* 550 */           ioh = (IClientIO)clz.newInstance();
/*     */         } catch (Exception localException2) {
/*     */         }
/* 553 */       if (ioh != null)
/* 554 */         ioHandler = ioh;
/*     */     }
/* 556 */     mServer.setIoHandler(ioHandler);
/*     */ 
/* 558 */     param = (String)result.get("timeout");
/* 559 */     int timeout = 1800;
/* 560 */     if (param != null)
/*     */       try {
/* 562 */         timeout = Integer.parseInt(param);
/*     */       } catch (Exception localException3) {
/*     */       }
/* 565 */     mServer.setTimeout(timeout);
/*     */ 
/* 567 */     this.socketServers.add(mServer);
/* 568 */     if (this.monitorEventHandler == null) {
/* 569 */       this.monitorEventHandler = ((BasicEventHook)ApplicationContextUtil.getBean(this.monitorEventHandlerId));
/*     */     }
/* 571 */     this.monitorEventHandler.setSource(mServer);
/* 572 */     this.eventHandlers.add(this.monitorEventHandler);
/*     */   }
/*     */ 
/*     */   private Map<String, String> parseUrlConfig(String url) {
/* 576 */     Map result = new HashMap();
/*     */ 
/* 578 */     String hostAddr = null; String params = null;
/* 579 */     int index = url.indexOf("?");
/* 580 */     if (index > 0) {
/* 581 */       hostAddr = url.substring(0, index);
/* 582 */       params = url.substring(index + 1);
/*     */     }
/*     */     else {
/* 585 */       hostAddr = url;
/*     */     }
/* 587 */     if (hostAddr != null) {
/* 588 */       index = hostAddr.indexOf(":");
/* 589 */       if (index > 0) {
/* 590 */         String ip = hostAddr.substring(0, index);
/* 591 */         String port = hostAddr.substring(index + 1);
/* 592 */         result.put("ip", ip);
/* 593 */         result.put("port", port);
/*     */       }
/*     */       else {
/* 596 */         result.put("port", hostAddr);
/*     */       }
/*     */     }
/* 599 */     if (params != null) {
/* 600 */       String[] paramArray = params.split("&");
/* 601 */       if (paramArray != null)
/* 602 */         for (String param : paramArray) {
/* 603 */           index = param.indexOf("=");
/* 604 */           if (index < 0) {
/* 605 */             log.error("Server config malformed,miss'=' :" + param);
/*     */           }
/*     */           else {
/* 608 */             String name = param.substring(0, index);
/* 609 */             String value = param.substring(index + 1);
/* 610 */             result.put(name, value);
/*     */           }
/*     */         }
/*     */     }
/* 614 */     return result;
/*     */   }
/*     */ 
/*     */   public final List<BaseSocketServer> getSocketServers() {
/* 618 */     return this.socketServers;
/*     */   }
/*     */ 
/*     */   public final List<BasicEventHook> getEventHandlers() {
/* 622 */     return this.eventHandlers;
/*     */   }
/*     */ 
/*     */   public final void setMonitorEventHandler(BasicEventHook monitorEventHandler) {
/* 626 */     this.monitorEventHandler = monitorEventHandler;
/*     */   }
/*     */ 
/*     */   public final void setMonitorEventHandlerId(String monitorEventHandlerId) {
/* 630 */     this.monitorEventHandlerId = monitorEventHandlerId;
/*     */   }
/*     */ 
/*     */   public final void setMonitorMessageCreator(String monitorMessageCreator) {
/* 634 */     this.monitorMessageCreator = monitorMessageCreator;
/*     */   }
/*     */ 
/*     */   public void parseConfig() {
/* 638 */     parseGprsGateClients();
/* 639 */     parseSmsGateClients();
/* 640 */     parseBpServer();
/* 641 */     parseMonitorServer();
/*     */   }
/*     */ 
/*     */   public final void setBufLength(int bufLength) {
/* 645 */     this.bufLength = bufLength;
/*     */   }
/*     */ 
/*     */   public final void setTimeout(int timeout) {
/* 649 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public final void setHeartInterval(int heartInterval) {
/* 653 */     this.heartInterval = heartInterval;
/*     */   }
/*     */ 
/*     */   public final void setRequestNum(int requestNum) {
/* 657 */     this.requestNum = requestNum;
/*     */   }
/*     */ 
/*     */   public final void setUmsSendSpeed(int umsSendSpeed) {
/* 661 */     this.umsSendSpeed = umsSendSpeed;
/*     */   }
/*     */ 
/*     */   public final void setSendUserLimit(int sendUserLimit) {
/* 665 */     this.sendUserLimit = sendUserLimit;
/*     */   }
/*     */ 
/*     */   public final void setSendRtuLimit(int sendRtuLimit) {
/* 669 */     this.sendRtuLimit = sendRtuLimit;
/*     */   }
/*     */ 
/*     */   public final void setRetrieveMsgLimit(int retrieveMsgLimit) {
/* 673 */     this.retrieveMsgLimit = retrieveMsgLimit;
/*     */   }
/*     */ 
/*     */   public final void setNoUpLogAlertTime(long noUpLogAlertTime) {
/* 677 */     this.noUpLogAlertTime = noUpLogAlertTime;
/*     */   }
/*     */ 
/*     */   public final void setNoUpAlertMobiles(String noUpAlertMobiles) {
/* 681 */     this.noUpAlertMobiles = noUpAlertMobiles;
/*     */   }
/*     */ 
/*     */   public final void setNoUpAlertContent(String noUpAlertContent) {
/* 685 */     this.noUpAlertContent = noUpAlertContent;
/*     */   }
/*     */ 
/*     */   public final void setUmsProtocolId(String umsProtocolId) {
/* 689 */     this.umsProtocolId = umsProtocolId;
/*     */   }
/*     */ 
/*     */   public final void setGprsMessageEventHandler(GateMessageEventHandler gprsMessageEventHandler)
/*     */   {
/* 694 */     this.gprsMessageEventHandler = gprsMessageEventHandler;
/*     */   }
/*     */ 
/*     */   public final void setGprsMessageEventHandlerId(String gprsMessageEventHandlerId) {
/* 698 */     this.gprsMessageEventHandlerId = gprsMessageEventHandlerId;
/*     */   }
/*     */ 
/*     */   public final void setSmsMessageEventHandler(SmsMessageEventHandler smsMessageEventHandler)
/*     */   {
/* 703 */     this.smsMessageEventHandler = smsMessageEventHandler;
/*     */   }
/*     */ 
/*     */   public final void setSmsMessageEventHandlerId(String smsMessageEventHandlerId) {
/* 707 */     this.smsMessageEventHandlerId = smsMessageEventHandlerId;
/*     */   }
/*     */ 
/*     */   public final void setBpMessageEventHandler(BasicEventHook bpMessageEventHandler) {
/* 711 */     this.bpMessageEventHandler = bpMessageEventHandler;
/*     */   }
/*     */ 
/*     */   public final void setBpMessageEventHandlerId(String bpMessageEventHandlerId) {
/* 715 */     this.bpMessageEventHandlerId = bpMessageEventHandlerId;
/*     */   }
/*     */ 
/*     */   public final List<ClientModule> getGprsClientModules() {
/* 719 */     return this.gprsClientModules;
/*     */   }
/*     */ 
/*     */   public final List<UmsModule> getUmsClientModules() {
/* 723 */     return this.umsClientModules;
/*     */   }
/*     */ 
/*     */   public final void setUmsServerAddr(String umsServerAddr) {
/* 727 */     this.umsServerAddr = umsServerAddr;
/*     */   }
/*     */ 
/*     */   public void setSleepInterval(long sleepInterval) {
/* 731 */     this.sleepInterval = sleepInterval;
/*     */   }
/*     */ }