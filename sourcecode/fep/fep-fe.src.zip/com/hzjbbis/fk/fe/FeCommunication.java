/*    */ package com.hzjbbis.fk.fe;
/*    */ 
/*    */ import com.hzjbbis.db.DbMonitor;
/*    */ import com.hzjbbis.fk.FasSystem;
/*    */ import com.hzjbbis.fk.common.spi.IEventHook;
/*    */ import com.hzjbbis.fk.common.spi.IModule;
/*    */ import com.hzjbbis.fk.fe.config.ApplicationPropertiesConfig;
/*    */ import com.hzjbbis.fk.fe.fiber.FiberManage;
/*    */ import com.hzjbbis.fk.fe.fiber.IFiber;
/*    */ import com.hzjbbis.fk.utils.ApplicationContextUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*    */ 
/*    */ public class FeCommunication
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     IModule mod;
/* 28 */     String[] path = { 
/* 29 */       "classpath*:applicationContext-common.xml", 
/* 30 */       "classpath*:applicationContext-socket.xml", 
/* 31 */       "classpath*:applicationContext-monitor.xml", 
/* 32 */       "classpath*:applicationContext-db-batch.xml", 
/* 33 */       "classpath*:applicationContext-ums.xml", 
/* 34 */       "classpath*:applicationContext-fec.xml" };
/*    */ 
/* 36 */     ApplicationContext context = new ClassPathXmlApplicationContext(path);
/* 37 */     ApplicationContextUtil.setContext(context);
/*    */ 
/* 39 */     FasSystem fasSystem = (FasSystem)context.getBean("fasSystem");
/* 40 */     fasSystem.setApplicationContext(context);
/*    */ 
/* 43 */     GateClientManage gateClients = GateClientManage.getInstance();
/*    */ 
/* 45 */     ApplicationPropertiesConfig config = ApplicationPropertiesConfig.getInstance();
/* 46 */     config.parseConfig();
/* 47 */     gateClients.setGprsGateClients(config.getGprsClientModules());
/* 48 */     gateClients.setUmsClients(config.getUmsClientModules());
/*    */ 
/* 51 */     fasSystem.setModules(new ArrayList());
/* 52 */     for (Iterator localIterator1 = config.getSocketServers().iterator(); localIterator1.hasNext(); ) { mod = (IModule)localIterator1.next();
/* 53 */       fasSystem.addModule(mod);
/*    */     }
/*    */ 
/* 56 */     fasSystem.setEventHooks(new ArrayList());
/* 57 */     for (IEventHook hook : config.getEventHandlers()) {
/* 58 */       fasSystem.addEventHook(hook);
/*    */     }
/*    */ 
/* 61 */     for (localIterator1 = gateClients.getGprsGateClients().iterator(); localIterator1.hasNext(); ) { mod = (IModule)localIterator1.next();
/* 62 */       fasSystem.addModule(mod);
/*    */     }
/* 64 */     for (localIterator1 = gateClients.getUmsClients().iterator(); localIterator1.hasNext(); ) { mod = (IModule)localIterator1.next();
/* 65 */       fasSystem.addModule(mod);
/*    */     }
/*    */ 
/* 68 */     DbMonitor mastDbMonitor = (DbMonitor)context.getBean("master.dbMonitor");
/* 69 */     mastDbMonitor.testDbConnection();
/*    */ 
/* 81 */     FiberManage fiberManage = FiberManage.getInstance();
/* 82 */     fiberManage.setFibers(new ArrayList());
/* 83 */     for (IFiber fiber : config.getUmsClientModules()) {
/* 84 */       fiberManage.schedule(fiber);
/*    */     }
/* 86 */     fasSystem.addUnMonitoredModules(fiberManage);
/*    */ 
/* 91 */     fasSystem.startSystem();
/*    */   }
/*    */ }