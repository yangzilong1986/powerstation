/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import com.hzjbbis.fk.model.TaskTemplate;
/*     */ import java.util.Calendar;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class RtuTaskUtil
/*     */ {
/*  19 */   private static final Log log = LogFactory.getLog(RtuTaskUtil.class);
/*     */   public static final String TIME_UNIT_MINUTE = "02";
/*     */   public static final String TIME_UNIT_HOUR = "03";
/*     */   public static final String TIME_UNIT_DAY = "04";
/*     */   public static final String TIME_UNIT_MONTH = "05";
/*     */   public static final long SECONDES_IN_MINUTE = 60L;
/*     */   public static final long SECONDES_IN_HOUR = 3600L;
/*     */   public static final long SECONDES_IN_DAY = 86400L;
/*  29 */   public static final int[] dayInMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*     */ 
/*     */   public static long lastRuntime(TaskTemplate task, long time)
/*     */   {
/*  38 */     long rt = time;
/*     */     try {
/*  40 */       if (task.getUploadIntervalUnit().equalsIgnoreCase("02"))
/*  41 */         rt = lastRuntimeM(task.getUploadStartTimeUnit(), task.getUploadStartTime(), task.getUploadIntervalUnit(), task.getUploadInterval(), time);
/*  42 */       else if (task.getUploadIntervalUnit().equalsIgnoreCase("03"))
/*  43 */         rt = lastRuntimeH(task.getUploadStartTimeUnit(), task.getUploadStartTime(), task.getUploadIntervalUnit(), task.getUploadInterval(), time);
/*  44 */       else if (task.getUploadIntervalUnit().equalsIgnoreCase("04")) {
/*  45 */         rt = lastRuntimeD(task.getUploadStartTimeUnit(), task.getUploadStartTime(), task.getUploadIntervalUnit(), task.getUploadInterval(), time);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  50 */       log.error("取最近运行时刻", e);
/*     */     }
/*  52 */     return rt;
/*     */   }
/*     */ 
/*     */   public static long lastSampTime(TaskTemplate task, long time)
/*     */   {
/*  62 */     long rt = time;
/*     */     try {
/*  64 */       if (task.getSampleIntervalUnit().equalsIgnoreCase("02"))
/*  65 */         rt = lastRuntimeM(task.getSampleStartTimeUnit(), task.getSampleStartTime(), task.getSampleIntervalUnit(), task.getSampleInterval(), time);
/*  66 */       else if (task.getSampleIntervalUnit().equalsIgnoreCase("03"))
/*  67 */         rt = lastRuntimeH(task.getSampleStartTimeUnit(), task.getSampleStartTime(), task.getSampleIntervalUnit(), task.getSampleInterval(), time);
/*  68 */       else if (task.getSampleIntervalUnit().equalsIgnoreCase("04")) {
/*  69 */         rt = lastRuntimeD(task.getSampleStartTimeUnit(), task.getSampleStartTime(), task.getSampleIntervalUnit(), task.getSampleInterval(), time);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  74 */       log.error("取最近采样时刻", e);
/*     */     }
/*  76 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int rCapacity(TaskTemplate task)
/*     */   {
/*  85 */     int rt = 0;
/*     */     try {
/*  87 */       if ((task != null) && 
/*  88 */         (task.getSampleInterval() > 0) && (task.getUploadInterval() > 0)) {
/*  89 */         long sinterval = getUnitSecondes(task.getSampleIntervalUnit()) * task.getSampleInterval();
/*  90 */         long rinterval = getUnitSecondes(task.getUploadIntervalUnit()) * task.getUploadInterval();
/*  91 */         if (sinterval == 0L) {
/*  92 */           if (rinterval == 0L)
/*  93 */             rt = task.getUploadInterval() / task.getSampleInterval();
/*     */         }
/*     */         else {
/*  96 */           long frq = task.getFrequence();
/*  97 */           if (frq <= 0L) {
/*  98 */             frq = 1L;
/*     */           }
/* 100 */           rt = (int)(rinterval / sinterval * frq);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 105 */       log.error("取上报包含数据点数", e);
/*     */     }
/* 107 */     return rt;
/*     */   }
/*     */ 
/*     */   public static long getStartTimeOfTask(TaskTemplate task, long time)
/*     */   {
/* 117 */     long rt = time;
/*     */     try {
/* 119 */       Calendar ctime = Calendar.getInstance();
/* 120 */       ctime.setTimeInMillis(time);
/*     */ 
/* 122 */       ctime.set(13, 0);
/* 123 */       ctime.set(14, 0);
/* 124 */       if (task.getUploadStartTimeUnit().equalsIgnoreCase("02")) {
/* 125 */         ctime.add(12, -task.getUploadStartTime());
/*     */       }
/* 127 */       else if (task.getUploadStartTimeUnit().equalsIgnoreCase(task.getUploadIntervalUnit())) {
/* 128 */         int delt = (int)getUnitSecondes(task.getUploadStartTimeUnit()) * task.getUploadStartTime();
/* 129 */         ctime.add(13, -delt);
/*     */       }
/*     */ 
/* 132 */       int spu = (int)getUnitSecondes(task.getUploadIntervalUnit()) * task.getUploadInterval();
/* 133 */       ctime.add(13, spu);
/* 134 */       rt = ctime.getTimeInMillis();
/*     */     } catch (Exception e) {
/* 136 */       log.error("", e);
/*     */     }
/* 138 */     return rt;
/*     */   }
/*     */ 
/*     */   public static long getUnitSecondes(String unit) {
/* 142 */     long rt = 0L;
/* 143 */     if (unit != null) {
/*     */       try {
/* 145 */         int u = Integer.parseInt(unit);
/* 146 */         switch (u)
/*     */         {
/*     */         case 2:
/* 148 */           rt = 60L;
/* 149 */           break;
/*     */         case 3:
/* 151 */           rt = 3600L;
/* 152 */           break;
/*     */         case 4:
/* 154 */           rt = 86400L;
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 158 */         log.error("单位时间包含秒数", e);
/*     */       }
/*     */     }
/* 161 */     return rt;
/*     */   }
/*     */ 
/*     */   private static long lastRuntimeM(String bUU, int bNN, String iUU, int iNN, long time)
/*     */   {
/* 174 */     long rt = time;
/*     */     try {
/* 176 */       Calendar ctime = Calendar.getInstance();
/* 177 */       ctime.setTimeInMillis(time);
/*     */ 
/* 179 */       ctime.set(13, 0);
/* 180 */       ctime.set(14, 0);
/*     */ 
/* 182 */       int minutes = ctime.get(11) * 60 + ctime.get(12);
/* 183 */       if (minutes < bNN) {
/* 184 */         ctime.set(12, bNN);
/* 185 */         ctime.add(12, -iNN);
/* 186 */         rt = ctime.getTimeInMillis();
/*     */       } else {
/* 188 */         minutes -= bNN;
/* 189 */         long mtime = minutes % iNN;
/* 190 */         if (mtime > 0L) {
/* 191 */           ctime.add(12, -(int)mtime);
/*     */         }
/*     */ 
/* 196 */         rt = ctime.getTimeInMillis();
/*     */       }
/*     */     } catch (Exception e) {
/* 199 */       log.error("获取最近运行时刻-分", e);
/*     */     }
/* 201 */     return rt;
/*     */   }
/*     */ 
/*     */   private static long lastRuntimeH(String bUU, int bNN, String iUU, int iNN, long time)
/*     */   {
/* 214 */     long rt = time;
/*     */     try {
/* 216 */       Calendar ctime = Calendar.getInstance();
/* 217 */       ctime.setTimeInMillis(time);
/*     */ 
/* 219 */       ctime.set(13, 0);
/* 220 */       ctime.set(14, 0);
/*     */ 
/* 222 */       long dtime = ctime.get(11) * 3600L + ctime.get(12) * 60L;
/*     */ 
/* 224 */       long ftime = getUnitSecondes(bUU) * bNN;
/*     */ 
/* 226 */       long interval = getUnitSecondes(iUU) * iNN;
/* 227 */       if (ftime > dtime) {
/* 228 */         if (bUU.equalsIgnoreCase("02")) {
/* 229 */           ctime.set(12, bNN);
/* 230 */           ctime.set(11, 0);
/* 231 */           ctime.add(13, (int)interval);
/* 232 */           rt = ctime.getTimeInMillis();
/* 233 */         } else if (bUU.equalsIgnoreCase("03")) {
/* 234 */           ctime.set(12, 0);
/* 235 */           ctime.set(11, bNN);
/* 236 */           ctime.add(13, (int)interval);
/* 237 */           rt = ctime.getTimeInMillis();
/*     */         }
/*     */         else {
/* 240 */           log.warn("错误的时间配置 bUU--" + bUU + " iUU--" + iUU);
/*     */         }
/*     */       } else {
/* 243 */         long delt = (dtime - ftime) % interval;
/* 244 */         ctime.add(13, (int)delt);
/* 245 */         rt = ctime.getTimeInMillis();
/*     */       }
/*     */     } catch (Exception e) {
/* 248 */       log.error("获取最近运行时刻-时", e);
/*     */     }
/* 250 */     return rt;
/*     */   }
/*     */ 
/*     */   private static long lastRuntimeD(String bUU, int bNN, String iUU, int iNN, long time)
/*     */   {
/* 263 */     long rt = time;
/*     */     try
/*     */     {
/*     */       int cday;
/* 265 */       Calendar ctime = Calendar.getInstance();
/* 266 */       ctime.setTimeInMillis(time);
/*     */ 
/* 268 */       ctime.set(12, 0);
/* 269 */       ctime.set(13, 0);
/* 270 */       ctime.set(14, 0);
/*     */ 
/* 272 */       if (bUU.equalsIgnoreCase("04"))
/*     */       {
/* 274 */         cday = ctime.get(5);
/* 275 */         if (bNN > cday)
/*     */         {
/* 277 */           ctime.set(5, bNN);
/* 278 */           ctime.add(5, -iNN);
/* 279 */           rt = ctime.getTimeInMillis();
/*     */         } else {
/* 281 */           cday -= (cday - bNN) % iNN;
/* 282 */           ctime.set(5, cday);
/* 283 */           rt = ctime.getTimeInMillis();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         int delt;
/* 285 */         if (bUU.equalsIgnoreCase("03"))
/*     */         {
/* 287 */           cday = ctime.get(5);
/* 288 */           delt = (cday - 1) % iNN;
/* 289 */           if (delt <= 0)
/*     */           {
/* 291 */             if (ctime.get(11) < bNN)
/*     */             {
/* 293 */               ctime.set(11, bNN);
/* 294 */               ctime.add(5, -iNN);
/* 295 */               rt = ctime.getTimeInMillis();
/*     */             }
/*     */             else {
/* 298 */               ctime.set(11, bNN);
/* 299 */               rt = ctime.getTimeInMillis();
/*     */             }
/*     */           } else {
/* 302 */             cday -= delt;
/* 303 */             ctime.set(5, cday);
/* 304 */             ctime.set(11, bNN);
/* 305 */             rt = ctime.getTimeInMillis();
/*     */           }
/* 307 */         } else if (bUU.equalsIgnoreCase("02"))
/*     */         {
/* 309 */           cday = ctime.get(5);
/* 310 */           delt = (cday - 1) % iNN;
/* 311 */           if (delt <= 0)
/*     */           {
/* 313 */             if ((ctime.get(11) == 0) && (ctime.get(12) < bNN))
/*     */             {
/* 315 */               ctime.set(12, bNN);
/* 316 */               ctime.add(5, -iNN);
/* 317 */               rt = ctime.getTimeInMillis();
/*     */             }
/*     */             else {
/* 320 */               ctime.set(11, 0);
/* 321 */               ctime.set(12, bNN);
/* 322 */               rt = ctime.getTimeInMillis();
/*     */             }
/*     */           } else {
/* 325 */             cday -= delt;
/* 326 */             ctime.set(5, cday);
/* 327 */             ctime.set(11, 0);
/* 328 */             ctime.set(12, bNN);
/* 329 */             rt = ctime.getTimeInMillis();
/*     */           }
/*     */         }
/*     */         else {
/* 333 */           log.warn("错误的时间配置 bUU--" + bUU + " iUU--" + iUU); }
/*     */       }
/*     */     } catch (Exception e) {
/* 336 */       log.error("获取最近运行时刻-天", e);
/*     */     }
/* 338 */     return rt;
/*     */   }
/*     */ }