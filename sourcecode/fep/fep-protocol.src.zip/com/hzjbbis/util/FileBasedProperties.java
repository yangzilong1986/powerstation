/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class FileBasedProperties extends Properties
/*     */ {
/*     */   private static final long serialVersionUID = 3788399848195322525L;
/*     */   private String filepath;
/*     */   private boolean readOnly;
/*     */ 
/*     */   public FileBasedProperties(String file)
/*     */   {
/*  35 */     this.filepath = getAbsolutePath(file);
/*  36 */     if (null == this.filepath)
/*  37 */       throw new RuntimeException("属性文件不存在：" + file);
/*  38 */     loadFromFile();
/*     */   }
/*     */ 
/*     */   private String getAbsolutePath(String name) {
/*  42 */     File file = new File(name);
/*  43 */     if (file.exists())
/*  44 */       return file.getAbsolutePath();
/*  45 */     int index = name.lastIndexOf(File.separator);
/*  46 */     if (index >= 0)
/*  47 */       name = name.substring(index, name.length());
/*     */     else {
/*  49 */       name = File.separator + name;
/*     */     }
/*     */ 
/*  52 */     String workDir = System.getProperty("user.dir");
/*  53 */     String cfgpath = workDir + File.separator + "config" + name;
/*  54 */     file = new File(cfgpath);
/*  55 */     if (file.exists())
/*  56 */       return file.getAbsolutePath();
/*  57 */     cfgpath = workDir + File.separator + "configuration" + name;
/*  58 */     file = new File(cfgpath);
/*  59 */     if (file.exists())
/*  60 */       return file.getAbsolutePath();
/*  61 */     cfgpath = workDir + File.separator + "cfg" + name;
/*  62 */     file = new File(cfgpath);
/*  63 */     if (file.exists()) {
/*  64 */       return file.getAbsolutePath();
/*     */     }
/*     */ 
/*  67 */     String classRoot = PathUtil.getRootPath(FileBasedProperties.class);
/*  68 */     String path = classRoot + name;
/*  69 */     file = new File(path);
/*  70 */     if (file.exists())
/*  71 */       return file.getAbsolutePath();
/*  72 */     file = new File(classRoot);
/*     */ 
/*  75 */     classRoot = file.getParentFile().getAbsolutePath();
/*  76 */     path = classRoot + name;
/*  77 */     file = new File(path);
/*  78 */     if (file.exists()) {
/*  79 */       return file.getAbsolutePath();
/*     */     }
/*     */ 
/*  82 */     cfgpath = classRoot + File.separator + "config" + name;
/*  83 */     file = new File(cfgpath);
/*  84 */     if (file.exists())
/*  85 */       return file.getAbsolutePath();
/*  86 */     cfgpath = classRoot + File.separator + "configuration" + name;
/*  87 */     file = new File(cfgpath);
/*  88 */     if (file.exists())
/*  89 */       return file.getAbsolutePath();
/*  90 */     cfgpath = classRoot + File.separator + "cfg" + name;
/*  91 */     file = new File(cfgpath);
/*  92 */     if (file.exists())
/*  93 */       return file.getAbsolutePath();
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   public FileBasedProperties(String file, Properties defaults)
/*     */   {
/* 103 */     super(defaults);
/* 104 */     this.filepath = getAbsolutePath(file);
/* 105 */     if (null == this.filepath)
/* 106 */       throw new RuntimeException("属性文件不存在：" + file);
/* 107 */     loadFromFile();
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */   {
/* 115 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String key, boolean defaultValue)
/*     */   {
/* 125 */     String value = getProperty(key);
/* 126 */     if (value == null) {
/* 127 */       return defaultValue;
/*     */     }
/*     */ 
/* 130 */     value = value.trim();
/* 131 */     if (value.length() == 0) {
/* 132 */       return defaultValue;
/*     */     }
/*     */ 
/* 135 */     return Boolean.valueOf(value).booleanValue();
/*     */   }
/*     */ 
/*     */   public int getInt(String key, int defaultValue)
/*     */   {
/* 145 */     String value = getProperty(key);
/* 146 */     if (value == null) {
/* 147 */       return defaultValue;
/*     */     }
/*     */ 
/* 150 */     value = value.trim();
/* 151 */     if (value.length() == 0) {
/* 152 */       return defaultValue;
/*     */     }
/*     */ 
/* 155 */     return Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   public Calendar getDate(String key)
/*     */   {
/* 164 */     String value = getProperty(key);
/* 165 */     return CalendarUtil.parse(value);
/*     */   }
/*     */ 
/*     */   public Calendar getDate(String key, Calendar defaultValue)
/*     */   {
/* 175 */     String value = getProperty(key);
/* 176 */     if (value == null) {
/* 177 */       return defaultValue;
/*     */     }
/*     */ 
/* 180 */     return CalendarUtil.parse(value, defaultValue);
/*     */   }
/*     */ 
/*     */   public long getSize(String key, long defaultValue)
/*     */   {
/*     */     int index;
/* 190 */     String value = getProperty(key);
/* 191 */     if ((value == null) || (value.trim().length() == 0)) {
/* 192 */       return defaultValue;
/*     */     }
/*     */ 
/* 195 */     String s = value.trim().toUpperCase();
/* 196 */     if (s.length() == 0) {
/* 197 */       return defaultValue;
/*     */     }
/*     */ 
/* 200 */     long multiplier = 1L;
/*     */ 
/* 203 */     if ((index = s.indexOf("KB")) == -1) if ((index = s.indexOf("K")) == -1) break label94;
/* 204 */     multiplier = 1024L;
/* 205 */     s = s.substring(0, index); break label183:
/*     */ 
/* 207 */     if ((index = s.indexOf("MB")) == -1) label94: if ((index = s.indexOf("M")) == -1) break label140;
/* 208 */     multiplier = 1048576L;
/* 209 */     s = s.substring(0, index); break label183:
/*     */ 
/* 211 */     if ((index = s.indexOf("GB")) == -1) label140: if ((index = s.indexOf("G")) == -1) break label183;
/* 212 */     multiplier = 1073741824L;
/* 213 */     s = s.substring(0, index);
/*     */ 
/* 216 */     label183: return (Long.parseLong(s) * multiplier);
/*     */   }
/*     */ 
/*     */   public synchronized Object setProperty(String key, String value)
/*     */   {
/* 223 */     Object oldValue = super.setProperty(key, value);
/* 224 */     if (!(this.readOnly)) {
/* 225 */       OutputStream out = null;
/*     */       try {
/* 227 */         File f = new File(this.filepath);
/* 228 */         if (!(f.exists())) {
/* 229 */           f.createNewFile();
/*     */         }
/* 231 */         out = new FileOutputStream(f);
/* 232 */         super.store(out, null);
/*     */       }
/*     */       catch (FileNotFoundException ex)
/*     */       {
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */       finally {
/* 241 */         if (out != null) {
/*     */           try {
/* 243 */             out.close();
/*     */           }
/*     */           catch (IOException e)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 252 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public void loadFromFile()
/*     */   {
/* 260 */     File f = new File(this.filepath);
/* 261 */     InputStream in = null;
/* 262 */     if (f.exists()) {
/* 263 */       this.readOnly = false;
/*     */       try {
/* 265 */         in = new FileInputStream(f);
/*     */       }
/*     */       catch (FileNotFoundException e)
/*     */       {
/*     */       }
/*     */     }
/*     */     else {
/* 272 */       in = FileBasedProperties.class.getResourceAsStream(this.filepath);
/* 273 */       if (in != null) {
/* 274 */         this.readOnly = true;
/*     */       }
/*     */     }
/*     */ 
/* 278 */     if (in == null) return;
/*     */     try {
/* 280 */       super.load(in);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/*     */     finally {
/*     */       try {
/* 287 */         in.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }