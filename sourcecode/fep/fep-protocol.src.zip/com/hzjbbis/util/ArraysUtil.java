/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ArraysUtil
/*     */ {
/*     */   public static boolean contains(Object[] elements, Object element)
/*     */   {
/*  19 */     return (indexOf(elements, element) > -1);
/*     */   }
/*     */ 
/*     */   public static int indexOf(Object[] elements, Object element)
/*     */   {
/*  29 */     if ((elements == null) || (element == null)) {
/*  30 */       return -1;
/*     */     }
/*     */ 
/*  33 */     int index = -1;
/*  34 */     for (int i = 0; i < elements.length; ++i) {
/*  35 */       if (elements[i] == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*  39 */       if (elements[i].equals(element)) {
/*  40 */         index = i;
/*  41 */         break;
/*     */       }
/*     */     }
/*     */ 
/*  45 */     return index;
/*     */   }
/*     */ 
/*     */   public static List asList(Object[] elements)
/*     */   {
/*  54 */     return asList(elements, 0, elements.length);
/*     */   }
/*     */ 
/*     */   public static List asList(Object[] elements, int offset, int length)
/*     */   {
/*  66 */     int size = length;
/*  67 */     if (offset + length >= elements.length) {
/*  68 */       size = elements.length - offset;
/*     */     }
/*     */ 
/*  71 */     List l = new ArrayList(size);
/*  72 */     for (int i = 0; i < length; ++i) {
/*  73 */       int index = offset + i;
/*  74 */       if (index >= elements.length) {
/*     */         break;
/*     */       }
/*  77 */       l.add(elements[index]);
/*     */     }
/*     */ 
/*  80 */     return l;
/*     */   }
/*     */ 
/*     */   public static String asString(Object[] elements)
/*     */   {
/*  89 */     if (elements == null) {
/*  90 */       return "null";
/*     */     }
/*     */ 
/*  93 */     StringBuffer sb = new StringBuffer();
/*  94 */     sb.append("[");
/*  95 */     for (int i = 0; i < elements.length; ++i) {
/*  96 */       if (i > 0) {
/*  97 */         sb.append(", ");
/*     */       }
/*  99 */       sb.append(elements[i].toString());
/*     */     }
/* 101 */     sb.append("]");
/*     */ 
/* 103 */     return sb.toString();
/*     */   }
/*     */ }