/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class EnvironmentBag
/*    */ {
/* 16 */   private static final Log log = LogFactory.getLog(EnvironmentBag.class);
/*    */   private static EnvironmentBag _instance;
/*    */   private HashMap fronts;
/*    */   private long time;
/*    */ 
/*    */   private EnvironmentBag()
/*    */   {
/* 22 */     this.fronts = new HashMap();
/* 23 */     this.time = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public static EnvironmentBag getInstance() {
/* 27 */     if (_instance == null) {
/* 28 */       synchronized (EnvironmentBag.class) {
/* 29 */         _instance = new EnvironmentBag();
/*    */       }
/*    */     }
/* 32 */     return _instance;
/*    */   }
/*    */ 
/*    */   public void onFrontConnected(String ip, Object dthread) {
/* 36 */     synchronized (this.fronts) {
/* 37 */       if (this.fronts.containsKey(ip)) {
/* 38 */         this.fronts.remove(ip);
/*    */       }
/* 40 */       this.fronts.put(ip, dthread);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void onFrontClose(String ip) {
/* 45 */     synchronized (this.fronts) {
/* 46 */       this.fronts.remove(ip);
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isAliveFront(String ip)
/*    */   {
/* 56 */     boolean rt = false;
/*    */     try {
/* 58 */       if (this.fronts != null)
/* 59 */         rt = this.fronts.containsKey(ip);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/* 64 */     return rt;
/*    */   }
/*    */ }