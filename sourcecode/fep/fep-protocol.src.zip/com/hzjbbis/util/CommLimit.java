/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ class CommLimit
/*     */ {
/*     */   private long maxSmsCount;
/*     */   private long maxThroughput;
/*     */ 
/*     */   public long getMaxSmsCount()
/*     */   {
/* 108 */     return this.maxSmsCount;
/*     */   }
/*     */ 
/*     */   public void setMaxSmsCount(long maxSmsCount)
/*     */   {
/* 114 */     this.maxSmsCount = maxSmsCount;
/*     */   }
/*     */ 
/*     */   public long getMaxThroughput()
/*     */   {
/* 120 */     return this.maxThroughput;
/*     */   }
/*     */ 
/*     */   public void setMaxThroughput(long maxThroughput)
/*     */   {
/* 126 */     this.maxThroughput = maxThroughput;
/*     */   }
/*     */ }