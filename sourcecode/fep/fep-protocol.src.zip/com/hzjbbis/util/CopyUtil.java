/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import com.hzjbbis.exception.CopyException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ public class CopyUtil
/*     */ {
/*     */   public static Object copyProperties(Object dest, Object orig)
/*     */   {
/*  27 */     if ((dest == null) || (orig == null)) {
/*  28 */       return dest;
/*     */     }
/*     */ 
/*  31 */     PropertyDescriptor[] destDesc = PropertyUtils.getPropertyDescriptors(dest);
/*     */     try {
/*  33 */       for (int i = 0; i < destDesc.length; ++i) {
/*  34 */         if (destDesc[i].getWriteMethod() == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*  38 */         Class destType = destDesc[i].getPropertyType();
/*  39 */         Class origType = PropertyUtils.getPropertyType(orig, destDesc[i].getName());
/*  40 */         if ((destType == null) || (!(destType.equals(origType))) || (destType.equals(Class.class)))
/*     */           continue;
/*  42 */         Object value = PropertyUtils.getProperty(orig, destDesc[i].getName());
/*  43 */         PropertyUtils.setProperty(dest, destDesc[i].getName(), value);
/*     */       }
/*     */ 
/*  47 */       return dest;
/*     */     } catch (Exception ex) {
/*  49 */       throw new CopyException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object copyProperties(Object dest, Object orig, String[] ignores)
/*     */   {
/*  62 */     if ((dest == null) || (orig == null)) {
/*  63 */       return dest;
/*     */     }
/*     */ 
/*  66 */     PropertyDescriptor[] destDesc = PropertyUtils.getPropertyDescriptors(dest);
/*     */     try {
/*  68 */       for (int i = 0; i < destDesc.length; ++i) {
/*  69 */         if (destDesc[i].getWriteMethod() == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*  73 */         if (contains(ignores, destDesc[i].getName())) {
/*     */           continue;
/*     */         }
/*     */ 
/*  77 */         Class destType = destDesc[i].getPropertyType();
/*  78 */         Class origType = PropertyUtils.getPropertyType(orig, destDesc[i].getName());
/*  79 */         if ((destType == null) || (!(destType.equals(origType))) || (destType.equals(Class.class)))
/*     */           continue;
/*  81 */         Object value = PropertyUtils.getProperty(orig, destDesc[i].getName());
/*  82 */         PropertyUtils.setProperty(dest, destDesc[i].getName(), value);
/*     */       }
/*     */ 
/*  86 */       return dest;
/*     */     } catch (Exception ex) {
/*  88 */       throw new CopyException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static boolean contains(String[] ignores, String name) {
/*  93 */     boolean ignored = false;
/*  94 */     for (int j = 0; (ignores != null) && (j < ignores.length); ++j) {
/*  95 */       if (ignores[j].equals(name)) {
/*  96 */         ignored = true;
/*  97 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 101 */     return ignored;
/*     */   }
/*     */ }