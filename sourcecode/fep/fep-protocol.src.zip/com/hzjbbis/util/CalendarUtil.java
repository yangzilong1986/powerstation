/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class CalendarUtil
/*     */ {
/*  14 */   private static final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  15 */   private static final SimpleDateFormat shortDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*  16 */   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  17 */   private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
/*  18 */   private static final SimpleDateFormat shortTimeFormat = new SimpleDateFormat("HH:mm");
/*     */ 
/*     */   public static Calendar getBeginOfToday()
/*     */   {
/*  25 */     Calendar date = Calendar.getInstance();
/*  26 */     clearTimePart(date);
/*  27 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getEndOfToday()
/*     */   {
/*  35 */     Calendar date = Calendar.getInstance();
/*  36 */     setLastTimeOfDay(date);
/*  37 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar clearTimePart(Calendar date)
/*     */   {
/*  47 */     date.set(11, 0);
/*  48 */     date.set(12, 0);
/*  49 */     date.set(13, 0);
/*  50 */     date.set(14, 0);
/*     */ 
/*  52 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar setLastTimeOfDay(Calendar date)
/*     */   {
/*  61 */     date.set(9, 1);
/*  62 */     date.set(11, 23);
/*  63 */     date.set(12, 59);
/*  64 */     date.set(13, 59);
/*  65 */     date.set(14, 999);
/*  66 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getFirstDayOfYear(int year)
/*     */   {
/*  75 */     Calendar date = Calendar.getInstance();
/*  76 */     date.set(1, year);
/*  77 */     date.set(2, 0);
/*  78 */     date.set(5, 1);
/*  79 */     clearTimePart(date);
/*     */ 
/*  81 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar getLastDayOfYear(int year)
/*     */   {
/*  90 */     Calendar date = Calendar.getInstance();
/*  91 */     date.set(1, year);
/*  92 */     date.set(2, 11);
/*  93 */     date.set(5, 31);
/*  94 */     date.set(10, 11);
/*  95 */     setLastTimeOfDay(date);
/*     */ 
/*  97 */     return date;
/*     */   }
/*     */ 
/*     */   public static Calendar parse(String val)
/*     */   {
/* 107 */     if (val == null) {
/* 108 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 112 */       Date date = null;
/* 113 */       String s = val.trim();
/* 114 */       int indexOfDateDelim = s.indexOf("-");
/* 115 */       int indexOfTimeDelim = s.indexOf(":");
/* 116 */       int indexOfTimeDelim2 = s.indexOf(":", indexOfTimeDelim + 1);
/* 117 */       if ((indexOfDateDelim < 0) && (indexOfTimeDelim > 0)) {
/* 118 */         if (indexOfTimeDelim2 > 0) {
/* 119 */           date = timeFormat.parse(s);
/*     */         }
/*     */         else {
/* 122 */           date = shortTimeFormat.parse(s);
/*     */         }
/*     */       }
/* 125 */       else if ((indexOfDateDelim > 0) && (indexOfTimeDelim < 0)) {
/* 126 */         date = dateFormat.parse(s);
/*     */       }
/* 129 */       else if (indexOfTimeDelim2 > 0) {
/* 130 */         date = dateTimeFormat.parse(s);
/*     */       }
/*     */       else {
/* 133 */         date = shortDateTimeFormat.parse(s);
/*     */       }
/*     */ 
/* 137 */       Calendar cal = Calendar.getInstance();
/* 138 */       cal.setTime(date);
/* 139 */       return cal;
/*     */     }
/*     */     catch (ParseException ex) {
/* 142 */       throw new IllegalArgumentException(val + " is invalid date format");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static long getTimeMillis(Calendar time)
/*     */   {
/* 152 */     if (time == null) {
/* 153 */       return 0L;
/*     */     }
/*     */ 
/* 156 */     return (time.get(11) * 3600000L + time.get(12) * 60000L + time.get(13) * 1000L + time.get(14));
/*     */   }
/*     */ 
/*     */   public static int compareTime(Calendar time1, Calendar time2)
/*     */   {
/* 169 */     long ms1 = getTimeMillis(time1);
/* 170 */     long ms2 = getTimeMillis(time2);
/* 171 */     if (ms1 == ms2) {
/* 172 */       return 0;
/*     */     }
/* 174 */     if (ms1 > ms2) {
/* 175 */       return 1;
/*     */     }
/*     */ 
/* 178 */     return -1;
/*     */   }
/*     */ 
/*     */   public static Calendar parse(String val, Calendar defaultValue)
/*     */   {
/*     */     try
/*     */     {
/* 191 */       return parse(val);
/*     */     } catch (Exception ex) {
/*     */     }
/* 194 */     return defaultValue;
/*     */   }
/*     */ }