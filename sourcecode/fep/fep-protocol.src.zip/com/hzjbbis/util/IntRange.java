/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ public class IntRange
/*    */ {
/*    */   private int min;
/*    */   private int max;
/* 13 */   private int hashCode = 0;
/*    */ 
/*    */   public IntRange(int min, int max)
/*    */   {
/* 21 */     if (min > max) {
/* 22 */       throw new IllegalArgumentException("max must equal or greater than min");
/*    */     }
/*    */ 
/* 25 */     this.min = min;
/* 26 */     this.max = max;
/* 27 */     this.hashCode = (37 * (629 + min) + max);
/*    */   }
/*    */ 
/*    */   public boolean contains(int val)
/*    */   {
/* 36 */     return ((val >= this.min) && (val <= this.max));
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 43 */     if (!(obj instanceof IntRange)) {
/* 44 */       return false;
/*    */     }
/*    */ 
/* 47 */     IntRange range = (IntRange)obj;
/* 48 */     return ((this.min == range.min) && (this.max == range.max));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 55 */     return this.hashCode;
/*    */   }
/*    */ }