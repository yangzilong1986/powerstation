/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ 
/*     */ public class FasProperties
/*     */ {
/*     */   private static final String PROPS_FILE = "/fas.properties";
/*     */   private static final String PROP_FILE_STORE_PATH = "fas.file.store.path";
/*     */   private static final String DEFAULT_FILE_STORE_PATH = "fas";
/*  19 */   private static FileBasedProperties props = null;
/*     */ 
/*     */   public static FileBasedProperties getProperties()
/*     */   {
/*  26 */     if (props == null) {
/*  27 */       synchronized (FasProperties.class) {
/*  28 */         if (props == null) {
/*  29 */           props = new FileBasedProperties("/fas.properties");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  34 */     return props;
/*     */   }
/*     */ 
/*     */   public static String getFileStorePath()
/*     */   {
/*  43 */     String path = getProperties().getProperty("fas.file.store.path");
/*  44 */     if ((path == null) || (path.trim().length() == 0)) {
/*  45 */       path = "fas";
/*     */     }
/*     */ 
/*  48 */     return FileUtil.getAbsolutePath(path);
/*     */   }
/*     */ 
/*     */   public static String getProperty(String key)
/*     */   {
/*  57 */     return getProperties().getProperty(key);
/*     */   }
/*     */ 
/*     */   public static String getProperty(String key, String defaultValue)
/*     */   {
/*  67 */     return getProperties().getProperty(key, defaultValue);
/*     */   }
/*     */ 
/*     */   public static boolean getBoolean(String key, boolean defaultValue)
/*     */   {
/*  77 */     return getProperties().getBoolean(key, defaultValue);
/*     */   }
/*     */ 
/*     */   public static int getInt(String key, int defaultValue)
/*     */   {
/*  87 */     return getProperties().getInt(key, defaultValue);
/*     */   }
/*     */ 
/*     */   public static long getSize(String key, long defaultValue)
/*     */   {
/*  97 */     return getProperties().getSize(key, defaultValue);
/*     */   }
/*     */ 
/*     */   public static Calendar getDate(String key)
/*     */   {
/* 106 */     return getProperties().getDate(key);
/*     */   }
/*     */ }