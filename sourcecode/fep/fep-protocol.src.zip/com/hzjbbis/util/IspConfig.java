/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class IspConfig
/*    */ {
/*    */   public static final String ISP_CODE_UNICOM = "01";
/*    */   public static final String ISP_CODE_MOBILE = "02";
/*    */   private static final String PROP_PFEFIX = "fas.isp.";
/*    */   private static final String PROP_MAX_SMSCOUNT = ".maxSmsCount";
/*    */   private static final String PROP_MAX_THROUGHPUT = ".maxThroughput";
/*    */   private static IspConfig instance;
/* 27 */   private Map limits = new HashMap(4);
/*    */ 
/*    */   private IspConfig()
/*    */   {
/* 33 */     CommLimit limit = readCommLimit("01");
/* 34 */     if (limit != null) {
/* 35 */       this.limits.put("01", limit);
/*    */     }
/*    */ 
/* 38 */     limit = readCommLimit("02");
/* 39 */     if (limit != null)
/* 40 */       this.limits.put("02", limit);
/*    */   }
/*    */ 
/*    */   public static IspConfig getInstance()
/*    */   {
/* 49 */     synchronized (IspConfig.class) {
/* 50 */       if (instance == null) {
/* 51 */         instance = new IspConfig();
/*    */       }
/*    */     }
/* 54 */     return instance;
/*    */   }
/*    */ 
/*    */   public long getMaxSmsCount(String ispCode)
/*    */   {
/* 63 */     CommLimit limit = (CommLimit)this.limits.get(ispCode);
/* 64 */     return ((limit == null) ? 0L : limit.getMaxSmsCount());
/*    */   }
/*    */ 
/*    */   public long getMaxThroughput(String ispCode)
/*    */   {
/* 73 */     CommLimit limit = (CommLimit)this.limits.get(ispCode);
/* 74 */     return ((limit == null) ? 0L : limit.getMaxThroughput());
/*    */   }
/*    */ 
/*    */   private CommLimit readCommLimit(String ispCode)
/*    */   {
/* 83 */     CommLimit limit = new CommLimit();
/* 84 */     long l = FasProperties.getSize("fas.isp." + ispCode + ".maxSmsCount", 0L);
/* 85 */     limit.setMaxSmsCount(l);
/* 86 */     l = FasProperties.getSize("fas.isp." + ispCode + ".maxThroughput", 0L);
/* 87 */     limit.setMaxThroughput(l);
/*    */ 
/* 89 */     return limit;
/*    */   }
/*    */ }