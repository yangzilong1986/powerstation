/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ import com.hzjbbis.exception.CastorException;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import org.exolab.castor.mapping.Mapping;
/*    */ import org.exolab.castor.xml.Unmarshaller;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ public class CastorUtil
/*    */ {
/*    */   public static Object unmarshal(String mappingResource, String dataResource)
/*    */   {
/* 26 */     if (!(mappingResource.startsWith("/"))) {
/* 27 */       mappingResource = "/" + mappingResource;
/*    */     }
/* 29 */     if (!(dataResource.startsWith("/"))) {
/* 30 */       dataResource = "/" + dataResource;
/*    */     }
/*    */     try
/*    */     {
/* 34 */       Mapping mapping = new Mapping();
/* 35 */       InputSource in = new InputSource(CastorUtil.class.getResourceAsStream(mappingResource));
/*    */       try {
/* 37 */         mapping.loadMapping(in);
/*    */       }
/*    */       finally {
/* 40 */         in.getByteStream().close();
/*    */       }
/*    */ 
/* 43 */       Unmarshaller unmarshaller = new Unmarshaller(mapping);
/* 44 */       Reader reader = new BufferedReader(new InputStreamReader(CastorUtil.class.getResourceAsStream(dataResource)));
/*    */       try {
/* 46 */         Object localObject2 = unmarshaller.unmarshal(reader);
/*    */ 
/* 49 */         return localObject2; } finally { reader.close();
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 53 */       String msg = "Error to unmarshal from xml [mappingResource: " + mappingResource + ", dataResource: " + dataResource + "]";
/*    */ 
/* 56 */       throw new CastorException(msg, ex);
/*    */     }
/*    */   }
/*    */ }