/*     */ package com.hzjbbis.util;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class HexDump
/*     */ {
/*     */   private static final byte[] highDigits;
/*     */   private static final byte[] lowDigits;
/*     */ 
/*     */   public static String hexDump(ByteBuffer in)
/*     */   {
/*  37 */     if (null == in)
/*  38 */       return "null";
/*  39 */     int size = in.remaining();
/*     */ 
/*  41 */     if (size == 0) {
/*  42 */       return "empty";
/*     */     }
/*     */ 
/*  45 */     StringBuffer out = new StringBuffer(in.remaining() * 3 - 1);
/*     */ 
/*  48 */     int i = in.position();
/*     */ 
/*  51 */     int byteValue = in.get(i) & 0xFF;
/*  52 */     out.append((char)highDigits[byteValue]);
/*  53 */     out.append((char)lowDigits[byteValue]);
/*  54 */     --size;
/*  55 */     ++i;
/*     */ 
/*  57 */     for (; size > 0; --size) {
/*  58 */       out.append(' ');
/*  59 */       byteValue = in.get(i) & 0xFF;
/*  60 */       out.append((char)highDigits[byteValue]);
/*  61 */       out.append((char)lowDigits[byteValue]);
/*  62 */       ++i;
/*     */     }
/*     */ 
/*  67 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompact(ByteBuffer in) {
/*  71 */     if (null == in)
/*  72 */       return "";
/*  73 */     int size = in.remaining();
/*     */ 
/*  75 */     if (size == 0) {
/*  76 */       return "";
/*     */     }
/*     */ 
/*  79 */     StringBuffer out = new StringBuffer(in.remaining() * 2);
/*     */ 
/*  81 */     int i = in.position();
/*     */ 
/*  87 */     for (; size > 0; --size) {
/*  88 */       int byteValue = in.get(i) & 0xFF;
/*  89 */       out.append((char)highDigits[byteValue]);
/*  90 */       out.append((char)lowDigits[byteValue]);
/*  91 */       ++i;
/*     */     }
/*     */ 
/*  96 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompactSilent(ByteBuffer in) {
/* 100 */     if (null == in)
/* 101 */       return "";
/* 102 */     int size = in.remaining();
/*     */ 
/* 104 */     if (size == 0) {
/* 105 */       return "";
/*     */     }
/*     */ 
/* 108 */     StringBuffer out = new StringBuffer(in.remaining() * 2);
/*     */ 
/* 112 */     int i = in.position();
/* 113 */     for (; size > 0; --size) {
/* 114 */       int byteValue = in.get(i) & 0xFF;
/* 115 */       out.append((char)highDigits[byteValue]);
/* 116 */       out.append((char)lowDigits[byteValue]);
/* 117 */       ++i;
/*     */     }
/*     */ 
/* 120 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDump(byte[] in, int offset, int length) {
/* 124 */     int size = in.length;
/* 125 */     if ((size == 0) || (length < 0) || (length > size) || (offset < 0) || (offset > size)) {
/* 126 */       return "empty";
/*     */     }
/* 128 */     if (offset + length > size) {
/* 129 */       return "empty";
/*     */     }
/*     */ 
/* 132 */     StringBuffer out = new StringBuffer(length * 3 - 1);
/*     */ 
/* 135 */     int byteValue = in[(offset++)] & 0xFF;
/* 136 */     out.append((char)highDigits[byteValue]);
/* 137 */     out.append((char)lowDigits[byteValue]);
/* 138 */     --length;
/*     */ 
/* 141 */     for (; length > 0; --length) {
/* 142 */       out.append(' ');
/* 143 */       byteValue = in[(offset++)] & 0xFF;
/* 144 */       out.append((char)highDigits[byteValue]);
/* 145 */       out.append((char)lowDigits[byteValue]);
/*     */     }
/*     */ 
/* 148 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String hexDumpCompact(byte[] in, int offset, int length) {
/* 152 */     int size = in.length;
/* 153 */     if ((size == 0) || (length < 0) || (length > size) || (offset < 0) || (offset > size)) {
/* 154 */       return "";
/*     */     }
/* 156 */     if (offset + length > size) {
/* 157 */       return "";
/*     */     }
/*     */ 
/* 160 */     StringBuffer out = new StringBuffer(length * 2);
/*     */ 
/* 165 */     for (; length > 0; --length) {
/* 166 */       int byteValue = in[(offset++)] & 0xFF;
/* 167 */       out.append((char)highDigits[byteValue]);
/* 168 */       out.append((char)lowDigits[byteValue]);
/*     */     }
/*     */ 
/* 171 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(byte byteValue) {
/* 175 */     StringBuffer out = new StringBuffer(2);
/* 176 */     int index = byteValue & 0xFF;
/* 177 */     out.append((char)highDigits[index]);
/* 178 */     out.append((char)lowDigits[index]);
/* 179 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(short shortValue) {
/* 183 */     StringBuffer out = new StringBuffer(5);
/* 184 */     int index = shortValue >> 8 & 0xFF;
/* 185 */     out.append((char)highDigits[index]);
/* 186 */     out.append((char)lowDigits[index]);
/* 187 */     index = shortValue & 0xFF;
/* 188 */     out.append((char)highDigits[index]);
/* 189 */     out.append((char)lowDigits[index]);
/* 190 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static String toHex(int i)
/*     */   {
/* 195 */     StringBuffer out = new StringBuffer(8);
/*     */ 
/* 198 */     int index = i >> 24 & 0xFF;
/* 199 */     out.append((char)highDigits[index]);
/* 200 */     out.append((char)lowDigits[index]);
/* 201 */     index = i >> 16 & 0xFF;
/* 202 */     out.append((char)highDigits[index]);
/* 203 */     out.append((char)lowDigits[index]);
/* 204 */     index = i >> 8 & 0xFF;
/* 205 */     out.append((char)highDigits[index]);
/* 206 */     out.append((char)lowDigits[index]);
/* 207 */     index = i & 0xFF;
/* 208 */     out.append((char)highDigits[index]);
/* 209 */     out.append((char)lowDigits[index]);
/* 210 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static ByteBuffer toByteBuffer(String str) {
/* 214 */     ByteBuffer buff = ByteBuffer.wrap(new byte[str.length() / 2]);
/*     */ 
/* 217 */     for (int i = 0; i < str.length() - 1; i += 2) {
/* 218 */       char c1 = str.charAt(i);
/* 219 */       char c2 = str.charAt(i + 1);
/* 220 */       byte b1 = (byte)(char2byte(c1) << 4 | 0xF & char2byte(c2));
/* 221 */       buff.put(b1);
/*     */     }
/* 223 */     buff.flip();
/* 224 */     return buff;
/*     */   }
/*     */ 
/*     */   public static ByteBuffer toByteBuffer(ByteBuffer dest, String str) {
/* 228 */     if ((null == str) || (str.length() == 0)) {
/* 229 */       return dest;
/*     */     }
/*     */ 
/* 232 */     for (int i = 0; i < str.length() - 1; i += 2) {
/* 233 */       char c1 = str.charAt(i);
/* 234 */       char c2 = str.charAt(i + 1);
/* 235 */       byte b1 = (byte)(char2byte(c1) << 4 | 0xF & char2byte(c2));
/* 236 */       dest.put(b1);
/*     */     }
/* 238 */     return dest;
/*     */   }
/*     */ 
/*     */   private static byte char2byte(char c) {
/* 242 */     if ((c >= '0') && (c <= '9'))
/* 243 */       return (byte)(c - '0');
/* 244 */     if ((c >= 'A') && (c <= 'F'))
/* 245 */       return (byte)(c - 'A' + 10);
/* 246 */     if ((c >= 'a') && (c <= 'f'))
/* 247 */       return (byte)(c - 'a' + 10);
/* 248 */     return 0;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  20 */     byte[] digits = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*     */ 
/*  24 */     byte[] high = new byte[256];
/*  25 */     byte[] low = new byte[256];
/*     */ 
/*  27 */     for (int i = 0; i < 256; ++i) {
/*  28 */       high[i] = digits[(i >>> 4)];
/*  29 */       low[i] = digits[(i & 0xF)];
/*     */     }
/*     */ 
/*  32 */     highDigits = high;
/*  33 */     lowDigits = low;
/*     */   }
/*     */ }