/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class FileUtil
/*    */ {
/*    */   public static File mkdirs(String path)
/*    */   {
/* 18 */     File dir = new File(path);
/* 19 */     if (dir.isFile()) {
/* 20 */       throw new IllegalArgumentException(path + " is not a directory");
/*    */     }
/*    */ 
/* 23 */     if (!(dir.exists())) {
/* 24 */       dir.mkdirs();
/*    */     }
/*    */ 
/* 27 */     return dir;
/*    */   }
/*    */ 
/*    */   public static File openFile(String path, String fileName)
/*    */   {
/* 37 */     File dir = mkdirs(path);
/* 38 */     File file = new File(dir, fileName);
/* 39 */     if (!(file.exists())) {
/*    */       try {
/* 41 */         file.createNewFile();
/*    */       }
/*    */       catch (IOException ex) {
/* 44 */         throw new RuntimeException("Error to open file: " + fileName, ex);
/*    */       }
/*    */     }
/*    */ 
/* 48 */     return file;
/*    */   }
/*    */ 
/*    */   public static void deleteFile(String path, String fileName)
/*    */   {
/* 57 */     File file = new File(path, fileName);
/* 58 */     if (file.exists())
/* 59 */       file.delete();
/*    */   }
/*    */ 
/*    */   public static String getAbsolutePath(String path)
/*    */   {
/* 69 */     File f = new File(path);
/* 70 */     return f.getAbsolutePath();
/*    */   }
/*    */ 
/*    */   public static String getAbsolutePath(String path, String fileName)
/*    */   {
/* 80 */     File dir = mkdirs(getAbsolutePath(path));
/* 81 */     File file = new File(dir, fileName);
/* 82 */     return file.getAbsolutePath();
/*    */   }
/*    */ }