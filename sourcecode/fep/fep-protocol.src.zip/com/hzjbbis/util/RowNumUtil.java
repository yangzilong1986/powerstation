/*    */ package com.hzjbbis.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RowNumUtil
/*    */ {
/*    */   public static Map calcRowNum(int pageNum, int pageSize)
/*    */   {
/* 20 */     int startRowNum = (pageNum - 1) * pageSize;
/*    */ 
/* 22 */     int endRowNum = startRowNum + pageSize;
/* 23 */     if (pageSize < 0) {
/* 24 */       startRowNum = 0;
/* 25 */       endRowNum = 2147483647;
/*    */     }
/*    */ 
/* 28 */     Map params = new HashMap();
/* 29 */     params.put("startRowNum", new Integer(startRowNum));
/* 30 */     params.put("endRowNum", new Integer(endRowNum));
/*    */ 
/* 32 */     return params;
/*    */   }
/*    */ }