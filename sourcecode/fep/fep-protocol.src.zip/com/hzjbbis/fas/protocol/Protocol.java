package com.hzjbbis.fas.protocol;

public abstract class Protocol
{
  public static final String ZJ = "01";
  public static final String G04 = "02";
  public static final String ZJPB = "07";
}