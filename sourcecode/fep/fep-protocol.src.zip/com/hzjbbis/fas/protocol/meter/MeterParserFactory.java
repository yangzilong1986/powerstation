/*    */ package com.hzjbbis.fas.protocol.meter;
/*    */ 
/*    */ public class MeterParserFactory
/*    */ {
/*    */   public static IMeterParser getMeterParser(String type)
/*    */   {
/* 11 */     IMeterParser rt = null;
/*    */     try {
/* 13 */       if (type.equals("ZJMeter")) {
/* 14 */         rt = new ZjMeterParser();
/*    */       }
/* 16 */       if (type.equals("BBMeter")) {
/* 17 */         rt = new BbMeterParser();
/*    */       }
/* 19 */       if (type.equals("SMMeter"))
/* 20 */         rt = new SmMeterParser();
/*    */     }
/*    */     catch (Exception e) {
/* 23 */       e.printStackTrace();
/*    */     }
/* 25 */     return rt;
/*    */   }
/*    */ }