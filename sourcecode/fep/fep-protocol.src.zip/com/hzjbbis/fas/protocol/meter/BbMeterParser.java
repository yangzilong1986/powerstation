/*     */ package com.hzjbbis.fas.protocol.meter;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.conf.MeterProtocolDataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.conf.MeterProtocolDataSet;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BbMeterParser
/*     */   implements IMeterParser
/*     */ {
/*  48 */   private final Log log = LogFactory.getLog(BbMeterParser.class);
/*     */   private MeterProtocolDataSet dataset;
/*     */ 
/*     */   public BbMeterParser()
/*     */   {
/*     */     try
/*     */     {
/*  53 */       this.dataset = MeterProtocolFactory.createMeterProtocolDataSet("BBMeter");
/*     */     } catch (Exception e) {
/*  55 */       this.log.error("部颁表规约初始化失败");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] convertDataKey(String[] datakey)
/*     */   {
/*  65 */     String[] rt = null;
/*     */     try {
/*  67 */       if ((datakey != null) && (datakey.length > 0)) {
/*  68 */         rt = new String[datakey.length];
/*  69 */         for (int i = 0; i < datakey.length; ++i)
/*  70 */           if ((datakey[i] != null) && (datakey[i].equalsIgnoreCase("8902")))
/*  71 */             addDataKey(rt, "C034");
/*     */           else
/*  73 */             addDataKey(rt, datakey[i]);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  78 */       this.log.error("部颁表数据标识转换", e);
/*     */     }
/*  80 */     return rt;
/*     */   }
/*     */ 
/*     */   private void addDataKey(String[] datakeys, String dkey)
/*     */   {
/*  90 */     for (int i = 0; i < datakeys.length; ++i) {
/*  91 */       if ((datakeys[i] == null) || (datakeys[i].equals(""))) {
/*  92 */         if (dkey.substring(0, 1).equalsIgnoreCase("F")) return; if (dkey.substring(1, 2).equalsIgnoreCase("F")) {
/*     */           return;
/*     */         }
/*     */ 
/*  96 */         datakeys[i] = dkey;
/*  97 */         return;
/*     */       }
/*  99 */       String char1 = datakeys[i].substring(0, 1);
/* 100 */       String char2 = datakeys[i].substring(1, 2);
/* 101 */       String char3 = datakeys[i].substring(2, 3);
/* 102 */       if ((!(char1.equalsIgnoreCase(dkey.substring(0, 1)))) || (!(char2.equalsIgnoreCase(dkey.substring(1, 2)))) || (!(char3.equalsIgnoreCase(dkey.substring(2, 3))))) {
/*     */         continue;
/*     */       }
/*     */ 
/* 106 */       StringBuffer sb = new StringBuffer();
/* 107 */       sb.append(char1);
/* 108 */       sb.append(char2);
/*     */ 
/* 110 */       sb.append(char3);
/* 111 */       sb.append("F");
/*     */ 
/* 113 */       datakeys[i] = sb.toString();
/* 114 */       sb = null;
/* 115 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] constructor(String[] datakey, DataItem para)
/*     */   {
/* 124 */     byte[] frame = null;
/*     */     try {
/* 126 */       if ((datakey != null) && (datakey.length > 0) && (para != null) && (para.getProperty("point") != null))
/*     */       {
/*     */         String maddr;
/*     */         String dkey;
/* 128 */         if (datakey[0].length() == 4) {
/* 129 */           frame = new byte[14];
/* 130 */           maddr = (String)para.getProperty("point");
/* 131 */           dkey = datakey[0];
/* 132 */           frame[0] = 104;
/* 133 */           ParseTool.HexsToBytesAA(frame, 1, maddr, 6, -86);
/* 134 */           frame[7] = 104;
/* 135 */           frame[8] = 1;
/* 136 */           frame[9] = 2;
/* 137 */           ParseTool.HexsToBytes(frame, 10, dkey);
/* 138 */           frame[10] = (byte)(frame[10] + 51);
/* 139 */           frame[11] = (byte)(frame[11] + 51);
/* 140 */           frame[12] = ParseTool.calculateCS(frame, 0, 12);
/* 141 */           frame[13] = 22;
/*     */         } else {
/* 143 */           frame = new byte[16];
/* 144 */           maddr = (String)para.getProperty("point");
/* 145 */           dkey = datakey[0];
/* 146 */           frame[0] = 104;
/* 147 */           ParseTool.HexsToBytesAA(frame, 1, maddr, 6, -86);
/* 148 */           frame[7] = 104;
/* 149 */           frame[8] = 17;
/* 150 */           frame[9] = 4;
/* 151 */           ParseTool.HexsToBytes(frame, 10, dkey);
/* 152 */           frame[10] = (byte)(frame[10] + 51);
/* 153 */           frame[11] = (byte)(frame[11] + 51);
/* 154 */           frame[12] = (byte)(frame[12] + 51);
/* 155 */           frame[13] = (byte)(frame[13] + 51);
/* 156 */           frame[14] = ParseTool.calculateCS(frame, 0, 14);
/* 157 */           frame[15] = 22;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 164 */     return frame;
/*     */   }
/*     */ 
/*     */   public Object[] parser(byte[] data, int loc, int len) {
/* 168 */     List result = null;
/*     */     try {
/* 170 */       BbMeterFrame frame = new BbMeterFrame();
/* 171 */       frame.parse(data, loc, len);
/* 172 */       if (frame.getDatalen() > 0)
/*     */       {
/*     */         byte[] framedata;
/*     */         int pos;
/*     */         String datakey;
/*     */         MeterProtocolDataItem item;
/* 173 */         result = new ArrayList();
/*     */ 
/* 175 */         int datalen = frame.getDatalen();
/* 176 */         String meteraddr = frame.getMeteraddr();
/* 177 */         DataItem ma = new DataItem();
/* 178 */         ma.addProperty("value", meteraddr);
/* 179 */         ma.addProperty("datakey", "8902");
/* 180 */         result.add(ma);
/*     */ 
/* 182 */         int ctrl = frame.getCtrl();
/* 183 */         if ((ctrl & 0x10) == 16) {
/* 184 */           framedata = frame.getData();
/* 185 */           pos = frame.getPos();
/* 186 */           switch (ctrl & 0xF)
/*     */           {
/*     */           case 1:
/* 188 */             datakey = ParseTool.BytesToHexC(framedata, pos, 4);
/* 189 */             datakey = this.dataset.getConvertCode(datakey);
/* 190 */             item = this.dataset.getDataItem(datakey);
/* 191 */             pos += 4;
/* 192 */             if (item != null) {
/* 193 */               parseValues(framedata, pos, item, result);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/* 201 */         else if ((ctrl & 0x40) <= 0) {
/* 202 */           framedata = frame.getData();
/*     */ 
/* 204 */           pos = frame.getPos();
/* 205 */           switch (ctrl & 0x1F)
/*     */           {
/*     */           case 1:
/* 207 */             datakey = ParseTool.BytesToHexC(framedata, pos, 2);
/* 208 */             item = this.dataset.getDataItem(datakey);
/* 209 */             pos += 2;
/* 210 */             if (item != null) {
/* 211 */               parseValues(framedata, pos, item, result);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 220 */       this.log.error("部颁表规约", e);
/*     */     }
/* 222 */     if (result != null) {
/* 223 */       return result.toArray();
/*     */     }
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getMeterCode(String[] codes)
/*     */   {
/* 233 */     String[] rtCodes = null;
/* 234 */     if ((codes != null) && (codes.length > 0)) {
/* 235 */       rtCodes = new String[codes.length];
/* 236 */       for (int i = 0; i < codes.length; ++i) {
/* 237 */         MeterProtocolDataItem item = this.dataset.getDataItem(codes[i]);
/* 238 */         rtCodes[i] = item.getZjcode();
/*     */       }
/*     */     }
/*     */ 
/* 242 */     return rtCodes;
/*     */   }
/*     */ 
/*     */   private int parseValues(byte[] data, int pos, MeterProtocolDataItem item, List results)
/*     */   {
/* 252 */     int rt = 0;
/*     */     try {
/* 254 */       int loc = pos;
/* 255 */       if ((item.getChildarray() != null) && (item.getChildarray().size() > 0)) {
/* 256 */         List children = item.getChildarray();
/* 257 */         for (int i = 0; i < children.size(); ++i) {
/* 258 */           if ((data[loc] & 0xFF) == 170) {
/* 259 */             ++rt;
/* 260 */             break;
/*     */           }
/* 262 */           if (loc >= data.length) {
/*     */             break;
/*     */           }
/* 265 */           int vlen = parseValues(data, loc, (MeterProtocolDataItem)children.get(i), results);
/* 266 */           if (vlen <= 0) {
/* 267 */             rt = 0;
/* 268 */             break;
/*     */           }
/* 270 */           loc += vlen;
/* 271 */           rt += vlen;
/*     */         }
/*     */       } else {
/* 274 */         DataItem di = new DataItem();
/* 275 */         di.addProperty("datakey", item.getCode());
/* 276 */         Object val = parseItem(data, pos, item);
/* 277 */         di.addProperty("value", val);
/* 278 */         results.add(di);
/* 279 */         rt = item.getLength();
/*     */       }
/*     */     } catch (Exception e) {
/* 282 */       rt = 0;
/* 283 */       this.log.error("解析部颁表数据", e);
/*     */     }
/* 285 */     return rt;
/*     */   }
/*     */ 
/*     */   private Object parseItem(byte[] frame, int loc, MeterProtocolDataItem mpd)
/*     */   {
/* 296 */     Object val = DataItemParser.parsevalue(frame, loc, mpd.getLength(), mpd.getFraction(), mpd.getType());
/* 297 */     return val;
/*     */   }
/*     */ }