/*    */ package com.hzjbbis.fas.protocol.meter;
/*    */ 
/*    */ import com.hzjbbis.fas.protocol.meter.conf.MeterProtocolDataSet;
/*    */ import com.hzjbbis.util.CastorUtil;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class MeterProtocolFactory
/*    */ {
/*    */   private static Hashtable datamappings;
/* 10 */   private static Object lock = new Object();
/*    */ 
/*    */   public static MeterProtocolDataSet createMeterProtocolDataSet(String key) {
/* 13 */     synchronized (lock) {
/* 14 */       if (datamappings == null) {
/* 15 */         datamappings = new Hashtable();
/*    */       }
/* 17 */       if (!(datamappings.containsKey(key))) {
/* 18 */         datamappings.put(key, createDataSet(key));
/*    */       }
/* 20 */       return ((MeterProtocolDataSet)datamappings.get(key));
/*    */     }
/*    */   }
/*    */ 
/*    */   private static MeterProtocolDataSet createDataSet(String key) {
/* 25 */     MeterProtocolDataSet dataset = null;
/*    */     try {
/* 27 */       if (key.equals("ZJMeter")) {
/* 28 */         dataset = (MeterProtocolDataSet)CastorUtil.unmarshal("com/hzjbbis/fas/protocol/meter/conf/protocol-meter-zj-mapping.xml", "com/hzjbbis/fas/protocol/meter/conf/protocol-meter-zj-dataset.xml");
/* 29 */         dataset.packup();
/* 30 */         return dataset;
/*    */       }
/* 32 */       if (key.equals("BBMeter")) {
/* 33 */         dataset = (MeterProtocolDataSet)CastorUtil.unmarshal("com/hzjbbis/fas/protocol/meter/conf/protocol-meter-zj-mapping.xml", "com/hzjbbis/fas/protocol/meter/conf/protocol-meter-bb-dataset.xml");
/* 34 */         dataset.packup();
/* 35 */         return dataset;
/*    */       }
/*    */     } catch (Exception e) {
/* 38 */       e.printStackTrace();
/*    */     }
/* 40 */     return dataset;
/*    */   }
/*    */ }