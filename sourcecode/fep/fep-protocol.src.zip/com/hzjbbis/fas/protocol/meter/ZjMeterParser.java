/*     */ package com.hzjbbis.fas.protocol.meter;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.conf.MeterProtocolDataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.conf.MeterProtocolDataSet;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ZjMeterParser
/*     */   implements IMeterParser
/*     */ {
/*  35 */   private final Log log = LogFactory.getLog(ZjMeterParser.class);
/*     */   private MeterProtocolDataSet dataset;
/*     */ 
/*     */   public ZjMeterParser()
/*     */   {
/*     */     try
/*     */     {
/*  40 */       this.dataset = MeterProtocolFactory.createMeterProtocolDataSet("ZJMeter");
/*     */     } catch (Exception e) {
/*  42 */       this.log.error("浙江表规约初始化失败");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] convertDataKey(String[] datakey) {
/*  47 */     String[] rt = null;
/*     */     try {
/*  49 */       if ((datakey != null) && (datakey.length > 0)) {
/*  50 */         List parents = getParents(this.dataset);
/*  51 */         if (parents != null) {
/*  52 */           rt = new String[datakey.length];
/*  53 */           for (int i = 0; i < datakey.length; ++i) {
/*  54 */             String dkprefix = datakey[i].substring(0, 3);
/*  55 */             for (Iterator iter = parents.iterator(); iter.hasNext(); ) {
/*  56 */               MeterProtocolDataItem di = (MeterProtocolDataItem)iter.next();
/*  57 */               boolean bfind = false;
/*  58 */               if ((di.getZjcode() != null) && (di.getZjcode().length() > 0))
/*     */               {
/*  60 */                 if (di.getZjcode().equalsIgnoreCase("B6FF"))
/*  61 */                   bfind = dkprefix.substring(0, 2).equalsIgnoreCase("B6");
/*     */                 else {
/*  63 */                   bfind = di.getZjcode().substring(0, 3).equals(dkprefix);
/*     */                 }
/*     */               }
/*  66 */               if ((!(bfind)) && (di.getZjcode2() != null) && (di.getZjcode2().length() > 0)) {
/*  67 */                 bfind = di.getZjcode2().substring(0, 3).equals(dkprefix);
/*     */               }
/*  69 */               if (bfind) {
/*  70 */                 boolean block = false;
/*  71 */                 if (di.getZjcode() != null) {
/*  72 */                   block = (di.getZjcode().equals(datakey[i])) || (datakey[i].equalsIgnoreCase("B61F")) || (datakey[i].equalsIgnoreCase("B62F"));
/*     */                 }
/*     */ 
/*  76 */                 if ((!(block)) && (di.getZjcode2() != null)) {
/*  77 */                   block = di.getZjcode2().equals(datakey[i]);
/*     */                 }
/*  79 */                 if (block) {
/*  80 */                   rt[i] = di.getCode(); break;
/*     */                 }
/*  82 */                 List cdks = di.getChildarray();
/*  83 */                 for (Iterator iter1 = cdks.iterator(); iter1.hasNext(); ) {
/*  84 */                   MeterProtocolDataItem cdi = (MeterProtocolDataItem)iter1.next();
/*  85 */                   if ((cdi.getZjcode() != null) && (cdi.getZjcode().equals(datakey[i]))) {
/*  86 */                     rt[i] = cdi.getCode();
/*  87 */                     break;
/*     */                   }
/*  89 */                   if ((cdi.getZjcode2() != null) && (cdi.getZjcode2().equals(datakey[i]))) {
/*  90 */                     rt[i] = cdi.getCode();
/*  91 */                     break;
/*     */                   }
/*     */                 }
/*     */ 
/*  95 */                 break;
/*     */               }
/*     */             }
/*  98 */             if ((rt[i] == null) || (rt[i].equals(""))) {
/*  99 */               this.log.info("不支持的数据召测：" + datakey[i]);
/* 100 */               rt = null;
/* 101 */               break;
/*     */             }
/*     */           }
/*     */         } else {
/* 105 */           this.log.info("空的表规约集合，请检查表规约定义");
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 109 */       this.log.error("convert datakey", e);
/*     */     }
/* 111 */     return fixCode(rt);
/*     */   }
/*     */ 
/*     */   private String[] fixCode(String[] codes)
/*     */   {
/* 120 */     String[] rt = null;
/*     */     try {
/* 122 */       rt = new String[codes.length];
/* 123 */       rt[0] = codes[0];
/* 124 */       int j = 1;
/* 125 */       for (int i = 1; i < codes.length; ++i) {
/* 126 */         boolean fixed = false;
/* 127 */         for (int k = 0; k < j; ++k) {
/* 128 */           if (rt[k].equalsIgnoreCase(codes[i])) {
/* 129 */             fixed = true;
/* 130 */             break;
/*     */           }
/* 132 */           if (rt[k].substring(0, 3).equalsIgnoreCase(codes[i].substring(0, 3))) {
/* 133 */             fixed = true;
/* 134 */             rt[k] = rt[k].substring(0, 3) + "0";
/*     */           }
/*     */         }
/*     */ 
/* 138 */         if (!(fixed)) {
/* 139 */           rt[j] = codes[i];
/* 140 */           ++j;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 146 */     return rt;
/*     */   }
/*     */ 
/*     */   private List getParents(MeterProtocolDataSet dataset) {
/* 150 */     List rt = null;
/*     */     try {
/* 152 */       Hashtable dks = dataset.getDataset();
/* 153 */       Enumeration dkey = dks.elements();
/* 154 */       rt = new ArrayList();
/* 155 */       while (dkey.hasMoreElements()) {
/* 156 */         MeterProtocolDataItem di = (MeterProtocolDataItem)dkey.nextElement();
/* 157 */         if (di.getChildarray() == null) {
/*     */           continue;
/*     */         }
/* 160 */         if (di.getChildarray().size() <= 0) {
/*     */           continue;
/*     */         }
/* 163 */         rt.add(di);
/*     */       }
/*     */     } catch (Exception e) {
/* 166 */       this.log.error("pretreatment protocol", e);
/*     */     }
/* 168 */     return rt;
/*     */   }
/*     */ 
/*     */   public byte[] constructor(String[] datakey, DataItem para)
/*     */   {
/* 176 */     String dk = "";
/* 177 */     byte[] frame = null;
/*     */     try {
/* 179 */       if ((datakey != null) && (datakey.length > 0) && (para != null) && (para.getProperty("point") != null))
/*     */       {
/* 182 */         if (datakey.length == 1) {
/* 183 */           dk = datakey[0];
/*     */         } else {
/* 185 */           dk = datakey[0].substring(0, 3) + "0";
/* 186 */           for (int i = 1; i < datakey.length; ++i) {
/* 187 */             if (dk.substring(0, 2).equals(datakey[i].substring(0, 2))) {
/* 188 */               if ((dk.substring(2, 3).equals(datakey[i].substring(2, 3))) || 
/* 189 */                 (dk.substring(2, 3).equals("0"))) continue;
/* 190 */               dk = dk.substring(0, 2) + "00";
/*     */             }
/*     */             else
/*     */             {
/* 195 */               this.log.info("目前只支持召测同类数据，非同类数据请分别召测！");
/* 196 */               dk = "";
/* 197 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 201 */         if (dk.length() > 0) {
/* 202 */           frame = new byte[9];
/* 203 */           constructFrameCallData(frame, dk, ParseTool.HexToByte((String)para.getProperty("point")));
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 207 */       this.log.error("Construct ZJ meter frame ", e);
/*     */     }
/* 209 */     return frame;
/*     */   }
/*     */ 
/*     */   private void constructFrameCallData(byte[] frame, String datakey, byte maddr) {
/* 213 */     frame[0] = 104;
/* 214 */     frame[1] = 3;
/* 215 */     frame[2] = 3;
/* 216 */     frame[3] = 104;
/* 217 */     frame[4] = maddr;
/* 218 */     ParseTool.HexsToBytes(frame, 5, datakey);
/* 219 */     frame[7] = ParseTool.calculateCS(frame, 4, 3);
/* 220 */     frame[8] = 13;
/*     */   }
/*     */ 
/*     */   public Object[] parser(byte[] data, int loc, int len)
/*     */   {
/* 227 */     List result = null;
/*     */     try {
/* 229 */       ZjMeterFrame frame = new ZjMeterFrame();
/* 230 */       frame.parse(data, loc, len);
/* 231 */       if (frame.getDatalen() > 0) {
/* 232 */         result = new ArrayList();
/*     */ 
/* 234 */         int datalen = frame.getDatalen();
/* 235 */         if (datalen != 1)
/*     */         {
/* 238 */           byte[] framedata = frame.getData();
/* 239 */           String meteraddr = frame.getMeteraddr();
/* 240 */           DataItem item = new DataItem();
/* 241 */           item.addProperty("value", meteraddr);
/* 242 */           item.addProperty("datakey", "8902");
/* 243 */           result.add(item);
/* 244 */           if (datalen == 2)
/*     */           {
/* 245 */             int rtype = framedata[(frame.getPos() + 1)] & 0xFF;
/* 246 */             if ((rtype == 240) && 
/* 249 */               (rtype != 250));
/*     */           }
/*     */           else
/*     */           {
/* 253 */             int iloc = frame.getPos();
/* 254 */             ++iloc;
/* 255 */             while (iloc < framedata.length - 2) {
/* 256 */               String datakey = ParseTool.BytesToHexC(framedata, iloc, 2);
/* 257 */               MeterProtocolDataItem mpd = this.dataset.getDataItem(datakey);
/* 258 */               iloc += 2;
/* 259 */               if (mpd == null) break;
/* 260 */               List children = mpd.getChildarray();
/* 261 */               if ((children != null) && (children.size() > 0)) {
/* 262 */                 for (int ic = 0; ic < children.size(); ++ic) {
/* 263 */                   MeterProtocolDataItem cmpd = (MeterProtocolDataItem)children.get(ic);
/* 264 */                   if ((framedata[iloc] & 0xFF) == 237) {
/*     */                     break;
/*     */                   }
/* 267 */                   if ((framedata[iloc] & 0xFF) == 186) {
/* 268 */                     ++iloc;
/*     */                   }
/*     */                   else
/*     */                   {
/* 272 */                     Object val = parseItem(framedata, iloc, cmpd);
/* 273 */                     toZjDataItem(val, cmpd, result);
/* 274 */                     iloc += cmpd.getLength(); }
/*     */                 }
/* 276 */                 if ((framedata[iloc] & 0xFF) == 237) {
/* 277 */                   ++iloc;
/*     */                 }
/*     */               }
/* 280 */               else if ((framedata[iloc] & 0xFF) == 186) {
/* 281 */                 ++iloc;
/*     */               } else {
/* 283 */                 Object val = parseItem(framedata, iloc, mpd);
/* 284 */                 toZjDataItem(val, mpd, result);
/* 285 */                 iloc += mpd.getLength();
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 297 */       this.log.error("解析浙江表规约", e);
/*     */     }
/* 299 */     if (result != null) {
/* 300 */       return result.toArray();
/*     */     }
/* 302 */     return null;
/*     */   }
/*     */ 
/*     */   private Object parseItem(byte[] frame, int loc, MeterProtocolDataItem mpd)
/*     */   {
/* 313 */     Object val = DataItemParser.parsevalue(frame, loc, mpd.getLength(), mpd.getFraction(), mpd.getType());
/* 314 */     return val;
/*     */   }
/*     */ 
/*     */   private void toZjDataItem(Object val, MeterProtocolDataItem mpd, List result) {
/*     */     try {
/* 319 */       if ((mpd.getZjcode2() != null) && (mpd.getZjcode2().length() > 0)) {
/* 320 */         String[] vals = ((String)val).split(",");
/* 321 */         DataItem item = new DataItem();
/* 322 */         item.addProperty("value", vals[0]);
/* 323 */         item.addProperty("datakey", mpd.getZjcode());
/* 324 */         result.add(item);
/* 325 */         if (vals.length > 1) {
/* 326 */           DataItem item2 = new DataItem();
/* 327 */           item2.addProperty("value", vals[1]);
/* 328 */           item2.addProperty("datakey", mpd.getZjcode2());
/* 329 */           result.add(item2);
/*     */         }
/*     */       } else {
/* 332 */         DataItem item = new DataItem();
/* 333 */         item.addProperty("value", val);
/* 334 */         item.addProperty("datakey", mpd.getZjcode());
/* 335 */         result.add(item);
/*     */       }
/*     */     } catch (Exception e) {
/* 338 */       this.log.error("convert to zj data", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getMeterCode(String[] codes)
/*     */   {
/* 347 */     String[] rtCodes = null;
/* 348 */     if ((codes != null) && (codes.length > 0)) {
/* 349 */       rtCodes = new String[codes.length];
/* 350 */       for (int i = 0; i < codes.length; ++i) {
/* 351 */         MeterProtocolDataItem item = this.dataset.getDataItem(codes[i]);
/* 352 */         rtCodes[i] = item.getZjcode();
/*     */       }
/*     */     }
/*     */ 
/* 356 */     return rtCodes;
/*     */   }
/*     */ }