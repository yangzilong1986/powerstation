/*     */ package com.hzjbbis.fas.protocol.meter;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BbMeterFrame extends AbstractMeterFrame
/*     */ {
/*  16 */   private final Log log = LogFactory.getLog(BbMeterFrame.class);
/*     */   public static final int CHARACTER_HEAD_FLAG = 104;
/*     */   public static final int CHARACTER_TAIL_FLAG = 22;
/*     */   public static final int MINIMUM_FRAME_LENGTH = 12;
/*     */   public static final int FLAG_ADDRESS_POSITION = 1;
/*     */   public static final int FLAG_DATA_POSITION = 10;
/*     */   public static final int FLAG_CTRL_POSITION = 8;
/*     */   public static final int FLAG_BLOCK_DATA = 170;
/*     */   private int datalen;
/*     */   private int pos;
/*     */   private String meteraddr;
/*     */   private int ctrl;
/*     */ 
/*     */   public BbMeterFrame()
/*     */   {
/*  32 */     this.datalen = 0;
/*  33 */     this.pos = 10;
/*     */   }
/*     */ 
/*     */   public BbMeterFrame(byte[] data, int loc, int len)
/*     */   {
/*  38 */     parse(data, loc, len);
/*  39 */     this.pos = 10;
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int loc, int len) {
/*  43 */     int head = loc;
/*  44 */     int rbound = 0;
/*     */ 
/*  46 */     super.clear();
/*     */     try {
/*  48 */       if (data != null) {
/*  49 */         if (data.length > loc + len)
/*  50 */           rbound = loc + len;
/*     */         else {
/*  52 */           rbound = data.length;
/*     */         }
/*  54 */         while ((rbound - loc >= 12) && 
/*  55 */           (head <= rbound - 12)) {
/*  56 */           if ((104 == (data[head] & 0xFF)) && 
/*  57 */             (104 == (data[(head + 7)] & 0xFF))) {
/*  58 */             int flen = data[(head + 9)] & 0xFF;
/*  59 */             if ((head + flen + 10 + 1 <= rbound) && 
/*  60 */               (22 == (data[(head + 10 + flen + 1)] & 0xFF)) && 
/*  62 */               (ParseTool.calculateCS(data, head, flen + 10) == data[(head + 10 + flen)])) {
/*  63 */               this.start = 0;
/*  64 */               this.len = (flen + 12);
/*  65 */               this.data = new byte[this.len];
/*  66 */               this.datalen = flen;
/*  67 */               System.arraycopy(data, head, this.data, this.start, this.len);
/*  68 */               this.meteraddr = ParseTool.BytesToHexC(this.data, 1, 6, -86);
/*  69 */               this.pos = 10;
/*  70 */               this.ctrl = this.data[8];
/*     */ 
/*  72 */               adjustData(this.data, this.pos, this.datalen, 51);
/*  73 */               break;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*  79 */           ++head;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  84 */       this.log.error("部颁帧识别", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void adjustData(byte[] data, int start, int len, int adjust) {
/*  89 */     if ((data != null) && (data.length >= start + len))
/*  90 */       for (int i = start; i < start + len; ++i)
/*     */       {
/*     */         int tmp26_24 = i;
/*     */         byte[] tmp26_23 = data; tmp26_23[tmp26_24] = (byte)(tmp26_23[tmp26_24] - adjust);
/*     */       }
/*     */   }
/*     */ 
/*     */   public int getDatalen()
/*     */   {
/* 100 */     return this.datalen;
/*     */   }
/*     */ 
/*     */   public void setDatalen(int datalen)
/*     */   {
/* 107 */     this.datalen = datalen;
/*     */   }
/*     */ 
/*     */   public String getMeteraddr()
/*     */   {
/* 114 */     return this.meteraddr;
/*     */   }
/*     */ 
/*     */   public void setMeteraddr(String meteraddr)
/*     */   {
/* 121 */     this.meteraddr = meteraddr;
/*     */   }
/*     */ 
/*     */   public int getPos()
/*     */   {
/* 128 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public void setPos(int pos)
/*     */   {
/* 135 */     this.pos = pos;
/*     */   }
/*     */ 
/*     */   public int getCtrl()
/*     */   {
/* 142 */     return this.ctrl;
/*     */   }
/*     */ }