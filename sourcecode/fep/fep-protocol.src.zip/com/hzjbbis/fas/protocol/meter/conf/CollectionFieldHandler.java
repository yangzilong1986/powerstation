/*    */ package com.hzjbbis.fas.protocol.meter.conf;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import org.exolab.castor.mapping.FieldHandler;
/*    */ import org.exolab.castor.mapping.MapHandler;
/*    */ import org.exolab.castor.mapping.ValidityException;
/*    */ 
/*    */ public class CollectionFieldHandler
/*    */   implements MapHandler, FieldHandler
/*    */ {
/*    */   private Hashtable map;
/*    */ 
/*    */   public Object create()
/*    */   {
/* 19 */     return new Hashtable();
/*    */   }
/*    */ 
/*    */   public Object put(Object map, Object key, Object object)
/*    */     throws ClassCastException
/*    */   {
/* 25 */     if ((map != null) && (key != null) && (object != null) && 
/* 26 */       (object instanceof MeterProtocolDataItem)) {
/* 27 */       System.out.println("type is ok!");
/*    */     }
/*    */ 
/* 30 */     return map;
/*    */   }
/*    */ 
/*    */   public Enumeration elements(Object map) throws ClassCastException {
/* 34 */     if (map == null) map = new Hashtable();
/* 35 */     return ((Hashtable)map).elements();
/*    */   }
/*    */ 
/*    */   public Enumeration keys(Object map) throws ClassCastException {
/* 39 */     if (map == null) map = new Hashtable();
/* 40 */     return ((Hashtable)map).keys();
/*    */   }
/*    */ 
/*    */   public int size(Object map) throws ClassCastException {
/* 44 */     if (map == null) return 0;
/* 45 */     return ((Hashtable)map).size();
/*    */   }
/*    */ 
/*    */   public void clear(Object map) throws ClassCastException {
/* 49 */     if (map == null) return;
/* 50 */     ((Hashtable)map).clear();
/*    */   }
/*    */ 
/*    */   public Object get(Object map, Object key) throws ClassCastException {
/* 54 */     if (map == null) return null;
/* 55 */     return ((Hashtable)map).get(key);
/*    */   }
/*    */ 
/*    */   public Object getValue(Object object) throws IllegalStateException {
/* 59 */     return this.map;
/*    */   }
/*    */ 
/*    */   public void setValue(Object object, Object value) throws IllegalStateException, IllegalArgumentException {
/* 63 */     if (object instanceof MeterProtocolDataItem) {
/* 64 */       if (this.map == null) {
/* 65 */         this.map = new Hashtable();
/*    */       }
/* 67 */       MeterProtocolDataItem child = (MeterProtocolDataItem)object;
/* 68 */       MeterProtocolDataItem parent = (MeterProtocolDataItem)this.map.get(child.getFamilycode());
/* 69 */       if (parent != null) {
/* 70 */         addChild(parent, child);
/*    */       }
/* 72 */       this.map.put(child.getCode(), child);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void resetValue(Object object) throws IllegalStateException, IllegalArgumentException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void checkValidity(Object object) throws ValidityException, IllegalStateException
/*    */   {
/*    */   }
/*    */ 
/*    */   public Object newInstance(Object parent) throws IllegalStateException {
/* 85 */     this.map = new Hashtable();
/* 86 */     return this.map;
/*    */   }
/*    */ 
/*    */   public void addChild(MeterProtocolDataItem parent, MeterProtocolDataItem item)
/*    */   {
/* 94 */     Hashtable children = parent.getChildren();
/* 95 */     if (item.getFamilycode().equals(parent.getCode())) {
/* 96 */       if (children == null) {
/* 97 */         children = new Hashtable();
/*    */       }
/* 99 */       children.put(item.getCode(), item);
/*    */     }
/*    */   }
/*    */ }