/*    */ package com.hzjbbis.fas.protocol.meter;
/*    */ 
/*    */ public abstract class AbstractMeterFrame
/*    */ {
/*    */   protected int start;
/*    */   protected int len;
/*    */   protected byte[] data;
/*    */ 
/*    */   public AbstractMeterFrame()
/*    */   {
/* 14 */     this(0, -1, new byte[0]);
/*    */   }
/*    */ 
/*    */   public AbstractMeterFrame(int start, int len, byte[] data) {
/* 18 */     this.data = data;
/* 19 */     this.len = len;
/* 20 */     this.start = start;
/*    */   }
/*    */ 
/*    */   public abstract void parse(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 33 */     return this.data;
/*    */   }
/*    */ 
/*    */   public int getLen()
/*    */   {
/* 40 */     return this.len;
/*    */   }
/*    */ 
/*    */   public int getStart()
/*    */   {
/* 47 */     return this.start;
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 51 */     this.data = null;
/* 52 */     this.start = 0;
/* 53 */     this.len = 0;
/*    */   }
/*    */ }