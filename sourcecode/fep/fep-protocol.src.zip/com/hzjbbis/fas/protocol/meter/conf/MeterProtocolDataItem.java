/*     */ package com.hzjbbis.fas.protocol.meter.conf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MeterProtocolDataItem
/*     */ {
/*     */   private String code;
/*     */   private String description;
/*     */   private String zjcode;
/*     */   private String zjcode2;
/*     */   private int length;
/*     */   private int type;
/*     */   private int fraction;
/*     */   private String familycode;
/*     */   private Hashtable children;
/*     */   private List childarray;
/*     */ 
/*     */   public MeterProtocolDataItem()
/*     */   {
/*  26 */     this("", "", "", 0, 0, 0, "");
/*     */   }
/*     */ 
/*     */   public MeterProtocolDataItem(String code, String zjcode, String description, int len, int type, int fraction, String familycode)
/*     */   {
/*  23 */     this.childarray = new ArrayList();
/*     */ 
/*  30 */     this.code = code;
/*  31 */     this.zjcode = zjcode;
/*  32 */     this.length = len;
/*  33 */     this.type = type;
/*  34 */     this.fraction = fraction;
/*  35 */     this.description = description;
/*  36 */     this.familycode = familycode;
/*  37 */     this.children = new Hashtable();
/*     */   }
/*     */ 
/*     */   public String getCode()
/*     */   {
/*  45 */     return this.code;
/*     */   }
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/*  52 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public int getFraction()
/*     */   {
/*  59 */     return this.fraction;
/*     */   }
/*     */ 
/*     */   public void setFraction(int fraction)
/*     */   {
/*  66 */     this.fraction = fraction;
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  73 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void setLength(int len)
/*     */   {
/*  80 */     this.length = len;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/*  87 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(int type)
/*     */   {
/*  94 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public String getZjcode()
/*     */   {
/* 101 */     return this.zjcode;
/*     */   }
/*     */ 
/*     */   public void setZjcode(String zjcode)
/*     */   {
/* 108 */     this.zjcode = zjcode;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 115 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 122 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public String getFamilycode()
/*     */   {
/* 129 */     return this.familycode;
/*     */   }
/*     */ 
/*     */   public void setFamilycode(String familycode)
/*     */   {
/* 136 */     this.familycode = familycode;
/*     */   }
/*     */ 
/*     */   public Hashtable getChildren()
/*     */   {
/* 143 */     return this.children;
/*     */   }
/*     */ 
/*     */   public void setChildren(Hashtable children)
/*     */   {
/* 150 */     this.children = children;
/*     */   }
/*     */ 
/*     */   public List getChildarray()
/*     */   {
/* 157 */     return this.childarray;
/*     */   }
/*     */ 
/*     */   public void setChildarray(ArrayList childarray)
/*     */   {
/* 164 */     this.childarray = childarray;
/*     */   }
/*     */ 
/*     */   public String getZjcode2()
/*     */   {
/* 171 */     return this.zjcode2;
/*     */   }
/*     */ 
/*     */   public void setZjcode2(String zjcode2)
/*     */   {
/* 178 */     this.zjcode2 = zjcode2;
/*     */   }
/*     */ }