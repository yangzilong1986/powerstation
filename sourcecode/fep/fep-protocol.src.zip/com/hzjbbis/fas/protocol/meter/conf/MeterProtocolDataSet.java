/*     */ package com.hzjbbis.fas.protocol.meter.conf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MeterProtocolDataSet
/*     */ {
/*     */   private static final String PROTOCOL_NAME = "ZJMETER";
/*     */   private String name;
/*     */   private Hashtable dataset;
/*     */   private Map<String, String> codeConvertMap;
/*     */   private List dataarray;
/*     */ 
/*     */   public MeterProtocolDataSet()
/*     */   {
/*  29 */     this("ZJMETER", new Hashtable());
/*     */   }
/*     */ 
/*     */   public MeterProtocolDataSet(String name, Hashtable dataset)
/*     */   {
/*  20 */     this.codeConvertMap = new HashMap();
/*  21 */     this.dataarray = new ArrayList();
/*     */ 
/*  37 */     this.name = name;
/*  38 */     this.dataset = dataset;
/*     */   }
/*     */ 
/*     */   public MeterProtocolDataItem getDataItem(String code)
/*     */   {
/*  47 */     return ((MeterProtocolDataItem)this.dataset.get(code));
/*     */   }
/*     */ 
/*     */   public Hashtable getDataset()
/*     */   {
/*  55 */     return this.dataset;
/*     */   }
/*     */ 
/*     */   public void setDataset(Hashtable dataset)
/*     */   {
/*  62 */     this.dataset = dataset;
/*     */   }
/*     */ 
/*     */   public List getDataarray()
/*     */   {
/*  69 */     return this.dataarray;
/*     */   }
/*     */ 
/*     */   public void setDataarray(List dataarray)
/*     */   {
/*  76 */     this.dataarray = dataarray;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  84 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  88 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void packup() {
/*  92 */     arrayToMap(this.dataarray);
/*     */   }
/*     */ 
/*     */   private void arrayToMap(List datas)
/*     */   {
/*     */     Iterator iter;
/*  96 */     if (datas != null)
/*  97 */       for (iter = datas.iterator(); iter.hasNext(); ) {
/*  98 */         MeterProtocolDataItem child = (MeterProtocolDataItem)iter.next();
/*  99 */         addChild(child);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void addChild(MeterProtocolDataItem item)
/*     */   {
/* 109 */     this.dataset.put(item.getCode(), item);
/* 110 */     this.codeConvertMap.put(item.getZjcode(), item.getCode());
/* 111 */     List cnodes = item.getChildarray();
/* 112 */     arrayToMap(cnodes); }
/*     */ 
/*     */   public String getConvertCode(String code) {
/* 115 */     return ((String)this.codeConvertMap.get(code));
/*     */   }
/*     */ }