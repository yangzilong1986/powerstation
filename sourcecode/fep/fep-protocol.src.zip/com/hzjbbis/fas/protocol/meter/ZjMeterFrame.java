/*     */ package com.hzjbbis.fas.protocol.meter;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ZjMeterFrame extends AbstractMeterFrame
/*     */ {
/*  15 */   private final Log log = LogFactory.getLog(ZjMeterFrame.class);
/*     */   public static final int CHARACTER_HEAD_FLAG = 104;
/*     */   public static final int CHARACTER_TAIL_FLAG = 13;
/*     */   public static final int MINIMUM_FRAME_LENGTH = 7;
/*     */   public static final int FLAG_REPLY_ERROR = 240;
/*     */   public static final int FLAG_REPLY_OK = 250;
/*     */   public static final int FLAG_BLOCK_DATA = 237;
/*     */   public static final int FLAG_NO_DATA = 186;
/*     */   public static final int FLAG_ADDRESS_POSITION = 4;
/*     */   private int datalen;
/*     */   private int pos;
/*     */   private String meteraddr;
/*     */ 
/*     */   public ZjMeterFrame()
/*     */   {
/*  31 */     this.pos = 4;
/*     */   }
/*     */ 
/*     */   public ZjMeterFrame(byte[] data, int loc, int len)
/*     */   {
/*  36 */     parse(data, loc, len);
/*  37 */     this.pos = 4;
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int loc, int len)
/*     */   {
/*  44 */     int head = loc;
/*  45 */     int rbound = 0;
/*     */ 
/*  47 */     super.clear();
/*     */     try {
/*  49 */       if (data != null) {
/*  50 */         if (data.length > loc + len)
/*  51 */           rbound = loc + len;
/*     */         else {
/*  53 */           rbound = data.length;
/*     */         }
/*  55 */         while ((rbound - loc >= 7) && 
/*  56 */           (head <= rbound - 7)) {
/*  57 */           if ((104 == (data[head] & 0xFF)) && 
/*  58 */             (104 == data[(head + 3)]) && (data[(head + 1)] == data[(head + 2)]))
/*     */           {
/*  60 */             int flen = data[(head + 1)] & 0xFF;
/*  61 */             if ((head + flen + 4 + 2 <= rbound) && 
/*  62 */               (13 == (data[(head + 5 + flen)] & 0xFF)) && 
/*  64 */               (calculateCS(data, head + 4, flen) == data[(head + 4 + flen)])) {
/*  65 */               this.start = 0;
/*  66 */               this.len = (flen + 6);
/*  67 */               this.data = new byte[this.len];
/*  68 */               this.datalen = flen;
/*  69 */               System.arraycopy(data, head, this.data, this.start, this.len);
/*  70 */               this.meteraddr = ParseTool.ByteToHex(this.data[this.pos]);
/*  71 */               this.pos = 4;
/*  72 */               break;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*  78 */           ++head;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  83 */       this.log.error("浙江表规约解析", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private byte calculateCS(byte[] data, int start, int len) {
/*  88 */     int cs = 0;
/*  89 */     for (int i = start; i < start + len; ++i) {
/*  90 */       cs += (data[i] & 0xFF);
/*  91 */       cs &= 255;
/*     */     }
/*  93 */     return (byte)(cs & 0xFF);
/*     */   }
/*     */ 
/*     */   public int getDatalen()
/*     */   {
/* 100 */     return this.datalen;
/*     */   }
/*     */ 
/*     */   public String getMeteraddr()
/*     */   {
/* 107 */     return this.meteraddr;
/*     */   }
/*     */ 
/*     */   public void setMeteraddr(String meteraddr)
/*     */   {
/* 114 */     this.meteraddr = meteraddr;
/*     */   }
/*     */ 
/*     */   public int getPos()
/*     */   {
/* 121 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public void setPos(int pos)
/*     */   {
/* 128 */     this.pos = pos;
/*     */   }
/*     */ }