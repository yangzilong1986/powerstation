/*     */ package com.hzjbbis.fas.protocol.meter;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SmMeterParser
/*     */   implements IMeterParser
/*     */ {
/*     */   private final Log log;
/*     */ 
/*     */   public SmMeterParser()
/*     */   {
/*  21 */     this.log = LogFactory.getLog(SmMeterParser.class);
/*     */   }
/*     */ 
/*     */   public byte[] constructor(String[] datakey, DataItem para) {
/*  25 */     return new byte[] { 47, 63, 33, 13, 10 };
/*     */   }
/*     */ 
/*     */   public String[] convertDataKey(String[] datakey)
/*     */   {
/*  30 */     return datakey;
/*     */   }
/*     */ 
/*     */   public Object[] parser(byte[] data, int loc, int len) {
/*  34 */     List result = null;
/*     */     try
/*     */     {
/*  37 */       SmMeterFrame frame = new SmMeterFrame();
/*  38 */       frame.parse(data, loc, len);
/*  39 */       if (frame.getLen() > 0)
/*     */       {
/*     */         String dstring;
/*     */         String val;
/*  41 */         String dbuf = new String(frame.getData(), "iso-8859-1");
/*  42 */         result = new ArrayList();
/*  43 */         int sindex = 0;
/*  44 */         int eindex = 0;
/*     */ 
/*  46 */         sindex = dbuf.indexOf("4.1(");
/*  47 */         if (sindex >= 0) {
/*  48 */           sindex += 4;
/*  49 */           eindex = dbuf.indexOf(")", sindex);
/*  50 */           if (eindex > 0) {
/*  51 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/*  53 */             val = fixValue(dstring);
/*  54 */             addItem(val, "9011", result);
/*     */           }
/*     */         }
/*  57 */         sindex = dbuf.indexOf("4.2(");
/*  58 */         if (sindex >= 0) {
/*  59 */           sindex += 4;
/*  60 */           eindex = dbuf.indexOf(")", sindex);
/*  61 */           if (eindex > 0) {
/*  62 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/*  64 */             val = fixValue(dstring);
/*  65 */             addItem(val, "9012", result);
/*     */           }
/*     */         }
/*  68 */         sindex = dbuf.indexOf("4.3(");
/*  69 */         if (sindex >= 0) {
/*  70 */           sindex += 4;
/*  71 */           eindex = dbuf.indexOf(")", sindex);
/*  72 */           if (eindex > 0) {
/*  73 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/*  75 */             val = fixValue(dstring);
/*  76 */             addItem(val, "9013", result);
/*     */           }
/*     */         }
/*     */ 
/*  80 */         sindex = dbuf.indexOf("5.1(");
/*  81 */         if (sindex >= 0) {
/*  82 */           sindex += 4;
/*  83 */           eindex = dbuf.indexOf(")", sindex);
/*  84 */           if (eindex > 0) {
/*  85 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/*  87 */             val = fixValue(dstring);
/*  88 */             addItem(val, "9021", result);
/*     */           }
/*     */         }
/*  91 */         sindex = dbuf.indexOf("5.2(");
/*  92 */         if (sindex >= 0) {
/*  93 */           sindex += 4;
/*  94 */           eindex = dbuf.indexOf(")", sindex);
/*  95 */           if (eindex > 0) {
/*  96 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/*  98 */             val = fixValue(dstring);
/*  99 */             addItem(val, "9022", result);
/*     */           }
/*     */         }
/* 102 */         sindex = dbuf.indexOf("5.3(");
/* 103 */         if (sindex >= 0) {
/* 104 */           sindex += 4;
/* 105 */           eindex = dbuf.indexOf(")", sindex);
/* 106 */           if (eindex > 0) {
/* 107 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 109 */             val = fixValue(dstring);
/* 110 */             addItem(val, "9023", result);
/*     */           }
/*     */         }
/*     */ 
/* 114 */         sindex = dbuf.indexOf("6(");
/* 115 */         if (sindex >= 0) {
/* 116 */           sindex += 2;
/* 117 */           eindex = dbuf.indexOf(")", sindex);
/* 118 */           if (eindex > 0) {
/* 119 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 121 */             val = fixValue(dstring);
/* 122 */             addItem(val, "9010", result);
/*     */           }
/*     */         }
/*     */ 
/* 126 */         sindex = dbuf.indexOf("7(");
/* 127 */         if (sindex >= 0) {
/* 128 */           sindex += 2;
/* 129 */           eindex = dbuf.indexOf(")", sindex);
/* 130 */           if (eindex > 0) {
/* 131 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 133 */             val = fixValue(dstring);
/* 134 */             addItem(val, "9020", result);
/*     */           }
/*     */         }
/*     */ 
/* 138 */         sindex = dbuf.indexOf("8(");
/* 139 */         if (sindex >= 0) {
/* 140 */           sindex += 2;
/* 141 */           eindex = dbuf.indexOf(")", sindex);
/* 142 */           if (eindex > 0) {
/* 143 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 145 */             val = fixValue(dstring);
/* 146 */             addItem(val, "9110", result);
/*     */           }
/*     */         }
/* 149 */         sindex = dbuf.indexOf("9(");
/* 150 */         if (sindex >= 0) {
/* 151 */           sindex += 2;
/* 152 */           eindex = dbuf.indexOf(")", sindex);
/* 153 */           if (eindex > 0) {
/* 154 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 156 */             val = fixValue(dstring);
/* 157 */             addItem(val, "9120", result);
/*     */           }
/*     */         }
/*     */ 
/* 161 */         sindex = dbuf.indexOf("12(");
/* 162 */         if (sindex >= 0) {
/* 163 */           sindex += 3;
/* 164 */           eindex = dbuf.indexOf(")", sindex);
/* 165 */           if (eindex > 0) {
/* 166 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 168 */             val = fixValue(dstring);
/* 169 */             addItem(val, "A010", result);
/*     */ 
/* 171 */             if (dbuf.substring(eindex + 1, eindex + 2).equals("(")) {
/* 172 */               sindex = eindex + 2;
/* 173 */               eindex = dbuf.indexOf(")", sindex + 1);
/* 174 */               if (eindex > 0) {
/* 175 */                 dstring = dbuf.substring(sindex, eindex);
/* 176 */                 addItem("20" + dstring, "B010", result);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 182 */         sindex = dbuf.indexOf("13(");
/* 183 */         if (sindex >= 0) {
/* 184 */           sindex += 3;
/* 185 */           eindex = dbuf.indexOf(")", sindex);
/* 186 */           if (eindex > 0) {
/* 187 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 189 */             val = fixValue(dstring);
/* 190 */             addItem(val, "A020", result);
/*     */ 
/* 192 */             if (dbuf.substring(eindex + 1, eindex + 2).equals("(")) {
/* 193 */               sindex = eindex + 2;
/* 194 */               eindex = dbuf.indexOf(")", sindex + 1);
/* 195 */               if (eindex > 0) {
/* 196 */                 dstring = dbuf.substring(sindex, eindex);
/* 197 */                 addItem("20" + dstring, "B020", result);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 203 */         sindex = dbuf.indexOf("L.1(");
/* 204 */         if (sindex >= 0) {
/* 205 */           sindex += 4;
/* 206 */           eindex = dbuf.indexOf(")", sindex);
/* 207 */           if (eindex > 0) {
/* 208 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 210 */             val = fixValue(dstring);
/* 211 */             addItem(val, "B611", result);
/*     */           }
/*     */         }
/* 214 */         sindex = dbuf.indexOf("L.2(");
/* 215 */         if (sindex >= 0) {
/* 216 */           sindex += 4;
/* 217 */           eindex = dbuf.indexOf(")", sindex);
/* 218 */           if (eindex > 0) {
/* 219 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 221 */             val = fixValue(dstring);
/* 222 */             addItem(val, "B612", result);
/*     */           }
/*     */         }
/* 225 */         sindex = dbuf.indexOf("L.3(");
/* 226 */         if (sindex >= 0) {
/* 227 */           sindex += 4;
/* 228 */           eindex = dbuf.indexOf(")", sindex);
/* 229 */           if (eindex > 0) {
/* 230 */             dstring = dbuf.substring(sindex, eindex);
/*     */ 
/* 232 */             val = fixValue(dstring);
/* 233 */             addItem(val, "B613", result);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 238 */       this.log.error("解析西门子表规约", e);
/*     */     }
/*     */ 
/* 241 */     if (result != null) {
/* 242 */       return result.toArray();
/*     */     }
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */   private String fixValue(String val) {
/* 248 */     int index = val.indexOf("*");
/* 249 */     if (index > 0) {
/* 250 */       return val.substring(0, index);
/*     */     }
/* 252 */     return val;
/*     */   }
/*     */ 
/*     */   private void addItem(String val, String key, List result) {
/* 256 */     DataItem item = new DataItem();
/* 257 */     item.addProperty("value", val);
/* 258 */     item.addProperty("datakey", key);
/* 259 */     result.add(item);
/*     */   }
/*     */ 
/*     */   public String[] getMeterCode(String[] codes)
/*     */   {
/* 267 */     return codes;
/*     */   }
/*     */ }