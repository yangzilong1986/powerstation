/*    */ package com.hzjbbis.fas.protocol.meter;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SmMeterFrame extends AbstractMeterFrame
/*    */ {
/*    */   private final Log log;
/*    */   public static final int SIEMENS_FRAME_HEAD = 47;
/*    */ 
/*    */   public SmMeterFrame()
/*    */   {
/* 15 */     this.log = LogFactory.getLog(SmMeterFrame.class);
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int loc, int len)
/*    */   {
/* 20 */     int head = loc;
/* 21 */     int rbound = 0;
/*    */ 
/* 23 */     super.clear();
/*    */     try {
/* 25 */       if (data != null) {
/* 26 */         if (data.length > loc + len)
/* 27 */           rbound = loc + len;
/*    */         else {
/* 29 */           rbound = data.length;
/*    */         }
/* 31 */         if (head < rbound)
/*    */         {
/* 33 */           this.start = 0;
/* 34 */           this.len = (rbound - head);
/* 35 */           this.data = new byte[this.len];
/* 36 */           System.arraycopy(data, head, this.data, this.start, this.len);
/*    */         }
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 43 */       this.log.error("西门子表规约解析", e);
/*    */     }
/*    */   }
/*    */ }