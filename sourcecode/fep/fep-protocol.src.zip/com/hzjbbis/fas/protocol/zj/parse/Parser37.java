/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class Parser37
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  29 */       if (ok)
/*     */       {
/*     */         int port;
/*     */         String ip;
/*  30 */         int type = fraction;
/*     */ 
/*  32 */         switch (type)
/*     */         {
/*     */         case 1:
/*  34 */           rt = ParseTool.toPhoneCode(data, loc, 8, 170);
/*  35 */           break;
/*     */         case 2:
/*  37 */           port = ParseTool.nByteToInt(data, loc, 2);
/*  38 */           ip = (data[(loc + 5)] & 0xFF) + "." + (data[(loc + 4)] & 0xFF) + "." + (data[(loc + 3)] & 0xFF) + "." + (data[(loc + 2)] & 0xFF);
/*     */ 
/*  40 */           rt = ip + ":" + port;
/*  41 */           break;
/*     */         case 3:
/*  43 */           rt = ParseTool.toPhoneCode(data, loc, 8, 170);
/*  44 */           break;
/*     */         case 4:
/*  46 */           port = ParseTool.nByteToInt(data, loc, 2);
/*  47 */           ip = (data[(loc + 5)] & 0xFF) + "." + (data[(loc + 4)] & 0xFF) + "." + (data[(loc + 3)] & 0xFF) + "." + (data[(loc + 2)] & 0xFF);
/*     */ 
/*  49 */           rt = ip + ":" + port;
/*  50 */           break;
/*     */         case 5:
/*  52 */           break;
/*     */         case 6:
/*  54 */           break;
/*     */         case 7:
/*  56 */           rt = ParseTool.toPhoneCode(data, loc, 8, 170);
/*  57 */           label352: break label352:
/*     */         case 8:
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  65 */       e.printStackTrace();
/*     */     }
/*  67 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*     */       int flen;
/*     */       int i;
/*  82 */       int type = fraction;
/*  83 */       switch (type)
/*     */       {
/*     */       case 1:
/*  86 */         ParseTool.StringToBcds(frame, loc, value);
/*  87 */         flen = (value.length() >>> 1) + (value.length() & 0x1);
/*  88 */         for (i = loc + flen; i < loc + len; ++i) {
/*  89 */           frame[i] = -86;
/*     */         }
/*  91 */         break;
/*     */       case 2:
/*  94 */         ParseTool.IPToBytes(frame, loc, value);
/*  95 */         frame[(loc + 6)] = -86;
/*  96 */         frame[(loc + 7)] = -86;
/*  97 */         break;
/*     */       case 3:
/* 100 */         ParseTool.StringToBcds(frame, loc, value);
/* 101 */         flen = (value.length() >>> 1) + (value.length() & 0x1);
/* 102 */         for (i = loc + flen; i < loc + len; ++i) {
/* 103 */           frame[i] = -86;
/*     */         }
/* 105 */         break;
/*     */       case 4:
/* 108 */         ParseTool.IPToBytes(frame, loc, value);
/* 109 */         frame[(loc + 6)] = -86;
/* 110 */         frame[(loc + 7)] = -86;
/* 111 */         break;
/*     */       case 5:
/* 113 */         break;
/*     */       case 6:
/* 115 */         break;
/*     */       case 7:
/* 118 */         ParseTool.StringToBcds(frame, loc, value);
/* 119 */         flen = (value.length() >>> 1) + (value.length() & 0x1);
/* 120 */         for (i = loc + flen; i < loc + len; ++i) {
/* 121 */           frame[i] = -86;
/*     */         }
/* 123 */         label261: break label261:
/*     */       case 8:
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 130 */       throw new MessageEncodeException("错误的 主站通讯地址 组帧参数:" + value);
/*     */     }
/*     */ 
/* 133 */     return len;
/*     */   }
/*     */ }