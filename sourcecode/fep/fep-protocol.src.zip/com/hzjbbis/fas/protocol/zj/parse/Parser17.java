/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser17
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 31 */         sb.append(",");
/* 32 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 33 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 36 */       e.printStackTrace();
/*    */     }
/* 38 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 53 */       for (int i = 0; i < value.length(); ++i) {
/* 54 */         char c = value.charAt(i);
/* 55 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 58 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 61 */         throw new MessageEncodeException("错误的 PIN 组帧参数:" + value);
/*    */       }
/* 63 */       String[] para = value.split(",");
/* 64 */       frame[loc] = ParseTool.StringToBcd(para[1]);
/* 65 */       ParseTool.IntToBcd(frame, Integer.parseInt(para[0]), loc + 1, 2);
/*    */     } catch (Exception e) {
/* 67 */       throw new MessageEncodeException("错误的 PIN 组帧参数:" + value);
/*    */     }
/*    */ 
/* 70 */     return len;
/*    */   }
/*    */ }