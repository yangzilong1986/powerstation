/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser18
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok)
/* 28 */         rt = ParseTool.BytesToHexL(data, loc, len);
/*    */     }
/*    */     catch (Exception e) {
/* 31 */       e.printStackTrace();
/*    */     }
/* 33 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 47 */       int nn = Integer.parseInt(value);
/* 48 */       ParseTool.IntToBcdC(frame, nn, loc, len);
/*    */     } catch (Exception e) {
/* 50 */       throw new MessageEncodeException("错误的 BCD 组帧参数:" + value);
/*    */     }
/*    */ 
/* 53 */     return len;
/*    */   }
/*    */ }