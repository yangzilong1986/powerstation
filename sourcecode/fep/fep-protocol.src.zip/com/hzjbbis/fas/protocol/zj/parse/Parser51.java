/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ public class Parser51
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  21 */     Object rt = null;
/*     */     try {
/*  23 */       boolean ok = true;
/*     */ 
/*  27 */       ok = ParseTool.isHaveValidBCD(data, loc, len);
/*  28 */       if (ok) {
/*  29 */         StringBuffer sb = new StringBuffer();
/*  30 */         sb.append("20");
/*  31 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 1)]));
/*  32 */         sb.append("-");
/*  33 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 2)]));
/*  34 */         sb.append("-");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 3)]));
/*  36 */         sb.append(" ");
/*  37 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 4)]));
/*  38 */         sb.append(":");
/*  39 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 5)]));
/*  40 */         sb.append(",");
/*  41 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, len - 5) / ParseTool.fraction[fraction]));
/*  42 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  45 */       e.printStackTrace();
/*     */     }
/*  47 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       NumberFormat nf = NumberFormat.getInstance();
/*  62 */       nf.setMaximumFractionDigits(4);
/*     */ 
/*  65 */       for (int i = 0; i < value.length(); ++i) {
/*  66 */         char c = value.charAt(i);
/*  67 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  70 */         if (c == ':') {
/*     */           continue;
/*     */         }
/*  73 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  76 */         if (c == ' ') {
/*     */           continue;
/*     */         }
/*  79 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  82 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  85 */         throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm 格式1 组帧参数:" + value);
/*     */       }
/*     */ 
/*  88 */       String[] para = value.split(",");
/*  89 */       String[] dpara = para[0].split(" ");
/*  90 */       String[] date = dpara[0].split("-");
/*  91 */       String[] time = dpara[1].split(":");
/*     */ 
/*  93 */       double xx = nf.parse(para[1]).doubleValue() * ParseTool.fraction[fraction];
/*  94 */       ParseTool.IntToBcd(frame, (int)xx, loc, len - 5);
/*  95 */       frame[(loc + len - 1)] = ParseTool.StringToBcd(date[0]);
/*  96 */       frame[(loc + len - 2)] = ParseTool.StringToBcd(date[1]);
/*  97 */       frame[(loc + len - 3)] = ParseTool.StringToBcd(date[2]);
/*  98 */       frame[(loc + len - 4)] = ParseTool.StringToBcd(time[0]);
/*  99 */       frame[(loc + len - 5)] = ParseTool.StringToBcd(time[1]);
/*     */     } catch (Exception e) {
/* 101 */       throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm 格式1 组帧参数:" + value);
/*     */     }
/*     */ 
/* 104 */     return len;
/*     */   }
/*     */ }