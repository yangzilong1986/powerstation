/*    */ package com.hzjbbis.fas.protocol.zj.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.model.HostCommandResult;
/*    */ import com.hzjbbis.fas.protocol.zj.ErrorCode;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class C08MessageDecoder extends AbstractMessageDecoder
/*    */ {
/*    */   public Object decode(IMessage message)
/*    */   {
/* 19 */     HostCommand hc = new HostCommand();
/*    */     try {
/* 21 */       if (ParseTool.getOrientation(message) == 1)
/*    */       {
/*    */         byte[] data;
/* 22 */         int rtype = ParseTool.getErrCode(message);
/*    */ 
/* 24 */         if (0 == rtype) {
/* 25 */           hc.setStatus("1");
/* 26 */           data = ParseTool.getData(message);
/* 27 */           if ((data == null) || (data.length <= 0))
/*    */           {
/* 29 */             throw new MessageDecodeException("空数据体");
/*    */           }
/* 31 */           int point = data[0];
/* 32 */           int loc = 1;
/* 33 */           if (data.length > 3) {
/* 34 */             toResult(data, loc, point, hc);
/*    */           }
/*    */           else
/* 37 */             throw new MessageDecodeException("数据长度不对");
/*    */         }
/*    */         else
/*    */         {
/* 41 */           data = ParseTool.getData(message);
/* 42 */           if ((data != null) && (data.length > 0)) {
/* 43 */             if (data.length == 1)
/* 44 */               hc.setStatus(ErrorCode.toHostCommandStatus(data[0]));
/*    */             else
/* 46 */               toResult(data, 1, data[0], hc);
/*    */           }
/*    */           else
/* 49 */             hc.setStatus("2");
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 54 */         byte[] data = ParseTool.getData(message);
/* 55 */         if ((data != null) && (data.length > 0)) {
/* 56 */           String code = ParseTool.BytesToHexC(data, 5, 2);
/* 57 */           if ((code.equals("7100")) || (code.equals("7101")) || (!(code.equals("7102"))));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 63 */       throw new MessageDecodeException(e);
/*    */     }
/* 65 */     return hc;
/*    */   }
/*    */ 
/*    */   private void toResult(byte[] data, int loc, int point, HostCommand hc)
/*    */   {
/*    */     try
/*    */     {
/* 75 */       int iloc = loc;
/* 76 */       while (iloc < data.length) {
/* 77 */         int datakey = ((data[(iloc + 1)] & 0xFF) << 8) + (data[iloc] & 0xFF);
/* 78 */         iloc += 2;
/* 79 */         String result = ParseTool.ByteToHex(data[iloc]);
/* 80 */         setItemResult(hc, point, ParseTool.IntToHex(datakey), result);
/*    */ 
/* 84 */         ++iloc;
/*    */       }
/*    */     } catch (Exception e) {
/* 87 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void setItemResult(HostCommand hc, int point, String code, String result) {
/* 92 */     HostCommandResult hcr = new HostCommandResult();
/* 93 */     hcr.setTn("" + point);
/* 94 */     hcr.setCode(code);
/* 95 */     hcr.setValue(result);
/* 96 */     hc.addResult(hcr);
/*    */   }
/*    */ }