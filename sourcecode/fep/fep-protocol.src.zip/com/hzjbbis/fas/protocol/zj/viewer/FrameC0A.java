/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameC0A extends AbstractFrame
/*    */ {
/*    */   public static final String FUNC_NAME = "告警确认";
/*    */ 
/*    */   public FrameC0A()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FrameC0A(byte[] frame)
/*    */   {
/* 16 */     super(frame);
/*    */   }
/*    */ 
/*    */   public FrameC0A(String data) {
/* 20 */     super(data);
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 24 */     if (this.frame != null) {
/* 25 */       StringBuffer sb = new StringBuffer();
/* 26 */       sb.append(super.getBase());
/* 27 */       sb.append("命令类型--").append("告警确认");
/* 28 */       sb.append("\n");
/* 29 */       sb.append("数据--").append(Util.BytesToHex(this.frame, 11, this.length));
/* 30 */       return sb.toString();
/*    */     }
/* 32 */     return null;
/*    */   }
/*    */ }