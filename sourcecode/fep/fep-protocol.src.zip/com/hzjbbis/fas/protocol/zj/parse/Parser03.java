/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser03
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isAllFF(data, loc, len);
/* 29 */       if (!(ok)) {
/* 30 */         int val = ParseTool.nByteToInt(data, loc, len);
/* 31 */         if (fraction > 0) {
/* 32 */           NumberFormat snf = NumberFormat.getInstance();
/* 33 */           snf.setMinimumFractionDigits(fraction);
/* 34 */           snf.setMinimumIntegerDigits(1);
/* 35 */           snf.setGroupingUsed(false);
/* 36 */           rt = snf.format(val / ParseTool.fraction[fraction]);
/*    */         } else {
/* 38 */           rt = new Integer(val);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 42 */       e.printStackTrace();
/*    */     }
/* 44 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 58 */       NumberFormat nf = NumberFormat.getInstance();
/* 59 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 61 */       double val = nf.parse(value).doubleValue();
/* 62 */       if (fraction > 0) {
/* 63 */         val *= ParseTool.fraction[fraction];
/*    */       }
/*    */ 
/* 66 */       ParseTool.DecimalToBytes(frame, (int)val, loc, len);
/*    */     } catch (Exception e) {
/* 68 */       throw new MessageEncodeException("错误的HEX码组帧参数:" + value);
/*    */     }
/*    */ 
/* 71 */     return len;
/*    */   }
/*    */ }