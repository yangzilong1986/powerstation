/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser44
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 24 */     Object rt = null;
/*    */     try {
/* 26 */       rt = ParseTool.BytesBit(data, loc, len);
/*    */     } catch (Exception e) {
/* 28 */       e.printStackTrace();
/*    */     }
/* 30 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/* 43 */     int slen = -1;
/*    */     try {
/* 45 */       int vlen = value.length();
/* 46 */       for (int i = 0; i < vlen; ++i) {
/* 47 */         if (value.substring(i, i + 1).equals("0")) continue; if (value.substring(i, i + 1).equals("1")) {
/*    */           continue;
/*    */         }
/* 50 */         throw new MessageEncodeException("错误的 bit位码 组帧参数:" + value);
/*    */       }
/*    */ 
/* 53 */       if ((vlen & 0x7) == 0) {
/* 54 */         int blen = 0;
/* 55 */         int iloc = loc + len - 1;
/* 56 */         while (blen < vlen) {
/* 57 */           frame[iloc] = ParseTool.bitToByte(value.substring(blen, blen + 8));
/* 58 */           blen += 8;
/* 59 */           --iloc;
/*    */         }
/* 61 */         slen = len;
/*    */       }
/*    */     } catch (Exception e) {
/* 64 */       throw new MessageEncodeException("错误的 bit位码 组帧参数:" + value);
/*    */     }
/* 66 */     return slen;
/*    */   }
/*    */ }