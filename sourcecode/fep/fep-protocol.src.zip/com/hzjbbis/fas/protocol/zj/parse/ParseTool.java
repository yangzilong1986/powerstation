/*      */ package com.hzjbbis.fas.protocol.zj.parse;
/*      */ 
/*      */ import com.hzjbbis.fk.message.IMessage;
/*      */ import com.hzjbbis.fk.message.zj.MessageZj;
/*      */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*      */ import java.net.Inet4Address;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class ParseTool
/*      */ {
/*   22 */   public static final String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
/*      */   public static final double FRACTION_TIMES_10 = 10.0D;
/*      */   public static final double FRACTION_TIMES_100 = 100.0D;
/*      */   public static final double FRACTION_TIMES_1000 = 1000.0D;
/*      */   public static final double FRACTION_TIMES_10000 = 10000.0D;
/*   27 */   public static final double[] fraction = { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D };
/*   28 */   public static final int[] days = { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*      */   public static final String METER_PROTOCOL_BB = "10";
/*      */   public static final String METER_PROTOCOL_ZJ = "20";
/*      */   public static final String METER_PROTOCOL_SM = "40";
/*   33 */   private static final Log log = LogFactory.getLog(ParseTool.class);
/*   34 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*      */ 
/*      */   public static String BytesToHex(byte[] data, int start, int len)
/*      */   {
/*   44 */     StringBuffer sb = new StringBuffer();
/*   45 */     for (int i = start; i < start + len; ++i) {
/*   46 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*   47 */       sb.append(hex[(data[i] & 0xF)]);
/*   48 */       sb.append(" ");
/*      */     }
/*   50 */     return sb.substring(0, sb.length() - 1);
/*      */   }
/*      */ 
/*      */   public static String ByteToHex(byte data) {
/*   54 */     String bt = "";
/*   55 */     bt = hex[((data & 0xF0) >> 4)] + hex[(data & 0xF)];
/*   56 */     return bt;
/*      */   }
/*      */ 
/*      */   public static String BytesToHexL(byte[] data, int start, int len)
/*      */   {
/*   67 */     StringBuffer sb = new StringBuffer();
/*   68 */     for (int i = start; i < start + len; ++i) {
/*   69 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*   70 */       sb.append(hex[(data[i] & 0xF)]);
/*      */     }
/*   72 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesToHexC(byte[] data, int start, int len)
/*      */   {
/*   83 */     StringBuffer sb = new StringBuffer();
/*   84 */     int loc = start + len - 1;
/*   85 */     for (int i = 0; i < len; ++i) {
/*   86 */       sb.append(hex[((data[loc] & 0xF0) >> 4)]);
/*   87 */       sb.append(hex[(data[loc] & 0xF)]);
/*   88 */       --loc;
/*      */     }
/*   90 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesToHexC(byte[] data, int start, int len, byte invalid)
/*      */   {
/*  102 */     StringBuffer sb = new StringBuffer();
/*  103 */     int loc = start + len - 1;
/*  104 */     for (int i = 0; i < len; ++i) {
/*  105 */       if (data[loc] != invalid) {
/*  106 */         sb.append(hex[((data[loc] & 0xF0) >> 4)]);
/*  107 */         sb.append(hex[(data[loc] & 0xF)]);
/*      */       }
/*  109 */       --loc;
/*      */     }
/*  111 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int BCDToDecimal(byte bcd)
/*      */   {
/*  120 */     int high = (bcd & 0xF0) >>> 4;
/*  121 */     int low = bcd & 0xF;
/*  122 */     if ((high > 9) || (low > 9)) {
/*  123 */       return -1;
/*      */     }
/*  125 */     return (high * 10 + low);
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimal(byte[] data, int start, int len)
/*      */   {
/*  136 */     int rt = 0;
/*  137 */     for (int i = 0; i < len; ++i) {
/*  138 */       rt *= 100;
/*      */ 
/*  140 */       int bval = BCDToDecimal(data[(start + len - i - 1)]);
/*  141 */       if (bval < 0) {
/*  142 */         rt = -1;
/*  143 */         break;
/*      */       }
/*  145 */       rt += bval;
/*      */     }
/*  147 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimalC(byte[] data, int start, int len)
/*      */   {
/*  158 */     int rt = 0;
/*  159 */     for (int i = start; i < start + len; ++i) {
/*  160 */       rt *= 100;
/*  161 */       int bval = BCDToDecimal(data[i]);
/*  162 */       if (bval < 0) {
/*  163 */         rt = -1;
/*  164 */         break;
/*      */       }
/*  166 */       rt += bval;
/*      */     }
/*  168 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimalS(byte[] data, int start, int len)
/*      */   {
/*  179 */     NumberFormat nf = NumberFormat.getInstance();
/*  180 */     nf.setMaximumFractionDigits(2);
/*  181 */     int rt = 0;
/*      */ 
/*  183 */     int loc1 = start + len - 1;
/*  184 */     for (int i = 0; i < len; ++i)
/*      */     {
/*      */       int bval;
/*  185 */       rt *= 100;
/*      */ 
/*  192 */       if (i > 0)
/*  193 */         bval = BCDToDecimal(data[(loc1 - i)]);
/*      */       else {
/*  195 */         bval = BCDToDecimal((byte)(data[(loc1 - i)] & 0xF));
/*      */       }
/*  197 */       if (bval < 0) {
/*  198 */         rt = -1;
/*  199 */         break;
/*      */       }
/*  201 */       rt += bval;
/*      */     }
/*      */ 
/*  204 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nByteToInt(byte[] data, int start, int len)
/*      */   {
/*  215 */     int rt = 0;
/*  216 */     for (int i = 0; i < len; ++i) {
/*  217 */       rt <<= 8;
/*  218 */       rt += (data[(start + len - i - 1)] & 0xFF);
/*      */     }
/*  220 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nByteToIntS(byte[] data, int start, int len)
/*      */   {
/*  231 */     int rt = 0;
/*  232 */     int loc = start + len - 1;
/*  233 */     for (int i = 0; i < len; ++i) {
/*  234 */       rt <<= 8;
/*  235 */       if (i > 0)
/*  236 */         rt += (data[(loc - i)] & 0xFF);
/*      */       else {
/*  238 */         rt += (data[(loc - i)] & 0x7F);
/*      */       }
/*      */     }
/*  241 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int HexToDecimal(String hex)
/*      */   {
/*  251 */     int rt = 0;
/*  252 */     for (int i = 0; i < hex.length(); ++i) {
/*  253 */       rt <<= 4;
/*  254 */       rt += CharToDecimal(hex.substring(i, i + 1));
/*      */     }
/*  256 */     return rt;
/*      */   }
/*      */ 
/*      */   public static String toPhoneCode(byte[] data, int index, int len, int invalid)
/*      */   {
/*  268 */     StringBuffer sb = new StringBuffer();
/*  269 */     int valid = index + len - 1;
/*  270 */     for (int i = index + len - 1; i >= index; --i) {
/*  271 */       if ((data[i] & 0xFF) != invalid) {
/*  272 */         valid = i;
/*  273 */         break;
/*      */       }
/*      */     }
/*  276 */     if (valid >= index) {
/*  277 */       if ((data[valid] & 0xF0) != 0) {
/*  278 */         sb.append(hex[((data[valid] & 0xF0) >> 4)]);
/*      */       }
/*  280 */       sb.append(hex[(data[valid] & 0xF)]);
/*  281 */       --valid;
/*      */     }
/*  283 */     for (int j = valid; j >= index; --j) {
/*  284 */       sb.append(hex[((data[j] & 0xF0) >> 4)]);
/*  285 */       sb.append(hex[(data[j] & 0xF)]);
/*      */     }
/*  287 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int CharToDecimalB(String c) {
/*  291 */     int rt = 0;
/*  292 */     int head = 0;
/*  293 */     int tail = 15;
/*  294 */     rt = head + tail >> 1;
/*  295 */     while (!(hex[rt].equals(c))) {
/*  296 */       if (head == tail) {
/*      */         break;
/*      */       }
/*      */ 
/*  300 */       int var = c.compareTo(hex[rt]);
/*  301 */       if (var == 0) {
/*      */         break;
/*      */       }
/*  304 */       if (var > 0) {
/*  305 */         if (rt == head) {
/*  306 */           rt = tail;
/*  307 */           break;
/*      */         }
/*  309 */         head = rt;
/*  310 */         rt = head + tail >> 1;
/*      */       } else {
/*  312 */         tail = rt;
/*  313 */         rt = head + tail >> 1;
/*      */       }
/*      */     }
/*  316 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int CharToDecimal(String hex) {
/*  320 */     int rt = 0;
/*  321 */     if (hex.equals("0")) {
/*  322 */       return 0;
/*      */     }
/*  324 */     if (hex.equals("1")) {
/*  325 */       return 1;
/*      */     }
/*  327 */     if (hex.equals("2")) {
/*  328 */       return 2;
/*      */     }
/*  330 */     if (hex.equals("3")) {
/*  331 */       return 3;
/*      */     }
/*  333 */     if (hex.equals("4")) {
/*  334 */       return 4;
/*      */     }
/*  336 */     if (hex.equals("5")) {
/*  337 */       return 5;
/*      */     }
/*  339 */     if (hex.equals("6")) {
/*  340 */       return 6;
/*      */     }
/*  342 */     if (hex.equals("7")) {
/*  343 */       return 7;
/*      */     }
/*  345 */     if (hex.equals("8")) {
/*  346 */       return 8;
/*      */     }
/*  348 */     if (hex.equals("9")) {
/*  349 */       return 9;
/*      */     }
/*  351 */     if ((hex.equals("A")) || (hex.equals("a"))) {
/*  352 */       return 10;
/*      */     }
/*  354 */     if ((hex.equals("B")) || (hex.equals("b"))) {
/*  355 */       return 11;
/*      */     }
/*  357 */     if ((hex.equals("C")) || (hex.equals("c"))) {
/*  358 */       return 12;
/*      */     }
/*  360 */     if ((hex.equals("D")) || (hex.equals("d"))) {
/*  361 */       return 13;
/*      */     }
/*  363 */     if ((hex.equals("E")) || (hex.equals("e"))) {
/*  364 */       return 14;
/*      */     }
/*  366 */     if ((hex.equals("F")) || (hex.equals("f"))) {
/*  367 */       return 15;
/*      */     }
/*  369 */     return rt;
/*      */   }
/*      */ 
/*      */   public static String IntToHex(int data)
/*      */   {
/*  378 */     StringBuffer sb = new StringBuffer();
/*  379 */     sb.append(hex[((data & 0xF000) >>> 12)]);
/*  380 */     sb.append(hex[((data & 0xF00) >>> 8)]);
/*  381 */     sb.append(hex[((data & 0xF0) >>> 4)]);
/*  382 */     sb.append(hex[(data & 0xF)]);
/*  383 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String IntToHex4(int data)
/*      */   {
/*  392 */     StringBuffer sb = new StringBuffer();
/*  393 */     sb.append(hex[((data & 0xF0000000) >>> 28)]);
/*  394 */     sb.append(hex[((data & 0xF000000) >>> 24)]);
/*  395 */     sb.append(hex[((data & 0xF00000) >>> 20)]);
/*  396 */     sb.append(hex[((data & 0xF0000) >>> 16)]);
/*  397 */     sb.append(hex[((data & 0xF000) >>> 12)]);
/*  398 */     sb.append(hex[((data & 0xF00) >>> 8)]);
/*  399 */     sb.append(hex[((data & 0xF0) >>> 4)]);
/*  400 */     sb.append(hex[(data & 0xF)]);
/*  401 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String ByteBit(byte data)
/*      */   {
/*  410 */     StringBuffer sb = new StringBuffer();
/*  411 */     int bd = data & 0xFF;
/*  412 */     for (int i = 0; i < 8; ++i) {
/*  413 */       if ((bd & 0x80) > 0)
/*  414 */         sb.append("1");
/*      */       else {
/*  416 */         sb.append("0");
/*      */       }
/*  418 */       bd <<= 1;
/*      */     }
/*  420 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String ByteBitC(byte data)
/*      */   {
/*  429 */     StringBuffer sb = new StringBuffer();
/*  430 */     int bd = data & 0xFF;
/*  431 */     for (int i = 0; i < 8; ++i) {
/*  432 */       if ((bd & 0x1) > 0)
/*  433 */         sb.append("1");
/*      */       else {
/*  435 */         sb.append("0");
/*      */       }
/*  437 */       bd >>>= 1;
/*      */     }
/*  439 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBit(byte[] data)
/*      */   {
/*  448 */     StringBuffer sb = new StringBuffer();
/*  449 */     int len = data.length;
/*  450 */     for (int i = 0; i < len; ++i) {
/*  451 */       sb.append(ByteBit(data[(len - i - 1)]));
/*      */     }
/*  453 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBit(byte[] data, int start, int len)
/*      */   {
/*  464 */     StringBuffer sb = new StringBuffer();
/*  465 */     int loc = start + len - 1;
/*  466 */     for (int i = 0; i < len; ++i) {
/*  467 */       sb.append(ByteBit(data[loc]));
/*  468 */       --loc;
/*      */     }
/*  470 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBitC(byte[] data, int start, int len)
/*      */   {
/*  481 */     StringBuffer sb = new StringBuffer();
/*  482 */     int loc = start;
/*  483 */     for (int i = 0; i < len; ++i) {
/*  484 */       sb.append(ByteBitC(data[loc]));
/*  485 */       ++loc;
/*      */     }
/*  487 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int bitToBytes(byte[] frame, String bits, int pos)
/*      */   {
/*  498 */     int rt = -1;
/*      */     try {
/*  500 */       int vlen = bits.length();
/*  501 */       boolean valid = true;
/*  502 */       for (int i = 0; i < vlen; ++i) {
/*  503 */         if (bits.substring(i, i + 1).equals("0")) continue; if (bits.substring(i, i + 1).equals("1")) {
/*      */           continue;
/*      */         }
/*  506 */         valid = false;
/*  507 */         break;
/*      */       }
/*      */ 
/*  510 */       if ((valid) && ((vlen & 0x7) == 0)) {
/*  511 */         int blen = 0;
/*  512 */         int len = vlen >>> 3;
/*  513 */         int iloc = pos + len - 1;
/*  514 */         while (blen < vlen) {
/*  515 */           frame[iloc] = bitToByte(bits.substring(blen, blen + 8));
/*  516 */           blen += 8;
/*  517 */           --iloc;
/*      */         }
/*  519 */         rt = len;
/*      */       }
/*  521 */       return rt;
/*      */     } catch (Exception e) {
/*  523 */       log.error("bits to bytes", e);
/*      */     }
/*  525 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int bitToBytesC(byte[] frame, String bits, int pos)
/*      */   {
/*  536 */     int rt = -1;
/*      */     try {
/*  538 */       int vlen = bits.length();
/*  539 */       boolean valid = true;
/*  540 */       for (int i = 0; i < vlen; ++i) {
/*  541 */         if (bits.substring(i, i + 1).equals("0")) continue; if (bits.substring(i, i + 1).equals("1")) {
/*      */           continue;
/*      */         }
/*  544 */         valid = false;
/*  545 */         break;
/*      */       }
/*      */ 
/*  548 */       if ((valid) && ((vlen & 0x7) == 0)) {
/*  549 */         int blen = 0;
/*  550 */         int len = vlen >>> 3;
/*  551 */         int iloc = pos;
/*  552 */         while (blen < vlen) {
/*  553 */           frame[iloc] = bitToByteC(bits.substring(blen, blen + 8));
/*  554 */           blen += 8;
/*  555 */           ++iloc;
/*      */         }
/*  557 */         rt = len;
/*      */       }
/*  559 */       return rt;
/*      */     } catch (Exception e) {
/*  561 */       log.error("bits to bytes", e);
/*      */     }
/*  563 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte bitToByte(String value)
/*      */   {
/*  572 */     byte rt = 0;
/*  573 */     byte[] aa = value.getBytes();
/*  574 */     for (int i = 0; i < aa.length; ++i) {
/*  575 */       rt = (byte)(rt << 1);
/*  576 */       rt = (byte)(rt + AsciiToInt(aa[i]));
/*      */     }
/*  578 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte bitToByteC(String value)
/*      */   {
/*  587 */     byte rt = 0;
/*  588 */     byte[] aa = value.getBytes();
/*  589 */     for (int i = aa.length - 1; i >= 0; --i) {
/*  590 */       rt = (byte)(rt << 1);
/*  591 */       rt = (byte)(rt + AsciiToInt(aa[i]));
/*      */     }
/*  593 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte IntToBcd(int data)
/*      */   {
/*  602 */     byte rt = 0;
/*  603 */     int i = data;
/*  604 */     i %= 100;
/*  605 */     rt = (byte)(i % 10 + (i / 10 << 4));
/*  606 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void IntToBcd(byte[] frame, int value, int loc, int len)
/*      */   {
/*  617 */     int val = value;
/*  618 */     int valxx = val % 100;
/*  619 */     for (int i = 0; i < len; ++i) {
/*  620 */       frame[(loc + i)] = (byte)(valxx % 10 + (valxx / 10 << 4));
/*  621 */       val /= 100;
/*  622 */       valxx = val % 100;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void IntToBcdC(byte[] frame, int value, int loc, int len)
/*      */   {
/*  634 */     int val = value;
/*  635 */     int valxx = val % 100;
/*  636 */     int start = loc + len - 1;
/*  637 */     for (int i = 0; i < len; ++i) {
/*  638 */       frame[start] = (byte)(valxx % 10 + (valxx / 10 << 4));
/*  639 */       val /= 100;
/*  640 */       valxx = val % 100;
/*  641 */       --start;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte StringToBcd(String data)
/*      */   {
/*  651 */     byte rt = 0;
/*      */     try {
/*  653 */       int i = Integer.parseInt(data);
/*  654 */       rt = IntToBcd(i);
/*      */     } catch (Exception e) {
/*  656 */       e.printStackTrace();
/*      */     }
/*  658 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int ByteToFlag(byte data)
/*      */   {
/*  667 */     int rt = 0;
/*  668 */     int val = data & 0xFF;
/*  669 */     int flag = 1;
/*  670 */     if (data > 0) {
/*  671 */       rt = 1;
/*  672 */       while ((flag & val) <= 0) {
/*  673 */         ++rt;
/*  674 */         flag <<= 1;
/*      */       }
/*      */     }
/*  677 */     return rt;
/*      */   }
/*      */ 
/*      */   public static double ByteToPercent(byte data)
/*      */   {
/*  686 */     double rt = data & 0x7F;
/*  687 */     if ((data & 0x80) > 0) {
/*  688 */       rt *= -1.0D;
/*      */     }
/*  690 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void StringToBcds(byte[] frame, int loc, String data)
/*      */   {
/*  699 */     String row = data;
/*  700 */     if (row.length() > 0) {
/*  701 */       if (row.length() % 2 > 0) {
/*  702 */         row = "0" + row;
/*      */       }
/*  704 */       int len = row.length() / 2;
/*      */ 
/*  706 */       for (int i = 0; i < len; ++i) {
/*  707 */         frame[(loc + len - i - 1)] = StringToBcd(row.substring(i << 1, i + 1 << 1));
/*      */       }
/*  709 */       row = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void StringToBcds1(byte[] frame, int loc, String data)
/*      */   {
/*  719 */     String row = data;
/*  720 */     if (row.length() > 0) {
/*  721 */       if (row.length() % 2 > 0) {
/*  722 */         row = "0" + row;
/*      */       }
/*  724 */       int len = row.length() / 2;
/*      */ 
/*  726 */       for (int i = 0; i < len; ++i) {
/*  727 */         frame[(loc + len - i - 1)] = StringToBcd(row.substring(i << 1, i + 1 << 1));
/*      */       }
/*  729 */       row = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte[] StringToBcdDec(String data) {
/*  734 */     if ((null == data) || (0 == data.length()))
/*  735 */       return new byte[0];
/*  736 */     if (0 != data.length() % 2)
/*  737 */       data = "0" + data;
/*  738 */     byte[] ret = new byte[data.length() / 2];
/*  739 */     int j = ret.length - 1;
/*      */ 
/*  741 */     for (int i = 0; i < data.length() - 1; i += 2) {
/*  742 */       byte b1 = (byte)(data.charAt(i) - '0');
/*  743 */       byte b2 = (byte)(data.charAt(i + 1) - '0');
/*  744 */       ret[(j--)] = (byte)((b1 << 4) + b2);
/*      */     }
/*  746 */     return ret;
/*      */   }
/*      */ 
/*      */   public static void StringToBcds(byte[] frame, int loc, String data, int len, byte invalid)
/*      */   {
/*  758 */     int slen = (data.length() >>> 1) + (data.length() & 0x1);
/*  759 */     int iloc = slen + loc - 1;
/*  760 */     int head = 0;
/*  761 */     if ((data.length() & 0x1) > 0) {
/*  762 */       frame[iloc] = StringToBcd(data.substring(0, 1));
/*  763 */       head = 1;
/*      */     } else {
/*  765 */       frame[iloc] = StringToBcd(data.substring(0, 2));
/*  766 */       head = 2;
/*      */     }
/*  768 */     --iloc;
/*  769 */     for (int i = 1; i < slen; ++i) {
/*  770 */       frame[iloc] = StringToBcd(data.substring(head, head + 2));
/*  771 */       head += 2;
/*  772 */       --iloc;
/*      */     }
/*  774 */     iloc = slen + loc;
/*  775 */     for (i = slen; i < len; ++i) {
/*  776 */       frame[iloc] = invalid;
/*  777 */       ++iloc;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesC(byte[] frame, int loc, String data)
/*      */   {
/*      */     try
/*      */     {
/*  788 */       int len = (data.length() >>> 1) + (data.length() & 0x1);
/*  789 */       int head = 0;
/*  790 */       if ((data.length() & 0x1) > 0) {
/*  791 */         frame[loc] = HexToByte(data.substring(0, 1));
/*  792 */         head = 1;
/*      */       } else {
/*  794 */         frame[loc] = HexToByte(data.substring(0, 2));
/*  795 */         head = 2;
/*      */       }
/*  797 */       for (int i = 1; i < len; ++i) {
/*  798 */         frame[(i + loc)] = HexToByte(data.substring(head, head + 2));
/*  799 */         head += 2;
/*      */       }
/*      */     } catch (Exception e) {
/*  802 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte HexToByte(String data) {
/*  807 */     int rt = 0;
/*  808 */     if (data.length() <= 2) {
/*  809 */       for (int i = 0; i < data.length(); ++i) {
/*  810 */         rt <<= 4;
/*  811 */         rt += CharToDecimal(data.substring(i, i + 1));
/*      */       }
/*      */     }
/*  814 */     return (byte)rt;
/*      */   }
/*      */ 
/*      */   public static int AsciiToInt(byte val) {
/*  818 */     int rt = val & 0xFF;
/*  819 */     if (val < 58)
/*  820 */       rt -= 48;
/*  821 */     else if (rt < 71)
/*  822 */       rt -= 55;
/*      */     else {
/*  824 */       rt -= 87;
/*      */     }
/*  826 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesCB(byte[] frame, int loc, String hex)
/*      */   {
/*      */     try
/*      */     {
/*  836 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*      */ 
/*  838 */       byte[] bt = hex.getBytes();
/*  839 */       int head = 0;
/*  840 */       if ((hex.length() & 0x1) > 0) {
/*  841 */         frame[loc] = (byte)AsciiToInt(bt[0]);
/*  842 */         head = 1;
/*      */       } else {
/*  844 */         frame[loc] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  845 */         head = 2;
/*      */       }
/*  847 */       for (int i = 1; i < len; ++i) {
/*  848 */         frame[(loc + i)] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  849 */         head += 2;
/*      */       }
/*      */     } catch (Exception e) {
/*  852 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytes(byte[] frame, int loc, String hex)
/*      */   {
/*      */     try
/*      */     {
/*  863 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*  864 */       byte[] bt = hex.getBytes();
/*  865 */       int head = 0;
/*  866 */       if ((hex.length() & 0x1) > 0) {
/*  867 */         frame[(loc + len - 1)] = (byte)AsciiToInt(bt[0]);
/*  868 */         head = 1;
/*      */       } else {
/*  870 */         frame[(loc + len - 1)] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  871 */         head = 2;
/*      */       }
/*  873 */       int start = loc + len - 2;
/*  874 */       for (int i = 1; i < len; ++i) {
/*  875 */         frame[start] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  876 */         head += 2;
/*  877 */         --start;
/*      */       }
/*      */     } catch (Exception e) {
/*  880 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesAA(byte[] frame, int loc, String hex, int flen, byte invalid)
/*      */   {
/*      */     try
/*      */     {
/*  891 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*  892 */       byte[] bt = hex.getBytes();
/*  893 */       int head = 0;
/*  894 */       if ((hex.length() & 0x1) > 0) {
/*  895 */         frame[(loc + len - 1)] = (byte)AsciiToInt(bt[0]);
/*  896 */         head = 1;
/*      */       } else {
/*  898 */         frame[(loc + len - 1)] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  899 */         head = 2;
/*      */       }
/*  901 */       int start = loc + len - 2;
/*  902 */       for (int i = 1; i < len; ++i) {
/*  903 */         frame[start] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  904 */         head += 2;
/*  905 */         --start;
/*      */       }
/*  907 */       start = len + loc;
/*  908 */       for (i = len; i < flen; ++i) {
/*  909 */         frame[start] = invalid;
/*  910 */         ++start;
/*      */       }
/*      */     } catch (Exception e) {
/*  913 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void DecimalToBytes(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  926 */       int vals = val;
/*  927 */       for (int i = 0; i < len; ++i) {
/*  928 */         frame[(loc + i)] = (byte)(vals & 0xFF);
/*  929 */         vals >>>= 8;
/*      */       }
/*      */     } catch (Exception e) {
/*  932 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void DecimalToBytesC(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  945 */       int vals = val;
/*  946 */       for (int i = 0; i < len; ++i) {
/*  947 */         frame[(loc + len - 1 - i)] = (byte)(vals & 0xFF);
/*  948 */         vals >>>= 8;
/*      */       }
/*      */     } catch (Exception e) {
/*  951 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void RtuaToBytesC(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  964 */       frame[loc] = (byte)((val & 0xFF000000) >>> 24);
/*  965 */       frame[(loc + 1)] = (byte)((val & 0xFF0000) >>> 16);
/*  966 */       frame[(loc + 2)] = (byte)(val & 0xFF);
/*  967 */       frame[(loc + 3)] = (byte)((val & 0xFF00) >>> 8);
/*      */     } catch (Exception e) {
/*  969 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void RtuaToBytesC(byte[] frame, String val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  982 */       int ival = Integer.parseInt(val);
/*  983 */       frame[loc] = (byte)((ival & 0xFF000000) >>> 24);
/*  984 */       frame[(loc + 1)] = (byte)((ival & 0xFF0000) >>> 16);
/*  985 */       frame[(loc + 2)] = (byte)(ival & 0xFF);
/*  986 */       frame[(loc + 3)] = (byte)((ival & 0xFF00) >>> 8);
/*      */     } catch (Exception e) {
/*  988 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte[] DateToBytes(String time, int len, int type)
/*      */   {
/* 1000 */     byte[] rt = null;
/*      */     try
/*      */     {
/*      */       SimpleDateFormat sdf;
/*      */       Date date;
/*      */       Calendar cd;
/* 1002 */       if (type == 0) {
/* 1003 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1004 */         date = sdf.parse(time);
/* 1005 */         cd = Calendar.getInstance();
/* 1006 */         cd.setTime(date);
/* 1007 */         rt = new byte[6];
/* 1008 */         rt[0] = IntToBcd(cd.get(13));
/* 1009 */         rt[1] = IntToBcd(cd.get(12));
/* 1010 */         rt[2] = IntToBcd(cd.get(11));
/* 1011 */         rt[3] = IntToBcd(cd.get(5));
/* 1012 */         rt[4] = IntToBcd(cd.get(2) + 1);
/* 1013 */         rt[5] = IntToBcd(cd.get(1));
/*      */       }
/* 1015 */       if (type == 1) {
/* 1016 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/* 1017 */         date = sdf.parse(time);
/* 1018 */         cd = Calendar.getInstance();
/* 1019 */         cd.setTime(date);
/* 1020 */         rt = new byte[5];
/* 1021 */         rt[0] = IntToBcd(cd.get(12));
/* 1022 */         rt[1] = IntToBcd(cd.get(11));
/* 1023 */         rt[2] = IntToBcd(cd.get(5));
/* 1024 */         rt[3] = IntToBcd(cd.get(2) + 1);
/* 1025 */         rt[4] = IntToBcd(cd.get(1));
/*      */       }
/*      */     } catch (Exception e) {
/* 1028 */       e.printStackTrace();
/*      */     }
/* 1030 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte[] TimeToBytes(String time, int len, int type)
/*      */   {
/* 1041 */     byte[] rt = null;
/*      */     try {
/* 1043 */       String[] cells = time.split(":");
/* 1044 */       if (type == 0) {
/* 1045 */         rt = new byte[3];
/* 1046 */         rt[0] = IntToBcd(Integer.parseInt(cells[2]));
/* 1047 */         rt[1] = IntToBcd(Integer.parseInt(cells[1]));
/* 1048 */         rt[2] = IntToBcd(Integer.parseInt(cells[0]));
/*      */       }
/* 1050 */       if (type == 1) {
/* 1051 */         rt = new byte[2];
/* 1052 */         rt[0] = IntToBcd(Integer.parseInt(cells[1]));
/* 1053 */         rt[1] = IntToBcd(Integer.parseInt(cells[0]));
/*      */       }
/*      */     } catch (Exception e) {
/* 1056 */       e.printStackTrace();
/*      */     }
/* 1058 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int getOrientation(IMessage message)
/*      */   {
/* 1067 */     int rt = 0;
/*      */     try {
/* 1069 */       byte reply = ((MessageZj)message).head.c_dir;
/* 1070 */       if ((reply & 0xFF) > 0)
/* 1071 */         rt = 1;
/*      */     }
/*      */     catch (Exception e) {
/* 1074 */       e.printStackTrace();
/*      */     }
/* 1076 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int getErrCode(IMessage message)
/*      */   {
/* 1085 */     int rt = 0;
/*      */     try {
/* 1087 */       byte err = ((MessageZj)message).head.c_expflag;
/* 1088 */       rt = err & 0xFF;
/*      */     } catch (Exception e) {
/* 1090 */       e.printStackTrace();
/*      */     }
/* 1092 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte[] getData(IMessage message)
/*      */   {
/* 1101 */     byte[] rt = null;
/*      */     try {
/* 1103 */       ByteBuffer data = null;
/* 1104 */       if (message instanceof MessageZj) {
/* 1105 */         data = ((MessageZj)message).data;
/*      */       }
/* 1107 */       data.rewind();
/* 1108 */       int len = data.limit();
/* 1109 */       if (len > 0) {
/* 1110 */         rt = new byte[len];
/* 1111 */         data.get(rt);
/*      */       }
/*      */     } catch (Exception e) {
/* 1114 */       e.printStackTrace();
/*      */     }
/* 1116 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTime(byte[] data, int offset)
/*      */   {
/* 1126 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1128 */       int num = BCDToDecimal(data[(4 + offset)]);
/* 1129 */       rt.set(1, num + 2000);
/* 1130 */       num = BCDToDecimal((byte)(data[(3 + offset)] & 0x1F));
/* 1131 */       rt.set(2, num - 1);
/* 1132 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1133 */       rt.set(5, num);
/* 1134 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x3F));
/* 1135 */       rt.set(11, num);
/* 1136 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1137 */       rt.set(12, num);
/* 1138 */       rt.set(13, 0);
/* 1139 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1141 */       e.printStackTrace();
/*      */     }
/* 1143 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeW(byte[] data, int offset)
/*      */   {
/* 1153 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1155 */       int num = BCDToDecimal(data[(5 + offset)]);
/* 1156 */       rt.set(1, num + 2000);
/* 1157 */       num = BCDToDecimal((byte)(data[(4 + offset)] & 0x1F));
/* 1158 */       rt.set(2, num - 1);
/* 1159 */       num = BCDToDecimal((byte)(data[(3 + offset)] & 0x3F));
/* 1160 */       rt.set(5, num);
/* 1161 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1162 */       rt.set(11, num);
/* 1163 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x7F));
/* 1164 */       rt.set(12, num);
/* 1165 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1166 */       rt.set(13, num);
/* 1167 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1169 */       e.printStackTrace();
/*      */     }
/* 1171 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeM(byte[] data, int offset)
/*      */   {
/* 1181 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1183 */       int num = BCDToDecimal((byte)(data[(3 + offset)] & 0x1F));
/* 1184 */       rt.set(2, num - 1);
/* 1185 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1186 */       rt.set(5, num);
/* 1187 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x3F));
/* 1188 */       rt.set(11, num);
/* 1189 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1190 */       rt.set(12, num);
/* 1191 */       rt.set(13, 0);
/* 1192 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1194 */       e.printStackTrace();
/*      */     }
/* 1196 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeL(byte[] data, int offset)
/*      */   {
/* 1206 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1208 */       int num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1209 */       rt.set(11, num);
/* 1210 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x5F));
/* 1211 */       rt.set(12, num);
/* 1212 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x5F));
/* 1213 */       rt.set(13, 0);
/* 1214 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1216 */       e.printStackTrace();
/*      */     }
/* 1218 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void IPToBytes(byte[] frame, int loc, String ip)
/*      */   {
/*      */     try
/*      */     {
/* 1229 */       String[] para = ip.split(":");
/* 1230 */       Inet4Address netaddress = (Inet4Address)Inet4Address.getByName(para[0]);
/* 1231 */       byte[] bip = netaddress.getAddress();
/* 1232 */       for (int i = 0; i < bip.length; ++i) {
/* 1233 */         frame[(loc + 2 + i)] = bip[(bip.length - i - 1)];
/*      */       }
/* 1235 */       int port = Integer.parseInt(para[1]);
/* 1236 */       frame[loc] = (byte)(port & 0xFF);
/* 1237 */       frame[(loc + 1)] = (byte)((port & 0xFF00) >> 8);
/*      */     } catch (Exception e) {
/* 1239 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean isValid(byte[] data, int start, int len)
/*      */   {
/* 1251 */     boolean rt = false;
/* 1252 */     for (int i = start; i < start + len; ++i) {
/* 1253 */       if ((data[i] & 0xFF) != 255) {
/* 1254 */         rt = true;
/* 1255 */         break;
/*      */       }
/*      */     }
/* 1258 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidBCD(byte[] data, int start, int len)
/*      */   {
/* 1269 */     boolean rt = true;
/* 1270 */     if ((data[start] & 0xFF) == 255) {
/* 1271 */       rt = !(isAllFF(data, start, len));
/*      */     }
/* 1273 */     if ((data[start] & 0xFF) == 238)
/*      */     {
/* 1275 */       rt = false;
/*      */     }
/* 1277 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isHaveValidBCD(byte[] data, int start, int len)
/*      */   {
/* 1287 */     boolean rt = true;
/* 1288 */     rt = !(isHaveFF(data, start, len));
/* 1289 */     if ((data[start] & 0xFF) == 238)
/*      */     {
/* 1291 */       rt = false;
/*      */     }
/* 1293 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isAllEE(byte[] data, int start, int len)
/*      */   {
/* 1303 */     boolean rt = true;
/* 1304 */     for (int i = start; i < start + len; ++i) {
/* 1305 */       if ((data[i] & 0xFF) != 238) {
/* 1306 */         rt = false;
/* 1307 */         break;
/*      */       }
/*      */     }
/* 1310 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isAllFF(byte[] data, int start, int len)
/*      */   {
/* 1320 */     boolean rt = true;
/* 1321 */     for (int i = start; i < start + len; ++i) {
/* 1322 */       if ((data[i] & 0xFF) != 255) {
/* 1323 */         rt = false;
/* 1324 */         break;
/*      */       }
/*      */     }
/* 1327 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isHaveFF(byte[] data, int start, int len)
/*      */   {
/* 1337 */     boolean rt = false;
/* 1338 */     for (int i = start; i < start + len; ++i) {
/* 1339 */       if ((data[i] & 0xFF) == 255) {
/* 1340 */         rt = true;
/* 1341 */         break;
/*      */       }
/*      */     }
/* 1344 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidMonth(byte data)
/*      */   {
/* 1352 */     boolean rt = false;
/* 1353 */     int hi = BCDToDecimal(data);
/* 1354 */     if ((hi >= 0) && (hi <= 12)) {
/* 1355 */       rt = true;
/*      */     }
/* 1357 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidDay(byte data, int month, int year)
/*      */   {
/* 1368 */     boolean rt = false;
/* 1369 */     int hi = BCDToDecimal(data);
/* 1370 */     if ((hi >= 0) && (hi <= 31)) {
/* 1371 */       if (month == 2) {
/* 1372 */         if (year < 0) {
/* 1373 */           if (hi < days[month]) {
/* 1374 */             rt = true;
/*      */           }
/*      */         }
/* 1377 */         else if (isLeapYear(year)) {
/* 1378 */           if (hi <= 29) {
/* 1379 */             rt = true;
/*      */           }
/*      */         }
/* 1382 */         else if (hi <= 28) {
/* 1383 */           rt = true;
/*      */         }
/*      */ 
/*      */       }
/* 1388 */       else if (hi <= days[month]) {
/* 1389 */         rt = true;
/*      */       }
/*      */     }
/*      */ 
/* 1393 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidHHMMSS(byte data)
/*      */   {
/* 1402 */     boolean rt = false;
/* 1403 */     int hi = BCDToDecimal(data);
/* 1404 */     if ((hi >= 0) && (hi <= 60)) {
/* 1405 */       rt = true;
/*      */     }
/* 1407 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isLeapYear(int year)
/*      */   {
/* 1416 */     boolean rt = false;
/* 1417 */     if (year >= 0) {
/* 1418 */       if (year % 100 == 0) {
/* 1419 */         if (year % 400 == 0) {
/* 1420 */           rt = true;
/*      */         }
/*      */       }
/* 1423 */       else if (year % 4 == 0) {
/* 1424 */         rt = true;
/*      */       }
/*      */     }
/*      */ 
/* 1428 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte calculateCS(byte[] data, int start, int len)
/*      */   {
/* 1433 */     int cs = 0;
/* 1434 */     for (int i = start; i < start + len; ++i) {
/* 1435 */       cs += (data[i] & 0xFF);
/* 1436 */       cs &= 255;
/*      */     }
/* 1438 */     return (byte)(cs & 0xFF);
/*      */   }
/*      */ 
/*      */   public static String getMeterProtocol(String type)
/*      */   {
/* 1447 */     if (type != null) {
/* 1448 */       if (type.equals("10")) {
/* 1449 */         return "BBMeter";
/*      */       }
/* 1451 */       if (type.equals("20")) {
/* 1452 */         return "ZJMeter";
/*      */       }
/* 1454 */       if (type.equals("30")) {
/* 1455 */         return "BBMeter";
/*      */       }
/* 1457 */       if (type.equals("40")) {
/* 1458 */         return "SMMeter";
/*      */       }
/*      */     }
/* 1461 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isTask(int datakey)
/*      */   {
/* 1470 */     boolean rt = false;
/* 1471 */     if ((datakey >= 33025) && (datakey < 33278)) {
/* 1472 */       rt = true;
/*      */     }
/* 1474 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidBCDString(String val) {
/* 1478 */     boolean rt = true;
/* 1479 */     if (val != null) {
/* 1480 */       for (int i = 0; i < val.length(); ++i) {
/* 1481 */         char c = val.charAt(i);
/* 1482 */         if ((c >= '0') && (c <= '9')) {
/*      */           continue;
/*      */         }
/* 1485 */         rt = false;
/* 1486 */         break;
/*      */       }
/*      */     }
/*      */     else {
/* 1490 */       rt = false;
/*      */     }
/* 1492 */     return rt;
/*      */   }
/*      */ }