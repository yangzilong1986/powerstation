/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class Parser11
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  20 */     Object rt = null;
/*     */     try {
/*  22 */       boolean ok = true;
/*     */ 
/*  26 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  27 */       if (ok) {
/*  28 */         StringBuffer sb = new StringBuffer();
/*  29 */         sb.append("20");
/*  30 */         sb.append(ParseTool.ByteToHex(data[(loc + 7)]));
/*  31 */         sb.append("-");
/*  32 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/*  33 */         sb.append("-");
/*  34 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  35 */         sb.append(" ");
/*  36 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/*  37 */         sb.append(":");
/*  38 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  39 */         sb.append(",");
/*  40 */         boolean bn = (data[(loc + 3 - 1)] & 0x10) > 0;
/*  41 */         int val = ParseTool.nBcdToDecimalS(data, loc, 3);
/*  42 */         if (bn) {
/*  43 */           val = -val;
/*     */         }
/*  45 */         sb.append(String.valueOf(val / ParseTool.fraction[2]));
/*  46 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  49 */       e.printStackTrace();
/*     */     }
/*  51 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  66 */       for (int i = 0; i < value.length(); ++i) {
/*  67 */         char c = value.charAt(i);
/*  68 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  71 */         if (c == ':') {
/*     */           continue;
/*     */         }
/*  74 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  77 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  80 */         if (c == ' ') {
/*     */           continue;
/*     */         }
/*  83 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  86 */         throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm SXXX.XX 组帧参数:" + value);
/*     */       }
/*  88 */       String[] para = value.split(",");
/*  89 */       String[] dpara = para[0].split(" ");
/*  90 */       String[] date = dpara[0].split("-");
/*  91 */       String[] time = dpara[1].split(":");
/*     */ 
/*  93 */       Parser02.constructor(frame, para[1], loc, 3, 2);
/*  94 */       frame[(loc + 7)] = ParseTool.StringToBcd(date[0]);
/*  95 */       frame[(loc + 6)] = ParseTool.StringToBcd(date[1]);
/*  96 */       frame[(loc + 5)] = ParseTool.StringToBcd(date[2]);
/*  97 */       frame[(loc + 4)] = ParseTool.StringToBcd(time[0]);
/*  98 */       frame[(loc + 3)] = ParseTool.StringToBcd(time[1]);
/*     */     } catch (Exception e) {
/* 100 */       throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm SXXX.XX 组帧参数:" + value);
/*     */     }
/*     */ 
/* 103 */     return len;
/*     */   }
/*     */ }