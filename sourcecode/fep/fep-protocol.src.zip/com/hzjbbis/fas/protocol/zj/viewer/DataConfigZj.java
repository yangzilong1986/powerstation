/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.util.CastorUtil;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class DataConfigZj
/*    */ {
/* 18 */   private static final Log log = LogFactory.getLog(DataConfigZj.class);
/*    */ 
/* 20 */   private static String DATA_MAP_FILE = "com/hzjbbis/fas/protocol/zj/conf/protocol-data-config-mapping.xml";
/* 21 */   private static String DATA_CONFIG_FILE = "com/hzjbbis/fas/protocol/zj/conf/protocol-data-config.xml";
/*    */   private static DataConfigZj _instance;
/*    */   private ProtocolDataConfig dataConfig;
/*    */ 
/*    */   private DataConfigZj()
/*    */   {
/* 28 */     dataIni();
/*    */   }
/*    */ 
/*    */   public static DataConfigZj getInstance() {
/* 32 */     if (_instance == null) {
/* 33 */       synchronized (DataConfigZj.class) {
/* 34 */         _instance = new DataConfigZj();
/*    */       }
/*    */     }
/* 37 */     return _instance;
/*    */   }
/*    */ 
/*    */   private void dataIni() {
/*    */     try {
/* 42 */       this.dataConfig = ((ProtocolDataConfig)CastorUtil.unmarshal(DATA_MAP_FILE, DATA_CONFIG_FILE));
/*    */ 
/* 44 */       this.dataConfig.fillMap();
/*    */     } catch (Exception e) {
/* 46 */       log.error("data config ini", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ProtocolDataConfig getDataConfig() {
/* 51 */     return this.dataConfig;
/*    */   }
/*    */ }