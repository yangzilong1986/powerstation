/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser46
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 24 */       if (ok)
/* 25 */         rt = ParseTool.BytesToHexC(data, loc, len, -86);
/*    */     }
/*    */     catch (Exception e) {
/* 28 */       e.printStackTrace();
/*    */     }
/* 30 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 45 */       for (int i = 0; i < value.length(); ++i) {
/* 46 */         char c = value.charAt(i);
/* 47 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 50 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 53 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 56 */         throw new MessageEncodeException("错误的 BCD 组帧参数:" + value);
/*    */       }
/* 58 */       ParseTool.HexsToBytesAA(frame, loc, value, len, -86);
/*    */     } catch (Exception e) {
/* 60 */       throw new MessageEncodeException("错误的 BCD 组帧参数:" + value);
/*    */     }
/*    */ 
/* 63 */     return len;
/*    */   }
/*    */ }