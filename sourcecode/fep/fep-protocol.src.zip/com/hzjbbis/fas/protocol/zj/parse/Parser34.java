/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser34
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 29 */       if (ok) {
/* 30 */         int tasktype = ParseTool.BCDToDecimal(data[loc]);
/* 31 */         switch (tasktype)
/*    */         {
/*    */         case 1:
/* 33 */           rt = Parser26.parsevalue(data, loc, len, fraction);
/* 34 */           break;
/*    */         case 2:
/* 36 */           rt = Parser27.parsevalue(data, loc, len, fraction);
/* 37 */           break;
/*    */         case 4:
/* 39 */           rt = Parser28.parsevalue(data, loc, len, fraction);
/*    */         case 3:
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 46 */       e.printStackTrace();
/*    */     }
/* 48 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/* 61 */     int slen = 0;
/*    */     try {
/* 63 */       int index = value.indexOf(",");
/* 64 */       if (index > 0) {
/* 65 */         int tasktype = Integer.parseInt(value.substring(0, index));
/* 66 */         switch (tasktype)
/*    */         {
/*    */         case 1:
/* 68 */           slen = Parser26.constructor(frame, value, loc, len, fraction);
/* 69 */           break;
/*    */         case 2:
/* 71 */           slen = Parser27.constructor(frame, value, loc, len, fraction);
/* 72 */           break;
/*    */         case 4:
/* 74 */           slen = Parser28.constructor(frame, value, loc, len, fraction);
/*    */         case 3:
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 81 */       throw new MessageEncodeException("错误的 任务 组帧参数:" + value);
/*    */     }
/* 83 */     return slen;
/*    */   }
/*    */ }