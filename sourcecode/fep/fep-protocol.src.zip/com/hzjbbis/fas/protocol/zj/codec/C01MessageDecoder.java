/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.model.HostCommandResult;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.ErrorCode;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C01MessageDecoder extends AbstractMessageDecoder
/*     */ {
/*  25 */   private static Log log = LogFactory.getLog(C01MessageDecoder.class);
/*     */ 
/*     */   public Object decode(IMessage message)
/*     */   {
/*  30 */     HostCommand hc = new HostCommand();
/*  31 */     List value = new ArrayList();
/*     */     try
/*     */     {
/*  34 */       if (ParseTool.getOrientation(message) == 1)
/*     */       {
/*     */         byte[] data;
/*  36 */         int rtype = ParseTool.getErrCode(message);
/*     */ 
/*  39 */         Long cmdid = new Long(0L);
/*     */ 
/*  47 */         if (rtype == 0)
/*     */         {
/*  51 */           hc.setStatus("1");
/*     */ 
/*  53 */           data = ParseTool.getData(message);
/*  54 */           if ((data != null) && (data.length > 10))
/*     */           {
/*  57 */             byte[] points = new byte[64];
/*  58 */             byte pn = 0;
/*  59 */             byte pnum = 0;
/*  60 */             for (int i = 0; i < 8; ++i) {
/*  61 */               int flag = 1;
/*  62 */               int tnm = data[i] & 0xFF;
/*  63 */               for (int j = 0; j < 8; ++j) {
/*  64 */                 if ((tnm & flag << j) > 0) {
/*  65 */                   points[pnum] = pn;
/*  66 */                   pnum = (byte)(pnum + 1);
/*     */                 }
/*  68 */                 pn = (byte)(pn + 1);
/*     */               }
/*     */             }
/*  71 */             if (pnum > 0)
/*     */             {
/*  73 */               int index = 8;
/*     */               while (true) { if (index >= data.length) break label348;
/*  75 */                 if (2 >= data.length - index) break;
/*  76 */                 int datakey = ((data[(index + 1)] & 0xFF) << 8) + (data[index] & 0xFF);
/*  77 */                 ProtocolDataItemConfig dic = getDataItemConfig(datakey);
/*  78 */                 if (dic != null) {
/*  79 */                   int loc = index + 2;
/*  80 */                   int itemlen = 0;
/*     */ 
/*  82 */                   for (int j = 0; j < pnum; ++j) {
/*  83 */                     itemlen = parseBlockData(data, loc, dic, points[j], cmdid, value);
/*  84 */                     loc += itemlen;
/*  85 */                     if (ParseTool.isTask(datakey)) {
/*  86 */                       loc = data.length;
/*  87 */                       break;
/*     */                     }
/*     */                   }
/*  90 */                   index = loc;
/*     */                 }
/*     */                 else
/*     */                 {
/*  94 */                   log.info("不支持的数据:" + ParseTool.IntToHex(datakey));
/*  95 */                   break label348:
/*     */                 }
/*     */               }
/*     */ 
/*  99 */               label348: throw new MessageDecodeException("帧数据太少");
/*     */             }
/*     */             else
/*     */             {
/* 103 */               throw new MessageDecodeException("帧内容错误，未指定测量点");
/*     */             }
/*     */           }
/*     */           else {
/* 107 */             hc.setStatus("2");
/*     */           }
/*     */         }
/*     */         else {
/* 111 */           data = ParseTool.getData(message);
/* 112 */           if ((data != null) && (data.length > 0)) {
/* 113 */             if (data.length == 1)
/* 114 */               hc.setStatus(ErrorCode.toHostCommandStatus(data[0]));
/* 115 */             else if (data.length == 9)
/* 116 */               hc.setStatus(ErrorCode.toHostCommandStatus(data[8]));
/*     */             else
/* 118 */               hc.setStatus("2");
/*     */           }
/*     */           else {
/* 121 */             hc.setStatus("2");
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 129 */       throw new MessageDecodeException(e);
/*     */     }
/* 131 */     hc.setResults(value);
/* 132 */     return hc;
/*     */   }
/*     */ 
/*     */   private int parseBlockData(byte[] data, int loc, ProtocolDataItemConfig pdc, byte point, Long cmdid, List<HostCommandResult> result)
/*     */   {
/* 145 */     int rt = 0;
/*     */     try {
/* 147 */       List children = pdc.getChildItems();
/* 148 */       int index = loc;
/* 149 */       if ((children != null) && (children.size() > 0)) {
/* 150 */         for (int i = 0; i < children.size(); ++i) {
/* 151 */           ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)children.get(i);
/* 152 */           int dlen = parseBlockData(data, index, cpdc, point, cmdid, result);
/* 153 */           index += dlen;
/* 154 */           rt += dlen;
/*     */         }
/*     */       } else {
/* 157 */         int dlen = parseItem(data, loc, pdc, point, cmdid, result);
/* 158 */         rt += dlen;
/*     */       }
/*     */     } catch (Exception e) {
/* 161 */       throw new MessageDecodeException(e);
/*     */     }
/* 163 */     return rt;
/*     */   }
/*     */ 
/*     */   private int parseItem(byte[] data, int loc, ProtocolDataItemConfig pdc, byte point, Long cmdid, List<HostCommandResult> result) {
/* 167 */     int rt = 0;
/*     */     try {
/* 169 */       int datakey = pdc.getDataKey();
/* 170 */       int itemlen = 0;
/* 171 */       if ((33024 < datakey) && (33278 > datakey)) {
/* 172 */         int tasktype = data[loc] & 0xFF;
/* 173 */         if (tasktype == 1) {
/* 174 */           if (16 < data.length - loc)
/* 175 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 15)]) * 2 + 16;
/*     */           else {
/* 177 */             throw new MessageDecodeException("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>16" + " 解析长度：" + (data.length - loc));
/*     */           }
/*     */         }
/*     */ 
/* 181 */         if (tasktype == 2) {
/* 182 */           if (21 < data.length - loc)
/* 183 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 20)]) + 21;
/*     */           else {
/* 185 */             throw new MessageDecodeException("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>21" + " 解析长度：" + (data.length - loc));
/*     */           }
/*     */         }
/*     */ 
/* 189 */         if (tasktype == 4) {
/* 190 */           if (7 < data.length - loc)
/* 191 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 6)]) * 3 + 8;
/*     */           else
/* 193 */             throw new MessageDecodeException("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>7" + " 解析长度：" + (data.length - loc));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 198 */         itemlen = pdc.getLength();
/*     */       }
/* 200 */       if (itemlen <= data.length - loc) {
/* 201 */         Object di = DataItemParser.parsevalue(data, loc, itemlen, pdc.getFraction(), pdc.getParserno());
/* 202 */         HostCommandResult hcr = new HostCommandResult();
/* 203 */         hcr.setCode(pdc.getCode());
/* 204 */         if (di != null) {
/* 205 */           hcr.setValue(di.toString());
/*     */         }
/* 207 */         hcr.setCommandId(cmdid);
/* 208 */         hcr.setTn(point + "");
/* 209 */         result.add(hcr);
/* 210 */         rt = itemlen;
/*     */       }
/* 213 */       else if (data.length - loc != 0)
/*     */       {
/* 217 */         throw new MessageDecodeException("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：" + itemlen + " 解析长度：" + (data.length - loc));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 222 */       throw new MessageDecodeException(e);
/*     */     }
/* 224 */     return rt;
/*     */   }
/*     */ 
/*     */   private ProtocolDataItemConfig getDataItemConfig(int datakey) {
/* 228 */     return this.dataConfig.getDataItemConfig(ParseTool.IntToHex(datakey));
/*     */   }
/*     */ }