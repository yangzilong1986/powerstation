/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class Parser28
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  20 */     Object rt = null;
/*     */     try {
/*  22 */       boolean ok = true;
/*     */ 
/*  26 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  27 */       if (ok) {
/*  28 */         StringBuffer sb = new StringBuffer();
/*  29 */         sb.append(ParseTool.ByteToHex(data[loc]));
/*  30 */         sb.append(",");
/*  31 */         sb.append(ParseTool.BytesToHexC(data, loc + 1, 2));
/*  32 */         sb.append(",");
/*  33 */         sb.append(String.valueOf(data[(loc + 4)] & 0xFF));
/*  34 */         sb.append(",");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  36 */         sb.append(",");
/*  37 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 5)])));
/*  38 */         sb.append(",");
/*  39 */         int din = ParseTool.BCDToDecimal(data[(loc + 6)]);
/*  40 */         sb.append(String.valueOf(din));
/*  41 */         if (din <= 32) {
/*  42 */           int iloc = loc + 7;
/*  43 */           for (int i = 0; i < din; ++i) {
/*  44 */             sb.append(",");
/*  45 */             sb.append(ParseTool.ByteToHex(data[(iloc + 2)]));
/*  46 */             sb.append(" ");
/*  47 */             sb.append(ParseTool.BytesToHexC(data, iloc, 2));
/*  48 */             iloc += 3;
/*     */           }
/*  50 */           sb.append(",");
/*  51 */           sb.append(String.valueOf(ParseTool.BCDToDecimal(data[iloc])));
/*     */         }
/*  53 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  56 */       e.printStackTrace();
/*     */     }
/*  58 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*  71 */     int slen = -1;
/*     */     try {
/*  73 */       String[] para = value.split(",");
/*  74 */       frame[loc] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/*     */ 
/*  76 */       ParseTool.HexsToBytes(frame, loc + 1, para[1]);
/*     */ 
/*  78 */       frame[(loc + 3)] = ParseTool.StringToBcd(para[3]);
/*  79 */       frame[(loc + 4)] = (byte)(Integer.parseInt(para[2]) & 0xFF);
/*     */ 
/*  81 */       frame[(loc + 5)] = ParseTool.IntToBcd(Integer.parseInt(para[4]));
/*     */ 
/*  83 */       int nums = Integer.parseInt(para[5]);
/*  84 */       frame[(loc + 6)] = ParseTool.IntToBcd(nums);
/*     */ 
/*  86 */       if (2 * nums != para.length - 7)
/*     */       {
/*  88 */         System.out.println("task para is error");
/*     */       }
/*  90 */       int iloc = loc + 7;
/*  91 */       int ipara = 6;
/*  92 */       for (int i = 0; i < nums; ++i) {
/*  93 */         ParseTool.HexsToBytes(frame, iloc, para[(ipara + 1)]);
/*  94 */         frame[(iloc + 2)] = ParseTool.IntToBcd(Integer.parseInt(para[ipara]));
/*  95 */         ipara += 2;
/*  96 */         iloc += 3;
/*     */       }
/*  98 */       frame[iloc] = ParseTool.IntToBcd(Integer.parseInt(para[ipara]));
/*  99 */       slen = iloc - loc + 1;
/*     */     } catch (Exception e) {
/* 101 */       throw new MessageEncodeException("错误的 异常任务 组帧参数:" + value);
/*     */     }
/* 103 */     return slen;
/*     */   }
/*     */ }