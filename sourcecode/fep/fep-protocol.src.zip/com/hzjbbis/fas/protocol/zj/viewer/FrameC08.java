/*     */ package com.hzjbbis.fas.protocol.zj.viewer;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FrameC08 extends AbstractFrame
/*     */ {
/*     */   public static final String FUNC_NAME = "设置终端参数";
/*     */ 
/*     */   public FrameC08()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FrameC08(byte[] frame)
/*     */   {
/*  24 */     super(frame);
/*     */   }
/*     */ 
/*     */   public FrameC08(String data) {
/*  28 */     super(data);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  32 */     if (this.frame != null) {
/*  33 */       StringBuffer sb = new StringBuffer();
/*  34 */       sb.append(super.getBase());
/*  35 */       sb.append("命令类型--").append("设置终端参数");
/*  36 */       sb.append("\n");
/*  37 */       if (this.direction > 0)
/*  38 */         descRtuReply(sb);
/*     */       else {
/*  40 */         descMastCmd(sb);
/*     */       }
/*  42 */       return sb.toString();
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   private void descRtuReply(StringBuffer buffer) {
/*     */     try {
/*  49 */       if (this.fexp > 0) {
/*  50 */         if (this.length > 1)
/*  51 */           parseErr(buffer);
/*     */         else
/*  53 */           buffer.append("异常应答--").append(errCode(this.frame[11]));
/*     */       }
/*     */       else
/*  56 */         parseErr(buffer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parseErr(StringBuffer buffer) {
/*  64 */     buffer.append("设置的测量点--");
/*  65 */     int point = this.frame[11] & 0xFF;
/*  66 */     buffer.append(point).append("\n");
/*     */ 
/*  68 */     int index = 12;
/*  69 */     int tail = this.length + 11;
/*     */ 
/*  71 */     while ((index < tail) && 
/*  72 */       (2 < tail - index)) {
/*  73 */       buffer.append(ParseTool.BytesToHexC(this.frame, index, 2));
/*  74 */       buffer.append("设置结果:").append(errCode(this.frame[(index + 2)])).append("\n");
/*  75 */       index += 3;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void descMastCmd(StringBuffer buffer)
/*     */   {
/*     */     try
/*     */     {
/*  84 */       buffer.append("设置的测量点--");
/*  85 */       int point = this.frame[11] & 0xFF;
/*  86 */       buffer.append(point).append("    ");
/*  87 */       buffer.append("使用的权限等级--");
/*  88 */       buffer.append(((this.frame[12] & 0xFF) == 17) ? "高级" : "低级").append("    ");
/*  89 */       buffer.append("密码--");
/*  90 */       buffer.append(ParseTool.BytesToHexC(this.frame, 13, 3)).append("\n");
/*  91 */       buffer.append("设置的数据项---");
/*  92 */       int index = 16;
/*  93 */       int tail = this.length + 11;
/*     */ 
/*  95 */       while ((index < tail) && 
/*  96 */         (2 < tail - index)) {
/*  97 */         int datakey = ((this.frame[(index + 1)] & 0xFF) << 8) + (this.frame[index] & 0xFF);
/*  98 */         ProtocolDataItemConfig dic = DataConfigZj.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/*  99 */         if (dic == null) {
/* 100 */           ProtocolDataItemConfig di = DataConfigZjpb.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/* 101 */           if (di != null)
/* 102 */             dic = di;
/*     */         }
/* 104 */         if (dic != null) {
/* 105 */           int loc = index + 2;
/* 106 */           int itemlen = 0;
/*     */ 
/* 108 */           itemlen = parseBlockData(this.frame, loc, dic, point, buffer);
/* 109 */           loc += itemlen;
/* 110 */           if (ParseTool.isTask(datakey)) {
/* 111 */             loc = tail;
/* 112 */             break;
/*     */           }
/*     */ 
/* 115 */           index = loc;
/*     */         }
/*     */         else {
/* 118 */           buffer.append("\n");
/* 119 */           buffer.append("不支持的数据:" + ParseTool.IntToHex(datakey));
/* 120 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private int parseBlockData(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer)
/*     */   {
/* 142 */     int rt = 0;
/*     */     try {
/* 144 */       List children = pdc.getChildItems();
/* 145 */       int index = loc;
/* 146 */       if ((children != null) && (children.size() > 0)) {
/* 147 */         for (int i = 0; i < children.size(); ++i) {
/* 148 */           ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)children.get(i);
/* 149 */           int dlen = parseBlockData(data, index, cpdc, point, buffer);
/* 150 */           if (dlen <= 0) {
/* 151 */             return -1;
/*     */           }
/* 153 */           index += dlen;
/* 154 */           rt += dlen;
/*     */         }
/*     */       } else {
/* 157 */         int dlen = parseItem(data, loc, pdc, point, buffer);
/* 158 */         if (dlen <= 0) {
/* 159 */           return -1;
/*     */         }
/* 161 */         rt += dlen;
/*     */       }
/*     */     } catch (Exception e) {
/* 164 */       throw new MessageDecodeException(e);
/*     */     }
/* 166 */     return rt;
/*     */   }
/*     */ 
/*     */   private int parseItem(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer) {
/* 170 */     int rt = 0;
/*     */     try {
/* 172 */       int datakey = pdc.getDataKey();
/* 173 */       int itemlen = 0;
/* 174 */       if ((33024 < datakey) && (33278 > datakey)) {
/* 175 */         int tasktype = data[loc] & 0xFF;
/* 176 */         if (tasktype == 1) {
/* 177 */           if (16 < data.length - loc) {
/* 178 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 15)]) * 2 + 16;
/*     */           } else {
/* 180 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>16" + " 解析长度：" + (data.length - loc));
/* 181 */             return -1;
/*     */           }
/*     */         }
/* 184 */         if (tasktype == 2) {
/* 185 */           if (21 < data.length - loc) {
/* 186 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 20)]) + 21;
/*     */           } else {
/* 188 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>21" + " 解析长度：" + (data.length - loc));
/* 189 */             return -1;
/*     */           }
/*     */         }
/* 192 */         if (tasktype == 4)
/* 193 */           if (7 < data.length - loc) {
/* 194 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 6)]) * 3 + 8;
/*     */           } else {
/* 196 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>7" + " 解析长度：" + (data.length - loc));
/* 197 */             return -1;
/*     */           }
/*     */       }
/*     */       else {
/* 201 */         itemlen = pdc.getLength();
/*     */       }
/* 203 */       if (itemlen <= data.length - loc) {
/* 204 */         Object di = DataItemParser.parsevalue(data, loc, itemlen, pdc.getFraction(), pdc.getParserno());
/* 205 */         buffer.append(pdc.getCode()).append("=");
/* 206 */         if (di != null) {
/* 207 */           buffer.append(di.toString());
/*     */         }
/* 209 */         buffer.append("\n");
/* 210 */         rt = itemlen;
/*     */       }
/* 213 */       else if (data.length - loc != 0)
/*     */       {
/* 217 */         buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：" + itemlen + " 解析长度：" + (data.length - loc));
/* 218 */         return -1;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 222 */       throw new MessageDecodeException(e);
/*     */     }
/* 224 */     return rt;
/*     */   }
/*     */ }