/*    */ package com.hzjbbis.fas.protocol.zj.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.protocol.zj.ErrorCode;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class C28MessageDecoder extends AbstractMessageDecoder
/*    */ {
/*    */   public Object decode(IMessage message)
/*    */   {
/* 20 */     HostCommand hc = null;
/*    */     try
/*    */     {
/* 23 */       if (ParseTool.getOrientation(message) == 1)
/*    */       {
/* 25 */         int rtype = ParseTool.getErrCode(message);
/*    */ 
/* 27 */         hc = new HostCommand();
/* 28 */         if (rtype == 0) {
/* 29 */           hc.setStatus("1");
/*    */         }
/*    */         else {
/* 32 */           byte[] data = ParseTool.getData(message);
/* 33 */           if ((data != null) && (data.length > 0))
/* 34 */             hc.setStatus(ErrorCode.toHostCommandStatus(data[0]));
/*    */           else {
/* 36 */             hc.setStatus("2");
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 45 */       throw new MessageDecodeException(e);
/*    */     }
/* 47 */     return hc;
/*    */   }
/*    */ }