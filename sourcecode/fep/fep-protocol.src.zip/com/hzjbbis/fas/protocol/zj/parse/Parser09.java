/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser09
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 30 */         sb.append(":");
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 32 */         sb.append(":");
/* 33 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 34 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 37 */       e.printStackTrace();
/*    */     }
/* 39 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/* 52 */     int slen = -1;
/*    */     try
/*    */     {
/* 55 */       for (int i = 0; i < value.length(); ++i) {
/* 56 */         char c = value.charAt(i);
/* 57 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 60 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 63 */         throw new MessageEncodeException("错误的 HH:mm:ss 组帧参数:" + value);
/*    */       }
/* 65 */       String[] para = value.split(":");
/* 66 */       frame[loc] = ParseTool.StringToBcd(para[2]);
/* 67 */       frame[(loc + 1)] = ParseTool.StringToBcd(para[1]);
/* 68 */       frame[(loc + 2)] = ParseTool.StringToBcd(para[0]);
/* 69 */       slen = len;
/*    */     } catch (Exception e) {
/* 71 */       throw new MessageEncodeException("错误的 hh:mm:ss 组帧参数:" + value);
/*    */     }
/* 73 */     return slen;
/*    */   }
/*    */ }