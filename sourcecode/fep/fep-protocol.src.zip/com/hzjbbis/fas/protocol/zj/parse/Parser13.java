/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser13
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 30 */         sb.append(":");
/* 31 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 32 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 35 */       e.printStackTrace();
/*    */     }
/* 37 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 52 */       for (int i = 0; i < value.length(); ++i) {
/* 53 */         char c = value.charAt(i);
/* 54 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 57 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 60 */         throw new MessageEncodeException("错误的 HH:mm 组帧参数:" + value);
/*    */       }
/* 62 */       String[] time = value.split(":");
/* 63 */       frame[(loc + 1)] = ParseTool.StringToBcd(time[0]);
/* 64 */       frame[loc] = ParseTool.StringToBcd(time[1]);
/*    */     } catch (Exception e) {
/* 66 */       throw new MessageEncodeException("错误的 hh:mm 组帧参数:" + value);
/*    */     }
/*    */ 
/* 69 */     return len;
/*    */   }
/*    */ }