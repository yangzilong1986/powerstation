/*     */ package com.hzjbbis.fas.protocol.zj.viewer;
/*     */ 
/*     */ public abstract class AbstractFrame
/*     */ {
/*     */   protected byte A1;
/*     */   protected byte A2;
/*     */   protected byte B1;
/*     */   protected byte B2;
/*     */   protected int mast;
/*     */   protected int fseq;
/*     */   protected int ifseq;
/*     */   protected int C;
/*     */   protected int fexp;
/*     */   protected int direction;
/*     */   protected int length;
/*     */   protected byte cs;
/*     */   protected byte rcs;
/*     */   protected byte[] frame;
/*     */ 
/*     */   public AbstractFrame()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AbstractFrame(byte[] frame)
/*     */   {
/*  46 */     if ((frame != null) && (frame.length >= 13)) {
/*  47 */       this.frame = frame;
/*  48 */       fillinfo();
/*     */     }
/*     */   }
/*     */ 
/*     */   public AbstractFrame(String data) {
/*  53 */     if ((data == null) || 
/*  54 */       (!(Util.validHex(data)))) return;
/*  55 */     this.frame = null;
/*  56 */     this.frame = new byte[(data.length() >>> 1) + (data.length() & 0x1)];
/*  57 */     Util.HexsToBytes(this.frame, 0, data);
/*  58 */     fillinfo();
/*     */   }
/*     */ 
/*     */   private void fillinfo()
/*     */   {
/*  64 */     this.A1 = this.frame[1];
/*  65 */     this.A2 = this.frame[2];
/*  66 */     this.B1 = this.frame[3];
/*  67 */     this.B2 = this.frame[4];
/*  68 */     this.mast = (this.frame[5] & 0x3F);
/*  69 */     this.fseq = (((this.frame[6] & 0x1F) << 2) + ((this.frame[5] & 0xC0) >>> 6));
/*  70 */     this.ifseq = ((this.frame[6] & 0xE0) >>> 5);
/*  71 */     this.C = (this.frame[8] & 0x3F);
/*  72 */     this.fexp = (((this.frame[8] & 0x40) == 64) ? 1 : 0);
/*  73 */     this.direction = (((this.frame[8] & 0x80) == 128) ? 1 : 0);
/*  74 */     this.length = (((this.frame[10] & 0xFF) << 8) + (this.frame[9] & 0xFF));
/*  75 */     this.cs = this.frame[(this.frame.length - 2)];
/*  76 */     this.rcs = Util.calculateCS(this.frame, 0, this.frame.length - 2);
/*     */   }
/*     */ 
/*     */   protected String getBase() {
/*  80 */     if (this.frame != null) {
/*  81 */       StringBuffer sb = new StringBuffer();
/*  82 */       sb.append((this.direction > 0) ? "传输方向--终端上行" : "传输方向--主站下行");
/*  83 */       sb.append("    ");
/*  84 */       sb.append("终端逻辑地址--").append(Util.ByteToHex(this.A1)).append(Util.ByteToHex(this.A2)).append(Util.ByteToHex(this.B2)).append(Util.ByteToHex(this.B1));
/*     */ 
/*  87 */       sb.append("    ");
/*  88 */       sb.append("主站地址--").append(String.valueOf(this.mast));
/*  89 */       sb.append("    ");
/*  90 */       sb.append("帧序号--").append(String.valueOf(this.fseq));
/*  91 */       sb.append("    ");
/*  92 */       sb.append("帧内序号--").append(String.valueOf(this.ifseq));
/*  93 */       sb.append("    ");
/*  94 */       sb.append("数据长度--").append(String.valueOf(this.length));
/*  95 */       sb.append("\n");
/*  96 */       sb.append("CS--").append(Util.ByteToHex(this.cs));
/*  97 */       sb.append("    DATA CS--").append(Util.ByteToHex(this.rcs));
/*  98 */       sb.append("\n");
/*  99 */       return sb.toString();
/*     */     }
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   public String errCode(byte errcode) {
/* 105 */     String err = null;
/* 106 */     switch (errcode & 0xFF) { case 0:
/* 108 */       err = "成功";
/* 109 */       break;
/*     */     case 1:
/* 111 */       err = "中继命令无返回";
/* 112 */       break;
/*     */     case 2:
/* 114 */       err = "设置内容非法";
/* 115 */       break;
/*     */     case 3:
/* 117 */       err = "密码权限不足";
/* 118 */       break;
/*     */     case 4:
/* 120 */       err = "无此数据项";
/* 121 */       break;
/*     */     case 5:
/* 123 */       err = "命令时间失效";
/* 124 */       break;
/*     */     case 17:
/* 126 */       err = "目标地址不存在";
/* 127 */       break;
/*     */     case 18:
/* 129 */       err = "发送失败";
/* 130 */       break;
/*     */     case 19:
/* 132 */       err = "短消息帧太长";
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16: } return err;
/*     */   }
/*     */ 
/*     */   public String timeUnit(byte tunit) {
/* 141 */     String ustr = null;
/* 142 */     switch (tunit & 0xFF)
/*     */     {
/*     */     case 2:
/* 144 */       ustr = "分钟";
/* 145 */       break;
/*     */     case 3:
/* 147 */       ustr = "小时";
/* 148 */       break;
/*     */     case 4:
/* 150 */       ustr = "日";
/* 151 */       break;
/*     */     case 5:
/* 153 */       ustr = "月";
/* 154 */       break;
/*     */     default:
/* 156 */       ustr = "未知时间单位";
/*     */     }
/*     */ 
/* 159 */     return ustr;
/*     */   }
/*     */ 
/*     */   public abstract String getDescription();
/*     */ }