/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser25
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 29 */       if (ok) {
/* 30 */         StringBuffer sb = new StringBuffer();
/* 31 */         boolean bn = (data[(loc + len - 1)] & 0x10) > 0;
/* 32 */         int val = ParseTool.nBcdToDecimalS(data, loc + 1, 4);
/* 33 */         if (bn) {
/* 34 */           val = -val;
/*    */         }
/* 36 */         sb.append(String.valueOf(val));
/* 37 */         sb.append(",");
/* 38 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 39 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 42 */       e.printStackTrace();
/*    */     }
/* 44 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 58 */       NumberFormat nf = NumberFormat.getInstance();
/* 59 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 61 */       for (int i = 0; i < value.length(); ++i) {
/* 62 */         char c = value.charAt(i);
/* 63 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 66 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 69 */         if (c == '.') {
/*    */           continue;
/*    */         }
/* 72 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 75 */         throw new MessageEncodeException("错误的 SNNNNNNN XX 组帧参数:" + value);
/*    */       }
/* 77 */       String[] para = value.split(",");
/*    */ 
/* 79 */       int val = nf.parse(para[0]).intValue();
/* 80 */       boolean bn = val < 0;
/* 81 */       if (bn) {
/* 82 */         val = -val;
/*    */       }
/* 84 */       ParseTool.IntToBcd(frame, val, loc + 1, 4);
/* 85 */       if (bn) {
/* 86 */         frame[(loc + 4)] = (byte)(frame[(loc + 4)] & 0xF | 0x10);
/*    */       }
/*    */ 
/* 89 */       frame[loc] = ParseTool.StringToBcd(para[1]);
/*    */     } catch (Exception e) {
/* 91 */       throw new MessageEncodeException("错误的 SNNNNNNN XX 组帧参数:" + value);
/*    */     }
/*    */ 
/* 94 */     return len;
/*    */   }
/*    */ }