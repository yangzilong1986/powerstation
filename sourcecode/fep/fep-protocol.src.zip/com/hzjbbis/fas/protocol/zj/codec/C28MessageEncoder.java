/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalSendSmsRequest;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.Parser43;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C28MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  25 */   private static Log log = LogFactory.getLog(C28MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj) {
/*  28 */     List rt = null;
/*     */     try {
/*  30 */       if (obj instanceof FaalSendSmsRequest) {
/*  31 */         FaalSendSmsRequest para = (FaalSendSmsRequest)obj;
/*  32 */         String content = para.getContent();
/*  33 */         if ((content == null) || (content.length() == 0))
/*     */         {
/*  35 */           throw new MessageEncodeException("请指定短信内容");
/*     */         }
/*     */ 
/*  38 */         byte[] bcont = content.getBytes("GB2312");
/*  39 */         exchangeBytes(bcont, 1);
/*  40 */         String[] phones = para.getMobiles();
/*  41 */         if ((phones != null) && (phones.length > 0)) {
/*  42 */           rt = new ArrayList();
/*  43 */           int len = 14 + bcont.length;
/*  44 */           if (bcont.length > content.length() * 2) {
/*  45 */             len -= 2;
/*     */           }
/*  47 */           for (int i = 0; i < phones.length; ++i)
/*     */           {
/*  49 */             MessageZjHead head = new MessageZjHead();
/*  50 */             head.c_dir = 0;
/*  51 */             head.c_expflag = 0;
/*  52 */             head.c_func = 40;
/*     */ 
/*  54 */             head.rtua_a1 = -110;
/*  55 */             head.rtua_a2 = 0;
/*  56 */             head.rtua_b1b2 = 7680;
/*     */ 
/*  58 */             head.iseq = 0;
/*     */ 
/*  61 */             head.dlen = (short)len;
/*     */ 
/*  63 */             byte[] frame = new byte[len];
/*  64 */             int dlen = Parser43.constructor(frame, phones[i], 0, 14, 0);
/*  65 */             if (dlen <= 0) {
/*     */               continue;
/*     */             }
/*     */ 
/*  69 */             if (bcont.length > content.length() * 2)
/*  70 */               System.arraycopy(bcont, 2, frame, 14, bcont.length - 2);
/*     */             else {
/*  72 */               System.arraycopy(bcont, 0, frame, 14, bcont.length);
/*     */             }
/*     */ 
/*  75 */             MessageZj msg = new MessageZj();
/*  76 */             msg.data = ByteBuffer.wrap(frame);
/*  77 */             msg.head = head;
/*  78 */             rt.add(msg);
/*  79 */             if (log.isDebugEnabled())
/*  80 */               log.debug(content + " to " + phones[i]);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  85 */           throw new MessageEncodeException("请指定短信发送对象的手机号码");
/*     */         }
/*     */       }
/*     */       else {
/*  89 */         throw new MessageEncodeException("错误的参数对象，请使用：FaalSendSmsRequest");
/*     */       }
/*     */     } catch (Exception e) {
/*  92 */       throw new MessageEncodeException(e);
/*     */     }
/*     */ 
/*  95 */     if ((rt != null) && (rt.size() > 0)) {
/*  96 */       IMessage[] msgs = new IMessage[rt.size()];
/*  97 */       rt.toArray(msgs);
/*  98 */       return msgs;
/*     */     }
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   private void exchangeBytes(byte[] data) {
/* 104 */     int i = 0;
/* 105 */     while (i < data.length)
/*     */     {
/* 107 */       byte cc = data[i];
/* 108 */       data[i] = data[(i + 1)];
/* 109 */       data[(i + 1)] = cc;
/* 110 */       i += 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void exchangeBytes(byte[] data, int type) {
/* 115 */     if (type == 0) {
/* 116 */       exchangeBytes(data);
/*     */     } else {
/* 118 */       int i = 0;
/* 119 */       int j = data.length - 1;
/* 120 */       while (i < data.length / 2)
/*     */       {
/* 122 */         byte cc = data[i];
/* 123 */         data[i] = data[j];
/* 124 */         data[j] = cc;
/* 125 */         ++i;
/* 126 */         --j;
/*     */       }
/*     */     }
/*     */   }
/*     */ }