/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser01
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 23 */     Object rt = null;
/*    */     try {
/* 25 */       boolean ok = true;
/*    */ 
/* 29 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 30 */       if (ok) {
/* 31 */         int val = ParseTool.nBcdToDecimal(data, loc, len);
/* 32 */         if (val >= 0)
/* 33 */           if (fraction > 0) {
/* 34 */             NumberFormat snf = NumberFormat.getInstance();
/* 35 */             snf.setMinimumFractionDigits(fraction);
/* 36 */             snf.setGroupingUsed(false);
/* 37 */             rt = snf.format(val / ParseTool.fraction[fraction]);
/*    */           } else {
/* 39 */             rt = new Integer(val);
/*    */           }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 44 */       throw new MessageDecodeException(e);
/*    */     }
/* 46 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       NumberFormat nf = NumberFormat.getInstance();
/* 61 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 63 */       double val = nf.parse(value).doubleValue();
/* 64 */       if (fraction > 0) {
/* 65 */         val *= ParseTool.fraction[fraction];
/*    */       }
/*    */ 
/* 68 */       ParseTool.IntToBcd(frame, (int)val, loc, len);
/*    */     }
/*    */     catch (Exception e) {
/* 71 */       throw new MessageEncodeException("bab BCD string:" + value);
/*    */     }
/* 73 */     return len;
/*    */   }
/*    */ }