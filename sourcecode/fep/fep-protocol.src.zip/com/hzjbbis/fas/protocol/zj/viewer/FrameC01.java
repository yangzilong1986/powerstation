/*     */ package com.hzjbbis.fas.protocol.zj.viewer;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FrameC01 extends AbstractFrame
/*     */ {
/*     */   public static final String FUNC_NAME = "召测终端当前数据";
/*     */ 
/*     */   public FrameC01()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FrameC01(byte[] frame)
/*     */   {
/*  24 */     super(frame);
/*     */   }
/*     */ 
/*     */   public FrameC01(String data) {
/*  28 */     super(data);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  32 */     if (this.frame != null) {
/*  33 */       StringBuffer sb = new StringBuffer();
/*  34 */       sb.append(super.getBase());
/*  35 */       sb.append("命令类型--").append("召测终端当前数据");
/*  36 */       sb.append("\n");
/*  37 */       if (this.direction > 0) {
/*  38 */         if (this.fexp > 0)
/*  39 */           sb.append("异常应答--").append(errCode(this.frame[11]));
/*     */         else
/*  41 */           descRtuReply(sb);
/*     */       }
/*     */       else {
/*  44 */         descMastCmd(sb);
/*     */       }
/*  46 */       return sb.toString();
/*     */     }
/*  48 */     return null;
/*     */   }
/*     */ 
/*     */   private void descMastCmd(StringBuffer buffer) {
/*     */     try {
/*  53 */       buffer.append("召测的测量点--");
/*  54 */       byte[] points = new byte[64];
/*  55 */       byte pn = 0;
/*  56 */       byte pnum = 0;
/*  57 */       for (int i = 0; i < 8; ++i) {
/*  58 */         int flag = 1;
/*  59 */         int tnm = this.frame[(11 + i)] & 0xFF;
/*  60 */         for (int j = 0; j < 8; ++j) {
/*  61 */           if ((tnm & flag << j) > 0) {
/*  62 */             points[pnum] = pn;
/*  63 */             pnum = (byte)(pnum + 1);
/*  64 */             buffer.append(pn + ",");
/*     */           }
/*  66 */           pn = (byte)(pn + 1);
/*     */         }
/*     */       }
/*  69 */       buffer.append("\n");
/*  70 */       buffer.append("召测的数据项---");
/*     */ 
/*  72 */       for (int pos = 19; pos < this.length + 11; pos += 2)
/*  73 */         buffer.append(Util.ByteToHex(this.frame[(pos + 1)])).append(Util.ByteToHex(this.frame[pos])).append(",");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void descRtuReply(StringBuffer buffer)
/*     */   {
/*     */     try {
/*  83 */       byte[] points = new byte[64];
/*  84 */       byte pn = 0;
/*  85 */       byte pnum = 0;
/*  86 */       for (int i = 0; i < 8; ++i) {
/*  87 */         int flag = 1;
/*  88 */         int tnm = this.frame[(11 + i)] & 0xFF;
/*  89 */         for (int j = 0; j < 8; ++j) {
/*  90 */           if ((tnm & flag << j) > 0) {
/*  91 */             points[pnum] = pn;
/*  92 */             pnum = (byte)(pnum + 1);
/*     */           }
/*  94 */           pn = (byte)(pn + 1);
/*     */         }
/*     */       }
/*     */ 
/*  98 */       buffer.append("召测的数据项---");
/*     */ 
/* 100 */       if (pnum > 0) {
/* 101 */         int index = 19;
/* 102 */         int tail = this.length + 11;
/* 103 */         while ((index < tail) && 
/* 104 */           (2 < tail - index)) {
/* 105 */           int datakey = ((this.frame[(index + 1)] & 0xFF) << 8) + (this.frame[index] & 0xFF);
/* 106 */           ProtocolDataItemConfig dic = DataConfigZj.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/* 107 */           if (dic == null) {
/* 108 */             ProtocolDataItemConfig di = DataConfigZjpb.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/* 109 */             if (di != null)
/* 110 */               dic = di;
/*     */           }
/* 112 */           if (dic != null) {
/* 113 */             int loc = index + 2;
/* 114 */             int itemlen = 0;
/*     */ 
/* 116 */             for (int j = 0; j < pnum; ++j) {
/* 117 */               itemlen = parseBlockData(this.frame, loc, dic, points[j] & 0xFF, buffer);
/* 118 */               loc += itemlen;
/* 119 */               if (ParseTool.isTask(datakey)) {
/* 120 */                 loc = tail;
/* 121 */                 break;
/*     */               }
/*     */             }
/* 124 */             index = loc;
/*     */           }
/*     */           else {
/* 127 */             buffer.append("\n");
/* 128 */             buffer.append("不支持的数据:" + ParseTool.IntToHex(datakey));
/* 129 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private int parseBlockData(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer)
/*     */   {
/* 151 */     int rt = 0;
/*     */     try {
/* 153 */       List children = pdc.getChildItems();
/* 154 */       int index = loc;
/* 155 */       if ((children != null) && (children.size() > 0)) {
/* 156 */         for (int i = 0; i < children.size(); ++i) {
/* 157 */           ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)children.get(i);
/* 158 */           int dlen = parseBlockData(data, index, cpdc, point, buffer);
/* 159 */           if (dlen <= 0) {
/* 160 */             return -1;
/*     */           }
/* 162 */           index += dlen;
/* 163 */           rt += dlen;
/*     */         }
/*     */       } else {
/* 166 */         int dlen = parseItem(data, loc, pdc, point, buffer);
/* 167 */         if (dlen <= 0) {
/* 168 */           return -1;
/*     */         }
/* 170 */         rt += dlen;
/*     */       }
/*     */     } catch (Exception e) {
/* 173 */       throw new MessageDecodeException(e);
/*     */     }
/* 175 */     return rt;
/*     */   }
/*     */ 
/*     */   private int parseItem(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer) {
/* 179 */     int rt = 0;
/*     */     try {
/* 181 */       int datakey = pdc.getDataKey();
/* 182 */       int itemlen = 0;
/* 183 */       if ((33024 < datakey) && (33278 > datakey)) {
/* 184 */         int tasktype = data[loc] & 0xFF;
/* 185 */         if (tasktype == 1) {
/* 186 */           if (16 < data.length - loc) {
/* 187 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 15)]) * 2 + 16;
/*     */           } else {
/* 189 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>16" + " 解析长度：" + (data.length - loc));
/* 190 */             return -1;
/*     */           }
/*     */         }
/* 193 */         if (tasktype == 2) {
/* 194 */           if (21 < data.length - loc) {
/* 195 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 20)]) + 21;
/*     */           } else {
/* 197 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>21" + " 解析长度：" + (data.length - loc));
/* 198 */             return -1;
/*     */           }
/*     */         }
/* 201 */         if (tasktype == 4)
/* 202 */           if (7 < data.length - loc) {
/* 203 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 6)]) * 3 + 8;
/*     */           } else {
/* 205 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>7" + " 解析长度：" + (data.length - loc));
/* 206 */             return -1;
/*     */           }
/*     */       }
/*     */       else {
/* 210 */         itemlen = pdc.getLength();
/*     */       }
/* 212 */       if (itemlen <= data.length - loc) {
/* 213 */         Object di = DataItemParser.parsevalue(data, loc, itemlen, pdc.getFraction(), pdc.getParserno());
/* 214 */         buffer.append("测量点" + point).append("/");
/* 215 */         buffer.append("数据项" + pdc.getCode()).append("=");
/* 216 */         if (di != null) {
/* 217 */           buffer.append(di.toString());
/*     */         }
/* 219 */         buffer.append("\n");
/* 220 */         rt = itemlen;
/*     */       }
/* 223 */       else if (data.length - loc != 0)
/*     */       {
/* 227 */         buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：" + itemlen + " 解析长度：" + (data.length - loc));
/* 228 */         return -1;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 232 */       throw new MessageDecodeException(e);
/*     */     }
/* 234 */     return rt;
/*     */   }
/*     */ }