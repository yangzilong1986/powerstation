/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser10
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append("20");
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/* 31 */         sb.append("-");
/* 32 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/* 33 */         sb.append("-");
/* 34 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/* 35 */         sb.append(" ");
/* 36 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 37 */         sb.append(":");
/* 38 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 39 */         sb.append(",");
/* 40 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, 2)));
/* 41 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 44 */       e.printStackTrace();
/*    */     }
/* 46 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       for (int i = 0; i < value.length(); ++i) {
/* 62 */         char c = value.charAt(i);
/* 63 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 66 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 69 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 72 */         if (c == '.') {
/*    */           continue;
/*    */         }
/* 75 */         if (c == ' ') {
/*    */           continue;
/*    */         }
/* 78 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 81 */         throw new MessageEncodeException("错误的 YYMMDDHHmm 0XXX 组帧参数:" + value);
/*    */       }
/* 83 */       String[] para = value.split(",");
/* 84 */       int xx = Integer.parseInt(para[1]);
/* 85 */       String[] dpara = para[0].split(" ");
/* 86 */       String[] date = dpara[0].split("-");
/* 87 */       String[] time = dpara[1].split(":");
/*    */ 
/* 89 */       ParseTool.IntToBcd(frame, xx, loc, 2);
/* 90 */       frame[(loc + 6)] = ParseTool.StringToBcd(date[0]);
/* 91 */       frame[(loc + 5)] = ParseTool.StringToBcd(date[1]);
/* 92 */       frame[(loc + 4)] = ParseTool.StringToBcd(date[2]);
/* 93 */       frame[(loc + 3)] = ParseTool.StringToBcd(time[0]);
/* 94 */       frame[(loc + 2)] = ParseTool.StringToBcd(time[1]);
/*    */     } catch (Exception e) {
/* 96 */       throw new MessageEncodeException("错误的 YYMMDDHHmm 0XXX 组帧参数:" + value);
/*    */     }
/*    */ 
/* 99 */     return len;
/*    */   }
/*    */ }