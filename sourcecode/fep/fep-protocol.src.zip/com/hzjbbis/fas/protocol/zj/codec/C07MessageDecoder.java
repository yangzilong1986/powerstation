/*    */ package com.hzjbbis.fas.protocol.zj.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.model.HostCommandResult;
/*    */ import com.hzjbbis.fas.protocol.zj.ErrorCode;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class C07MessageDecoder extends AbstractMessageDecoder
/*    */ {
/*    */   public Object decode(IMessage message)
/*    */   {
/* 14 */     HostCommand hc = null;
/*    */     try {
/* 16 */       if (ParseTool.getOrientation(message) == 1)
/*    */       {
/*    */         byte[] data;
/* 17 */         int rtype = ParseTool.getErrCode(message);
/* 18 */         hc = new HostCommand();
/* 19 */         if (0 == rtype) {
/* 20 */           hc.setStatus("1");
/* 21 */           data = ParseTool.getData(message);
/* 22 */           int point = data[0];
/* 23 */           int loc = 1;
/* 24 */           if (data.length > 3) {
/* 25 */             toResult(data, loc, point, hc);
/*    */           }
/*    */           else
/* 28 */             throw new MessageDecodeException("数据长度不对");
/*    */         }
/*    */         else
/*    */         {
/* 32 */           data = ParseTool.getData(message);
/* 33 */           if ((data != null) && (data.length > 0)) {
/* 34 */             if (data.length == 1)
/* 35 */               hc.setStatus(ErrorCode.toHostCommandStatus(data[0]));
/*    */             else
/* 37 */               toResult(data, 1, data[0], hc);
/*    */           }
/*    */           else {
/* 40 */             hc.setStatus("2");
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 47 */       throw new MessageDecodeException(e);
/*    */     }
/* 49 */     return hc;
/*    */   }
/*    */ 
/*    */   private void toResult(byte[] data, int loc, int point, HostCommand hc)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       int iloc = loc;
/* 62 */       while (iloc < data.length) {
/* 63 */         int datakey = ((data[(iloc + 1)] & 0xFF) << 8) + (data[iloc] & 0xFF);
/* 64 */         iloc += 2;
/* 65 */         String result = ParseTool.ByteToHex(data[iloc]);
/* 66 */         setItemResult(hc, point, ParseTool.IntToHex(datakey), result);
/* 67 */         ++iloc;
/*    */       }
/*    */     } catch (Exception e) {
/* 70 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void setItemResult(HostCommand hc, int point, String code, String result) {
/* 75 */     HostCommandResult hcr = new HostCommandResult();
/* 76 */     hcr.setTn("" + point);
/* 77 */     hcr.setCode(code);
/* 78 */     hcr.setValue(result);
/* 79 */     hc.addResult(hcr);
/*    */   }
/*    */ }