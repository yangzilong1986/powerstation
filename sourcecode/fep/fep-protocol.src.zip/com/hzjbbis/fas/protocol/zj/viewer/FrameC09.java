/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameC09 extends AbstractFrame
/*    */ {
/*    */   public static final String FUNC_NAME = "异常告警";
/*    */ 
/*    */   public FrameC09()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FrameC09(byte[] frame)
/*    */   {
/* 16 */     super(frame);
/*    */   }
/*    */ 
/*    */   public FrameC09(String data) {
/* 20 */     super(data);
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 24 */     if (this.frame != null) {
/* 25 */       StringBuffer sb = new StringBuffer();
/* 26 */       sb.append(super.getBase());
/* 27 */       sb.append("命令类型--").append("异常告警");
/* 28 */       sb.append("\n");
/* 29 */       if (this.direction > 0)
/* 30 */         descRtuReply(sb);
/*    */       else {
/* 32 */         descMastCmd(sb);
/*    */       }
/* 34 */       return sb.toString();
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   private void descRtuReply(StringBuffer buffer) {
/*    */     try {
/* 41 */       if (this.fexp > 0) {
/* 42 */         buffer.append("异常应答--").append(errCode(this.frame[11]));
/*    */       } else {
/* 44 */         buffer.append("本次上送告警条数--").append(this.frame[11] & 0xFF).append("\n");
/* 45 */         buffer.append("告警发生的测量点号--").append(this.frame[12] & 0xFF).append("    ");
/* 46 */         buffer.append("告警发生时间---");
/* 47 */         buffer.append("20").append(Util.ByteToHex(this.frame[13])).append("-").append(Util.ByteToHex(this.frame[14])).append("-").append(Util.ByteToHex(this.frame[15])).append(" ").append(Util.ByteToHex(this.frame[16])).append(":").append(Util.ByteToHex(this.frame[17])).append(":00    ");
/*    */ 
/* 50 */         buffer.append("告警编码--").append(Util.ByteToHex(this.frame[19])).append(Util.ByteToHex(this.frame[18])).append("\n");
/* 51 */         buffer.append("告警数据--").append(Util.BytesToHex(this.frame, 20, this.length - 9));
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/*    */     }
/*    */   }
/*    */ 
/*    */   private void descMastCmd(StringBuffer buffer) {
/*    */     try {
/* 60 */       buffer.append("告警发生的测量点号--").append(Util.ByteToHex(this.frame[11])).append("    ");
/* 61 */       buffer.append("告警编码--").append(Util.ByteToHex(this.frame[13])).append(Util.ByteToHex(this.frame[12])).append("    ");
/* 62 */       buffer.append("告警发生时间---");
/* 63 */       buffer.append("20").append(Util.ByteToHex(this.frame[14])).append("-").append(Util.ByteToHex(this.frame[15])).append("-").append(Util.ByteToHex(this.frame[16])).append(" ").append(Util.ByteToHex(this.frame[17])).append(":").append(Util.ByteToHex(this.frame[18])).append(":00\n");
/*    */ 
/* 66 */       buffer.append("本次召测告警条数--").append(this.frame[19] & 0xFF).append("\n");
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }