/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser04
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isAllFF(data, loc, len);
/* 29 */       if (!(ok)) {
/* 30 */         boolean bn = (data[(loc + len - 1)] & 0x80) > 0;
/* 31 */         int val = ParseTool.nByteToIntS(data, loc, len);
/* 32 */         if (bn) {
/* 33 */           val = -val;
/*    */         }
/* 35 */         if (fraction > 0) {
/* 36 */           NumberFormat snf = NumberFormat.getInstance();
/* 37 */           snf.setMinimumFractionDigits(fraction);
/* 38 */           snf.setMinimumIntegerDigits(1);
/* 39 */           snf.setGroupingUsed(false);
/* 40 */           rt = snf.format(val / ParseTool.fraction[fraction]);
/*    */         } else {
/* 42 */           rt = new Integer(val);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 46 */       e.printStackTrace();
/*    */     }
/* 48 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       NumberFormat nf = NumberFormat.getInstance();
/* 62 */       nf.setMaximumFractionDigits(4);
/* 63 */       String sn = "";
/* 64 */       if (value.substring(0, 1).equals("+"))
/* 65 */         sn = value.substring(1, value.length());
/*    */       else {
/* 67 */         sn = value;
/*    */       }
/* 69 */       double val = nf.parse(sn).doubleValue();
/* 70 */       if (fraction > 0) {
/* 71 */         val *= ParseTool.fraction[fraction];
/*    */       }
/* 73 */       boolean bn = val < 0.0D;
/* 74 */       if (bn) {
/* 75 */         val = -val;
/*    */       }
/* 77 */       ParseTool.DecimalToBytes(frame, (int)val, loc, len);
/* 78 */       if (bn)
/* 79 */         frame[(loc + len - 1)] = (byte)(frame[(loc + len - 1)] | 0x80);
/*    */     }
/*    */     catch (Exception e) {
/* 82 */       throw new MessageEncodeException("错误的HEX码组帧参数:" + value);
/*    */     }
/* 84 */     return len;
/*    */   }
/*    */ }