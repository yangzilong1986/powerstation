/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ public class Parser32
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  29 */       if (ok) {
/*  30 */         StringBuffer sb = new StringBuffer();
/*  31 */         sb.append(String.valueOf(ParseTool.BytesToHexC(data, loc + 9, 2)));
/*  32 */         sb.append(",");
/*  33 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 8)])));
/*  34 */         sb.append(",");
/*  35 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 7)])));
/*  36 */         sb.append(",");
/*  37 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + 4, 3) / ParseTool.fraction[2]));
/*  38 */         sb.append(",");
/*  39 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + 2, 2) / ParseTool.fraction[2]));
/*  40 */         sb.append(",");
/*  41 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, 2) / ParseTool.fraction[2]));
/*  42 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  45 */       e.printStackTrace();
/*     */     }
/*  47 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       NumberFormat nf = NumberFormat.getInstance();
/*  62 */       nf.setMaximumFractionDigits(4);
/*     */ 
/*  65 */       for (int i = 0; i < value.length(); ++i) {
/*  66 */         char c = value.charAt(i);
/*  67 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  70 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  73 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  76 */         if ((c >= 'A') && (c <= 'F')) {
/*     */           continue;
/*     */         }
/*  79 */         if ((c >= 'a') && (c <= 'f')) {
/*     */           continue;
/*     */         }
/*  82 */         throw new MessageEncodeException("错误的 DI1DI0 NN1 NN2 MMMM.MM RR.RR SS.SS 组帧参数:" + value);
/*     */       }
/*     */ 
/*  85 */       String[] para = value.split(",");
/*     */ 
/*  87 */       ParseTool.HexsToBytes(frame, loc + 9, para[0]);
/*  88 */       frame[(loc + 8)] = ParseTool.IntToBcd(Integer.parseInt(para[1]));
/*  89 */       frame[(loc + 7)] = ParseTool.IntToBcd(Integer.parseInt(para[2]));
/*  90 */       double val = nf.parse(para[3]).doubleValue();
/*  91 */       val *= ParseTool.fraction[2];
/*  92 */       ParseTool.IntToBcd(frame, (int)val, loc + 4, 3);
/*  93 */       val = nf.parse(para[4]).doubleValue();
/*  94 */       val *= ParseTool.fraction[2];
/*  95 */       ParseTool.IntToBcd(frame, (int)val, loc + 2, 2);
/*  96 */       val = nf.parse(para[5]).doubleValue();
/*  97 */       val *= ParseTool.fraction[2];
/*  98 */       ParseTool.IntToBcd(frame, (int)val, loc, 2);
/*     */     } catch (Exception e) {
/* 100 */       throw new MessageEncodeException("错误的 DI1DI0 NN1 NN2 MMMM.MM RR.RR SS.SS 组帧参数:" + value);
/*     */     }
/*     */ 
/* 103 */     return len;
/*     */   }
/*     */ }