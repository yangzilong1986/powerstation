/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalReadTaskDataRequest;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.TaskSetting;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C02MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  26 */   private static Log log = LogFactory.getLog(C02MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj) { List rt = null;
/*     */     try {
/*  30 */       if (obj instanceof FaalReadTaskDataRequest) {
/*  31 */         FaalReadTaskDataRequest para = (FaalReadTaskDataRequest)obj;
/*     */ 
/*  33 */         Calendar ptime = Calendar.getInstance();
/*  34 */         ptime.setTime(para.getStartTime());
/*     */ 
/*  36 */         int num = para.getCount();
/*  37 */         int taskno = Integer.parseInt(para.getTaskNum());
/*  38 */         int rate = para.getFrequence();
/*     */ 
/*  41 */         int len = 8;
/*     */ 
/*  43 */         List rtuid = para.getRtuIds();
/*  44 */         List cmdIds = para.getCmdIds();
/*  45 */         rt = new ArrayList();
/*  46 */         for (int iter = 0; iter < rtuid.size(); ++iter) {
/*  47 */           Calendar stime = Calendar.getInstance();
/*  48 */           stime.setTime(ptime.getTime());
/*     */ 
/*  50 */           String id = (String)rtuid.get(iter);
/*  51 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/*     */ 
/*  53 */           if (rtu == null)
/*     */           {
/*  55 */             log.info("终端信息未在缓存列表：" + id);
/*     */           }
/*     */           else
/*     */           {
/*  60 */             TaskSetting ts = new TaskSetting(rtu.getRtua(), taskno, this.dataConfig);
/*  61 */             if ((ts == null) || (ts.getRtu() == null)) {
/*  62 */               log.info("终端未建档！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + " 任务号--" + String.valueOf(taskno));
/*     */             }
/*  65 */             else if (ts.getRtask() == null) {
/*  66 */               log.info("终端任务未配置！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + " 任务号--" + String.valueOf(taskno));
/*     */             }
/*     */             else {
/*  69 */               int tsu = ts.getTIUnit();
/*  70 */               int tsn = ts.getTI();
/*     */ 
/*  72 */               List datacs = ts.getDI();
/*  73 */               int tsbytes = 0;
/*  74 */               for (int guard = 0; guard < datacs.size(); ++guard) {
/*  75 */                 ProtocolDataItemConfig pdc = (ProtocolDataItemConfig)datacs.get(guard);
/*  76 */                 if (pdc == null) {
/*  77 */                   throw new MessageEncodeException("错误的终端任务配置--" + ts.getDataCodes());
/*     */                 }
/*  79 */                 tsbytes += pdc.getLength();
/*     */               }
/*  81 */               if (tsbytes <= 0) {
/*  82 */                 log.info("数据描述错误，请检查浙江规约数据集！");
/*     */               }
/*     */               else
/*     */               {
/*  86 */                 int datamax = DataItemCoder.getDataMax(rtu);
/*     */ 
/*  88 */                 int pointnum = datamax / tsbytes;
/*  89 */                 if (pointnum <= 0) {
/*  90 */                   pointnum = 1;
/*     */                 }
/*  92 */                 int curnum = num;
/*     */ 
/*  94 */                 int msgcount = 0;
/*     */ 
/* 102 */                 while (curnum > 0) {
/* 103 */                   int realp = 0;
/* 104 */                   if (curnum > pointnum)
/* 105 */                     realp = pointnum;
/*     */                   else {
/* 107 */                     realp = curnum;
/*     */                   }
/*     */ 
/* 111 */                   MessageZjHead head = createHead(rtu);
/* 112 */                   byte[] frame = new byte[len];
/* 113 */                   frame[0] = (byte)taskno;
/* 114 */                   frame[1] = ParseTool.IntToBcd(stime.get(1) % 100);
/* 115 */                   frame[2] = ParseTool.IntToBcd(stime.get(2) + 1);
/* 116 */                   frame[3] = ParseTool.IntToBcd(stime.get(5));
/* 117 */                   frame[4] = ParseTool.IntToBcd(stime.get(11));
/* 118 */                   frame[5] = ParseTool.IntToBcd(stime.get(12));
/* 119 */                   frame[6] = (byte)realp;
/* 120 */                   frame[7] = (byte)rate;
/*     */ 
/* 122 */                   MessageZj msg = new MessageZj();
/* 123 */                   msg.data = ByteBuffer.wrap(frame);
/* 124 */                   msg.head = head;
/* 125 */                   rt.add(msg);
/*     */ 
/* 127 */                   msg.setCmdId((Long)cmdIds.get(iter));
/*     */ 
/* 130 */                   ++msgcount;
/* 131 */                   int ti = getTimeInterval((byte)tsu);
/* 132 */                   if (ti <= 1440) {
/* 133 */                     stime.add(12, ti * tsn * realp * rate);
/*     */                   }
/*     */                   else {
/* 136 */                     stime.add(2, realp * tsn * rate);
/*     */                   }
/* 138 */                   curnum -= pointnum;
/*     */                 }
/*     */ 
/* 141 */                 setMsgcount(rt, msgcount); } } }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 145 */       throw new MessageEncodeException(e);
/*     */     }
/* 147 */     if (rt != null) {
/* 148 */       IMessage[] msgs = new IMessage[rt.size()];
/* 149 */       rt.toArray(msgs);
/* 150 */       return msgs;
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */   private MessageZjHead createHead(BizRtu rtu)
/*     */   {
/* 157 */     MessageZjHead head = new MessageZjHead();
/* 158 */     head.c_dir = 0;
/* 159 */     head.c_expflag = 0;
/* 160 */     head.c_func = 2;
/* 161 */     head.rtua = rtu.getRtua();
/*     */ 
/* 163 */     head.iseq = 0;
/*     */ 
/* 166 */     return head;
/*     */   }
/*     */ 
/*     */   private int getTimeInterval(byte type)
/*     */   {
/* 175 */     int rt = 0;
/* 176 */     switch (type)
/*     */     {
/*     */     case 2:
/* 178 */       rt = 1;
/* 179 */       break;
/*     */     case 3:
/* 181 */       rt = 60;
/* 182 */       break;
/*     */     case 4:
/* 184 */       rt = 1440;
/* 185 */       break;
/*     */     case 5:
/* 187 */       rt = 43200;
/*     */     }
/*     */ 
/* 192 */     return rt; }
/*     */ 
/*     */   private void setMsgcount(List msgs, int msgcount) {
/* 195 */     for (Iterator iter = msgs.iterator(); iter.hasNext(); ) {
/* 196 */       MessageZj msg = (MessageZj)iter.next();
/* 197 */       if (msg.getMsgCount() == 0)
/* 198 */         msg.setMsgCount(msgcount);
/*     */     }
/*     */   }
/*     */ }