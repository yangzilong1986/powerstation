/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser29
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 29 */       if (ok) {
/* 30 */         StringBuffer sb = new StringBuffer();
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 32 */         sb.append(",");
/* 33 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 34 */         sb.append(",");
/* 35 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 36 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 39 */       e.printStackTrace();
/*    */     }
/* 41 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 56 */       for (int i = 0; i < value.length(); ++i) {
/* 57 */         char c = value.charAt(i);
/* 58 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 61 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 64 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 67 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 70 */         throw new MessageEncodeException("错误的 MM YP 组帧参数:" + value);
/*    */       }
/* 72 */       String[] para = value.split(",");
/* 73 */       frame[loc] = ParseTool.IntToBcd(Integer.parseInt(para[2]));
/* 74 */       frame[(loc + 1)] = ParseTool.IntToBcd(Integer.parseInt(para[1]));
/* 75 */       frame[(loc + 2)] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/*    */     } catch (Exception e) {
/* 77 */       throw new MessageEncodeException("错误的 MM YP 组帧参数:" + value);
/*    */     }
/*    */ 
/* 80 */     return len;
/*    */   }
/*    */ }