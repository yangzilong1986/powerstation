/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser31
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 18)])));
/* 30 */         sb.append(",");
/* 31 */         sb.append(String.valueOf(ParseTool.BytesToHexC(data, loc + 16, 2)));
/* 32 */         int iloc = loc + 14;
/* 33 */         for (int i = 0; i < 8; ++i) {
/* 34 */           sb.append(",");
/* 35 */           sb.append(ParseTool.ByteToHex(data[(iloc + 1)]));
/* 36 */           sb.append(",");
/* 37 */           sb.append(String.valueOf(ParseTool.BCDToDecimal(data[iloc])));
/* 38 */           iloc -= 2;
/*    */         }
/* 40 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 43 */       e.printStackTrace();
/*    */     }
/* 45 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       for (int i = 0; i < value.length(); ++i) {
/* 61 */         char c = value.charAt(i);
/* 62 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 65 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 68 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 71 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 74 */         throw new MessageEncodeException("错误的 MM DI1DI0 cc1NN1cc2NN2……cc8NN8 组帧参数:" + value);
/*    */       }
/*    */ 
/* 77 */       String[] para = value.split(",");
/* 78 */       frame[(loc + 18)] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/* 79 */       ParseTool.HexsToBytes(frame, loc + 16, para[1]);
/* 80 */       int iloc = 14;
/* 81 */       int ipara = 2;
/* 82 */       for (int i = 0; i < 8; ++i) {
/* 83 */         frame[(iloc + 1)] = ParseTool.IntToBcd(Integer.parseInt(para[ipara]));
/* 84 */         frame[iloc] = ParseTool.IntToBcd(Integer.parseInt(para[(ipara + 1)]));
/* 85 */         iloc -= 2;
/* 86 */         ipara += 2;
/*    */       }
/*    */     } catch (Exception e) {
/* 89 */       throw new MessageEncodeException("错误的 MM DI1DI0 cc1NN1cc2NN2……cc8NN8 组帧参数:" + value);
/*    */     }
/*    */ 
/* 92 */     return len;
/*    */   }
/*    */ }