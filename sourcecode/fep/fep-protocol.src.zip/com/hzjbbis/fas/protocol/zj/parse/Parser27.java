/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class Parser27
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  20 */     Object rt = null;
/*     */     try {
/*  22 */       boolean ok = true;
/*     */ 
/*  26 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  27 */       if (ok) {
/*  28 */         StringBuffer sb = new StringBuffer();
/*  29 */         sb.append(ParseTool.ByteToHex(data[loc]));
/*  30 */         sb.append(",");
/*  31 */         sb.append(String.valueOf(data[(loc + 2)] & 0xFF));
/*  32 */         sb.append(",");
/*  33 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/*  34 */         sb.append(",");
/*  35 */         sb.append(String.valueOf(data[(loc + 4)] & 0xFF));
/*  36 */         sb.append(",");
/*  37 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  38 */         sb.append(",");
/*  39 */         sb.append(String.valueOf(data[(loc + 6)] & 0xFF));
/*  40 */         sb.append(",");
/*  41 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  42 */         sb.append(",");
/*  43 */         sb.append(String.valueOf(data[(loc + 8)] & 0xFF));
/*  44 */         sb.append(",");
/*  45 */         sb.append(ParseTool.ByteToHex(data[(loc + 7)]));
/*  46 */         sb.append(",");
/*  47 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 9)])));
/*  48 */         sb.append(",");
/*  49 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 10)])));
/*  50 */         sb.append(",");
/*  51 */         sb.append(ParseTool.ByteToHex(data[(loc + 11)]));
/*  52 */         sb.append(",");
/*  53 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + 12, 2)));
/*  54 */         sb.append(",");
/*  55 */         sb.append(String.valueOf(data[(loc + 14)] & 0xFF));
/*  56 */         sb.append(",");
/*  57 */         sb.append(ParseTool.ByteToHex(data[(loc + 15)]));
/*  58 */         sb.append(",");
/*  59 */         sb.append(String.valueOf(ParseTool.nByteToInt(data, loc + 16, 2)));
/*  60 */         sb.append(",");
/*  61 */         sb.append(String.valueOf(ParseTool.nByteToInt(data, loc + 18, 2)));
/*  62 */         sb.append(",");
/*  63 */         int cl = ParseTool.BCDToDecimal(data[(loc + 20)]);
/*  64 */         sb.append(String.valueOf(cl));
/*  65 */         sb.append(",");
/*  66 */         if (cl <= 32) {
/*  67 */           sb.append(ParseTool.BytesToHexL(data, loc + 21, cl));
/*     */         }
/*  69 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  72 */       e.printStackTrace();
/*     */     }
/*  74 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*  87 */     int nums = 0;
/*  88 */     int slen = -1;
/*     */     try
/*     */     {
/*  91 */       String[] para = value.split(",");
/*  92 */       frame[loc] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/*     */ 
/*  94 */       frame[(loc + 1)] = ParseTool.StringToBcd(para[2]);
/*  95 */       frame[(loc + 2)] = (byte)(Integer.parseInt(para[1]) & 0xFF);
/*     */ 
/*  97 */       frame[(loc + 3)] = ParseTool.StringToBcd(para[4]);
/*  98 */       frame[(loc + 4)] = (byte)(Integer.parseInt(para[3]) & 0xFF);
/*     */ 
/* 100 */       frame[(loc + 5)] = ParseTool.StringToBcd(para[6]);
/* 101 */       frame[(loc + 6)] = (byte)(Integer.parseInt(para[5]) & 0xFF);
/*     */ 
/* 103 */       frame[(loc + 7)] = ParseTool.StringToBcd(para[8]);
/* 104 */       frame[(loc + 8)] = (byte)(Integer.parseInt(para[7]) & 0xFF);
/*     */ 
/* 106 */       frame[(loc + 9)] = ParseTool.IntToBcd(Integer.parseInt(para[9]));
/*     */ 
/* 108 */       frame[(loc + 10)] = ParseTool.IntToBcd(Integer.parseInt(para[10]));
/*     */ 
/* 110 */       frame[(loc + 11)] = (byte)Integer.parseInt(para[11]);
/*     */ 
/* 112 */       nums = Integer.parseInt(para[12]);
/* 113 */       ParseTool.IntToBcd(frame, nums, loc + 12, 2);
/*     */ 
/* 115 */       frame[(loc + 14)] = ParseTool.IntToBcd(Integer.parseInt(para[13]));
/*     */ 
/* 117 */       frame[(loc + 15)] = ParseTool.HexToByte(para[14]);
/*     */ 
/* 119 */       ParseTool.DecimalToBytes(frame, Integer.parseInt(para[15]), loc + 16, 2);
/* 120 */       ParseTool.DecimalToBytes(frame, Integer.parseInt(para[16]), loc + 18, 2);
/*     */ 
/* 122 */       nums = Integer.parseInt(para[17]);
/* 123 */       frame[(loc + 20)] = ParseTool.IntToBcd(nums);
/*     */ 
/* 125 */       if (nums != para[18].length() / 2)
/*     */       {
/* 127 */         System.out.println("task para is error");
/*     */       }
/* 129 */       ParseTool.HexsToBytesCB(frame, loc + 21, para[18]);
/* 130 */       slen = nums + 21;
/*     */     } catch (Exception e) {
/* 132 */       throw new MessageEncodeException("错误的 中继任务 组帧参数:" + value);
/*     */     }
/*     */ 
/* 135 */     return slen;
/*     */   }
/*     */ }