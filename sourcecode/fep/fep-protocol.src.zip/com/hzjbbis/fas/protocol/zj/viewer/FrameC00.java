/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameC00 extends AbstractFrame
/*    */ {
/*    */   public static final String FUNC_NAME = "中继";
/*    */ 
/*    */   public FrameC00()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FrameC00(byte[] frame)
/*    */   {
/* 16 */     super(frame);
/*    */   }
/*    */ 
/*    */   public FrameC00(String data) {
/* 20 */     super(data);
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 24 */     if (this.frame != null) {
/* 25 */       StringBuffer sb = new StringBuffer();
/* 26 */       sb.append(super.getBase());
/* 27 */       sb.append("命令类型--").append("中继");
/* 28 */       sb.append("\n");
/*    */ 
/* 30 */       if (this.direction > 0)
/* 31 */         descRtuReply(sb);
/*    */       else {
/* 33 */         descMastCmd(sb);
/*    */       }
/* 35 */       return sb.toString();
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */   private void descMastCmd(StringBuffer buffer) {
/*    */     try {
/* 42 */       buffer.append("端口号--").append(Util.BytesToHex(this.frame, 11, 1));
/* 43 */       buffer.append("    ");
/* 44 */       buffer.append("超时时间--").append(this.frame[12] & 0xFF);
/* 45 */       buffer.append("    ");
/* 46 */       buffer.append("特征字节--").append(Util.BytesToHex(this.frame, 13, 1));
/* 47 */       buffer.append("    ");
/* 48 */       int loc = (this.frame[14] & 0xFF) + ((this.frame[15] & 0xFF) << 8);
/* 49 */       buffer.append("截取开始--").append(loc);
/* 50 */       buffer.append("    ");
/* 51 */       loc = (this.frame[16] & 0xFF) + ((this.frame[17] & 0xFF) << 8);
/* 52 */       buffer.append("截取长度--").append(loc);
/* 53 */       buffer.append("    ");
/* 54 */       buffer.append("中继命令--").append(Util.BytesToHex(this.frame, 18, this.length - 7));
/*    */     }
/*    */     catch (Exception e) {
/*    */     }
/*    */   }
/*    */ 
/*    */   private void descRtuReply(StringBuffer buffer) {
/*    */     try {
/* 62 */       if (this.fexp > 0) {
/* 63 */         buffer.append("中继失败--").append(errCode(this.frame[11]));
/*    */       } else {
/* 65 */         buffer.append("端口号--").append(Util.BytesToHex(this.frame, 11, 1));
/* 66 */         buffer.append("\n");
/* 67 */         buffer.append("中继返回--").append(Util.BytesToHex(this.frame, 12, this.length - 1));
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }