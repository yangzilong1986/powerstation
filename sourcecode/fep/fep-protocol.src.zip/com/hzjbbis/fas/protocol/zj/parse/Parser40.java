/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ public class Parser40
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  29 */       if (ok) {
/*  30 */         StringBuffer sb = new StringBuffer();
/*  31 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/*  32 */         sb.append("-");
/*  33 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  34 */         sb.append(" ");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/*  36 */         sb.append(":");
/*  37 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  38 */         sb.append(",");
/*  39 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, 3) / ParseTool.fraction[4]));
/*  40 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  43 */       e.printStackTrace();
/*     */     }
/*  45 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       NumberFormat nf = NumberFormat.getInstance();
/*  60 */       nf.setMaximumFractionDigits(4);
/*     */ 
/*  63 */       for (int i = 0; i < value.length(); ++i) {
/*  64 */         char c = value.charAt(i);
/*  65 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  68 */         if (c == ' ') {
/*     */           continue;
/*     */         }
/*  71 */         if (c == ':') {
/*     */           continue;
/*     */         }
/*  74 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  77 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  80 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  83 */         throw new MessageEncodeException("错误的 MM-DD HH:mm XX.XXXX 组帧参数:" + value);
/*     */       }
/*     */ 
/*  86 */       String[] para = value.split(",");
/*  87 */       String[] dpara = para[0].split(" ");
/*  88 */       String[] date = dpara[0].split("-");
/*  89 */       String[] time = dpara[1].split(":");
/*     */ 
/*  91 */       double xx = nf.parse(para[1]).doubleValue() * ParseTool.fraction[4];
/*  92 */       ParseTool.IntToBcd(frame, (int)xx, loc, 3);
/*  93 */       frame[(loc + 6)] = ParseTool.StringToBcd(date[0]);
/*  94 */       frame[(loc + 5)] = ParseTool.StringToBcd(date[1]);
/*  95 */       frame[(loc + 4)] = ParseTool.StringToBcd(time[0]);
/*  96 */       frame[(loc + 3)] = ParseTool.StringToBcd(time[1]);
/*     */     } catch (Exception e) {
/*  98 */       throw new MessageEncodeException("错误的 MM-DD HH:mm XX.XXXX 组帧参数:" + value);
/*     */     }
/*     */ 
/* 101 */     return len;
/*     */   }
/*     */ }