/*    */ package com.hzjbbis.fas.protocol.zj.handler;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import com.hzjbbis.exception.ProtocolHandleException;
/*    */ import com.hzjbbis.fas.model.FaalRequest;
/*    */ import com.hzjbbis.fas.protocol.codec.MessageCodecFactory;
/*    */ import com.hzjbbis.fas.protocol.codec.MessageDecoder;
/*    */ import com.hzjbbis.fas.protocol.codec.MessageEncoder;
/*    */ import com.hzjbbis.fas.protocol.handler.ProtocolHandler;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.zj.MessageZj;
/*    */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class PrototalHandlerImpl
/*    */   implements ProtocolHandler
/*    */ {
/* 22 */   private static final Log log = LogFactory.getLog(PrototalHandlerImpl.class);
/*    */   private MessageCodecFactory codecFactory;
/*    */ 
/*    */   public void setCodecFactory(MessageCodecFactory codecFactory)
/*    */   {
/* 30 */     this.codecFactory = codecFactory;
/*    */   }
/*    */ 
/*    */   public MessageCodecFactory getCodecFactory()
/*    */   {
/* 37 */     return this.codecFactory;
/*    */   }
/*    */ 
/*    */   public Object process(IMessage message)
/*    */   {
/*    */     Object value;
/* 45 */     if (!(message instanceof MessageZj)) {
/* 46 */       throw new ProtocolHandleException("Unsupported message type: " + message.getClass());
/*    */     }
/*    */ 
/* 49 */     MessageZj msg = (MessageZj)message;
/* 50 */     int funCode = msg.head.c_func & 0xFF;
/*    */ 
/* 52 */     MessageDecoder decoder = this.codecFactory.getDecoder(funCode);
/* 53 */     if (decoder == null)
/* 54 */       throw new ProtocolHandleException("Can't find decoder for function code: " + funCode);
/*    */     try
/*    */     {
/* 57 */       value = decoder.decode(msg);
/* 58 */       if (log.isDebugEnabled()) {
/* 59 */         log.debug("Message decoded");
/*    */       }
/*    */     }
/*    */     catch (MessageDecodeException ex)
/*    */     {
/* 64 */       throw ex;
/*    */     }
/*    */     catch (Exception ex) {
/* 67 */       throw new ProtocolHandleException("Error to process message", ex);
/*    */     }
/* 69 */     return value;
/*    */   }
/*    */ 
/*    */   public IMessage[] createMessage(FaalRequest request)
/*    */   {
/* 76 */     MessageEncoder encoder = this.codecFactory.getEncoder(request.getType());
/* 77 */     if (encoder == null) {
/* 78 */       throw new ProtocolHandleException("Can't find encoder for function code: " + request.getType());
/*    */     }
/*    */     try
/*    */     {
/* 82 */       return encoder.encode(request);
/*    */     }
/*    */     catch (MessageEncodeException ex) {
/* 85 */       throw ex;
/*    */     }
/*    */     catch (Exception ex) {
/* 88 */       throw new ProtocolHandleException("Error to encoding message", ex);
/*    */     }
/*    */   }
/*    */ }