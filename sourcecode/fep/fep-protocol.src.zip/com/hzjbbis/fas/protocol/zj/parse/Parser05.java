/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser05
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 27 */       if (ok)
/* 28 */         rt = ParseTool.BytesToHexC(data, loc, len);
/*    */     }
/*    */     catch (Exception e) {
/* 31 */       e.printStackTrace();
/*    */     }
/* 33 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 48 */       for (int i = 0; i < value.length(); ++i) {
/* 49 */         char c = value.charAt(i);
/* 50 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 53 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 56 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 59 */         throw new MessageEncodeException("错误的 Hex 组帧参数:" + value);
/*    */       }
/* 61 */       ParseTool.HexsToBytes(frame, loc, value);
/*    */     } catch (Exception e) {
/* 63 */       throw new MessageEncodeException("错误的HEX码组帧参数:" + value);
/*    */     }
/* 65 */     return len;
/*    */   }
/*    */ }