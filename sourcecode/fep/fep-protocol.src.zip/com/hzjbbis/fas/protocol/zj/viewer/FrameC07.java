/*     */ package com.hzjbbis.fas.protocol.zj.viewer;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FrameC07 extends AbstractFrame
/*     */ {
/*     */   public static final String FUNC_NAME = "实时设置终端参数";
/*     */ 
/*     */   public FrameC07()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FrameC07(byte[] frame)
/*     */   {
/*  24 */     super(frame);
/*     */   }
/*     */ 
/*     */   public FrameC07(String data) {
/*  28 */     super(data);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  32 */     if (this.frame != null) {
/*  33 */       StringBuffer sb = new StringBuffer();
/*  34 */       sb.append(super.getBase());
/*  35 */       sb.append("命令类型--").append("实时设置终端参数");
/*  36 */       sb.append("\n");
/*  37 */       if (this.direction > 0)
/*  38 */         descRtuReply(sb);
/*     */       else {
/*  40 */         descMastCmd(sb);
/*     */       }
/*  42 */       return sb.toString();
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   private void descRtuReply(StringBuffer buffer) {
/*     */     try {
/*  49 */       if (this.fexp > 0) {
/*  50 */         if (this.length > 1)
/*  51 */           parseErr(buffer);
/*     */         else
/*  53 */           buffer.append("异常应答--").append(errCode(this.frame[11]));
/*     */       }
/*     */       else
/*  56 */         parseErr(buffer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parseErr(StringBuffer buffer) {
/*  64 */     buffer.append("设置的测量点--");
/*  65 */     int point = this.frame[11] & 0xFF;
/*  66 */     buffer.append(point).append("\n");
/*     */ 
/*  68 */     int index = 12;
/*  69 */     int tail = this.length + 11;
/*     */ 
/*  71 */     while ((index < tail) && 
/*  72 */       (2 < tail - index)) {
/*  73 */       buffer.append(ParseTool.BytesToHexC(this.frame, index, 2));
/*  74 */       buffer.append("设置结果:").append(errCode(this.frame[(index + 2)])).append("\n");
/*  75 */       index += 3;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void descMastCmd(StringBuffer buffer)
/*     */   {
/*     */     try
/*     */     {
/*  84 */       buffer.append("设置的测量点--");
/*  85 */       int point = this.frame[11] & 0xFF;
/*  86 */       buffer.append(point).append("    ");
/*  87 */       buffer.append("使用的权限等级--");
/*  88 */       buffer.append(((this.frame[12] & 0xFF) == 17) ? "高级" : "低级").append("    ");
/*  89 */       buffer.append("密码--");
/*  90 */       buffer.append(ParseTool.BytesToHexC(this.frame, 13, 3)).append("\n");
/*  91 */       buffer.append("命令下发时间---");
/*  92 */       buffer.append("20").append(Util.ByteToHex(this.frame[16])).append("-").append(Util.ByteToHex(this.frame[17])).append("-").append(Util.ByteToHex(this.frame[18])).append(" ").append(Util.ByteToHex(this.frame[19])).append(":").append(Util.ByteToHex(this.frame[20])).append(":00    ");
/*     */ 
/*  95 */       buffer.append("命令有效时间---").append(Util.ByteToHex(this.frame[21])).append("min\n");
/*  96 */       buffer.append("设置的数据项---");
/*  97 */       int index = 22;
/*  98 */       int tail = this.length + 11;
/*     */ 
/* 100 */       while ((index < tail) && 
/* 101 */         (2 < tail - index)) {
/* 102 */         int datakey = ((this.frame[(index + 1)] & 0xFF) << 8) + (this.frame[index] & 0xFF);
/* 103 */         ProtocolDataItemConfig dic = DataConfigZj.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/* 104 */         if (dic == null) {
/* 105 */           ProtocolDataItemConfig di = DataConfigZjpb.getInstance().getDataConfig().getDataItemConfig(ParseTool.IntToHex(datakey));
/* 106 */           if (di != null)
/* 107 */             dic = di;
/*     */         }
/* 109 */         if (dic != null) {
/* 110 */           int loc = index + 2;
/* 111 */           int itemlen = 0;
/*     */ 
/* 113 */           itemlen = parseBlockData(this.frame, loc, dic, point, buffer);
/* 114 */           loc += itemlen;
/* 115 */           if (ParseTool.isTask(datakey)) {
/* 116 */             loc = tail;
/* 117 */             break;
/*     */           }
/*     */ 
/* 120 */           index = loc;
/*     */         }
/*     */         else {
/* 123 */           buffer.append("\n");
/* 124 */           buffer.append("不支持的数据:" + ParseTool.IntToHex(datakey));
/* 125 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private int parseBlockData(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer)
/*     */   {
/* 147 */     int rt = 0;
/*     */     try {
/* 149 */       List children = pdc.getChildItems();
/* 150 */       int index = loc;
/* 151 */       if ((children != null) && (children.size() > 0)) {
/* 152 */         for (int i = 0; i < children.size(); ++i) {
/* 153 */           ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)children.get(i);
/* 154 */           int dlen = parseBlockData(data, index, cpdc, point, buffer);
/* 155 */           if (dlen <= 0) {
/* 156 */             return -1;
/*     */           }
/* 158 */           index += dlen;
/* 159 */           rt += dlen;
/*     */         }
/*     */       } else {
/* 162 */         int dlen = parseItem(data, loc, pdc, point, buffer);
/* 163 */         if (dlen <= 0) {
/* 164 */           return -1;
/*     */         }
/* 166 */         rt += dlen;
/*     */       }
/*     */     } catch (Exception e) {
/* 169 */       throw new MessageDecodeException(e);
/*     */     }
/* 171 */     return rt;
/*     */   }
/*     */ 
/*     */   private int parseItem(byte[] data, int loc, ProtocolDataItemConfig pdc, int point, StringBuffer buffer) {
/* 175 */     int rt = 0;
/*     */     try {
/* 177 */       int datakey = pdc.getDataKey();
/* 178 */       int itemlen = 0;
/* 179 */       if ((33024 < datakey) && (33278 > datakey)) {
/* 180 */         int tasktype = data[loc] & 0xFF;
/* 181 */         if (tasktype == 1) {
/* 182 */           if (16 < data.length - loc) {
/* 183 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 15)]) * 2 + 16;
/*     */           } else {
/* 185 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>16" + " 解析长度：" + (data.length - loc));
/* 186 */             return -1;
/*     */           }
/*     */         }
/* 189 */         if (tasktype == 2) {
/* 190 */           if (21 < data.length - loc) {
/* 191 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 20)]) + 21;
/*     */           } else {
/* 193 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>21" + " 解析长度：" + (data.length - loc));
/* 194 */             return -1;
/*     */           }
/*     */         }
/* 197 */         if (tasktype == 4)
/* 198 */           if (7 < data.length - loc) {
/* 199 */             itemlen = ParseTool.BCDToDecimal(data[(loc + 6)]) * 3 + 8;
/*     */           } else {
/* 201 */             buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：>7" + " 解析长度：" + (data.length - loc));
/* 202 */             return -1;
/*     */           }
/*     */       }
/*     */       else {
/* 206 */         itemlen = pdc.getLength();
/*     */       }
/* 208 */       if (itemlen <= data.length - loc) {
/* 209 */         Object di = DataItemParser.parsevalue(data, loc, itemlen, pdc.getFraction(), pdc.getParserno());
/* 210 */         buffer.append(pdc.getCode()).append("=");
/* 211 */         if (di != null) {
/* 212 */           buffer.append(di.toString());
/*     */         }
/* 214 */         buffer.append("\n");
/* 215 */         rt = itemlen;
/*     */       }
/* 218 */       else if (data.length - loc != 0)
/*     */       {
/* 222 */         buffer.append("错误数据长度，数据项：" + pdc.getCode() + " 期望数据长度：" + itemlen + " 解析长度：" + (data.length - loc));
/* 223 */         return -1;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 227 */       throw new MessageDecodeException(e);
/*     */     }
/* 229 */     return rt;
/*     */   }
/*     */ }