/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.model.TaskTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TaskSetting
/*     */ {
/*  19 */   private final Log log = LogFactory.getLog(TaskSetting.class);
/*     */   public static final int TIME_UNIT_MINUTE = 2;
/*     */   public static final int TIME_UNIT_HOUR = 3;
/*     */   public static final int TIME_UNIT_DAY = 4;
/*     */   public static final int TIME_UNIT_MONTH = 5;
/*     */   private int TT;
/*     */   private int TS;
/*     */   private int TSUnit;
/*     */   private int TI;
/*     */   private int TIUnit;
/*     */   private int RS;
/*     */   private int RSUnit;
/*     */   private int RI;
/*     */   private int RIUnit;
/*     */   private int RDI;
/*     */   private int TN;
/*     */   private int SP;
/*     */   private int RT;
/*     */   private int DIN;
/*     */   private List DI;
/*  51 */   private BizRtu rtu = null;
/*  52 */   private TaskTemplate rtask = null;
/*     */ 
/*     */   public TaskSetting()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TaskSetting(int rtua, int taskid, ProtocolDataConfig pdc)
/*     */   {
/*  65 */     this.TT = 0;
/*  66 */     this.TS = 0;
/*  67 */     this.TSUnit = 2;
/*  68 */     this.TI = 15;
/*  69 */     this.TIUnit = 2;
/*  70 */     this.RS = 5;
/*  71 */     this.RSUnit = 2;
/*  72 */     this.RI = 1;
/*  73 */     this.RIUnit = 4;
/*  74 */     this.RDI = 1;
/*  75 */     this.TN = 0;
/*  76 */     this.SP = 96;
/*  77 */     this.RT = 0;
/*  78 */     this.DIN = 1;
/*  79 */     this.DI = new ArrayList();
/*     */     try {
/*  81 */       this.rtu = RtuManage.getInstance().getBizRtuInCache(rtua);
/*  82 */       if (this.rtu == null)
/*  83 */         return;
/*  84 */       this.rtask = this.rtu.getTaskTemplate(String.valueOf(taskid));
/*  85 */       if (this.rtask == null)
/*  86 */         return;
/*  87 */       List dids = this.rtask.getDataCodes();
/*  88 */       this.log.debug("任务配置：终端--" + ParseTool.IntToHex4(rtua) + "，任务号--" + taskid + "，数据项个数--" + dids.size());
/*     */ 
/*  90 */       for (int iter = 0; iter < dids.size(); ++iter) {
/*  91 */         this.DI.add(iter, pdc.getDataItemConfig((String)dids.get(iter)));
/*     */       }
/*  93 */       this.TS = this.rtask.getSampleStartTime();
/*  94 */       this.TSUnit = Integer.parseInt(this.rtask.getSampleStartTimeUnit(), 16);
/*  95 */       this.TI = this.rtask.getSampleInterval();
/*  96 */       this.TIUnit = Integer.parseInt(this.rtask.getSampleIntervalUnit(), 16);
/*  97 */       this.RS = this.rtask.getUploadStartTime();
/*  98 */       this.RSUnit = Integer.parseInt(this.rtask.getUploadStartTimeUnit(), 16);
/*  99 */       this.RI = this.rtask.getUploadInterval();
/* 100 */       this.RIUnit = Integer.parseInt(this.rtask.getUploadIntervalUnit(), 16);
/* 101 */       this.RDI = this.rtask.getFrequence();
/*     */     }
/*     */     catch (Exception e) {
/* 104 */       throw new MessageDecodeException("无法获取终端任务配置，终端逻辑地址：" + ParseTool.IntToHex4(rtua) + "，任务号：" + taskid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getDataLength()
/*     */   {
/* 113 */     int rt = 0;
/* 114 */     for (Iterator iter = this.DI.iterator(); iter.hasNext(); ) {
/* 115 */       ProtocolDataItemConfig dc = (ProtocolDataItemConfig)iter.next();
/* 116 */       rt += dc.getLength();
/*     */     }
/* 118 */     return rt;
/*     */   }
/*     */ 
/*     */   public String getDataCodes() {
/* 122 */     StringBuffer sb = new StringBuffer();
/* 123 */     for (Iterator iter = this.DI.iterator(); iter.hasNext(); ) {
/* 124 */       ProtocolDataItemConfig dc = (ProtocolDataItemConfig)iter.next();
/* 125 */       if (sb.length() > 0) {
/* 126 */         sb.append(",");
/*     */       }
/* 128 */       sb.append(dc.getCode());
/*     */     }
/* 130 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public int getDataNum() {
/* 134 */     int rt = 0;
/* 135 */     if (this.DI != null) {
/* 136 */       rt = this.DI.size();
/*     */     }
/* 138 */     return rt;
/*     */   }
/*     */ 
/*     */   public List getDI()
/*     */   {
/* 145 */     return this.DI;
/*     */   }
/*     */ 
/*     */   public void setDI(List di)
/*     */   {
/* 152 */     this.DI = di;
/*     */   }
/*     */ 
/*     */   public int getDIN()
/*     */   {
/* 159 */     return this.DIN;
/*     */   }
/*     */ 
/*     */   public void setDIN(int din)
/*     */   {
/* 166 */     this.DIN = din;
/*     */   }
/*     */ 
/*     */   public int getRDI()
/*     */   {
/* 173 */     return this.RDI;
/*     */   }
/*     */ 
/*     */   public void setRDI(int rdi)
/*     */   {
/* 180 */     this.RDI = rdi;
/*     */   }
/*     */ 
/*     */   public int getRI()
/*     */   {
/* 187 */     return this.RI;
/*     */   }
/*     */ 
/*     */   public void setRI(int ri)
/*     */   {
/* 194 */     this.RI = ri;
/*     */   }
/*     */ 
/*     */   public int getRIUnit()
/*     */   {
/* 201 */     return this.RIUnit;
/*     */   }
/*     */ 
/*     */   public void setRIUnit(int unit)
/*     */   {
/* 208 */     this.RIUnit = unit;
/*     */   }
/*     */ 
/*     */   public int getRS()
/*     */   {
/* 215 */     return this.RS;
/*     */   }
/*     */ 
/*     */   public void setRS(int rs)
/*     */   {
/* 222 */     this.RS = rs;
/*     */   }
/*     */ 
/*     */   public int getRSUnit()
/*     */   {
/* 229 */     return this.RSUnit;
/*     */   }
/*     */ 
/*     */   public void setRSUnit(int unit)
/*     */   {
/* 236 */     this.RSUnit = unit;
/*     */   }
/*     */ 
/*     */   public int getRT()
/*     */   {
/* 243 */     return this.RT;
/*     */   }
/*     */ 
/*     */   public void setRT(int rt)
/*     */   {
/* 250 */     this.RT = rt;
/*     */   }
/*     */ 
/*     */   public int getSP()
/*     */   {
/* 257 */     return this.SP;
/*     */   }
/*     */ 
/*     */   public void setSP(int sp)
/*     */   {
/* 264 */     this.SP = sp;
/*     */   }
/*     */ 
/*     */   public int getTI()
/*     */   {
/* 271 */     return this.TI;
/*     */   }
/*     */ 
/*     */   public void setTI(int ti)
/*     */   {
/* 278 */     this.TI = ti;
/*     */   }
/*     */ 
/*     */   public int getTIUnit()
/*     */   {
/* 285 */     return this.TIUnit;
/*     */   }
/*     */ 
/*     */   public void setTIUnit(int unit)
/*     */   {
/* 292 */     this.TIUnit = unit;
/*     */   }
/*     */ 
/*     */   public int getTN()
/*     */   {
/* 299 */     return this.TN;
/*     */   }
/*     */ 
/*     */   public void setTN(int tn)
/*     */   {
/* 306 */     this.TN = tn;
/*     */   }
/*     */ 
/*     */   public int getTS()
/*     */   {
/* 313 */     return this.TS;
/*     */   }
/*     */ 
/*     */   public void setTS(int ts)
/*     */   {
/* 320 */     this.TS = ts;
/*     */   }
/*     */ 
/*     */   public int getTSUnit()
/*     */   {
/* 327 */     return this.TSUnit;
/*     */   }
/*     */ 
/*     */   public void setTSUnit(int unit)
/*     */   {
/* 334 */     this.TSUnit = unit;
/*     */   }
/*     */ 
/*     */   public int getTT()
/*     */   {
/* 341 */     return this.TT;
/*     */   }
/*     */ 
/*     */   public void setTT(int tt)
/*     */   {
/* 348 */     this.TT = tt;
/*     */   }
/*     */ 
/*     */   public BizRtu getRtu()
/*     */   {
/* 358 */     return this.rtu;
/*     */   }
/*     */ 
/*     */   public TaskTemplate getRtask() {
/* 362 */     return this.rtask;
/*     */   }
/*     */ 
/*     */   public void setRtask(TaskTemplate rtask) {
/* 366 */     this.rtask = rtask;
/*     */   }
/*     */ }