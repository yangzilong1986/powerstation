/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalReadCurrentDataRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C01MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  29 */   private static Log log = LogFactory.getLog(C01MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj)
/*     */   {
/*  34 */     List rt = null;
/*     */     try {
/*  36 */       if (obj instanceof FaalReadCurrentDataRequest) {
/*  37 */         FaalReadCurrentDataRequest para = (FaalReadCurrentDataRequest)obj;
/*     */ 
/*  40 */         String[] sps = para.getTn();
/*  41 */         if (sps == null) {
/*  42 */           throw new MessageEncodeException("未指定测量点");
/*     */         }
/*  44 */         byte[] points = new byte[sps.length];
/*  45 */         for (int i = 0; i < sps.length; ++i) {
/*  46 */           points[i] = Byte.parseByte(sps[i]);
/*     */         }
/*     */ 
/*  50 */         List dks = para.getParams();
/*  51 */         if ((dks == null) || (dks.size() <= 0)) {
/*  52 */           throw new MessageEncodeException("未指定召测数据项");
/*     */         }
/*  54 */         int[] datakeys = new int[dks.size()];
/*  55 */         int[] itemlen = new int[dks.size()];
/*     */ 
/*  57 */         for (int i = 0; i < dks.size(); ++i) {
/*  58 */           FaalRequestParam frp = (FaalRequestParam)dks.get(i);
/*  59 */           datakeys[i] = ParseTool.HexToDecimal(frp.getName());
/*     */           try {
/*  61 */             itemlen[i] = getDataItemConfig(frp.getName()).getLength();
/*     */           } catch (Exception e) {
/*  63 */             throw new MessageEncodeException("召测不支持的参数--" + frp.getName());
/*     */           }
/*     */         }
/*  66 */         dks = null;
/*     */ 
/*  69 */         int len = datakeys.length * 2 + 8;
/*     */ 
/*  71 */         byte[] frame = new byte[len];
/*  72 */         for (int i = 0; i < points.length; ++i) {
/*  73 */           int index = 0;
/*  74 */           int flag = 1;
/*  75 */           index = (points[i] & 0xFF) / 8;
/*  76 */           flag <<= (points[i] & 0xFF) % 8;
/*  77 */           frame[index] = (byte)((frame[index] & 0xFF | flag) & 0xFF);
/*     */         }
/*  79 */         int loc = 8;
/*  80 */         int fdlen = 0;
/*  81 */         int ntnum = 0;
/*  82 */         List titems = new ArrayList();
/*  83 */         for (int j = 0; j < datakeys.length; ++j) {
/*  84 */           if (ParseTool.isTask(datakeys[j])) {
/*  85 */             titems.add(new byte[] { (byte)(datakeys[j] & 0xFF), (byte)((datakeys[j] & 0xFF00) >>> 8) });
/*     */           } else {
/*  87 */             frame[loc] = (byte)(datakeys[j] & 0xFF);
/*  88 */             frame[(loc + 1)] = (byte)((datakeys[j] & 0xFF00) >>> 8);
/*  89 */             loc += 2;
/*  90 */             fdlen += 2;
/*  91 */             fdlen += itemlen[j] * sps.length;
/*  92 */             ++ntnum;
/*     */           }
/*     */         }
/*     */ 
/*  96 */         List rtuid = para.getRtuIds();
/*  97 */         if (rtuid == null) {
/*  98 */           throw new MessageEncodeException("未指定召测终端");
/*     */         }
/* 100 */         List cmdIds = para.getCmdIds();
/* 101 */         if (cmdIds == null) {
/* 102 */           throw new MessageEncodeException("命令ID缺失");
/*     */         }
/* 104 */         rt = new ArrayList();
/* 105 */         for (int i = 0; i < rtuid.size(); ++i) {
/* 106 */           String id = (String)rtuid.get(i);
/* 107 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/* 108 */           if (rtu == null) {
/* 109 */             log.info("终端信息未在缓存列表：" + id);
/*     */           }
/*     */           else
/*     */           {
/* 113 */             int datamax = DataItemCoder.getDataMax(rtu);
/*     */ 
/* 117 */             int msgcount = 0;
/*     */ 
/* 119 */             if (titems.size() > 0) {
/* 120 */               for (int k = 0; k < titems.size(); ++k)
/*     */               {
/* 122 */                 MessageZjHead head = createHead(rtu);
/* 123 */                 head.dlen = 10;
/*     */ 
/* 125 */                 byte[] frameA = new byte[10];
/* 126 */                 System.arraycopy(frame, 0, frameA, 0, 8);
/* 127 */                 System.arraycopy((byte[])(byte[])titems.get(k), 0, frameA, 8, 2);
/* 128 */                 MessageZj msg = new MessageZj();
/*     */ 
/* 130 */                 msg.setCmdId((Long)cmdIds.get(i));
/*     */ 
/* 133 */                 ++msgcount;
/* 134 */                 msg.data = ByteBuffer.wrap(frameA);
/* 135 */                 msg.head = head;
/*     */ 
/* 137 */                 rt.add(msg);
/*     */               }
/*     */             }
/*     */ 
/* 141 */             if ((datamax >= fdlen + 8) || (datakeys.length == 1))
/*     */             {
/* 143 */               if (ntnum > 0) {
/* 144 */                 len = 8 + ntnum * 2;
/* 145 */                 MessageZjHead head = createHead(rtu);
/* 146 */                 head.dlen = (short)len;
/*     */ 
/* 148 */                 byte[] frameA = new byte[len];
/* 149 */                 System.arraycopy(frame, 0, frameA, 0, len);
/*     */ 
/* 151 */                 MessageZj msg = new MessageZj();
/*     */ 
/* 153 */                 msg.setCmdId((Long)cmdIds.get(i));
/*     */ 
/* 155 */                 ++msgcount;
/* 156 */                 msg.data = ByteBuffer.wrap(frameA);
/* 157 */                 msg.head = head;
/*     */ 
/* 159 */                 rt.add(msg);
/*     */               }
/*     */             } else {
/* 162 */               int dnum = 0;
/* 163 */               int pos = 0;
/* 164 */               int curlen = 0;
/* 165 */               for (int j = 0; j < ntnum; ++j)
/*     */               {
/* 167 */                 ++dnum;
/* 168 */                 curlen += 2 + itemlen[j] * sps.length;
/* 169 */                 if ((curlen + 8 <= datamax) && (j != ntnum - 1))
/*     */                   continue;
/* 171 */                 MessageZjHead head = createHead(rtu);
/* 172 */                 head.dlen = (short)(8 + dnum * 2);
/*     */ 
/* 174 */                 byte[] frameA = new byte[head.dlen];
/* 175 */                 System.arraycopy(frame, 0, frameA, 0, 8);
/* 176 */                 System.arraycopy(frame, 8 + pos * 2, frameA, 8, head.dlen - 8);
/*     */ 
/* 178 */                 MessageZj msg = new MessageZj();
/*     */ 
/* 180 */                 msg.setCmdId((Long)cmdIds.get(i));
/*     */ 
/* 182 */                 ++msgcount;
/* 183 */                 msg.data = ByteBuffer.wrap(frameA);
/* 184 */                 msg.head = head;
/* 185 */                 rt.add(msg);
/* 186 */                 pos += dnum;
/* 187 */                 dnum = 0;
/* 188 */                 curlen = 0;
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 194 */             setMsgcount(rt, msgcount); }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 198 */       throw new MessageEncodeException(e);
/*     */     }
/* 200 */     if (rt != null) {
/* 201 */       IMessage[] msgs = new IMessage[rt.size()];
/* 202 */       rt.toArray(msgs);
/* 203 */       return msgs;
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   private MessageZjHead createHead(BizRtu rtu)
/*     */   {
/* 210 */     MessageZjHead head = new MessageZjHead();
/* 211 */     head.c_dir = 0;
/* 212 */     head.c_expflag = 0;
/* 213 */     head.c_func = 1;
/*     */ 
/* 217 */     head.rtua = rtu.getRtua();
/*     */ 
/* 219 */     head.iseq = 0;
/*     */ 
/* 222 */     return head;
/*     */   }
/*     */ 
/*     */   private ProtocolDataItemConfig getDataItemConfig(String datakey) {
/* 226 */     return this.dataConfig.getDataItemConfig(datakey); }
/*     */ 
/*     */   private void setMsgcount(List msgs, int msgcount) {
/* 229 */     for (Iterator iter = msgs.iterator(); iter.hasNext(); ) {
/* 230 */       MessageZj msg = (MessageZj)iter.next();
/* 231 */       if (msg.getMsgCount() == 0)
/* 232 */         msg.setMsgCount(msgcount);
/*     */     }
/*     */   }
/*     */ }