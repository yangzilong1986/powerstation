/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser08
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append("20");
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 31 */         sb.append("-");
/* 32 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 33 */         sb.append("-");
/* 34 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 35 */         sb.append(",");
/* 36 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 37 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 40 */       e.printStackTrace();
/*    */     }
/* 42 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       for (int i = 0; i < value.length(); ++i) {
/* 58 */         char c = value.charAt(i);
/* 59 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 62 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 65 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 68 */         throw new MessageEncodeException("错误的 YYYY-MM-DD 组帧参数:" + value);
/*    */       }
/* 70 */       String[] para = value.split(",");
/* 71 */       String[] date = para[0].split("-");
/* 72 */       frame[loc] = ParseTool.StringToBcd(para[1]);
/* 73 */       frame[(loc + 1)] = ParseTool.StringToBcd(date[2]);
/* 74 */       frame[(loc + 2)] = ParseTool.StringToBcd(date[1]);
/* 75 */       frame[(loc + 3)] = ParseTool.StringToBcd(date[0].substring(date[0].length() - 2, date[0].length()));
/*    */     } catch (Exception e) {
/* 77 */       throw new MessageEncodeException("错误的 YYYY-MM-DD,WW 组帧参数:" + value);
/*    */     }
/* 79 */     return len;
/*    */   }
/*    */ }