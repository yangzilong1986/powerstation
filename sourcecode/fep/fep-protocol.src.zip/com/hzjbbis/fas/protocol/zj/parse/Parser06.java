/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser06
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 27 */       if (ok)
/* 28 */         rt = ParseTool.BytesToHexL(data, loc, len);
/*    */     }
/*    */     catch (Exception e) {
/* 31 */       e.printStackTrace();
/*    */     }
/* 33 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 47 */       ParseTool.HexsToBytesCB(frame, loc, value);
/*    */     } catch (Exception e) {
/* 49 */       throw new MessageEncodeException("错误的HEX码组帧参数:" + value);
/*    */     }
/* 51 */     return len;
/*    */   }
/*    */ }