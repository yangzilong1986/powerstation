/*      */ package com.hzjbbis.fas.protocol.zj.parse;
/*      */ 
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ 
/*      */ public class DataItemParser
/*      */ {
/*      */   public static final int COMM_TYPE_SMS = 1;
/*      */   public static final int COMM_TYPE_GPRS = 2;
/*      */   public static final int COMM_TYPE_DTMF = 3;
/*      */   public static final int COMM_TYPE_ETHERNET = 4;
/*      */   public static final int COMM_TYPE_INFRA = 5;
/*      */   public static final int COMM_TYPE_RS232 = 6;
/*      */   public static final int COMM_TYPE_CSD = 7;
/*      */   public static final int COMM_TYPE_RADIO = 8;
/*      */   public static final int COMM_TYPE_INVALID = 255;
/*      */   public static final int TASK_TYPE_NORMAL = 1;
/*      */   public static final int TASK_TYPE_RELAY = 2;
/*      */   public static final int TASK_TYPE_EXCEPTION = 4;
/*      */ 
/*      */   public static Object parsevalue(byte[] data, int loc, int len, int fraction, int parserno)
/*      */   {
/*   39 */     Object rt = null;
/*      */     try {
/*   41 */       if (data != null) {
/*   42 */         switch (parserno)
/*      */         {
/*      */         case 1:
/*   44 */           rt = Parser01.parsevalue(data, loc, len, fraction);
/*   45 */           break;
/*      */         case 2:
/*   47 */           rt = Parser02.parsevalue(data, loc, len, fraction);
/*   48 */           break;
/*      */         case 3:
/*   50 */           rt = Parser03.parsevalue(data, loc, len, fraction);
/*   51 */           break;
/*      */         case 4:
/*   53 */           rt = Parser04.parsevalue(data, loc, len, fraction);
/*   54 */           break;
/*      */         case 5:
/*   56 */           rt = Parser05.parsevalue(data, loc, len, fraction);
/*   57 */           break;
/*      */         case 6:
/*   59 */           rt = Parser06.parsevalue(data, loc, len, fraction);
/*   60 */           break;
/*      */         case 7:
/*   62 */           rt = Parser07.parsevalue(data, loc, len, fraction);
/*   63 */           break;
/*      */         case 8:
/*   65 */           rt = Parser08.parsevalue(data, loc, len, fraction);
/*   66 */           break;
/*      */         case 9:
/*   68 */           rt = Parser09.parsevalue(data, loc, len, fraction);
/*   69 */           break;
/*      */         case 10:
/*   71 */           rt = Parser10.parsevalue(data, loc, len, fraction);
/*   72 */           break;
/*      */         case 11:
/*   74 */           rt = Parser11.parsevalue(data, loc, len, fraction);
/*   75 */           break;
/*      */         case 12:
/*   77 */           rt = Parser12.parsevalue(data, loc, len, fraction);
/*   78 */           break;
/*      */         case 13:
/*   80 */           rt = Parser13.parsevalue(data, loc, len, fraction);
/*   81 */           break;
/*      */         case 14:
/*   83 */           rt = Parser14.parsevalue(data, loc, len, fraction);
/*   84 */           break;
/*      */         case 15:
/*   86 */           rt = Parser15.parsevalue(data, loc, len, fraction);
/*   87 */           break;
/*      */         case 16:
/*   89 */           rt = Parser16.parsevalue(data, loc, len, fraction);
/*   90 */           break;
/*      */         case 17:
/*   92 */           rt = Parser17.parsevalue(data, loc, len, fraction);
/*   93 */           break;
/*      */         case 18:
/*   95 */           rt = Parser18.parsevalue(data, loc, len, fraction);
/*   96 */           break;
/*      */         case 19:
/*   98 */           rt = Parser19.parsevalue(data, loc, len, fraction);
/*   99 */           break;
/*      */         case 20:
/*  101 */           rt = Parser20.parsevalue(data, loc, len, fraction);
/*  102 */           break;
/*      */         case 21:
/*  104 */           rt = Parser21.parsevalue(data, loc, len, fraction);
/*  105 */           break;
/*      */         case 22:
/*  107 */           rt = Parser22.parsevalue(data, loc, len, fraction);
/*  108 */           break;
/*      */         case 23:
/*  110 */           rt = Parser23.parsevalue(data, loc, len, fraction);
/*  111 */           break;
/*      */         case 24:
/*  113 */           rt = Parser24.parsevalue(data, loc, len, fraction);
/*  114 */           break;
/*      */         case 25:
/*  116 */           rt = Parser25.parsevalue(data, loc, len, fraction);
/*  117 */           break;
/*      */         case 26:
/*  119 */           rt = Parser26.parsevalue(data, loc, len, fraction);
/*  120 */           break;
/*      */         case 27:
/*  122 */           rt = Parser27.parsevalue(data, loc, len, fraction);
/*  123 */           break;
/*      */         case 28:
/*  125 */           rt = Parser28.parsevalue(data, loc, len, fraction);
/*  126 */           break;
/*      */         case 29:
/*  128 */           rt = Parser29.parsevalue(data, loc, len, fraction);
/*  129 */           break;
/*      */         case 30:
/*  131 */           rt = Parser30.parsevalue(data, loc, len, fraction);
/*  132 */           break;
/*      */         case 31:
/*  134 */           rt = Parser31.parsevalue(data, loc, len, fraction);
/*  135 */           break;
/*      */         case 32:
/*  137 */           rt = Parser32.parsevalue(data, loc, len, fraction);
/*  138 */           break;
/*      */         case 33:
/*  140 */           rt = Parser33.parsevalue(data, loc, len, fraction);
/*  141 */           break;
/*      */         case 34:
/*  143 */           rt = Parser34.parsevalue(data, loc, len, fraction);
/*  144 */           break;
/*      */         case 35:
/*  146 */           rt = Parser35.parsevalue(data, loc, len, fraction);
/*  147 */           break;
/*      */         case 36:
/*  149 */           rt = Parser36.parsevalue(data, loc, len, fraction);
/*  150 */           break;
/*      */         case 37:
/*  152 */           rt = Parser37.parsevalue(data, loc, len, fraction);
/*  153 */           break;
/*      */         case 38:
/*  155 */           rt = Parser38.parsevalue(data, loc, len, fraction);
/*  156 */           break;
/*      */         case 39:
/*  158 */           rt = Parser39.parsevalue(data, loc, len, fraction);
/*  159 */           break;
/*      */         case 40:
/*  161 */           rt = Parser40.parsevalue(data, loc, len, fraction);
/*  162 */           break;
/*      */         case 41:
/*  164 */           rt = Parser41.parsevalue(data, loc, len, fraction);
/*  165 */           break;
/*      */         case 42:
/*  167 */           rt = Parser42.parsevalue(data, loc, len, fraction);
/*  168 */           break;
/*      */         case 43:
/*  170 */           rt = Parser43.parsevalue(data, loc, len, fraction);
/*  171 */           break;
/*      */         case 44:
/*  173 */           rt = Parser44.parsevalue(data, loc, len, fraction);
/*  174 */           break;
/*      */         case 45:
/*  176 */           rt = Parser45.parsevalue(data, loc, len, fraction);
/*  177 */           break;
/*      */         case 46:
/*  179 */           rt = Parser46.parsevalue(data, loc, len, fraction);
/*  180 */           break;
/*      */         case 47:
/*  182 */           rt = Parser47.parsevalue(data, loc, len, fraction);
/*  183 */           break;
/*      */         case 48:
/*  185 */           rt = Parser48.parsevalue(data, loc, len, fraction);
/*  186 */           break;
/*      */         case 49:
/*  188 */           rt = Parser49.parsevalue(data, loc, len, fraction);
/*  189 */           break;
/*      */         case 50:
/*  191 */           rt = Parser50.parsevalue(data, loc, len, fraction);
/*  192 */           break;
/*      */         case 51:
/*  194 */           rt = Parser51.parsevalue(data, loc, len, fraction);
/*  195 */           break;
/*      */         case 52:
/*  197 */           rt = Parser52.parsevalue(data, loc, len, fraction);
/*  198 */           break;
/*      */         case 53:
/*  200 */           rt = Parser53.parsevalue(data, loc, len, fraction);
/*  201 */           break;
/*      */         case 54:
/*  203 */           rt = Parser54.parsevalue(data, loc, len, fraction);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  212 */       e.printStackTrace();
/*      */     }
/*  214 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parsevalue(byte[] data, int index, int datakey)
/*      */   {
/*  225 */     Object di = null;
/*      */     try {
/*  227 */       switch (datakey & 0xFF00)
/*      */       {
/*      */       case 32768:
/*  229 */         di = parseVC8000(data, index, 0, datakey);
/*  230 */         break;
/*      */       case 33024:
/*  232 */         di = parseVC81XX(data, index, 0, datakey);
/*  233 */         break;
/*      */       case 33280:
/*  235 */         di = parseVC82XX(data, index, 0, datakey);
/*  236 */         break;
/*      */       case 33536:
/*  238 */         di = parseVC83XX(data, index, 0, datakey);
/*  239 */         break;
/*      */       case 33792:
/*  241 */         di = parseVC84XX(data, index, 0, datakey);
/*  242 */         break;
/*      */       case 34048:
/*  244 */         di = parseVC85XX(data, index, 0, datakey);
/*  245 */         break;
/*      */       case 34304:
/*  247 */         di = parseVC86XX(data, index, 0, datakey);
/*  248 */         break;
/*      */       case 34560:
/*  250 */         di = parseVC87XX(data, index, 0, datakey);
/*  251 */         break;
/*      */       case 34816:
/*  253 */         di = parseVC88XX(data, index, 0, datakey);
/*  254 */         break;
/*      */       case 35072:
/*  256 */         di = parseVC89XX(data, index, 0, datakey);
/*  257 */         break;
/*      */       case 36352:
/*  259 */         di = parseVC8EXX(data, index, 0, datakey);
/*  260 */         break;
/*      */       case 36864:
/*      */       case 37120:
/*  263 */         di = parseVC9XXX(data, index, 4, datakey);
/*  264 */         break;
/*      */       case 40960:
/*      */       case 41984:
/*  267 */         di = parseVCAXXX(data, index, 3, datakey);
/*  268 */         break;
/*      */       case 45056:
/*  270 */         di = parseVCB0XX(data, index, 4, datakey);
/*  271 */         break;
/*      */       case 45568:
/*  273 */         di = parseVCB2XX(data, index, 2, datakey);
/*  274 */         break;
/*      */       case 45824:
/*  276 */         di = parseVCB3XX(data, index, 3, datakey);
/*  277 */         break;
/*      */       case 46080:
/*  279 */         di = parseVCB0XX(data, index, 4, datakey);
/*  280 */         break;
/*      */       case 46592:
/*  282 */         di = parseVCB6XX(data, index, 4, datakey);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/*  291 */     return di;
/*      */   }
/*      */ 
/*      */   public static Object parseC8010(byte[] data, int index, int len)
/*      */   {
/*      */     int port;
/*      */     String ip;
/*  301 */     String des = "";
/*  302 */     int type = data[(index + 8)] & 0xFF;
/*  303 */     switch (type)
/*      */     {
/*      */     case 1:
/*  305 */       des = ParseTool.toPhoneCode(data, index, 8, 170);
/*  306 */       break;
/*      */     case 2:
/*  308 */       port = ParseTool.nBcdToDecimal(data, index, 2);
/*  309 */       ip = (data[(index + 5)] & 0xFF) + "." + (data[(index + 4)] & 0xFF) + "." + (data[(index + 3)] & 0xFF) + "." + (data[(index + 2)] & 0xFF);
/*  310 */       des = ip + ":" + port;
/*  311 */       break;
/*      */     case 3:
/*  313 */       des = ParseTool.toPhoneCode(data, index, 8, 170);
/*  314 */       break;
/*      */     case 4:
/*  316 */       port = ParseTool.nBcdToDecimal(data, index, 2);
/*  317 */       ip = (data[(index + 5)] & 0xFF) + "." + (data[(index + 4)] & 0xFF) + "." + (data[(index + 3)] & 0xFF) + "." + (data[(index + 2)] & 0xFF);
/*  318 */       des = ip + ":" + port;
/*  319 */       break;
/*      */     case 5:
/*  321 */       break;
/*      */     case 6:
/*  323 */       break;
/*      */     case 7:
/*  325 */       des = ParseTool.toPhoneCode(data, index, 8, 170);
/*  326 */       break;
/*      */     case 8:
/*      */     }
/*      */ 
/*  332 */     return des;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8013(byte[] data, int index, int len)
/*      */   {
/*  342 */     String rt = "";
/*      */     try {
/*  344 */       rt = ParseTool.toPhoneCode(data, index, len, 170);
/*      */     } catch (Exception e) {
/*  346 */       e.printStackTrace();
/*      */     }
/*  348 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8014(byte[] data, int index, int len)
/*      */   {
/*  358 */     String rt = "";
/*      */     try {
/*  360 */       int port = ParseTool.nBcdToDecimal(data, index, 2);
/*  361 */       String ip = (data[(index + 5)] & 0xFF) + "." + (data[(index + 4)] & 0xFF) + "." + (data[(index + 3)] & 0xFF) + "." + (data[(index + 2)] & 0xFF);
/*  362 */       rt = ip + ":" + port;
/*      */     } catch (Exception e) {
/*  364 */       e.printStackTrace();
/*      */     }
/*  366 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8015(byte[] data, int index, int len)
/*      */   {
/*  376 */     String rt = "";
/*      */     try {
/*  378 */       rt = new String(data, index, len);
/*      */     } catch (Exception e) {
/*  380 */       e.printStackTrace();
/*      */     }
/*  382 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseC8016(byte[] data, int index, int len)
/*      */   {
/*  394 */     int code = ((data[index] & 0xFF) << 8) + (data[(index + 1)] & 0xFF);
/*      */ 
/*  396 */     return String.valueOf(code);
/*      */   }
/*      */ 
/*      */   public static Object parseC8017(byte[] data, int index, int len)
/*      */   {
/*  408 */     int code = ((data[index] & 0xFF) << 8) + (data[(index + 1)] & 0xFF);
/*      */ 
/*  410 */     return String.valueOf(code);
/*      */   }
/*      */ 
/*      */   public static Object parseVC8020(byte[] data, int index, int len)
/*      */   {
/*  420 */     String rt = "";
/*      */     try {
/*  422 */       rt = (data[index] & 0xF) + "," + ParseTool.BytesToHexC(data, index + 1, 2);
/*      */     } catch (Exception e) {
/*  424 */       e.printStackTrace();
/*      */     }
/*  426 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8021(byte[] data, int index, int len)
/*      */   {
/*  436 */     String rt = "";
/*      */     try {
/*  438 */       rt = ParseTool.BytesToHexL(data, index, len);
/*      */     } catch (Exception e) {
/*  440 */       e.printStackTrace();
/*      */     }
/*  442 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8030(byte[] data, int index, int len)
/*      */   {
/*  452 */     String rt = "";
/*      */     try {
/*  454 */       Calendar time = ParseTool.getTimeW(data, index);
/*  455 */       SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  456 */       rt = sf.format(time.getTime());
/*      */     } catch (Exception e) {
/*  458 */       e.printStackTrace();
/*      */     }
/*  460 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8031(byte[] data, int index, int len)
/*      */   {
/*  470 */     String rt = "";
/*      */     try
/*      */     {
/*  487 */       rt = rt + ParseTool.ByteToHex(data[(index + 3)]);
/*  488 */       rt = rt + "," + (data[(index + 2)] & 0xFF);
/*  489 */       rt = rt + "," + ParseTool.ByteToHex(data[(index + 1)]) + ":" + ParseTool.ByteToHex(data[index]);
/*      */     }
/*      */     catch (Exception e) {
/*  492 */       e.printStackTrace();
/*      */     }
/*  494 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8032(byte[] data, int index, int len)
/*      */   {
/*  504 */     return new Integer(data[index] & 0xF);
/*      */   }
/*      */ 
/*      */   public static Object parseVC8000(byte[] data, int index, int len, int datakey)
/*      */   {
/*  517 */     Object rt = null;
/*  518 */     switch (datakey & 0xFFF0)
/*      */     {
/*      */     case 32784:
/*  520 */       rt = parseVC801X(data, index, len, datakey);
/*  521 */       break;
/*      */     case 32800:
/*  523 */       rt = parseVC802X(data, index, len, datakey);
/*  524 */       break;
/*      */     case 32816:
/*  526 */       rt = parseVC803X(data, index, len, datakey);
/*  527 */       break;
/*      */     case 32832:
/*  529 */       rt = parseVC804X(data, index, len, datakey);
/*  530 */       break;
/*      */     case 32848:
/*  532 */       rt = parseVC805X(data, index, len, datakey);
/*  533 */       break;
/*      */     case 32864:
/*  535 */       rt = parseVC806X(data, index, len, datakey);
/*      */     }
/*      */ 
/*  540 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC801X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  552 */     Object rt = null;
/*  553 */     switch (datakey)
/*      */     {
/*      */     case 32784:
/*      */     case 32785:
/*      */     case 32786:
/*  557 */       rt = parseC8010(data, index, len);
/*  558 */       break;
/*      */     case 32787:
/*  560 */       rt = parseVC8013(data, index, len);
/*  561 */       break;
/*      */     case 32788:
/*  563 */       rt = parseVC8014(data, index, len);
/*  564 */       break;
/*      */     case 32789:
/*  566 */       rt = parseVC8015(data, index, len);
/*  567 */       break;
/*      */     case 32790:
/*  569 */       rt = parseC8016(data, index, len);
/*  570 */       break;
/*      */     case 32791:
/*  572 */       rt = parseC8017(data, index, len);
/*      */     }
/*      */ 
/*  577 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC802X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  589 */     Object rt = null;
/*  590 */     switch (datakey)
/*      */     {
/*      */     case 32800:
/*  592 */       rt = parseVC8020(data, index, 3);
/*  593 */       break;
/*      */     case 32801:
/*      */     case 32802:
/*  596 */       rt = parseVC8021(data, index, 3);
/*  597 */       break;
/*      */     case 32803:
/*  599 */       rt = parseVC8021(data, index, 1);
/*      */     }
/*      */ 
/*  604 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC803X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  616 */     Object rt = null;
/*  617 */     switch (datakey)
/*      */     {
/*      */     case 32816:
/*  619 */       rt = parseVC8030(data, index, 6);
/*  620 */       break;
/*      */     case 32817:
/*  622 */       rt = parseVC8031(data, index, 4);
/*      */     case 32818:
/*  624 */       rt = parseVC8032(data, index, 1);
/*  625 */       break;
/*      */     case 32819:
/*  627 */       rt = ParseTool.BytesToHexL(data, index, 16);
/*  628 */       break;
/*      */     case 32820:
/*      */     case 32821:
/*      */     case 32822:
/*  632 */       rt = new Integer(data[index] & 0xFF);
/*  633 */       break;
/*      */     case 32823:
/*  635 */       rt = ParseTool.ByteToHex(data[index]);
/*      */     }
/*      */ 
/*  640 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8048(byte[] data, int index, int len)
/*      */   {
/*  650 */     StringBuffer sb = new StringBuffer();
/*  651 */     sb.append(ParseTool.ByteToHex(data[(index + 8)]));
/*  652 */     for (int i = 0; i < 8; ++i) {
/*  653 */       sb.append(",");
/*  654 */       sb.append(String.valueOf(data[(index + 7 - i)] & 0xFF));
/*      */     }
/*  656 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC804C(byte[] data, int index, int len)
/*      */   {
/*  666 */     StringBuffer sb = new StringBuffer();
/*  667 */     NumberFormat nf = NumberFormat.getInstance();
/*  668 */     nf.setMaximumFractionDigits(2);
/*  669 */     nf.setGroupingUsed(false);
/*  670 */     sb.append(String.valueOf(data[(index + 3)] & 0xF));
/*  671 */     sb.append(",");
/*  672 */     sb.append(nf.format((data[(index + 2)] & 0xFF) / 100.0D));
/*  673 */     sb.append(",");
/*  674 */     sb.append(ParseTool.ByteToHex(data[(index + 1)]));
/*  675 */     sb.append(":");
/*  676 */     sb.append(ParseTool.ByteToHex(data[index]));
/*  677 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC804X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  689 */     Object rt = null;
/*  690 */     switch (datakey)
/*      */     {
/*      */     case 32832:
/*      */     case 32833:
/*      */     case 32834:
/*      */     case 32835:
/*      */     case 32836:
/*  696 */       rt = ParseTool.ByteToHex(data[index]);
/*  697 */       break;
/*      */     case 32837:
/*      */     case 32838:
/*  700 */       rt = ParseTool.ByteToHex(data[(index + 2)]) + ":" + ParseTool.ByteToHex(data[(index + 1)]) + ":" + ParseTool.ByteToHex(data[index]);
/*  701 */       break;
/*      */     case 32839:
/*  703 */       rt = new Integer(data[index] & 0xFF);
/*  704 */       break;
/*      */     case 32840:
/*      */     case 32841:
/*  707 */       rt = parseVC8048(data, index, 9);
/*  708 */       break;
/*      */     case 32842:
/*      */     case 32843:
/*  711 */       rt = new Double(ParseTool.ByteToPercent(data[index]));
/*  712 */       break;
/*      */     case 32844:
/*  714 */       rt = parseVC804C(data, index, 4);
/*  715 */       break;
/*      */     case 32845:
/*  717 */       rt = new Integer(data[index] & 0xFF);
/*  718 */       break;
/*      */     case 32846:
/*  720 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 4) / 100.0D);
/*      */     }
/*      */ 
/*  725 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8051(byte[] data, int index, int len)
/*      */   {
/*  735 */     StringBuffer sb = new StringBuffer();
/*  736 */     NumberFormat nf = NumberFormat.getInstance();
/*  737 */     nf.setMaximumFractionDigits(2);
/*  738 */     nf.setGroupingUsed(false);
/*  739 */     sb.append(ParseTool.ByteToHex(data[(index + 6)]));
/*  740 */     sb.append(":");
/*  741 */     sb.append(ParseTool.ByteToHex(data[(index + 5)]));
/*  742 */     sb.append(",");
/*  743 */     sb.append(String.valueOf(data[(index + 4)] & 0xF));
/*  744 */     sb.append(",");
/*  745 */     sb.append(nf.format(ParseTool.nBcdToDecimal(data, index, 4) / 100.0D));
/*      */ 
/*  747 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC8059(byte[] data, int index, int len)
/*      */   {
/*  757 */     StringBuffer sb = new StringBuffer();
/*  758 */     NumberFormat nf = NumberFormat.getInstance();
/*  759 */     nf.setMaximumFractionDigits(2);
/*  760 */     nf.setGroupingUsed(false);
/*  761 */     sb.append(ParseTool.ByteToHex(data[(index + 8)]));
/*  762 */     sb.append("-");
/*  763 */     sb.append(ParseTool.ByteToHex(data[(index + 7)]));
/*  764 */     sb.append(",");
/*  765 */     sb.append(ParseTool.ByteToHex(data[(index + 6)]));
/*  766 */     sb.append("-");
/*  767 */     sb.append(ParseTool.ByteToHex(data[(index + 5)]));
/*  768 */     sb.append(",");
/*  769 */     sb.append(ParseTool.ByteToHex(data[(index + 4)]));
/*  770 */     sb.append(",");
/*  771 */     sb.append(ParseTool.ByteToHex(data[(index + 3)]));
/*  772 */     sb.append(",");
/*  773 */     sb.append(ParseTool.ByteToHex(data[(index + 2)]));
/*  774 */     sb.append(",");
/*  775 */     sb.append(ParseTool.ByteToHex(data[(index + 1)]));
/*  776 */     sb.append(",");
/*  777 */     sb.append(ParseTool.ByteToHex(data[(index + 0)]));
/*  778 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC805X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  790 */     Object rt = null;
/*  791 */     switch (datakey)
/*      */     {
/*      */     case 32848:
/*  793 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32849:
/*      */     case 32850:
/*      */     case 32851:
/*      */     case 32852:
/*      */     case 32853:
/*      */     case 32854:
/*      */     case 32855:
/*      */     case 32856:
/*  802 */       rt = parseVC8051(data, index, 7);
/*  803 */       break;
/*      */     case 32857:
/*  805 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/*  810 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC806X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  823 */     Object rt = null;
/*  824 */     switch (datakey)
/*      */     {
/*      */     case 32864:
/*      */     case 32865:
/*  827 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 4));
/*      */     case 32866:
/*  829 */       rt = String.valueOf(ParseTool.nBcdToDecimalS(data, index + 1, 4)) + "," + (data[index] & 0xFF);
/*  830 */       break;
/*      */     case 32867:
/*  832 */       rt = new Integer(ParseTool.nBcdToDecimalS(data, index, 5));
/*  833 */       break;
/*      */     case 32868:
/*  835 */       rt = ParseTool.ByteToHex(data[(index + 1)]) + ":" + ParseTool.ByteToHex(data[index]);
/*  836 */       break;
/*      */     case 32869:
/*  838 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 4));
/*      */     }
/*      */ 
/*  843 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC807X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  855 */     Object rt = null;
/*  856 */     switch (datakey)
/*      */     {
/*      */     case 32880:
/*  858 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32881:
/*      */     case 32882:
/*      */     case 32883:
/*      */     case 32884:
/*      */     case 32885:
/*      */     case 32886:
/*      */     case 32887:
/*      */     case 32888:
/*  867 */       rt = parseVC8051(data, index, 7);
/*  868 */       break;
/*      */     case 32889:
/*  870 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/*  875 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC808X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  887 */     Object rt = null;
/*  888 */     switch (datakey)
/*      */     {
/*      */     case 32896:
/*  890 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32897:
/*      */     case 32898:
/*      */     case 32899:
/*      */     case 32900:
/*      */     case 32901:
/*      */     case 32902:
/*      */     case 32903:
/*      */     case 32904:
/*  899 */       rt = parseVC8051(data, index, 7);
/*  900 */       break;
/*      */     case 32905:
/*  902 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/*  907 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC809X(byte[] data, int index, int len, int datakey)
/*      */   {
/*  919 */     Object rt = null;
/*  920 */     switch (datakey)
/*      */     {
/*      */     case 32912:
/*  922 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32913:
/*      */     case 32914:
/*      */     case 32915:
/*      */     case 32916:
/*      */     case 32917:
/*      */     case 32918:
/*      */     case 32919:
/*      */     case 32920:
/*  931 */       rt = parseVC8051(data, index, 7);
/*  932 */       break;
/*      */     case 32921:
/*  934 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/*  939 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC80AX(byte[] data, int index, int len, int datakey)
/*      */   {
/*  951 */     Object rt = null;
/*  952 */     switch (datakey)
/*      */     {
/*      */     case 32928:
/*  954 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32929:
/*      */     case 32930:
/*      */     case 32931:
/*      */     case 32932:
/*      */     case 32933:
/*      */     case 32934:
/*      */     case 32935:
/*      */     case 32936:
/*  963 */       rt = parseVC8051(data, index, 7);
/*  964 */       break;
/*      */     case 32937:
/*  966 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/*  971 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC80BX(byte[] data, int index, int len, int datakey)
/*      */   {
/*  983 */     Object rt = null;
/*  984 */     switch (datakey)
/*      */     {
/*      */     case 32944:
/*  986 */       rt = new Integer(data[index] & 0xF);
/*      */     case 32945:
/*      */     case 32946:
/*      */     case 32947:
/*      */     case 32948:
/*      */     case 32949:
/*      */     case 32950:
/*      */     case 32951:
/*      */     case 32952:
/*  995 */       rt = parseVC8051(data, index, 7);
/*  996 */       break;
/*      */     case 32953:
/*  998 */       rt = parseVC8059(data, index, 9);
/*      */     }
/*      */ 
/* 1003 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8101(byte[] data, int index, int len)
/*      */   {
/* 1013 */     StringBuffer sb = new StringBuffer();
/* 1014 */     sb.append(ParseTool.ByteToHex(data[index]));
/* 1015 */     sb.append(",");
/* 1016 */     sb.append(String.valueOf(data[(index + 2)] & 0xFF));
/* 1017 */     sb.append(",");
/* 1018 */     sb.append(ParseTool.ByteToHex(data[(index + 1)]));
/* 1019 */     sb.append(",");
/* 1020 */     sb.append(String.valueOf(data[(index + 4)] & 0xFF));
/* 1021 */     sb.append(",");
/* 1022 */     sb.append(ParseTool.ByteToHex(data[(index + 3)]));
/* 1023 */     sb.append(",");
/* 1024 */     sb.append(String.valueOf(data[(index + 6)] & 0xFF));
/* 1025 */     sb.append(",");
/* 1026 */     sb.append(ParseTool.ByteToHex(data[(index + 5)]));
/* 1027 */     sb.append(",");
/* 1028 */     sb.append(String.valueOf(data[(index + 8)] & 0xFF));
/* 1029 */     sb.append(",");
/* 1030 */     sb.append(ParseTool.ByteToHex(data[(index + 7)]));
/* 1031 */     sb.append(",");
/* 1032 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 9)])));
/* 1033 */     sb.append(",");
/* 1034 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 10)])));
/* 1035 */     sb.append(",");
/* 1036 */     sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, index + 11, 2)));
/* 1037 */     sb.append(",");
/* 1038 */     sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, index + 13, 2)));
/* 1039 */     sb.append(",");
/* 1040 */     int din = ParseTool.BCDToDecimal(data[(index + 15)]);
/* 1041 */     sb.append(String.valueOf(din));
/* 1042 */     if (din <= 32) {
/* 1043 */       int loc = index + 16;
/* 1044 */       for (int i = 0; i < din; ++i) {
/* 1045 */         sb.append(",");
/* 1046 */         sb.append(ParseTool.BytesToHexC(data, loc, 2));
/* 1047 */         loc += 2;
/*      */       }
/*      */     }
/* 1050 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC8102(byte[] data, int index, int len)
/*      */   {
/* 1060 */     StringBuffer sb = new StringBuffer();
/* 1061 */     sb.append(ParseTool.ByteToHex(data[index]));
/* 1062 */     sb.append(",");
/* 1063 */     sb.append(String.valueOf(data[(index + 2)] & 0xFF));
/* 1064 */     sb.append(",");
/* 1065 */     sb.append(ParseTool.ByteToHex(data[(index + 1)]));
/* 1066 */     sb.append(",");
/* 1067 */     sb.append(String.valueOf(data[(index + 4)] & 0xFF));
/* 1068 */     sb.append(",");
/* 1069 */     sb.append(ParseTool.ByteToHex(data[(index + 3)]));
/* 1070 */     sb.append(",");
/* 1071 */     sb.append(String.valueOf(data[(index + 6)] & 0xFF));
/* 1072 */     sb.append(",");
/* 1073 */     sb.append(ParseTool.ByteToHex(data[(index + 5)]));
/* 1074 */     sb.append(",");
/* 1075 */     sb.append(String.valueOf(data[(index + 8)] & 0xFF));
/* 1076 */     sb.append(",");
/* 1077 */     sb.append(ParseTool.ByteToHex(data[(index + 7)]));
/* 1078 */     sb.append(",");
/* 1079 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 9)])));
/* 1080 */     sb.append(",");
/* 1081 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 10)])));
/* 1082 */     sb.append(",");
/* 1083 */     sb.append(ParseTool.ByteToHex(data[(index + 11)]));
/* 1084 */     sb.append(",");
/* 1085 */     sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, index + 12, 2)));
/* 1086 */     sb.append(",");
/* 1087 */     sb.append(String.valueOf(data[(index + 14)] & 0xFF));
/* 1088 */     sb.append(",");
/* 1089 */     sb.append(ParseTool.ByteToHex(data[(index + 15)]));
/* 1090 */     sb.append(",");
/* 1091 */     sb.append(String.valueOf(ParseTool.nByteToInt(data, index + 16, 2)));
/* 1092 */     sb.append(",");
/* 1093 */     sb.append(String.valueOf(ParseTool.nByteToInt(data, index + 18, 2)));
/* 1094 */     sb.append(",");
/* 1095 */     int cl = ParseTool.BCDToDecimal(data[(index + 20)]);
/* 1096 */     sb.append(String.valueOf(cl));
/* 1097 */     sb.append(",");
/* 1098 */     if (cl <= 32) {
/* 1099 */       sb.append(ParseTool.BytesToHexL(data, index + 21, cl));
/*      */     }
/* 1101 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC8104(byte[] data, int index, int len)
/*      */   {
/* 1111 */     StringBuffer sb = new StringBuffer();
/* 1112 */     sb.append(ParseTool.ByteToHex(data[index]));
/* 1113 */     sb.append(",");
/* 1114 */     sb.append(ParseTool.BytesToHexC(data, index + 1, 2));
/* 1115 */     sb.append(",");
/* 1116 */     sb.append(String.valueOf(data[(index + 4)] & 0xFF));
/* 1117 */     sb.append(",");
/* 1118 */     sb.append(ParseTool.ByteToHex(data[(index + 3)]));
/* 1119 */     sb.append(",");
/* 1120 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 5)])));
/* 1121 */     sb.append(",");
/* 1122 */     int din = ParseTool.BCDToDecimal(data[(index + 6)]);
/* 1123 */     sb.append(String.valueOf(din));
/* 1124 */     if (din <= 32) {
/* 1125 */       int loc = index + 7;
/* 1126 */       for (int i = 0; i < din; ++i) {
/* 1127 */         sb.append(",");
/* 1128 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 1129 */         sb.append(" ");
/* 1130 */         sb.append(ParseTool.BytesToHexC(data, loc, 2));
/* 1131 */         loc += 3;
/*      */       }
/* 1133 */       sb.append(",");
/* 1134 */       sb.append(String.valueOf(ParseTool.BCDToDecimal(data[loc])));
/*      */     }
/* 1136 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC81XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1148 */     Object rt = null;
/* 1149 */     if (datakey == 33024) {
/* 1150 */       rt = new Integer(data[index] & 0xFF);
/* 1151 */     } else if ((datakey > 33024) && (datakey < 33278))
/*      */     {
/* 1153 */       int type = data[index] & 0xFF;
/* 1154 */       switch (type)
/*      */       {
/*      */       case 1:
/* 1156 */         parseVC8101(data, index, 16);
/* 1157 */         break;
/*      */       case 2:
/* 1159 */         parseVC8102(data, index, 21);
/* 1160 */         break;
/*      */       case 4:
/* 1162 */         parseVC8104(data, index, 7);
/*      */       case 3:
/*      */       }
/*      */     }
/* 1167 */     else if (datakey == 33278) {
/* 1168 */       rt = ParseTool.BytesToHexC(data, index, 32);
/*      */     }
/* 1170 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC82XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1182 */     Object rt = null;
/* 1183 */     rt = new Integer(data[index] & 0xFF);
/* 1184 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC83XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1196 */     Object rt = null;
/* 1197 */     if (datakey == 33536)
/* 1198 */       rt = new Integer(data[index] & 0xFF);
/* 1199 */     else if ((datakey > 33536) && (datakey < 33790))
/*      */     {
/* 1201 */       rt = String.valueOf(ParseTool.BCDToDecimal(data[(index + 1)])) + "," + String.valueOf((data[index] & 0xFF) >> 4) + "," + String.valueOf(data[index] & 0xF);
/* 1202 */     } else if (datakey == 33790) {
/* 1203 */       rt = ParseTool.BytesToHexC(data, index, 32);
/*      */     }
/* 1205 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC84XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1217 */     Object rt = null;
/* 1218 */     if (datakey == 33792)
/* 1219 */       rt = new Integer(data[index] & 0xFF);
/* 1220 */     else if ((datakey > 33792) && (datakey < 34046))
/*      */     {
/* 1222 */       rt = String.valueOf(ParseTool.BCDToDecimal(data[(index + 4)])) + "," + ParseTool.ByteToHex(data[(index + 3)]) + "," + String.valueOf(ParseTool.nBcdToDecimal(data, index, 3));
/* 1223 */     } else if (datakey == 34046) {
/* 1224 */       rt = ParseTool.BytesToHexC(data, index, 32);
/*      */     }
/* 1226 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8501(byte[] data, int index, int len)
/*      */   {
/* 1236 */     StringBuffer sb = new StringBuffer();
/* 1237 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 18)])));
/* 1238 */     sb.append(",");
/* 1239 */     sb.append(String.valueOf(ParseTool.BytesToHexC(data, index + 16, 2)));
/* 1240 */     int loc = index + 14;
/* 1241 */     for (int i = 0; i < 8; ++i) {
/* 1242 */       sb.append(",");
/* 1243 */       sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 1244 */       sb.append(",");
/* 1245 */       sb.append(String.valueOf(ParseTool.BCDToDecimal(data[loc])));
/* 1246 */       loc -= 2;
/*      */     }
/* 1248 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC85XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1260 */     Object rt = null;
/* 1261 */     if (datakey == 34048)
/* 1262 */       rt = new Integer(data[index] & 0xFF);
/* 1263 */     else if ((datakey > 34048) && (datakey < 34302))
/*      */     {
/* 1265 */       rt = parseVC8501(data, index, 19);
/* 1266 */     } else if (datakey == 34302) {
/* 1267 */       rt = ParseTool.BytesToHexC(data, index, 32);
/*      */     }
/* 1269 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8601(byte[] data, int index, int len)
/*      */   {
/* 1279 */     StringBuffer sb = new StringBuffer();
/* 1280 */     NumberFormat nf = NumberFormat.getInstance();
/* 1281 */     nf.setMaximumFractionDigits(2);
/* 1282 */     nf.setGroupingUsed(false);
/* 1283 */     sb.append(String.valueOf(ParseTool.BytesToHexC(data, index + 9, 2)));
/* 1284 */     sb.append(",");
/* 1285 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 8)])));
/* 1286 */     sb.append(",");
/* 1287 */     sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(index + 7)])));
/* 1288 */     sb.append(",");
/* 1289 */     sb.append(nf.format(ParseTool.nBcdToDecimal(data, index + 4, 3) / 100.0D));
/* 1290 */     sb.append(",");
/* 1291 */     sb.append(nf.format(ParseTool.nBcdToDecimal(data, index + 2, 2) / 100.0D));
/* 1292 */     sb.append(",");
/* 1293 */     sb.append(nf.format(ParseTool.nBcdToDecimal(data, index, 2) / 100.0D));
/* 1294 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Object parseVC86XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1306 */     Object rt = null;
/* 1307 */     if (datakey == 34304)
/* 1308 */       rt = new Integer(data[index] & 0xFF);
/* 1309 */     else if ((datakey > 34304) && (datakey < 34558))
/*      */     {
/* 1311 */       rt = parseVC8601(data, index, 19);
/* 1312 */     } else if (datakey == 34558) {
/* 1313 */       rt = ParseTool.BytesToHexC(data, index, 32);
/*      */     }
/* 1315 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC87XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1327 */     Object rt = null;
/* 1328 */     switch (datakey & 0xFF0F)
/*      */     {
/*      */     case 34560:
/* 1330 */       rt = new Integer((data[index] & 0xFF) * 300);
/* 1331 */       break;
/*      */     case 34561:
/* 1333 */       rt = new Integer(ParseTool.BCDToDecimal(data[index]));
/* 1334 */       break;
/*      */     case 34562:
/* 1336 */       rt = new Integer(ParseTool.BCDToDecimal(data[index]));
/* 1337 */       break;
/*      */     case 34563:
/* 1339 */       rt = new Integer(ParseTool.BCDToDecimal(data[index]));
/*      */     }
/*      */ 
/* 1344 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC88XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1356 */     Object rt = null;
/* 1357 */     switch (datakey)
/*      */     {
/*      */     case 34816:
/* 1359 */       rt = ParseTool.BytesToHexC(data, index, 2);
/* 1360 */       break;
/*      */     case 34817:
/* 1362 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 10.0D);
/* 1363 */       break;
/*      */     case 34818:
/*      */     case 34819:
/*      */     case 34820:
/*      */     case 34821:
/*      */     case 34822:
/* 1369 */       rt = new Integer(data[index] & 0xFF);
/* 1370 */       break;
/*      */     case 34823:
/* 1372 */       rt = ParseTool.BytesToHexC(data, index, 2);
/* 1373 */       break;
/*      */     case 34824:
/* 1375 */       rt = ParseTool.BytesToHexC(data, index, 1);
/* 1376 */       break;
/*      */     case 34825:
/* 1378 */       rt = ParseTool.BytesToHexC(data, index, 8);
/* 1379 */       break;
/*      */     case 34826:
/* 1381 */       rt = ParseTool.BytesToHexC(data, index, 2);
/*      */     }
/*      */ 
/* 1386 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC89XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1398 */     Object rt = null;
/* 1399 */     switch (datakey)
/*      */     {
/*      */     case 35072:
/* 1401 */       rt = new Integer(data[index] & 0xFF);
/* 1402 */       break;
/*      */     case 35073:
/* 1404 */       rt = ParseTool.ByteToHex(data[index]);
/* 1405 */       break;
/*      */     case 35074:
/* 1407 */       rt = ParseTool.BytesToHexC(data, index, 6);
/* 1408 */       break;
/*      */     case 35075:
/* 1410 */       rt = ParseTool.ByteToHex(data[index]);
/* 1411 */       break;
/*      */     case 35076:
/* 1413 */       rt = new Integer(ParseTool.BCDToDecimal(data[index]));
/* 1414 */       break;
/*      */     case 35077:
/* 1416 */       rt = new Integer(ParseTool.BCDToDecimal(data[index]) * 300);
/* 1417 */       break;
/*      */     case 34822:
/* 1419 */       rt = new Integer(data[index] & 0xFF);
/* 1420 */       break;
/*      */     case 35088:
/* 1422 */       rt = ParseTool.ByteToHex(data[index]);
/* 1423 */       break;
/*      */     case 35089:
/*      */     case 35090:
/*      */     case 35091:
/* 1427 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 2));
/* 1428 */       break;
/*      */     case 35092:
/*      */     case 35093:
/*      */     case 35094:
/*      */     case 35105:
/*      */     case 35106:
/*      */     case 35107:
/*      */     case 35108:
/*      */     case 35109:
/* 1437 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 100.0D);
/* 1438 */       break;
/*      */     case 35110:
/*      */     case 35111:
/*      */     case 35112:
/*      */     case 35113:
/* 1443 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 1) / 100.0D);
/*      */     }
/*      */ 
/* 1448 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC9XXX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1459 */     Double rt = null;
/* 1460 */     int v = ParseTool.nBcdToDecimal(data, index, len);
/* 1461 */     rt = new Double(v / 100.0D);
/* 1462 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVCAXXX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1473 */     Double rt = null;
/* 1474 */     int v = ParseTool.nBcdToDecimal(data, index, len);
/* 1475 */     rt = new Double(v / 10000.0D);
/* 1476 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVCB0XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1487 */     return ParseTool.getTimeM(data, index);
/*      */   }
/*      */ 
/*      */   public static Object parseVCB2XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1498 */     Object rt = null;
/* 1499 */     switch (datakey)
/*      */     {
/*      */     case 45584:
/*      */     case 45585:
/* 1502 */       rt = parseVCB0XX(data, index, len, datakey);
/* 1503 */       break;
/*      */     case 45586:
/*      */     case 45587:
/* 1506 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, len));
/*      */     }
/*      */ 
/* 1512 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVCB3XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1523 */     Object rt = null;
/* 1524 */     switch (datakey & 0xFFF0)
/*      */     {
/*      */     case 45840:
/* 1526 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 2));
/* 1527 */       break;
/*      */     case 45856:
/* 1529 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 3));
/*      */     }
/*      */ 
/* 1535 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVCB6XX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1546 */     Object rt = null;
/* 1547 */     switch (datakey & 0xFFF0)
/*      */     {
/*      */     case 46608:
/* 1549 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 2));
/* 1550 */       break;
/*      */     case 46624:
/* 1552 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 100.0D);
/* 1553 */       break;
/*      */     case 46640:
/* 1555 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 3) / 10000.0D);
/* 1556 */       break;
/*      */     case 46656:
/* 1558 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 100.0D);
/* 1559 */       break;
/*      */     case 46672:
/* 1561 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 1000.0D);
/*      */     }
/*      */ 
/* 1567 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVCCXXX(byte[] data, int index, int len, int datakey)
/*      */   {
/* 1578 */     Object rt = null;
/* 1579 */     switch (datakey)
/*      */     {
/*      */     case 49168:
/* 1581 */       rt = "20" + ParseTool.ByteToHex(data[(index + 3)]) + "-" + ParseTool.ByteToHex(data[(index + 2)]) + "-" + ParseTool.ByteToHex(data[(index + 1)]) + "," + ParseTool.ByteToHex(data[index]);
/*      */ 
/* 1583 */       break;
/*      */     case 49169:
/* 1585 */       rt = ParseTool.ByteToHex(data[(index + 2)]) + ":" + ParseTool.ByteToHex(data[(index + 1)]) + ":" + ParseTool.ByteToHex(data[index]);
/*      */ 
/* 1587 */       break;
/*      */     case 49184:
/* 1589 */       rt = new Integer(data[index] & 0xF);
/* 1590 */       break;
/*      */     case 49200:
/*      */     case 49201:
/* 1593 */       rt = new Integer(ParseTool.nBcdToDecimal(data, index, 3));
/* 1594 */       break;
/*      */     case 49433:
/*      */     case 49434:
/* 1597 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 4) / 100.0D);
/* 1598 */       break;
/*      */     case 49969:
/*      */     case 49970:
/*      */     case 49971:
/*      */     case 49972:
/*      */     case 49973:
/*      */     case 49974:
/*      */     case 49975:
/*      */     case 49976:
/* 1607 */       rt = ParseTool.ByteToHex(data[(index + 2)]) + ":" + ParseTool.ByteToHex(data[(index + 1)]) + "," + ParseTool.ByteToHex(data[index]);
/*      */     }
/*      */ 
/* 1614 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVC8EXX(byte[] data, int index, int len, int datakey)
/*      */   {
/*      */     SimpleDateFormat sf;
/* 1625 */     Object rt = null;
/* 1626 */     switch (datakey & 0xFFF0)
/*      */     {
/*      */     case 36368:
/*      */     case 36384:
/* 1629 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 4) / 100.0D);
/* 1630 */       break;
/*      */     case 36400:
/*      */     case 36416:
/* 1633 */       rt = new Double(ParseTool.nBcdToDecimalS(data, index, 4) / 10.0D);
/* 1634 */       break;
/*      */     case 36448:
/* 1636 */       if (datakey < 36450) {
/* 1637 */         rt = new Double(ParseTool.nBcdToDecimalS(data, index, 4) / 10.0D); break label512:
/*      */       }
/* 1639 */       rt = new Double(ParseTool.nBcdToDecimalS(data, index, 3) / 100.0D);
/*      */ 
/* 1641 */       break;
/*      */     case 36464:
/* 1643 */       rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 100.0D);
/* 1644 */       break;
/*      */     case 36480:
/* 1646 */       if (datakey < 36486) {
/* 1647 */         rt = new Integer(ParseTool.BCDToDecimal(data[index])); break label512:
/*      */       }
/* 1649 */       sf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
/* 1650 */       Calendar time = ParseTool.getTime(data, index + 2);
/* 1651 */       int val = ParseTool.nBcdToDecimal(data, index, 2);
/* 1652 */       rt = sf.format(time.getTime()) + "," + val;
/*      */ 
/* 1654 */       break;
/*      */     case 36496:
/* 1656 */       if (datakey == 36496) {
/* 1657 */         rt = new Double(ParseTool.nBcdToDecimal(data, index, 2) / 10.0D); break label512: }
/* 1658 */       if (datakey < 36499) {
/* 1659 */         sf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/* 1660 */         nf = NumberFormat.getInstance();
/* 1661 */         nf.setMaximumFractionDigits(2);
/* 1662 */         nf.setGroupingUsed(false);
/* 1663 */         time = ParseTool.getTime(data, index + 3);
/* 1664 */         val = ParseTool.nBcdToDecimalS(data, index, 3);
/* 1665 */         rt = sf.format(time.getTime()) + "," + nf.format(val / 100.0D);
/* 1666 */         break label512: }
/* 1667 */       sf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/* 1668 */       NumberFormat nf = NumberFormat.getInstance();
/* 1669 */       nf.setMaximumFractionDigits(2);
/* 1670 */       nf.setGroupingUsed(false);
/* 1671 */       Calendar time = ParseTool.getTime(data, index + 2);
/* 1672 */       int val = ParseTool.nBcdToDecimal(data, index, 2);
/* 1673 */       rt = sf.format(time.getTime()) + "," + nf.format(val / 100.0D);
/*      */     }
/*      */ 
/* 1680 */     label512: return rt;
/*      */   }
/*      */ 
/*      */   public static Object parseVError(byte err)
/*      */   {
/* 1691 */     String rt = "";
/* 1692 */     switch (err & 0xFF) { case 0:
/* 1694 */       rt = "正确";
/* 1695 */       break;
/*      */     case 1:
/* 1697 */       rt = "中继命令没有返回";
/* 1698 */       break;
/*      */     case 2:
/* 1700 */       rt = "设置内容非法";
/* 1701 */       break;
/*      */     case 3:
/* 1703 */       rt = "密码权限不足";
/* 1704 */       break;
/*      */     case 4:
/* 1706 */       rt = "无此数据项";
/* 1707 */       break;
/*      */     case 5:
/* 1709 */       rt = "命令时间失效";
/* 1710 */       break;
/*      */     case 17:
/* 1712 */       rt = "目标地址不存在";
/* 1713 */       break;
/*      */     case 18:
/* 1715 */       rt = "发送失败";
/* 1716 */       break;
/*      */     case 19:
/* 1718 */       rt = "短信息帧太长";
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15:
/*      */     case 16: } return rt;
/*      */   }
/*      */ }