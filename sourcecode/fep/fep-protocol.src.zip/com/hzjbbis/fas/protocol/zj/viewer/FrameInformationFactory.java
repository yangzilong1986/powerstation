/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameInformationFactory
/*    */ {
/*    */   public static String getFrameInformation(byte[] frame)
/*    */   {
/* 11 */     if ((frame != null) && (frame.length >= 13)) {
/* 12 */       int func = frame[8] & 0x3F;
/* 13 */       AbstractFrame aframe = null;
/* 14 */       switch (func) { case 0:
/* 16 */         aframe = new FrameC00(frame);
/* 17 */         break;
/*    */       case 1:
/* 19 */         aframe = new FrameC01(frame);
/* 20 */         break;
/*    */       case 2:
/* 22 */         aframe = new FrameC02(frame);
/* 23 */         break;
/*    */       case 4:
/* 25 */         aframe = new FrameC04(frame);
/* 26 */         break;
/*    */       case 7:
/* 28 */         aframe = new FrameC07(frame);
/* 29 */         break;
/*    */       case 8:
/* 31 */         aframe = new FrameC08(frame);
/* 32 */         break;
/*    */       case 9:
/* 34 */         aframe = new FrameC09(frame);
/* 35 */         break;
/*    */       case 10:
/* 37 */         aframe = new FrameC0A(frame);
/* 38 */         break;
/*    */       case 33:
/* 40 */         aframe = new FrameC21(frame);
/* 41 */         break;
/*    */       case 36:
/* 43 */         aframe = new FrameC24(frame);
/*    */       case 3:
/*    */       case 5:
/*    */       case 6:
/*    */       case 11:
/*    */       case 12:
/*    */       case 13:
/*    */       case 14:
/*    */       case 15:
/*    */       case 16:
/*    */       case 17:
/*    */       case 18:
/*    */       case 19:
/*    */       case 20:
/*    */       case 21:
/*    */       case 22:
/*    */       case 23:
/*    */       case 24:
/*    */       case 25:
/*    */       case 26:
/*    */       case 27:
/*    */       case 28:
/*    */       case 29:
/*    */       case 30:
/*    */       case 31:
/*    */       case 32:
/*    */       case 34:
/*    */       case 35: } if (aframe != null) {
/* 49 */         return aframe.getDescription();
/*    */       }
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   public static String getFrameInformation(String frame) {
/* 56 */     if (frame != null) {
/* 57 */       String data = frame.replaceAll(" ", "");
/* 58 */       int index = data.indexOf("68");
/* 59 */       if (index > 0) {
/* 60 */         data = data.substring(index);
/*    */       }
/* 62 */       if (Util.validHex(data)) {
/* 63 */         byte[] bframe = new byte[(data.length() >>> 1) + (data.length() & 0x1)];
/* 64 */         Util.HexsToBytes(bframe, 0, data);
/* 65 */         return getFrameInformation(bframe);
/*    */       }
/*    */     }
/* 68 */     return null;
/*    */   }
/*    */ }