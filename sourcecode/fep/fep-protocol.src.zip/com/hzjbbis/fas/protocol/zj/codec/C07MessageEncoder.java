/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalRealTimeWriteParamsRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C07MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*     */   private final Log log;
/*     */ 
/*     */   public C07MessageEncoder()
/*     */   {
/*  26 */     this.log = LogFactory.getLog(C07MessageEncoder.class); }
/*     */ 
/*     */   public IMessage[] encode(Object obj) { List rt = null;
/*     */     try {
/*  30 */       if (obj instanceof FaalRealTimeWriteParamsRequest) {
/*  31 */         FaalRealTimeWriteParamsRequest para = (FaalRealTimeWriteParamsRequest)obj;
/*     */ 
/*  34 */         int point = Integer.parseInt(para.getTn());
/*  35 */         byte rights = 17;
/*     */ 
/*  37 */         List paras = para.getParams();
/*  38 */         if ((paras == null) || (paras.size() == 0)) {
/*  39 */           throw new MessageEncodeException("空配置，请指定设置参数");
/*     */         }
/*     */ 
/*  42 */         List nparas = paras;
/*     */ 
/*  52 */         int[] itemlen = new int[nparas.size()];
/*  53 */         int[] keysinpara = new int[nparas.size()];
/*  54 */         String[] valsinpara = new String[nparas.size()];
/*     */ 
/*  56 */         byte[] rowdata = new byte[2048];
/*  57 */         byte[] rowdataHL = new byte[2048];
/*  58 */         byte[] rowdataHLi = new byte[2048];
/*     */ 
/*  60 */         int loc = 0;
/*  61 */         Calendar time = para.getCmdTime();
/*  62 */         if (time == null) {
/*  63 */           time = Calendar.getInstance();
/*     */         }
/*  65 */         int wt = para.getTimeout();
/*  66 */         rowdata[0] = (byte)point;
/*  67 */         rowdata[1] = rights;
/*  68 */         rowdata[5] = ParseTool.IntToBcd(time.get(1) % 100);
/*  69 */         rowdata[6] = ParseTool.IntToBcd(time.get(2) + 1);
/*  70 */         rowdata[7] = ParseTool.IntToBcd(time.get(5));
/*  71 */         rowdata[8] = ParseTool.IntToBcd(time.get(11));
/*  72 */         rowdata[9] = ParseTool.IntToBcd(time.get(12));
/*  73 */         rowdata[10] = ParseTool.IntToBcd(wt);
/*     */ 
/*  75 */         rowdataHL[0] = (byte)point;
/*  76 */         rowdataHL[1] = rights;
/*  77 */         rowdataHL[5] = ParseTool.IntToBcd(time.get(1) % 100);
/*  78 */         rowdataHL[6] = ParseTool.IntToBcd(time.get(2) + 1);
/*  79 */         rowdataHL[7] = ParseTool.IntToBcd(time.get(5));
/*  80 */         rowdataHL[8] = ParseTool.IntToBcd(time.get(11));
/*  81 */         rowdataHL[9] = ParseTool.IntToBcd(time.get(12));
/*  82 */         rowdataHL[10] = ParseTool.IntToBcd(wt);
/*     */ 
/*  84 */         rowdataHLi[0] = (byte)point;
/*  85 */         rowdataHLi[1] = rights;
/*  86 */         rowdataHLi[5] = ParseTool.IntToBcd(time.get(1) % 100);
/*  87 */         rowdataHLi[6] = ParseTool.IntToBcd(time.get(2) + 1);
/*  88 */         rowdataHLi[7] = ParseTool.IntToBcd(time.get(5));
/*  89 */         rowdataHLi[8] = ParseTool.IntToBcd(time.get(11));
/*  90 */         rowdataHLi[9] = ParseTool.IntToBcd(time.get(12));
/*  91 */         rowdataHLi[10] = ParseTool.IntToBcd(wt);
/*     */ 
/*  93 */         loc = 11;
/*  94 */         int index = 0;
/*  95 */         for (Iterator iter = nparas.iterator(); iter.hasNext(); ) {
/*  96 */           FaalRequestParam fp = (FaalRequestParam)iter.next();
/*  97 */           ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(fp.getName());
/*  98 */           if (pdc != null)
/*     */           {
/*     */             int zi;
/*     */             int si;
/*     */             int k;
/*  99 */             rowdata[loc] = (byte)(pdc.getDataKey() & 0xFF);
/* 100 */             rowdata[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/* 102 */             rowdataHL[loc] = (byte)(pdc.getDataKey() & 0xFF);
/* 103 */             rowdataHL[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/* 105 */             rowdataHLi[loc] = (byte)(pdc.getDataKey() & 0xFF);
/* 106 */             rowdataHLi[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/* 108 */             loc += 2;
/* 109 */             int dlen = DataItemCoder.coder(rowdata, loc, fp, pdc);
/* 110 */             if (dlen <= 0)
/*     */             {
/* 112 */               throw new MessageEncodeException(fp.getName(), "错误的参数:" + fp.getName() + "---" + fp.getValue());
/*     */             }
/*     */ 
/* 115 */             if ((pdc.getDataKey() & 0xFFFF) == 32789) {
/* 116 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/* 117 */               zi = 16;
/* 118 */               si = loc + 15;
/* 119 */               for (k = 0; (k < 16) && 
/* 120 */                 ((rowdata[si] & 0xFF) == 0); ++k)
/*     */               {
/* 121 */                 rowdataHL[(loc + k)] = 0;
/* 122 */                 rowdataHLi[si] = -86;
/* 123 */                 --si;
/* 124 */                 --zi;
/*     */               }
/*     */ 
/* 129 */               if (zi > 0)
/* 130 */                 System.arraycopy(rowdata, loc, rowdataHL, loc + 16 - zi, zi);
/*     */             }
/* 132 */             else if ((pdc.getDataKey() & 0xFFFF) == 35074) {
/* 133 */               System.arraycopy(rowdata, loc, rowdataHL, loc, dlen);
/* 134 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/* 135 */               zi = 6;
/* 136 */               si = loc + 5;
/* 137 */               for (k = 0; (k < 6) && 
/* 138 */                 ((rowdata[si] & 0xFF) == 170); ++k)
/*     */               {
/* 139 */                 rowdataHLi[si] = 0;
/* 140 */                 --si;
/* 141 */                 --zi;
/*     */               }
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 147 */               System.arraycopy(rowdata, loc, rowdataHL, loc, dlen);
/* 148 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/*     */             }
/*     */ 
/* 151 */             itemlen[index] = dlen;
/* 152 */             keysinpara[index] = pdc.getDataKey();
/* 153 */             valsinpara[index] = fp.getValue();
/* 154 */             ++index;
/* 155 */             loc += dlen;
/*     */           } else {
/* 157 */             throw new MessageEncodeException(fp.getName(), "配置无法获取，数据项：" + fp.getName());
/*     */           }
/*     */         }
/*     */ 
/* 161 */         List rtuid = para.getRtuIds();
/* 162 */         List cmdIds = para.getCmdIds();
/* 163 */         rt = new ArrayList();
/* 164 */         for (int iter = 0; iter < rtuid.size(); ++iter) {
/* 165 */           String id = (String)rtuid.get(iter);
/* 166 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/* 167 */           byte[] fdata = null;
/*     */ 
/* 169 */           if (rtu == null) {
/* 170 */             this.log.info("终端信息缺失，终端ID--" + rtu.getRtuId());
/*     */           }
/*     */           else
/*     */           {
/* 174 */             if ((rtu.getManufacturer() != null) && (((rtu.getManufacturer().equalsIgnoreCase("0087")) || (rtu.getManufacturer().equalsIgnoreCase("0112")) || (rtu.getManufacturer().equalsIgnoreCase("0094")) || (rtu.getManufacturer().equalsIgnoreCase("0117")))))
/* 175 */               fdata = rowdataHL;
/* 176 */             else if ((rtu.getManufacturer() != null) && (((rtu.getManufacturer().equalsIgnoreCase("0061")) || (rtu.getManufacturer().equalsIgnoreCase("0098"))))) {
/* 177 */               fdata = rowdataHLi;
/*     */             }
/*     */             else {
/* 180 */               fdata = rowdata;
/*     */             }
/* 182 */             String pwd = rtu.getHiAuthPassword();
/* 183 */             if (pwd == null) {
/* 184 */               this.log.info("终端密码缺失，终端ID--" + rtu.getRtuId());
/*     */             }
/*     */             else
/*     */             {
/* 188 */               int datamax = DataItemCoder.getDataMax(rtu);
/*     */ 
/* 191 */               int msgcount = 0;
/* 192 */               int dnum = 0;
/* 193 */               int pos = 0;
/* 194 */               int curlen = 0;
/*     */ 
/* 197 */               for (int j = 0; j < itemlen.length; ++j)
/*     */               {
/*     */                 MessageZj msg;
/* 198 */                 if (curlen + 11 + 2 + itemlen[j] > datamax) {
/* 199 */                   msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 200 */                   if (msg != null) {
/* 201 */                     ++msgcount;
/* 202 */                     rt.add(msg);
/*     */                   }
/* 204 */                   pos += curlen;
/* 205 */                   dnum = 1;
/* 206 */                   curlen = 2 + itemlen[j];
/*     */                 }
/*     */                 else
/*     */                 {
/* 212 */                   ++dnum;
/* 213 */                   curlen += 2 + itemlen[j];
/*     */ 
/* 218 */                   if ((keysinpara[j] > 33024) && (keysinpara[j] <= 33278)) {
/* 219 */                     msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 220 */                     if (msg != null) {
/* 221 */                       ++msgcount;
/* 222 */                       rt.add(msg);
/*     */                     }
/* 224 */                     dnum = 0;
/* 225 */                     pos += curlen;
/* 226 */                     curlen = 0;
/*     */                   }
/*     */                 }
/*     */               }
/*     */ 
/* 231 */               if (dnum > 0) {
/* 232 */                 MessageZj msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 233 */                 if (msg != null)
/*     */                 {
/* 235 */                   ++msgcount;
/* 236 */                   rt.add(msg);
/*     */                 }
/*     */               }
/*     */ 
/* 240 */               setMsgcount(rt, msgcount); } }
/*     */         }
/*     */       }
/*     */     } catch (MessageEncodeException e) {
/* 244 */       throw e;
/*     */     }
/*     */     catch (Exception e) {
/* 247 */       throw new MessageEncodeException(e);
/*     */     }
/* 249 */     if (rt != null) {
/* 250 */       IMessage[] msgs = new IMessage[rt.size()];
/* 251 */       rt.toArray(msgs);
/* 252 */       return msgs;
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   private MessageZjHead createHead(BizRtu rtu)
/*     */   {
/* 259 */     MessageZjHead head = new MessageZjHead();
/* 260 */     head.c_dir = 0;
/* 261 */     head.c_expflag = 0;
/* 262 */     head.c_func = 7;
/*     */ 
/* 266 */     head.rtua = rtu.getRtua();
/*     */ 
/* 268 */     head.iseq = 0;
/*     */ 
/* 271 */     return head;
/*     */   }
/*     */ 
/*     */   private MessageZj createMessageZj(byte[] rowdata, BizRtu rtu, int pos, int dlen, Object cmdid)
/*     */   {
/* 276 */     MessageZjHead head = createHead(rtu);
/* 277 */     head.dlen = (short)(dlen + 11);
/*     */ 
/* 279 */     byte[] frameA = new byte[head.dlen];
/* 280 */     System.arraycopy(rowdata, 0, frameA, 0, 11);
/* 281 */     System.arraycopy(rowdata, 11 + pos, frameA, 11, dlen);
/*     */ 
/* 283 */     String pwd = rtu.getHiAuthPassword();
/* 284 */     ParseTool.HexsToBytesAA(frameA, 2, pwd, 3, -86);
/*     */ 
/* 286 */     MessageZj msg = new MessageZj();
/* 287 */     msg.setCmdId((Long)cmdid);
/*     */ 
/* 289 */     msg.data = ByteBuffer.wrap(frameA);
/* 290 */     msg.head = head;
/* 291 */     return msg;
/*     */   }
/*     */ 
/*     */   private void setMsgcount(List msgs, int msgcount) {
/* 295 */     for (Iterator iter = msgs.iterator(); iter.hasNext(); ) {
/* 296 */       MessageZj msg = (MessageZj)iter.next();
/* 297 */       if (msg.getMsgCount() == 0)
/* 298 */         msg.setMsgCount(msgcount);
/*     */     }
/*     */   }
/*     */ }