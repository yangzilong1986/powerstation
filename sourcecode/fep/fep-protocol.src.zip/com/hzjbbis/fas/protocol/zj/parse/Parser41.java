/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser41
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 30 */         sb.append("-");
/* 31 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 32 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 35 */       e.printStackTrace();
/*    */     }
/* 37 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 52 */       for (int i = 0; i < value.length(); ++i) {
/* 53 */         char c = value.charAt(i);
/* 54 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 57 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 60 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 63 */         throw new MessageEncodeException("错误的 MM-DD 组帧参数:" + value);
/*    */       }
/* 65 */       String[] date = value.split("-");
/* 66 */       frame[loc] = ParseTool.StringToBcd(date[1]);
/* 67 */       frame[(loc + 1)] = ParseTool.StringToBcd(date[0]);
/*    */     } catch (Exception e) {
/* 69 */       throw new MessageEncodeException("错误的 MM-DD 组帧参数:" + value);
/*    */     }
/* 71 */     return len;
/*    */   }
/*    */ }