/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class Parser43
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 23 */     Object rt = null;
/*    */     try {
/* 25 */       int begin = loc;
/* 26 */       for (int i = 0; i < len; ++i) {
/* 27 */         if (((data[(loc + i)] & 0xFF) != 0) && ((data[(loc + i)] & 0xFF) < 128)) {
/*    */           break;
/*    */         }
/* 30 */         ++begin;
/*    */       }
/* 32 */       int rlen = 0;
/* 33 */       for (int i = begin; (i < loc + len) && 
/* 34 */         ((data[i] & 0xFF) != 0); ++i) {
/* 34 */         if ((data[i] & 0xFF) >= 128) {
/*    */           break;
/*    */         }
/* 37 */         ++rlen;
/*    */       }
/* 39 */       if (rlen > 0) {
/* 40 */         byte[] apn = new byte[rlen];
/* 41 */         int iloc = begin + rlen - 1;
/* 42 */         for (int i = 0; i < rlen; ++i) {
/* 43 */           apn[i] = data[iloc];
/* 44 */           --iloc;
/*    */         }
/* 46 */         rt = new String(apn, "GBK");
/*    */       }
/*    */     } catch (Exception e) {
/* 49 */       e.printStackTrace();
/*    */     }
/* 51 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/* 64 */     int slen = -1;
/*    */     try
/*    */     {
/*    */       int src;
/*    */       int dest;
/*    */       int i;
/* 66 */       Arrays.fill(frame, loc, loc + len - 1, 0);
/* 67 */       byte[] str = value.getBytes();
/* 68 */       int rlen = str.length;
/* 69 */       if (rlen > len) {
/* 70 */         rlen = len;
/*    */       }
/* 72 */       if (fraction == 0) {
/* 73 */         src = str.length - 1;
/* 74 */         dest = loc;
/* 75 */         for (i = 0; i < rlen; ++i) {
/* 76 */           frame[dest] = str[src];
/* 77 */           --src;
/* 78 */           ++dest;
/*    */         }
/*    */       } else {
/* 81 */         src = 0;
/* 82 */         dest = loc + len - 1;
/* 83 */         for (i = 0; i < rlen; ++i) {
/* 84 */           frame[dest] = str[src];
/* 85 */           ++src;
/* 86 */           --dest;
/*    */         }
/*    */       }
/*    */ 
/* 90 */       slen = len;
/*    */     } catch (Exception e) {
/* 92 */       throw new MessageEncodeException("错误的 ascii字符码 组帧参数:" + value);
/*    */     }
/* 94 */     return slen;
/*    */   }
/*    */ }