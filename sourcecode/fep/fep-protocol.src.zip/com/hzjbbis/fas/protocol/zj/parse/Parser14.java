/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class Parser14
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  20 */     Object rt = null;
/*     */     try {
/*  22 */       boolean ok = true;
/*     */ 
/*  26 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  27 */       if (ok)
/*     */       {
/*     */         int port;
/*     */         String ip;
/*  28 */         int type = ParseTool.BCDToDecimal(data[(loc + 8)]);
/*  29 */         String stype = ParseTool.ByteToHex(data[(loc + 8)]);
/*     */ 
/*  31 */         switch (type)
/*     */         {
/*     */         case 1:
/*  33 */           rt = stype + "," + ParseTool.toPhoneCode(data, loc, 8, 170);
/*  34 */           break;
/*     */         case 2:
/*  36 */           port = ParseTool.nByteToInt(data, loc, 2);
/*  37 */           ip = (data[(loc + 5)] & 0xFF) + "." + (data[(loc + 4)] & 0xFF) + "." + (data[(loc + 3)] & 0xFF) + "." + (data[(loc + 2)] & 0xFF);
/*     */ 
/*  39 */           rt = stype + "," + ip + ":" + port;
/*  40 */           break;
/*     */         case 3:
/*  42 */           rt = stype + "," + ParseTool.toPhoneCode(data, loc, 8, 170);
/*  43 */           break;
/*     */         case 4:
/*  45 */           port = ParseTool.nByteToInt(data, loc, 2);
/*  46 */           ip = (data[(loc + 5)] & 0xFF) + "." + (data[(loc + 4)] & 0xFF) + "." + (data[(loc + 3)] & 0xFF) + "." + (data[(loc + 2)] & 0xFF);
/*     */ 
/*  48 */           rt = stype + "," + ip + ":" + port;
/*  49 */           break;
/*     */         case 5:
/*  51 */           break;
/*     */         case 6:
/*  53 */           break;
/*     */         case 7:
/*  55 */           rt = stype + "," + ParseTool.toPhoneCode(data, loc, 8, 170);
/*  56 */           label457: break label457:
/*     */         case 8:
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  64 */       e.printStackTrace();
/*     */     }
/*  66 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*     */       int flen;
/*     */       int i;
/*  80 */       String[] para = value.split(",");
/*  81 */       int type = Integer.parseInt(para[0]);
/*  82 */       frame[(loc + 8)] = (byte)type;
/*  83 */       switch (type)
/*     */       {
/*     */       case 1:
/*  86 */         ParseTool.StringToBcds(frame, loc, para[1]);
/*  87 */         flen = (para[1].length() >>> 1) + (para[1].length() & 0x1);
/*  88 */         for (i = loc + flen; i < loc + len - 1; ++i) {
/*  89 */           frame[i] = -86;
/*     */         }
/*  91 */         break;
/*     */       case 2:
/*  94 */         ParseTool.IPToBytes(frame, loc, para[1]);
/*  95 */         frame[(loc + 6)] = -86;
/*  96 */         frame[(loc + 7)] = -86;
/*  97 */         break;
/*     */       case 3:
/* 100 */         ParseTool.StringToBcds(frame, loc, para[1]);
/* 101 */         flen = (para[1].length() >>> 1) + (para[1].length() & 0x1);
/* 102 */         for (i = loc + flen; i < loc + len - 1; ++i) {
/* 103 */           frame[i] = -86;
/*     */         }
/* 105 */         break;
/*     */       case 4:
/* 108 */         ParseTool.IPToBytes(frame, loc, para[1]);
/* 109 */         frame[(loc + 6)] = -86;
/* 110 */         frame[(loc + 7)] = -86;
/* 111 */         break;
/*     */       case 5:
/* 113 */         break;
/*     */       case 6:
/* 115 */         break;
/*     */       case 7:
/* 118 */         ParseTool.StringToBcds(frame, loc, para[1]);
/* 119 */         flen = (para[1].length() >>> 1) + (para[1].length() & 0x1);
/* 120 */         for (i = loc + flen; i < loc + len - 1; ++i) {
/* 121 */           frame[i] = -86;
/*     */         }
/* 123 */         label324: break label324:
/*     */       case 8:
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 130 */       throw new MessageEncodeException("错误的 主站通讯地址 组帧参数:" + value);
/*     */     }
/*     */ 
/* 133 */     return len;
/*     */   }
/*     */ }