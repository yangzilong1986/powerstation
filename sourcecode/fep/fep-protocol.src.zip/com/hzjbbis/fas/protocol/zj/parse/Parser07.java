/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser07
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 30 */         sb.append("-");
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 32 */         sb.append(" ");
/* 33 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 34 */         sb.append(":");
/* 35 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 36 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 39 */       e.printStackTrace();
/*    */     }
/* 41 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 56 */       for (int i = 0; i < value.length(); ++i) {
/* 57 */         char c = value.charAt(i);
/* 58 */         if (c == ' ') {
/*    */           continue;
/*    */         }
/* 61 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 64 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 67 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 70 */         throw new MessageEncodeException("错误的 MM-DD HH:mm 组帧参数:" + value);
/*    */       }
/* 72 */       String[] para = value.split(" ");
/* 73 */       String[] date = para[0].split("-");
/* 74 */       String[] time = para[1].split(":");
/* 75 */       frame[loc] = ParseTool.StringToBcd(time[1]);
/* 76 */       frame[(loc + 1)] = ParseTool.StringToBcd(time[0]);
/* 77 */       frame[(loc + 2)] = ParseTool.StringToBcd(date[1]);
/* 78 */       frame[(loc + 3)] = ParseTool.StringToBcd(date[0]);
/*    */     } catch (Exception e) {
/* 80 */       throw new MessageEncodeException("错误的 MM-DD hh:mm 组帧参数:" + value);
/*    */     }
/* 82 */     return len;
/*    */   }
/*    */ }