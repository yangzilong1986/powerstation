/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ public class Parser35
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  29 */       if (ok) {
/*  30 */         StringBuffer sb = new StringBuffer();
/*  31 */         sb.append("20");
/*  32 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/*  33 */         sb.append("-");
/*  34 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  35 */         sb.append("-");
/*  36 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/*  37 */         sb.append(" ");
/*  38 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  39 */         sb.append(":");
/*  40 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/*  41 */         sb.append(",");
/*  42 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, 2) / ParseTool.fraction[2]));
/*  43 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  46 */       e.printStackTrace();
/*     */     }
/*  48 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  62 */       NumberFormat nf = NumberFormat.getInstance();
/*  63 */       nf.setMaximumFractionDigits(4);
/*     */ 
/*  66 */       for (int i = 0; i < value.length(); ++i) {
/*  67 */         char c = value.charAt(i);
/*  68 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  71 */         if (c == ':') {
/*     */           continue;
/*     */         }
/*  74 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  77 */         if (c == ' ') {
/*     */           continue;
/*     */         }
/*  80 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  83 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  86 */         throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm XX.XX 组帧参数:" + value);
/*     */       }
/*     */ 
/*  89 */       String[] para = value.split(",");
/*  90 */       String[] dpara = para[0].split(" ");
/*  91 */       String[] date = dpara[0].split("-");
/*  92 */       String[] time = dpara[1].split(":");
/*     */ 
/*  94 */       double xx = nf.parse(para[1]).doubleValue() * ParseTool.fraction[2];
/*  95 */       ParseTool.IntToBcd(frame, (int)xx, loc, 2);
/*  96 */       frame[(loc + 6)] = ParseTool.StringToBcd(date[0]);
/*  97 */       frame[(loc + 5)] = ParseTool.StringToBcd(date[1]);
/*  98 */       frame[(loc + 4)] = ParseTool.StringToBcd(date[2]);
/*  99 */       frame[(loc + 3)] = ParseTool.StringToBcd(time[0]);
/* 100 */       frame[(loc + 2)] = ParseTool.StringToBcd(time[1]);
/*     */     } catch (Exception e) {
/* 102 */       throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm XX.XX 组帧参数:" + value);
/*     */     }
/*     */ 
/* 105 */     return len;
/*     */   }
/*     */ }