/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser53
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 19 */     Object rt = null;
/*    */     try {
/* 21 */       boolean ok = true;
/*    */ 
/* 25 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 26 */       if (ok) {
/* 27 */         StringBuffer sb = new StringBuffer();
/* 28 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 29 */         sb.append(":");
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 31 */         sb.append(",");
/* 32 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 33 */         sb.append(",");
/* 34 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 35 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 38 */       e.printStackTrace();
/*    */     }
/* 40 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       for (int i = 0; i < value.length(); ++i) {
/* 56 */         char c = value.charAt(i);
/* 57 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 60 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 63 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 66 */         throw new MessageEncodeException("错误的 HH:mm NN MM组帧参数:" + value);
/*    */       }
/* 68 */       String[] para = value.split(",");
/* 69 */       String[] time = para[0].split(":");
/*    */ 
/* 71 */       frame[loc] = ParseTool.StringToBcd(para[2]);
/* 72 */       frame[(loc + 1)] = ParseTool.StringToBcd(para[1]);
/* 73 */       frame[(loc + 3)] = ParseTool.StringToBcd(time[0]);
/* 74 */       frame[(loc + 2)] = ParseTool.StringToBcd(time[1]);
/*    */     } catch (Exception e) {
/* 76 */       throw new MessageEncodeException("错误的 hh:mm NN MM组帧参数:" + value);
/*    */     }
/*    */ 
/* 79 */     return len;
/*    */   }
/*    */ }