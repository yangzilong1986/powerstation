/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.RtuData;
/*     */ import com.hzjbbis.fas.model.RtuDataItem;
/*     */ import com.hzjbbis.fas.protocol.codec.MessageCodecContext;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.IMeterParser;
/*     */ import com.hzjbbis.fas.protocol.meter.MeterParserFactory;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.TaskSetting;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C02MessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  33 */     List datas = new ArrayList();
/*     */     try {
/*  35 */       if (getOrientation(message) == 1) {
/*  36 */         int rtype = getErrCode(message);
/*  37 */         if (rtype == 0)
/*     */         {
/*  39 */           byte[] data = getData(message);
/*     */ 
/*  41 */           if (data.length > 9) {
/*  42 */             String tasknum = String.valueOf(data[0] & 0xFF);
/*  43 */             TaskSetting ts = new TaskSetting(((MessageZj)message).head.rtua, data[0] & 0xFF, this.dataConfig);
/*  44 */             if ((ts != null) && (ts.getRtask() != null) && (ts.getDataNum() > 0)) {
/*  45 */               Calendar time = getTime(data, 1);
/*  46 */               if (time == null) {
/*  47 */                 throw new MessageDecodeException("帧中包含的时间数据错误:" + ParseTool.BytesToHex(data, 1, 5));
/*     */               }
/*     */ 
/*  53 */               int pnum = data[6] & 0xFF;
/*  54 */               int ti = getTimeInterval(data[7]);
/*  55 */               int tn = data[8] & 0xFF;
/*     */ 
/*  57 */               if (ts.getTT() == 2) {
/*  58 */                 parseRelayTask(data, 9, time, tasknum, ts, datas);
/*     */               }
/*  61 */               else if (data.length - 9 == ts.getDataLength() * pnum) {
/*  62 */                 List datacs = ts.getDI();
/*  63 */                 int loc = 9;
/*  64 */                 Hashtable keys = new Hashtable();
/*  65 */                 for (int i = 0; i < pnum; ++i) {
/*  66 */                   RtuData bean = new RtuData();
/*  67 */                   RtuDataItem beanItem = null;
/*  68 */                   keys.clear();
/*  69 */                   for (int j = 0; j < ts.getDataNum(); ++j)
/*     */                   {
/*     */                     Iterator iterc;
/*  70 */                     ProtocolDataItemConfig pdc = (ProtocolDataItemConfig)datacs.get(j);
/*  71 */                     List childs = pdc.getChildItems();
/*  72 */                     if ((childs != null) && (childs.size() > 0)) {
/*  73 */                       for (iterc = childs.iterator(); iterc.hasNext(); ) {
/*  74 */                         ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)iterc.next();
/*  75 */                         Object di = DataItemParser.parsevalue(data, loc, cpdc.getLength(), cpdc.getFraction(), cpdc.getParserno());
/*  76 */                         loc += cpdc.getLength();
/*  77 */                         if (!(keys.containsKey(cpdc.getCode()))) {
/*  78 */                           beanItem = new RtuDataItem();
/*  79 */                           beanItem.setCode(cpdc.getCode());
/*  80 */                           beanItem.setValue((di == null) ? null : di.toString());
/*  81 */                           bean.addDataList(beanItem);
/*  82 */                           keys.put(cpdc.getCode(), cpdc.getCode());
/*     */                         }
/*  84 */                         bean.setLogicAddress(ts.getRtu().getLogicAddress());
/*  85 */                         bean.setTaskNum(tasknum);
/*  86 */                         bean.setTime(time.getTime());
/*     */                       }
/*     */ 
/*     */                     }
/*     */                     else
/*     */                     {
/*  96 */                       Object di = DataItemParser.parsevalue(data, loc, pdc.getLength(), pdc.getFraction(), pdc.getParserno());
/*  97 */                       loc += pdc.getLength();
/*  98 */                       if (!(keys.containsKey(pdc.getCode()))) {
/*  99 */                         beanItem = new RtuDataItem();
/* 100 */                         beanItem.setCode(pdc.getCode());
/* 101 */                         beanItem.setValue((di == null) ? null : di.toString());
/* 102 */                         bean.addDataList(beanItem);
/* 103 */                         keys.put(pdc.getCode(), pdc.getCode());
/*     */                       }
/* 105 */                       bean.setLogicAddress(ts.getRtu().getLogicAddress());
/* 106 */                       bean.setTime(time.getTime());
/* 107 */                       bean.setTaskNum(tasknum);
/*     */                     }
/*     */ 
/*     */                   }
/*     */ 
/* 117 */                   datas.add(bean);
/* 118 */                   if (ti <= 1440) {
/* 119 */                     time.add(12, ti * tn);
/*     */                   }
/*     */                   else
/* 122 */                     time.add(2, tn);
/*     */                 }
/*     */               }
/*     */               else {
/* 126 */                 MessageCodecContext.setTaskNum(tasknum);
/* 127 */                 String msg = "终端逻辑地址：" + ParseTool.IntToHex4(((MessageZj)message).head.rtua) + "，任务号：" + tasknum;
/* 128 */                 msg = msg + "\r\n数据长度不对,期望数据长度：" + (ts.getDataLength() * pnum + 9) + "  上报数据长度：" + data.length;
/* 129 */                 throw new MessageDecodeException(msg);
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 134 */               MessageCodecContext.setTaskNum(tasknum);
/* 135 */               throw new MessageDecodeException("未知的任务");
/*     */             }
/*     */           }
/*     */           else {
/* 139 */             String msg = "终端逻辑地址：" + ParseTool.IntToHex4(((MessageZj)message).head.rtua) + "任务数据长度非法";
/* 140 */             throw new MessageDecodeException(msg);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 154 */         String msg = "终端逻辑地址：" + ParseTool.IntToHex4(((MessageZj)message).head.rtua) + "任务数据格式非法";
/* 155 */         throw new MessageDecodeException(msg);
/*     */       }
/*     */     } catch (Exception e) {
/* 158 */       throw new MessageDecodeException(e);
/*     */     }
/*     */ 
/* 163 */     return datas;
/*     */   }
/*     */ 
/*     */   private int getOrientation(IMessage message)
/*     */   {
/* 194 */     return ParseTool.getOrientation(message);
/*     */   }
/*     */ 
/*     */   private int getErrCode(IMessage message)
/*     */   {
/* 203 */     return ParseTool.getErrCode(message);
/*     */   }
/*     */ 
/*     */   private byte[] getData(IMessage message)
/*     */   {
/* 212 */     return ParseTool.getData(message);
/*     */   }
/*     */ 
/*     */   private Calendar getTime(byte[] data, int offset)
/*     */   {
/* 222 */     Calendar rt = null;
/*     */     try {
/* 224 */       int month = ParseTool.BCDToDecimal(data[(1 + offset)]);
/* 225 */       int year = ParseTool.BCDToDecimal(data[offset]);
/* 226 */       if ((month > 0) && (year >= 0) && 
/* 227 */         (ParseTool.isValidMonth(data[(1 + offset)])) && (ParseTool.isValidDay(data[(2 + offset)], month, year + 2000)) && (ParseTool.isValidHHMMSS(data[(3 + offset)])) && (ParseTool.isValidHHMMSS(data[(4 + offset)])))
/*     */       {
/* 230 */         rt = Calendar.getInstance();
/* 231 */         rt.set(1, year + 2000);
/* 232 */         rt.set(2, month - 1);
/* 233 */         int num = ParseTool.BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 234 */         rt.set(5, num);
/* 235 */         num = ParseTool.BCDToDecimal((byte)(data[(3 + offset)] & 0x3F));
/* 236 */         rt.set(11, num);
/* 237 */         num = ParseTool.BCDToDecimal((byte)(data[(4 + offset)] & 0x7F));
/* 238 */         if (num >= 60) {
/* 239 */           rt.add(11, 1);
/* 240 */           num = 0;
/*     */         }
/* 242 */         rt.set(12, num);
/* 243 */         rt.set(13, 0);
/* 244 */         rt.set(14, 0);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 248 */       e.printStackTrace();
/*     */     }
/* 250 */     return rt;
/*     */   }
/*     */ 
/*     */   private int getTimeInterval(byte type)
/*     */   {
/* 259 */     int rt = 0;
/* 260 */     switch (type)
/*     */     {
/*     */     case 2:
/* 262 */       rt = 1;
/* 263 */       break;
/*     */     case 3:
/* 265 */       rt = 60;
/* 266 */       break;
/*     */     case 4:
/* 268 */       rt = 1440;
/* 269 */       break;
/*     */     case 5:
/* 271 */       rt = 43200;
/*     */     }
/*     */ 
/* 276 */     return rt;
/*     */   }
/*     */ 
/*     */   private void parseRelayTask(byte[] data, int pos, Calendar time, String tasknum, TaskSetting ts, List<RtuData> result) {
/* 280 */     if (data == null)
/*     */       return;
/* 282 */     MeasuredPoint mp = ts.getRtu().getMeasuredPoint(String.valueOf(ts.getTN()));
/* 283 */     if (mp == null) {
/* 284 */       throw new MessageDecodeException("指定测量点不存在！终端--" + ts.getRtu().getLogicAddress() + "  测量点--" + ts.getTN());
/*     */     }
/* 286 */     String pm = ParseTool.getMeterProtocol(mp.getAtrProtocol());
/* 287 */     if (pm == null) {
/* 288 */       throw new MessageDecodeException("不支持的表规约：" + mp.getAtrProtocol());
/*     */     }
/* 290 */     IMeterParser mparser = MeterParserFactory.getMeterParser(pm);
/* 291 */     if (mparser == null) {
/* 292 */       throw new MessageDecodeException("不支持的表规约：" + mp.getAtrProtocol());
/*     */     }
/*     */ 
/* 295 */     Object[] dis = mparser.parser(data, pos, data.length - pos);
/* 296 */     if (dis != null) {
/* 297 */       RtuData bean = new RtuData();
/* 298 */       RtuDataItem beanItem = null;
/* 299 */       for (int i = 0; i < dis.length; ++i) {
/* 300 */         DataItem di = (DataItem)dis[i];
/* 301 */         beanItem = new RtuDataItem();
/* 302 */         beanItem.setCode((String)di.getProperty("datakey"));
/* 303 */         beanItem.setValue((di == null) ? null : di.toString());
/* 304 */         bean.addDataList(beanItem);
/* 305 */         bean.setLogicAddress(ts.getRtu().getLogicAddress());
/* 306 */         bean.setTaskNum(tasknum);
/* 307 */         bean.setTime(time.getTime());
/*     */ 
/* 314 */         result.add(bean);
/*     */       }
/*     */     }
/*     */   }
/*     */ }