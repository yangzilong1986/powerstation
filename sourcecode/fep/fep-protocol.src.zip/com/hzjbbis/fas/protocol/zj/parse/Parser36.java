/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser36
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 29 */       if (len != 4) {
/* 30 */         ok = false;
/*    */       }
/* 32 */       if (ok) {
/* 33 */         StringBuffer sb = new StringBuffer();
/* 34 */         sb.append(ParseTool.BytesToHexL(data, loc, 2));
/* 35 */         sb.append(ParseTool.BytesToHexL(data, loc + 2, 2));
/* 36 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 39 */       e.printStackTrace();
/*    */     }
/* 41 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       ParseTool.HexsToBytesCB(frame, loc, value.substring(0, 4));
/* 56 */       ParseTool.HexsToBytesCB(frame, loc + 2, value.substring(4, 8));
/*    */     } catch (Exception e) {
/* 58 */       throw new MessageEncodeException("错误的 A1A2B2B1 组帧参数:" + value);
/*    */     }
/* 60 */     return len;
/*    */   }
/*    */ }