/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataItemCoder
/*     */ {
/*  18 */   private static Log log = LogFactory.getLog(DataItemCoder.class);
/*     */   public static final int DEFAULT_DATABLOCK_MAX = 100;
/*     */   public static final int SMS_DATABLOCK_MAX = 210;
/*     */   public static final int NET_DATABLOCK_MAX = 1000;
/*     */ 
/*     */   public static int coder(byte[] frame, int loc, FaalRequestParam fp, ProtocolDataItemConfig dic)
/*     */   {
/*  27 */     int slen = -1;
/*     */     try {
/*  29 */       if ((frame != null) && 
/*  30 */         (fp != null) && (dic != null)) {
/*  31 */         String value = fp.getValue();
/*  32 */         switch (dic.getParserno())
/*     */         {
/*     */         case 1:
/*  34 */           slen = Parser01.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  35 */           break;
/*     */         case 2:
/*  37 */           slen = Parser02.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  38 */           break;
/*     */         case 3:
/*  40 */           slen = Parser03.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  41 */           break;
/*     */         case 4:
/*  43 */           slen = Parser04.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  44 */           break;
/*     */         case 5:
/*  46 */           slen = Parser05.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  47 */           break;
/*     */         case 6:
/*  49 */           slen = Parser06.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  50 */           break;
/*     */         case 7:
/*  52 */           slen = Parser07.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  53 */           break;
/*     */         case 8:
/*  55 */           slen = Parser08.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  56 */           break;
/*     */         case 9:
/*  58 */           slen = Parser09.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  59 */           break;
/*     */         case 10:
/*  61 */           slen = Parser10.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  62 */           break;
/*     */         case 11:
/*  64 */           slen = Parser11.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  65 */           break;
/*     */         case 12:
/*  67 */           slen = Parser12.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  68 */           break;
/*     */         case 13:
/*  70 */           slen = Parser13.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  71 */           break;
/*     */         case 14:
/*  73 */           slen = Parser14.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  74 */           break;
/*     */         case 15:
/*  76 */           slen = Parser15.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  77 */           break;
/*     */         case 16:
/*  79 */           slen = Parser16.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  80 */           break;
/*     */         case 17:
/*  82 */           slen = Parser17.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  83 */           break;
/*     */         case 18:
/*  85 */           slen = Parser18.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  86 */           break;
/*     */         case 19:
/*  88 */           slen = Parser19.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  89 */           break;
/*     */         case 20:
/*  91 */           slen = Parser20.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  92 */           break;
/*     */         case 21:
/*  94 */           slen = Parser21.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  95 */           break;
/*     */         case 22:
/*  97 */           slen = Parser22.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/*  98 */           break;
/*     */         case 23:
/* 100 */           slen = Parser23.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 101 */           break;
/*     */         case 24:
/* 103 */           slen = Parser24.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 104 */           break;
/*     */         case 25:
/* 106 */           slen = Parser25.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 107 */           break;
/*     */         case 26:
/* 109 */           slen = Parser26.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 110 */           break;
/*     */         case 27:
/* 112 */           slen = Parser27.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 113 */           break;
/*     */         case 28:
/* 115 */           slen = Parser28.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 116 */           break;
/*     */         case 29:
/* 118 */           slen = Parser29.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 119 */           break;
/*     */         case 30:
/* 121 */           slen = Parser30.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 122 */           break;
/*     */         case 31:
/* 124 */           slen = Parser31.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 125 */           break;
/*     */         case 32:
/* 127 */           slen = Parser32.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 128 */           break;
/*     */         case 33:
/* 130 */           slen = Parser33.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 131 */           break;
/*     */         case 34:
/* 133 */           slen = Parser34.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 134 */           break;
/*     */         case 35:
/* 136 */           slen = Parser35.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 137 */           break;
/*     */         case 36:
/* 139 */           slen = Parser36.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 140 */           break;
/*     */         case 37:
/* 142 */           slen = Parser37.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 143 */           break;
/*     */         case 38:
/* 145 */           slen = Parser38.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 146 */           break;
/*     */         case 39:
/* 148 */           slen = Parser39.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 149 */           break;
/*     */         case 40:
/* 151 */           slen = Parser40.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 152 */           break;
/*     */         case 41:
/* 154 */           slen = Parser41.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 155 */           break;
/*     */         case 42:
/* 157 */           slen = Parser42.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 158 */           break;
/*     */         case 43:
/* 160 */           slen = Parser43.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 161 */           break;
/*     */         case 44:
/* 163 */           slen = Parser44.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 164 */           break;
/*     */         case 45:
/* 166 */           slen = Parser45.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 167 */           break;
/*     */         case 46:
/* 169 */           slen = Parser46.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 170 */           break;
/*     */         case 47:
/* 172 */           slen = Parser47.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 173 */           break;
/*     */         case 48:
/* 175 */           slen = Parser48.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 176 */           break;
/*     */         case 49:
/* 178 */           slen = Parser49.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 179 */           break;
/*     */         case 50:
/* 181 */           slen = Parser50.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 182 */           break;
/*     */         case 51:
/* 184 */           slen = Parser51.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 185 */           break;
/*     */         case 52:
/* 187 */           slen = Parser52.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 188 */           break;
/*     */         case 53:
/* 190 */           slen = Parser53.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 191 */           break;
/*     */         case 54:
/* 193 */           slen = Parser54.constructor(frame, value, loc, dic.getLength(), dic.getFraction());
/* 194 */           break;
/*     */         default:
/* 196 */           slen = fakeCoder(frame, loc, value, dic.getLength());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 207 */       log.error("coder", e);
/*     */     }
/* 209 */     return slen;
/*     */   }
/*     */ 
/*     */   public static int fakeCoder(byte[] frame, int loc, String data, int len)
/*     */   {
/*     */     try
/*     */     {
/* 293 */       Arrays.fill(frame, loc, loc + len - 1, -1);
/*     */     } catch (Exception e) {
/* 295 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 298 */     return len;
/*     */   }
/*     */ 
/*     */   public static int getDataMax(BizRtu rtu) {
/* 302 */     return 100;
/*     */   }
/*     */ }