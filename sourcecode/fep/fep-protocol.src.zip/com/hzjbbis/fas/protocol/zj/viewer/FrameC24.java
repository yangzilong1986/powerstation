/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameC24 extends AbstractFrame
/*    */ {
/*    */   public static final String FUNC_NAME = "心跳";
/*    */ 
/*    */   public FrameC24()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FrameC24(byte[] frame)
/*    */   {
/* 19 */     super(frame);
/*    */   }
/*    */ 
/*    */   public FrameC24(String data) {
/* 23 */     super(data);
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 27 */     if (this.frame != null) {
/* 28 */       StringBuffer sb = new StringBuffer();
/* 29 */       sb.append(super.getBase());
/* 30 */       sb.append("命令类型--").append("心跳");
/* 31 */       sb.append("\n");
/* 32 */       sb.append("数据--").append(Util.BytesToHex(this.frame, 11, this.length));
/* 33 */       return sb.toString();
/*    */     }
/* 35 */     return null;
/*    */   }
/*    */ }