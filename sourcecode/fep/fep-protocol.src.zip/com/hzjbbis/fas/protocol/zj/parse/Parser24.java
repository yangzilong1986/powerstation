/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class Parser24
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc + 4, len - 4);
/*  29 */       if (ok) {
/*  30 */         StringBuffer sb = new StringBuffer();
/*  31 */         sb.append(ParseTool.ByteToHex(data[(loc + 8)]));
/*  32 */         sb.append("-");
/*  33 */         sb.append(ParseTool.ByteToHex(data[(loc + 7)]));
/*  34 */         sb.append(",");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/*  36 */         sb.append("-");
/*  37 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  38 */         sb.append(",");
/*  39 */         int ti = data[(loc + 4)] & 0xFF;
/*  40 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/*  41 */         sb.append(",");
/*  42 */         switch (ti)
/*     */         {
/*     */         case 4:
/*  44 */           sb.append(ParseTool.ByteToHex(data[loc]));
/*  45 */           break;
/*     */         case 5:
/*  54 */           sb.append(ParseTool.BytesBitC(data, loc, 4));
/*  55 */           break;
/*     */         case 6:
/*  57 */           sb.append(ParseTool.ByteBitC(data[loc]));
/*  58 */           break;
/*     */         default:
/*  60 */           sb.append("0");
/*     */         }
/*     */ 
/*  63 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  66 */       e.printStackTrace();
/*     */     }
/*  68 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       for (int i = 0; i < value.length(); ++i) {
/*  84 */         char c = value.charAt(i);
/*  85 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  88 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  91 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  94 */         throw new MessageEncodeException("错误的 MS-DS ME-DE TI N3N2N1N0 组帧参数:" + value);
/*     */       }
/*     */ 
/*  97 */       String[] para = value.split(",");
/*  98 */       String[] sdate = para[0].split("-");
/*  99 */       String[] edate = para[1].split("-");
/*     */ 
/* 101 */       frame[(loc + 8)] = ParseTool.StringToBcd(sdate[0]);
/* 102 */       frame[(loc + 7)] = ParseTool.StringToBcd(sdate[1]);
/* 103 */       frame[(loc + 6)] = ParseTool.StringToBcd(edate[0]);
/* 104 */       frame[(loc + 5)] = ParseTool.StringToBcd(edate[1]);
/*     */ 
/* 106 */       int ti = Integer.parseInt(para[2]);
/* 107 */       frame[(loc + 4)] = (byte)(ti % 10);
/* 108 */       Arrays.fill(frame, loc, loc + 3, 0);
/* 109 */       switch (ti)
/*     */       {
/*     */       case 4:
/* 111 */         frame[loc] = ParseTool.IntToBcd(Integer.parseInt(para[3]));
/* 112 */         break;
/*     */       case 5:
/* 114 */         ParseTool.bitToBytesC(frame, para[3], loc);
/* 115 */         break;
/*     */       case 6:
/* 117 */         ParseTool.bitToBytesC(frame, para[3], loc);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 123 */       throw new MessageEncodeException("错误的 MS-DS ME-DE TI N3N2N1N0 组帧参数:" + value);
/*     */     }
/*     */ 
/* 126 */     return len;
/*     */   }
/*     */ }