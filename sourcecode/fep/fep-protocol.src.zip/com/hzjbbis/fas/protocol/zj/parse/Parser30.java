/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser30
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/* 30 */         sb.append(",");
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 32 */         sb.append(",");
/* 33 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc, 3)));
/* 34 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 37 */       e.printStackTrace();
/*    */     }
/* 39 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 54 */       for (int i = 0; i < value.length(); ++i) {
/* 55 */         char c = value.charAt(i);
/* 56 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 59 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 62 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 65 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 68 */         throw new MessageEncodeException("错误的 MM YY PPPPPP 组帧参数:" + value);
/*    */       }
/* 70 */       String[] para = value.split(",");
/* 71 */       ParseTool.IntToBcd(frame, Integer.parseInt(para[2]), loc, 3);
/* 72 */       frame[(loc + 3)] = ParseTool.IntToBcd(Integer.parseInt(para[1]));
/* 73 */       frame[(loc + 4)] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/*    */     } catch (Exception e) {
/* 75 */       throw new MessageEncodeException("错误的 MM YY PPPPPP 组帧参数:" + value);
/*    */     }
/*    */ 
/* 78 */     return len;
/*    */   }
/*    */ }