/*     */ package com.hzjbbis.fas.protocol.zj.viewer;
/*     */ 
/*     */ public class Util
/*     */ {
/*  10 */   public static String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
/*     */ 
/*     */   public static String BytesToHex(byte[] data, int start, int len)
/*     */   {
/*  20 */     StringBuffer sb = new StringBuffer();
/*  21 */     for (int i = start; i < start + len; ++i) {
/*  22 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*  23 */       sb.append(hex[(data[i] & 0xF)]);
/*  24 */       sb.append(" ");
/*     */     }
/*  26 */     if (sb.length() > 0) {
/*  27 */       return sb.substring(0, sb.length() - 1);
/*     */     }
/*  29 */     return "";
/*     */   }
/*     */ 
/*     */   public static String ByteToHex(byte data) {
/*  33 */     String bt = "";
/*  34 */     bt = hex[((data & 0xF0) >> 4)] + hex[(data & 0xF)];
/*  35 */     return bt;
/*     */   }
/*     */ 
/*     */   public static String BytesToHexL(byte[] data, int start, int len)
/*     */   {
/*  46 */     StringBuffer sb = new StringBuffer();
/*  47 */     for (int i = start; i < start + len; ++i) {
/*  48 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*  49 */       sb.append(hex[(data[i] & 0xF)]);
/*     */     }
/*  51 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static void HexsToBytes(byte[] frame, int loc, String hex)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*     */ 
/*  63 */       byte[] bt = hex.getBytes();
/*  64 */       int head = 0;
/*  65 */       if ((hex.length() & 0x1) > 0) {
/*  66 */         frame[loc] = (byte)AsciiToInt(bt[0]);
/*  67 */         head = 1;
/*     */       } else {
/*  69 */         frame[loc] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  70 */         head = 2;
/*     */       }
/*  72 */       for (int i = 1; i < len; ++i) {
/*  73 */         frame[(loc + i)] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  74 */         head += 2;
/*     */       }
/*     */     } catch (Exception e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int AsciiToInt(byte val) {
/*  82 */     int rt = val & 0xFF;
/*  83 */     if (val < 58)
/*  84 */       rt -= 48;
/*  85 */     else if (rt < 71)
/*  86 */       rt -= 55;
/*     */     else {
/*  88 */       rt -= 87;
/*     */     }
/*  90 */     return rt;
/*     */   }
/*     */ 
/*     */   public static boolean validHex(String data) {
/*  94 */     boolean rt = true;
/*  95 */     for (int i = 0; i < data.length(); ++i) {
/*  96 */       String c = data.substring(i, i + 1);
/*  97 */       if ((c.compareTo("0") >= 0) && (c.compareToIgnoreCase("9") <= 0)) {
/*     */         continue;
/*     */       }
/* 100 */       if ((c.compareToIgnoreCase("A") >= 0) && (c.compareToIgnoreCase("F") <= 0)) {
/*     */         continue;
/*     */       }
/* 103 */       rt = false;
/* 104 */       break;
/*     */     }
/* 106 */     return rt;
/*     */   }
/*     */ 
/*     */   public static byte calculateCS(byte[] data, int start, int len) {
/* 110 */     int cs = 0;
/* 111 */     for (int i = start; i < start + len; ++i) {
/* 112 */       cs += (data[i] & 0xFF);
/* 113 */       cs &= 255;
/*     */     }
/* 115 */     return (byte)(cs & 0xFF);
/*     */   }
/*     */ 
/*     */   public static int maxArrow(String arrow) {
/* 119 */     int len = 0;
/* 120 */     int flag = 0;
/* 121 */     int style = -1;
/* 122 */     int lastc = 0;
/* 123 */     String arrow01 = ">";
/* 124 */     String arrow02 = "<";
/* 125 */     String handle01 = "-";
/* 126 */     String handle02 = "=";
/*     */ 
/* 130 */     if (arrow != null) {
/* 131 */       String strm = arrow.trim();
/* 132 */       if (strm.length() > 0) {
/* 133 */         flag = 0;
/* 134 */         style = -1;
/* 135 */         int alen = 0;
/*     */ 
/* 137 */         for (int i = 0; i < strm.length(); ++i) {
/* 138 */           String strc = strm.substring(i, i + 1);
/*     */ 
/* 140 */           if (strc.equals(arrow01)) {
/* 141 */             if (style < 0)
/*     */             {
/* 143 */               if (len <= 0)
/* 144 */                 len = 1;
/*     */             }
/* 146 */             else if (style == 0)
/*     */             {
/* 148 */               ++alen;
/* 149 */               if (alen > len) {
/* 150 */                 len = alen;
/*     */               }
/* 152 */               alen = 0;
/* 153 */               flag = 0;
/* 154 */               style = -1;
/*     */             }
/*     */             else {
/* 157 */               if (alen > len) {
/* 158 */                 len = alen;
/*     */               }
/* 160 */               alen = 0;
/* 161 */               flag = 0;
/* 162 */               style = -1;
/*     */             }
/* 164 */             lastc = 0;
/* 165 */           } else if (strc.equals(arrow02)) {
/* 166 */             if (style < 0)
/*     */             {
/* 168 */               style = 1;
/* 169 */               alen = 1;
/* 170 */               flag = 0;
/* 171 */             } else if (style == 0)
/*     */             {
/* 173 */               style = 1;
/* 174 */               alen = 1;
/* 175 */               flag = 0;
/*     */             } else {
/* 177 */               if ((len <= 0) || (alen > len)) {
/* 178 */                 len = alen;
/*     */               }
/* 180 */               style = 1;
/* 181 */               alen = 1;
/* 182 */               flag = 0;
/*     */             }
/* 184 */             lastc = 1;
/* 185 */           } else if (strc.equals(handle01)) {
/* 186 */             if (style < 0)
/*     */             {
/* 188 */               style = 0;
/* 189 */               alen = 1;
/* 190 */               flag = 0;
/* 191 */             } else if (style == 0) {
/* 192 */               if (lastc == 2)
/*     */               {
/* 194 */                 ++alen;
/*     */               }
/*     */               else alen = 1;
/*     */ 
/*     */             }
/* 199 */             else if ((lastc == 2) || (lastc == 1))
/*     */             {
/* 201 */               ++alen;
/*     */             }
/*     */             else {
/* 204 */               if (alen > len) {
/* 205 */                 len = alen;
/*     */               }
/* 207 */               alen = 1;
/* 208 */               flag = 0;
/* 209 */               style = 0;
/*     */             }
/*     */ 
/* 212 */             lastc = 2;
/* 213 */           } else if (strc.equals(handle02)) {
/* 214 */             if (style < 0)
/*     */             {
/* 216 */               style = 0;
/* 217 */               alen = 1;
/* 218 */               flag = 0;
/* 219 */             } else if (style == 0) {
/* 220 */               if (lastc == 3)
/*     */               {
/* 222 */                 ++alen;
/*     */               }
/*     */               else alen = 1;
/*     */ 
/*     */             }
/* 227 */             else if ((lastc == 3) || (lastc == 1))
/*     */             {
/* 229 */               ++alen;
/*     */             }
/*     */             else {
/* 232 */               if (alen > len) {
/* 233 */                 len = alen;
/*     */               }
/* 235 */               alen = 1;
/* 236 */               flag = 0;
/* 237 */               style = 0;
/*     */             }
/*     */ 
/* 240 */             lastc = 3;
/*     */           }
/*     */           else {
/* 243 */             if ((alen > 0) && (alen > len)) {
/* 244 */               len = alen;
/*     */             }
/* 246 */             alen = 0;
/* 247 */             flag = 0;
/* 248 */             style = -1;
/*     */           }
/*     */         }
/* 251 */         if ((style == 1) && (alen > len)) {
/* 252 */           len = alen;
/*     */         }
/*     */       }
/*     */     }
/* 256 */     return len;
/*     */   }
/*     */ }