/*    */ package com.hzjbbis.fas.protocol.zj.viewer;
/*    */ 
/*    */ public class FrameC21 extends AbstractFrame
/*    */ {
/*    */   public static final String FUNC_NAME = "登录";
/*    */ 
/*    */   public FrameC21()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FrameC21(byte[] frame)
/*    */   {
/* 18 */     super(frame);
/*    */   }
/*    */ 
/*    */   public FrameC21(String data) {
/* 22 */     super(data);
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 26 */     if (this.frame != null) {
/* 27 */       StringBuffer sb = new StringBuffer();
/* 28 */       sb.append(super.getBase());
/* 29 */       sb.append("命令类型--").append("登录");
/* 30 */       sb.append("\n");
/* 31 */       sb.append("数据--").append(Util.BytesToHex(this.frame, 11, this.length));
/* 32 */       return sb.toString();
/*    */     }
/* 34 */     return null;
/*    */   }
/*    */ }