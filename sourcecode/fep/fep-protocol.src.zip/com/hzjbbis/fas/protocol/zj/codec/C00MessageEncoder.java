/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalReadForwardDataRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.IMeterParser;
/*     */ import com.hzjbbis.fas.protocol.meter.MeterParserFactory;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C00MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  28 */   private static Log log = LogFactory.getLog(C00MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj) {
/*  31 */     List rt = new ArrayList();
/*     */     try {
/*  33 */       if (obj instanceof FaalReadForwardDataRequest) {
/*  34 */         FaalReadForwardDataRequest para = (FaalReadForwardDataRequest)obj;
/*     */ 
/*  37 */         int waittime = para.getTimeout();
/*  38 */         byte character = 0;
/*  39 */         int cutindex = 0;
/*  40 */         int cutlen = 0;
/*     */ 
/*  42 */         List dkeys = para.getParams();
/*  43 */         String tn = para.getTn();
/*  44 */         if (dkeys != null)
/*     */         {
/*  46 */           String[] datakeyzj = new String[dkeys.size()];
/*  47 */           for (int index = 0; index < dkeys.size(); ++index) {
/*  48 */             FaalRequestParam frp = (FaalRequestParam)dkeys.get(index);
/*  49 */             datakeyzj[index] = frp.getName();
/*     */           }
/*     */ 
/*  55 */           List rtuid = para.getRtuIds();
/*  56 */           if (rtuid == null) {
/*  57 */             throw new MessageEncodeException("未指定召测终端");
/*     */           }
/*  59 */           List cmdIds = para.getCmdIds();
/*  60 */           if (cmdIds == null) {
/*  61 */             throw new MessageEncodeException("命令ID缺失");
/*     */           }
/*     */ 
/*  64 */           for (int i = 0; i < rtuid.size(); ++i)
/*  65 */             createRtuFrame(rt, para, waittime, character, cutindex, cutlen, tn, datakeyzj, rtuid, cmdIds, i);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  70 */       throw new MessageEncodeException(e);
/*     */     }
/*  72 */     if (rt != null) {
/*  73 */       IMessage[] msgs = new IMessage[rt.size()];
/*  74 */       rt.toArray(msgs);
/*  75 */       return msgs;
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   private void createRtuFrame(List<MessageZj> rt, FaalReadForwardDataRequest para, int waittime, byte character, int cutindex, int cutlen, String tn, String[] datakeyzj, List rtuid, List cmdIds, int i)
/*     */   {
/*     */     try {
/*  83 */       MessageZj msg = null;
/*  84 */       String id = (String)rtuid.get(i);
/*  85 */       BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/*  86 */       if (rtu == null) {
/*  87 */         throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */       }
/*     */ 
/*  90 */       IMeterParser mparser = null;
/*  91 */       String pm = null;
/*  92 */       String maddr = null;
/*  93 */       String portstr = null;
/*     */ 
/*  95 */       if (para.getFixProto() == null)
/*  96 */         pm = getProtoWithMpPara(rtu, tn);
/*     */       else {
/*  98 */         pm = ParseTool.getMeterProtocol(para.getFixProto());
/*     */       }
/* 100 */       if (para.getFixAddre() == null)
/* 101 */         maddr = getAddrWithMpPara(rtu, tn, para);
/*     */       else {
/* 103 */         maddr = para.getFixAddre();
/*     */       }
/* 105 */       if (para.getFixPort() == null)
/* 106 */         portstr = getPortWithMpPara(rtu, tn);
/*     */       else {
/* 108 */         portstr = para.getFixPort();
/*     */       }
/*     */ 
/* 111 */       mparser = MeterParserFactory.getMeterParser(pm);
/* 112 */       if (mparser == null) {
/* 113 */         throw new MessageEncodeException("不支持的表规约");
/*     */       }
/*     */ 
/* 116 */       if (maddr == null) {
/* 117 */         throw new MessageEncodeException("测量点地址缺失！");
/*     */       }
/*     */ 
/* 120 */       if ((pm.equalsIgnoreCase("20")) && 
/* 121 */         (maddr.length() > 2)) {
/* 122 */         String xxa = maddr.substring(maddr.length() - 2);
/* 123 */         if (xxa.equalsIgnoreCase("AA"))
/*     */         {
/* 125 */           maddr = maddr.substring(0, 2);
/*     */         }
/*     */         else maddr = xxa;
/*     */ 
/*     */       }
/*     */ 
/* 133 */       DataItem dipara = new DataItem();
/* 134 */       dipara.addProperty("point", maddr);
/* 135 */       String[] dks = mparser.convertDataKey(datakeyzj);
/*     */ 
/* 139 */       int msgcount = 0;
/*     */ 
/* 141 */       for (int k = 0; (k < dks.length) && 
/* 142 */         (dks[k] != null); ++k) {
/* 142 */         if (dks[k].length() <= 0) {
/*     */           break;
/*     */         }
/* 145 */         byte[] cmd = mparser.constructor(new String[] { dks[k] }, dipara);
/* 146 */         if (cmd == null) {
/* 147 */           StringBuffer se = new StringBuffer();
/* 148 */           for (int j = 0; j < datakeyzj.length; ++j) {
/* 149 */             se.append(datakeyzj[j]);
/* 150 */             se.append(" ");
/*     */           }
/* 152 */           throw new MessageEncodeException("不支持召测的表规约数据：" + se.toString() + "  RTU:" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */         }
/* 154 */         int len = cmd.length + 7;
/*     */ 
/* 157 */         MessageZjHead head = new MessageZjHead();
/* 158 */         head.c_dir = 0;
/* 159 */         head.c_expflag = 0;
/* 160 */         head.c_func = 0;
/* 161 */         head.rtua = rtu.getRtua();
/* 162 */         head.iseq = 0;
/* 163 */         head.dlen = (short)len;
/*     */ 
/* 165 */         int port = 1;
/* 166 */         if (portstr != null) {
/* 167 */           port = Integer.parseInt(portstr);
/*     */         }
/* 169 */         byte[] frame = new byte[len];
/* 170 */         frame[0] = (byte)port;
/* 171 */         frame[1] = (byte)waittime;
/* 172 */         frame[2] = character;
/* 173 */         frame[3] = (byte)(cutindex & 0xFF);
/* 174 */         frame[4] = (byte)((cutindex & 0xFF00) >>> 8);
/* 175 */         frame[5] = (byte)(cutlen & 0xFF);
/* 176 */         frame[6] = (byte)((cutlen & 0xFF00) >>> 8);
/* 177 */         System.arraycopy(cmd, 0, frame, 7, cmd.length);
/*     */ 
/* 179 */         msg = new MessageZj();
/* 180 */         msg.data = ByteBuffer.wrap(frame);
/*     */ 
/* 188 */         msg.setCmdId((Long)cmdIds.get(i));
/*     */ 
/* 190 */         msg.head = head;
/*     */ 
/* 192 */         rt.add(msg);
/* 193 */         ++msgcount;
/*     */       }
/*     */ 
/* 197 */       setMsgcount(rt, msgcount);
/*     */     }
/*     */     catch (Exception e) {
/*     */       try {
/* 201 */         MessageZj msg = new MessageZj();
/* 202 */         HostCommand hc = new HostCommand();
/* 203 */         hc.setId((Long)cmdIds.get(i));
/* 204 */         msg.setCmdId((Long)cmdIds.get(i));
/* 205 */         msg.setStatus("6");
/* 206 */         rt.add(msg);
/*     */       }
/*     */       catch (Exception ex) {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getProtoWithMpPara(BizRtu rtu, String tn) {
/* 214 */     String proto = null;
/*     */ 
/* 216 */     MeasuredPoint mp = rtu.getMeasuredPoint(tn);
/* 217 */     if (mp == null) {
/* 218 */       throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */     }
/*     */ 
/* 221 */     if (mp.getAtrProtocol() == null) {
/* 222 */       log.error("表规约缺失，将使用默认规约类型------RTU:" + ParseTool.IntToHex4(rtu.getRtua()));
/* 223 */       proto = ParseTool.getMeterProtocol("20");
/*     */     } else {
/* 225 */       proto = ParseTool.getMeterProtocol(mp.getAtrProtocol());
/*     */     }
/*     */ 
/* 228 */     return proto;
/*     */   }
/*     */ 
/*     */   private String getPortWithMpPara(BizRtu rtu, String tn) {
/* 232 */     String port = null;
/* 233 */     MeasuredPoint mp = rtu.getMeasuredPoint(tn);
/* 234 */     if (mp == null) {
/* 235 */       throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */     }
/* 237 */     port = mp.getAtrPort();
/* 238 */     return port;
/*     */   }
/*     */ 
/*     */   private String getAddrWithMpPara(BizRtu rtu, String tn, FaalReadForwardDataRequest para)
/*     */   {
/*     */     MeasuredPoint mp;
/* 242 */     String maddr = null;
/* 243 */     if (para.isBroadcast()) {
/* 244 */       if (para.getBroadcastAddress() != null) {
/* 245 */         maddr = para.getBroadcastAddress();
/*     */       } else {
/* 247 */         mp = rtu.getMeasuredPoint(tn);
/* 248 */         if (mp == null) {
/* 249 */           throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */         }
/* 251 */         maddr = getBroadcastAddress(mp);
/*     */       }
/*     */     } else {
/* 254 */       mp = rtu.getMeasuredPoint(tn);
/* 255 */       if (mp == null) {
/* 256 */         throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */       }
/* 258 */       if (mp.getAtrAddress() == null)
/* 259 */         maddr = getBroadcastAddress(mp);
/*     */       else {
/* 261 */         maddr = mp.getAtrAddress();
/*     */       }
/*     */     }
/* 264 */     return maddr;
/*     */   }
/*     */ 
/*     */   private String getBroadcastAddress(MeasuredPoint mp) {
/* 268 */     String maddr = null;
/* 269 */     if (mp.getAtrProtocol() == null) {
/* 270 */       maddr = "FF";
/*     */     } else {
/* 272 */       if (mp.getAtrProtocol().equalsIgnoreCase("10")) {
/* 273 */         maddr = "999999999999";
/*     */       }
/* 275 */       if (mp.getAtrProtocol().equalsIgnoreCase("20")) {
/* 276 */         maddr = "FF";
/*     */       }
/* 278 */       if (mp.getAtrProtocol().equalsIgnoreCase("40")) {
/* 279 */         maddr = "FF";
/*     */       }
/*     */     }
/* 282 */     return maddr; }
/*     */ 
/*     */   private void setMsgcount(List msgs, int msgcount) {
/* 285 */     for (Iterator iter = msgs.iterator(); iter.hasNext(); ) {
/* 286 */       MessageZj msg = (MessageZj)iter.next();
/* 287 */       if (msg.getMsgCount() == 0)
/* 288 */         msg.setMsgCount(msgcount);
/*     */     }
/*     */   }
/*     */ }