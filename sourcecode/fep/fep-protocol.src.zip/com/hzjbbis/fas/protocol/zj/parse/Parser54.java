/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser54
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 21 */     Object rt = null;
/*    */     try {
/* 23 */       boolean ok = true;
/*    */ 
/* 27 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 28 */       if (ok) {
/* 29 */         StringBuffer sb = new StringBuffer();
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 48)]));
/* 31 */         sb.append(",");
/* 32 */         for (int i = 15; i >= 0; --i) {
/* 33 */           sb.append(ParseTool.ByteToHex(data[(loc + i * 3 + 2)]));
/* 34 */           sb.append(",");
/* 35 */           sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + i * 3, 2) / ParseTool.fraction[2]));
/* 36 */           sb.append(",");
/*    */         }
/* 38 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 41 */       e.printStackTrace();
/*    */     }
/* 43 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       NumberFormat nf = NumberFormat.getInstance();
/* 58 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 60 */       for (int i = 0; i < value.length(); ++i) {
/* 61 */         char c = value.charAt(i);
/* 62 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 65 */         if (c == '.') {
/*    */           continue;
/*    */         }
/* 68 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 71 */         throw new MessageEncodeException("错误的 NN,SS1,PP.PP1……SS16,PP.PP16 组帧参数:" + value);
/*    */       }
/* 73 */       String[] para = value.split(",");
/* 74 */       frame[(loc + 48)] = ParseTool.StringToBcd(para[0]);
/* 75 */       for (int i = 0; i < 16; ++i) {
/* 76 */         double xx = nf.parse(para[(32 - (i * 2))]).doubleValue() * ParseTool.fraction[2];
/* 77 */         ParseTool.IntToBcd(frame, (int)xx, loc + i * 3, 2);
/* 78 */         frame[(loc + i * 3 + 2)] = ParseTool.IntToBcd(Integer.parseInt(para[(32 - (i * 2) - 1)]));
/*    */       }
/*    */     } catch (Exception e) {
/* 81 */       throw new MessageEncodeException("错误的 NN,SS1,PP.PP1……SS16,PP.PP16 组帧参数:" + value);
/*    */     }
/*    */ 
/* 84 */     return len;
/*    */   }
/*    */ }