/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser19
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append("20");
/* 30 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/* 31 */         sb.append("-");
/* 32 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/* 33 */         sb.append("-");
/* 34 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 35 */         sb.append(" ");
/* 36 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 37 */         sb.append(":");
/* 38 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 39 */         sb.append(":");
/* 40 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 41 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 44 */       e.printStackTrace();
/*    */     }
/* 46 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       for (int i = 0; i < value.length(); ++i) {
/* 62 */         char c = value.charAt(i);
/* 63 */         if (c == '-') {
/*    */           continue;
/*    */         }
/* 66 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 69 */         if (c == ' ') {
/*    */           continue;
/*    */         }
/* 72 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 75 */         throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm:ss 组帧参数:" + value);
/*    */       }
/* 77 */       String[] dpara = value.split(" ");
/* 78 */       String[] date = dpara[0].split("-");
/* 79 */       String[] time = dpara[1].split(":");
/*    */ 
/* 81 */       frame[(loc + 5)] = ParseTool.StringToBcd(date[0]);
/* 82 */       frame[(loc + 4)] = ParseTool.StringToBcd(date[1]);
/* 83 */       frame[(loc + 3)] = ParseTool.StringToBcd(date[2]);
/* 84 */       frame[(loc + 2)] = ParseTool.StringToBcd(time[0]);
/* 85 */       frame[(loc + 1)] = ParseTool.StringToBcd(time[1]);
/* 86 */       frame[loc] = ParseTool.StringToBcd(time[2]);
/*    */     } catch (Exception e) {
/* 88 */       throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm:ss 组帧参数:" + value);
/*    */     }
/*    */ 
/* 91 */     return len;
/*    */   }
/*    */ }