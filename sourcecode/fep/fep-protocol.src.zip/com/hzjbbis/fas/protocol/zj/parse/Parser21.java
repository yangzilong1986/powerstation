/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser21
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.BytesBitC(data, loc + 8, 1));
/* 30 */         sb.append(",");
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 7)]));
/* 32 */         sb.append(",");
/* 33 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/* 34 */         sb.append(",");
/* 35 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/* 36 */         sb.append(",");
/* 37 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/* 38 */         sb.append(",");
/* 39 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/* 40 */         sb.append(",");
/* 41 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 42 */         sb.append(",");
/* 43 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 44 */         sb.append(",");
/* 45 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 46 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 49 */       e.printStackTrace();
/*    */     }
/* 51 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 66 */       for (int i = 0; i < value.length(); ++i) {
/* 67 */         char c = value.charAt(i);
/* 68 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 71 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 74 */         if ((c >= 'A') && (c <= 'F')) {
/*    */           continue;
/*    */         }
/* 77 */         if ((c >= 'a') && (c <= 'f')) {
/*    */           continue;
/*    */         }
/* 80 */         throw new MessageEncodeException("错误的 NN TN1TN2……TN8 组帧参数:" + value);
/*    */       }
/* 82 */       String[] para = value.split(",");
/*    */ 
/* 84 */       frame[(loc + 8)] = ParseTool.bitToByteC(para[0]);
/* 85 */       frame[loc] = ParseTool.StringToBcd(para[8]);
/* 86 */       frame[(loc + 1)] = ParseTool.StringToBcd(para[7]);
/* 87 */       frame[(loc + 2)] = ParseTool.StringToBcd(para[6]);
/* 88 */       frame[(loc + 3)] = ParseTool.StringToBcd(para[5]);
/* 89 */       frame[(loc + 4)] = ParseTool.StringToBcd(para[4]);
/* 90 */       frame[(loc + 5)] = ParseTool.StringToBcd(para[3]);
/* 91 */       frame[(loc + 6)] = ParseTool.StringToBcd(para[2]);
/* 92 */       frame[(loc + 7)] = ParseTool.StringToBcd(para[1]);
/*    */     } catch (Exception e) {
/* 94 */       throw new MessageEncodeException("错误的 NN TN1TN2……TN8 组帧参数:" + value);
/*    */     }
/*    */ 
/* 97 */     return len;
/*    */   }
/*    */ }