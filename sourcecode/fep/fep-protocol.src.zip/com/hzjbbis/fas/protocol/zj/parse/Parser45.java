/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser45
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       rt = ParseTool.BytesBitC(data, loc, len);
/*    */     } catch (Exception e) {
/* 26 */       e.printStackTrace();
/*    */     }
/* 28 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/* 41 */     int slen = -1;
/*    */     try {
/* 43 */       int vlen = value.length();
/* 44 */       for (int i = 0; i < vlen; ++i) {
/* 45 */         if (value.substring(i, i + 1).equals("0")) continue; if (value.substring(i, i + 1).equals("1")) {
/*    */           continue;
/*    */         }
/* 48 */         throw new MessageEncodeException("错误的 bit位码 组帧参数:" + value);
/*    */       }
/*    */ 
/* 51 */       if ((vlen & 0x7) == 0) {
/* 52 */         int blen = 0;
/* 53 */         int iloc = loc;
/* 54 */         while (blen < vlen) {
/* 55 */           frame[iloc] = ParseTool.bitToByteC(value.substring(blen, blen + 8));
/* 56 */           blen += 8;
/* 57 */           ++iloc;
/*    */         }
/* 59 */         slen = len;
/*    */       }
/*    */     } catch (Exception e) {
/* 62 */       throw new MessageEncodeException("错误的 bit位码 组帧参数:" + value);
/*    */     }
/* 64 */     return slen;
/*    */   }
/*    */ }