/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class Parser52
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  19 */     Object rt = null;
/*     */     try {
/*  21 */       boolean ok = true;
/*     */ 
/*  25 */       ok = ParseTool.isHaveValidBCD(data, loc, len);
/*  26 */       if (ok) {
/*  27 */         StringBuffer sb = new StringBuffer();
/*  28 */         sb.append("20");
/*  29 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 1)]));
/*  30 */         sb.append("-");
/*  31 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 2)]));
/*  32 */         sb.append("-");
/*  33 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 3)]));
/*  34 */         sb.append(" ");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 4)]));
/*  36 */         sb.append(":");
/*  37 */         sb.append(ParseTool.ByteToHex(data[(loc + len - 5)]));
/*  38 */         sb.append(",");
/*  39 */         boolean bn = (data[(loc + len - 5 - 1)] & 0x10) > 0;
/*  40 */         int val = ParseTool.nBcdToDecimalS(data, loc, len - 5);
/*  41 */         if (bn) {
/*  42 */           val = -val;
/*     */         }
/*  44 */         sb.append(String.valueOf(val / ParseTool.fraction[fraction]));
/*  45 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  48 */       e.printStackTrace();
/*     */     }
/*  50 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*     */     try
/*     */     {
/*  65 */       for (int i = 0; i < value.length(); ++i) {
/*  66 */         char c = value.charAt(i);
/*  67 */         if (c == ',') {
/*     */           continue;
/*     */         }
/*  70 */         if (c == ':') {
/*     */           continue;
/*     */         }
/*  73 */         if (c == '-') {
/*     */           continue;
/*     */         }
/*  76 */         if (c == '.') {
/*     */           continue;
/*     */         }
/*  79 */         if (c == ' ') {
/*     */           continue;
/*     */         }
/*  82 */         if ((c >= '0') && (c <= '9')) {
/*     */           continue;
/*     */         }
/*  85 */         throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm 格式2 组帧参数:" + value);
/*     */       }
/*  87 */       String[] para = value.split(",");
/*  88 */       String[] dpara = para[0].split(" ");
/*  89 */       String[] date = dpara[0].split("-");
/*  90 */       String[] time = dpara[1].split(":");
/*     */ 
/*  92 */       Parser02.constructor(frame, para[1], loc, len - 5, fraction);
/*  93 */       frame[(loc + len - 1)] = ParseTool.StringToBcd(date[0]);
/*  94 */       frame[(loc + len - 2)] = ParseTool.StringToBcd(date[1]);
/*  95 */       frame[(loc + len - 3)] = ParseTool.StringToBcd(date[2]);
/*  96 */       frame[(loc + len - 4)] = ParseTool.StringToBcd(time[0]);
/*  97 */       frame[(loc + len - 5)] = ParseTool.StringToBcd(time[1]);
/*     */     } catch (Exception e) {
/*  99 */       throw new MessageEncodeException("错误的 YYYY-MM-DD HH:mm 格式2 组帧参数:" + value);
/*     */     }
/*     */ 
/* 102 */     return len;
/*     */   }
/*     */ }