/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Parser39
/*     */ {
/*  18 */   private static final Log log = LogFactory.getLog(Parser39.class);
/*     */ 
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  29 */     Object rt = null;
/*     */     try {
/*  31 */       boolean ok = true;
/*     */ 
/*  35 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  36 */       if (ok) {
/*  37 */         StringBuffer sb = new StringBuffer();
/*  38 */         int num = ((data[1] & 0xFF) << 8) + (data[0] & 0xFF);
/*  39 */         int iloc = loc + 2;
/*  40 */         rt = new ArrayList();
/*  41 */         for (int i = 0; i < num; ++i);
/*  92 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  95 */       e.printStackTrace();
/*     */     }
/*  97 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/* 110 */     int slen = -1;
/*     */     try {
/* 112 */       String[] para = value.split(",");
/* 113 */       if ((para != null) && (para.length > 0)) {
/* 114 */         int iloc = loc;
/*     */ 
/* 116 */         ParseTool.RtuaToBytesC(frame, para[0], iloc, 4);
/* 117 */         iloc += 4;
/*     */ 
/* 119 */         if (!(para[1].equals("null")))
/* 120 */           frame[iloc] = (byte)Integer.parseInt(para[1]);
/*     */         else {
/* 122 */           frame[iloc] = -1;
/*     */         }
/* 124 */         ++iloc;
/*     */ 
/* 126 */         if (!(para[2].equals("null"))) {
/* 127 */           if (fraction > 0)
/* 128 */             Parser37.constructor(frame, para[2], iloc, 8, 1);
/*     */           else
/* 130 */             Parser37.constructor(frame, para[2], iloc, 8, frame[(iloc - 1)] & 0xFF);
/*     */         }
/*     */         else {
/* 133 */           Arrays.fill(frame, iloc, iloc + 8, -1);
/*     */         }
/* 135 */         iloc += 8;
/*     */ 
/* 137 */         if (!(para[3].equals("null")))
/* 138 */           frame[iloc] = (byte)Integer.parseInt(para[3]);
/*     */         else {
/* 140 */           frame[iloc] = -1;
/*     */         }
/* 142 */         ++iloc;
/*     */ 
/* 144 */         if (!(para[4].equals("null")))
/* 145 */           frame[iloc] = para[4].getBytes()[0];
/*     */         else {
/* 147 */           frame[iloc] = -1;
/*     */         }
/* 149 */         ++iloc;
/*     */ 
/* 151 */         if (!(para[5].equals("null")))
/* 152 */           Parser43.constructor(frame, para[5], iloc, 10, 0);
/*     */         else {
/* 154 */           Arrays.fill(frame, iloc, iloc + 10, -1);
/*     */         }
/* 156 */         iloc += 10;
/*     */ 
/* 158 */         if (!(para[6].equals("null")))
/* 159 */           Parser43.constructor(frame, para[6], iloc, 20, 0);
/*     */         else {
/* 161 */           Arrays.fill(frame, iloc, iloc + 20, -1);
/*     */         }
/* 163 */         iloc += 20;
/*     */ 
/* 165 */         if (!(para[7].equals("null")))
/* 166 */           Parser43.constructor(frame, para[7], iloc, 12, 0);
/*     */         else {
/* 168 */           Arrays.fill(frame, iloc, iloc + 12, -1);
/*     */         }
/* 170 */         iloc += 12;
/*     */ 
/* 172 */         if (!(para[8].equals("null")))
/* 173 */           Parser43.constructor(frame, para[8], iloc, 14, 0);
/*     */         else {
/* 175 */           Arrays.fill(frame, iloc, iloc + 14, -1);
/*     */         }
/*     */ 
/* 178 */         slen = 71;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 182 */       log.warn("错误的 终端参数 组帧参数:" + value);
/*     */     }
/* 184 */     return slen;
/*     */   }
/*     */ }