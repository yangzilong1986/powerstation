/*     */ package com.hzjbbis.fas.protocol.zj.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class Parser26
/*     */ {
/*     */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*     */   {
/*  22 */     Object rt = null;
/*     */     try {
/*  24 */       boolean ok = true;
/*     */ 
/*  28 */       ok = ParseTool.isValidBCD(data, loc, len);
/*  29 */       if (ok) {
/*  30 */         StringBuffer sb = new StringBuffer();
/*  31 */         sb.append(ParseTool.ByteToHex(data[loc]));
/*  32 */         sb.append(",");
/*  33 */         sb.append(String.valueOf(data[(loc + 2)] & 0xFF));
/*  34 */         sb.append(",");
/*  35 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/*  36 */         sb.append(",");
/*  37 */         sb.append(String.valueOf(data[(loc + 4)] & 0xFF));
/*  38 */         sb.append(",");
/*  39 */         sb.append(ParseTool.ByteToHex(data[(loc + 3)]));
/*  40 */         sb.append(",");
/*  41 */         sb.append(String.valueOf(data[(loc + 6)] & 0xFF));
/*  42 */         sb.append(",");
/*  43 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/*  44 */         sb.append(",");
/*  45 */         sb.append(String.valueOf(data[(loc + 8)] & 0xFF));
/*  46 */         sb.append(",");
/*  47 */         sb.append(ParseTool.ByteToHex(data[(loc + 7)]));
/*  48 */         sb.append(",");
/*  49 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 9)])));
/*  50 */         sb.append(",");
/*  51 */         sb.append(String.valueOf(ParseTool.BCDToDecimal(data[(loc + 10)])));
/*  52 */         sb.append(",");
/*  53 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + 11, 2)));
/*  54 */         sb.append(",");
/*  55 */         sb.append(String.valueOf(ParseTool.nBcdToDecimal(data, loc + 13, 2)));
/*  56 */         sb.append(",");
/*  57 */         int din = ParseTool.BCDToDecimal(data[(loc + 15)]);
/*  58 */         sb.append(String.valueOf(din));
/*  59 */         if (din <= 32) {
/*  60 */           int iloc = loc + 16;
/*  61 */           for (int i = 0; i < din; ++i) {
/*  62 */             sb.append(",");
/*  63 */             sb.append(ParseTool.BytesToHexC(data, iloc, 2));
/*  64 */             iloc += 2;
/*     */           }
/*     */         }
/*  67 */         rt = sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/*  70 */       e.printStackTrace();
/*     */     }
/*  72 */     return rt;
/*     */   }
/*     */ 
/*     */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*     */   {
/*  85 */     int iloc = loc;
/*  86 */     int slen = -1;
/*     */     try {
/*  88 */       String[] para = value.split(",");
/*  89 */       frame[loc] = ParseTool.IntToBcd(Integer.parseInt(para[0]));
/*     */ 
/*  91 */       frame[(loc + 1)] = ParseTool.StringToBcd(para[2]);
/*  92 */       frame[(loc + 2)] = (byte)(Integer.parseInt(para[1]) & 0xFF);
/*     */ 
/*  94 */       frame[(loc + 3)] = ParseTool.StringToBcd(para[4]);
/*  95 */       frame[(loc + 4)] = (byte)(Integer.parseInt(para[3]) & 0xFF);
/*     */ 
/*  97 */       frame[(loc + 5)] = ParseTool.StringToBcd(para[6]);
/*  98 */       frame[(loc + 6)] = (byte)(Integer.parseInt(para[5]) & 0xFF);
/*     */ 
/* 100 */       frame[(loc + 7)] = ParseTool.StringToBcd(para[8]);
/* 101 */       frame[(loc + 8)] = (byte)(Integer.parseInt(para[7]) & 0xFF);
/*     */ 
/* 103 */       frame[(loc + 9)] = ParseTool.IntToBcd(Integer.parseInt(para[9]));
/*     */ 
/* 105 */       frame[(loc + 10)] = ParseTool.IntToBcd(Integer.parseInt(para[10]));
/*     */ 
/* 107 */       int nums = Integer.parseInt(para[11]);
/* 108 */       ParseTool.IntToBcd(frame, nums, loc + 11, 2);
/*     */ 
/* 110 */       nums = Integer.parseInt(para[12]);
/* 111 */       ParseTool.IntToBcd(frame, nums, loc + 13, 2);
/*     */ 
/* 113 */       nums = Integer.parseInt(para[13]);
/* 114 */       frame[(loc + 15)] = ParseTool.IntToBcd(nums);
/*     */ 
/* 116 */       if (nums != para.length - 14)
/*     */       {
/* 118 */         System.out.println("task para is error");
/*     */       }
/* 120 */       iloc = loc + 16;
/* 121 */       for (int i = 14; i < para.length; ++i) {
/* 122 */         ParseTool.HexsToBytes(frame, iloc, para[i]);
/* 123 */         iloc += 2;
/*     */       }
/* 125 */       slen = iloc - loc;
/*     */     } catch (Exception e) {
/* 127 */       throw new MessageEncodeException("错误的 普通任务设置 组帧参数:" + value);
/*     */     }
/*     */ 
/* 130 */     return slen;
/*     */   }
/*     */ }