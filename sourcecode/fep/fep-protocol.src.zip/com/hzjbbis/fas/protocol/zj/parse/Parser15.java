/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser15
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok)
/* 28 */         rt = ParseTool.toPhoneCode(data, loc, len, 170);
/*    */     }
/*    */     catch (Exception e) {
/* 31 */       e.printStackTrace();
/*    */     }
/* 33 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 48 */       for (int i = 0; i < value.length(); ++i) {
/* 49 */         char c = value.charAt(i);
/* 50 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 53 */         throw new MessageEncodeException("错误的 短信中心号码 组帧参数:" + value);
/*    */       }
/* 55 */       ParseTool.StringToBcds(frame, loc, value);
/* 56 */       int flen = (value.length() >>> 1) + (value.length() & 0x1);
/* 57 */       for (int i = loc + flen; i < loc + len; ++i)
/* 58 */         frame[i] = -86;
/*    */     }
/*    */     catch (Exception e) {
/* 61 */       throw new MessageEncodeException("错误的 短信中心号码 组帧参数:" + value);
/*    */     }
/* 63 */     return len;
/*    */   }
/*    */ }