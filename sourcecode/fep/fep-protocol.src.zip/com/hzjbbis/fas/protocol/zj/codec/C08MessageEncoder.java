/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.model.FaalWriteParamsRequest;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C08MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  30 */   private static Log log = LogFactory.getLog(C08MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj) {
/*  33 */     List rt = null;
/*     */     try
/*     */     {
/*  36 */       if (obj instanceof FaalWriteParamsRequest) {
/*  37 */         FaalWriteParamsRequest para = (FaalWriteParamsRequest)obj;
/*     */ 
/*  39 */         int point = Integer.parseInt(para.getTn());
/*  40 */         List paras = para.getParams();
/*     */ 
/*  42 */         if ((paras == null) || (paras.size() == 0)) {
/*  43 */           throw new MessageEncodeException("空配置，请指定设置参数");
/*     */         }
/*  45 */         List nparas = paras;
/*  46 */         int[] itemlen = new int[nparas.size()];
/*  47 */         int[] keysinpara = new int[nparas.size()];
/*  48 */         String[] valsinpara = new String[nparas.size()];
/*     */ 
/*  50 */         byte[] rowdata = new byte[2048];
/*  51 */         byte[] rowdataHL = new byte[2048];
/*  52 */         byte[] rowdataHLi = new byte[2048];
/*     */ 
/*  54 */         int loc = 0;
/*     */ 
/*  56 */         rowdata[0] = (byte)point;
/*  57 */         rowdata[1] = 17;
/*     */ 
/*  59 */         rowdataHL[0] = (byte)point;
/*  60 */         rowdataHL[1] = 17;
/*     */ 
/*  62 */         rowdataHLi[0] = (byte)point;
/*  63 */         rowdataHLi[1] = 17;
/*     */ 
/*  65 */         loc = 5;
/*  66 */         int index = 0;
/*  67 */         for (int iter = 0; iter < nparas.size(); ++iter) {
/*  68 */           FaalRequestParam fp = (FaalRequestParam)nparas.get(iter);
/*  69 */           ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(fp.getName());
/*  70 */           if (pdc != null)
/*     */           {
/*     */             int zi;
/*     */             int si;
/*     */             int k;
/*  71 */             rowdata[loc] = (byte)(pdc.getDataKey() & 0xFF);
/*  72 */             rowdata[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/*  74 */             rowdataHL[loc] = (byte)(pdc.getDataKey() & 0xFF);
/*  75 */             rowdataHL[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/*  77 */             rowdataHLi[loc] = (byte)(pdc.getDataKey() & 0xFF);
/*  78 */             rowdataHLi[(loc + 1)] = (byte)((pdc.getDataKey() & 0xFF00) >>> 8);
/*     */ 
/*  80 */             loc += 2;
/*  81 */             int dlen = DataItemCoder.coder(rowdata, loc, fp, pdc);
/*  82 */             if (dlen <= 0)
/*     */             {
/*  84 */               throw new MessageEncodeException(fp.getName(), "错误的参数:" + fp.getName() + "---" + fp.getValue());
/*     */             }
/*     */ 
/*  87 */             if ((pdc.getDataKey() & 0xFFFF) == 32789) {
/*  88 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/*  89 */               zi = 16;
/*  90 */               si = loc + 15;
/*  91 */               for (k = 0; (k < 16) && 
/*  92 */                 ((rowdata[si] & 0xFF) == 0); ++k)
/*     */               {
/*  93 */                 rowdataHL[(loc + k)] = 0;
/*  94 */                 rowdataHLi[si] = -86;
/*  95 */                 --si;
/*  96 */                 --zi;
/*     */               }
/*     */ 
/* 101 */               if (zi > 0)
/* 102 */                 System.arraycopy(rowdata, loc, rowdataHL, loc + 16 - zi, zi);
/*     */             }
/* 104 */             else if ((pdc.getDataKey() & 0xFFFF) == 35074) {
/* 105 */               System.arraycopy(rowdata, loc, rowdataHL, loc, dlen);
/* 106 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/* 107 */               zi = 6;
/* 108 */               si = loc + 5;
/* 109 */               for (k = 0; (k < 6) && 
/* 110 */                 ((rowdata[si] & 0xFF) == 170); ++k)
/*     */               {
/* 111 */                 rowdataHLi[si] = 0;
/* 112 */                 --si;
/* 113 */                 --zi;
/*     */               }
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 119 */               System.arraycopy(rowdata, loc, rowdataHL, loc, dlen);
/* 120 */               System.arraycopy(rowdata, loc, rowdataHLi, loc, dlen);
/*     */             }
/*     */ 
/* 123 */             itemlen[index] = dlen;
/* 124 */             keysinpara[index] = pdc.getDataKey();
/* 125 */             valsinpara[index] = fp.getValue();
/* 126 */             ++index;
/* 127 */             loc += dlen;
/*     */           } else {
/* 129 */             throw new MessageEncodeException(fp.getName(), "配置无法获取，数据项：" + fp.getName());
/*     */           }
/*     */         }
/*     */ 
/* 133 */         List rtuid = para.getRtuIds();
/* 134 */         List cmdIds = para.getCmdIds();
/* 135 */         rt = new ArrayList();
/* 136 */         for (int iter = 0; iter < rtuid.size(); ++iter) {
/* 137 */           String id = (String)rtuid.get(iter);
/* 138 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/* 139 */           byte[] fdata = null;
/*     */ 
/* 141 */           if (rtu == null) {
/* 142 */             log.info("终端信息未在缓存列表：" + id);
/*     */           }
/*     */           else
/*     */           {
/* 146 */             if ((rtu.getManufacturer() != null) && (((rtu.getManufacturer().equalsIgnoreCase("0087")) || (rtu.getManufacturer().equalsIgnoreCase("0112")) || (rtu.getManufacturer().equalsIgnoreCase("0094")) || (rtu.getManufacturer().equalsIgnoreCase("0117")))))
/* 147 */               fdata = rowdataHL;
/* 148 */             else if ((rtu.getManufacturer() != null) && (((rtu.getManufacturer().equalsIgnoreCase("0061")) || (rtu.getManufacturer().equalsIgnoreCase("0098")))))
/* 149 */               fdata = rowdataHLi;
/*     */             else {
/* 151 */               fdata = rowdata;
/*     */             }
/*     */ 
/* 154 */             int datamax = DataItemCoder.getDataMax(rtu);
/*     */ 
/* 157 */             int msgcount = 0;
/*     */ 
/* 180 */             int dnum = 0;
/* 181 */             int pos = 0;
/* 182 */             int curlen = 0;
/*     */ 
/* 185 */             for (int j = 0; j < itemlen.length; ++j)
/*     */             {
/*     */               MessageZj msg;
/* 186 */               if (curlen + 5 + 2 + itemlen[j] > datamax) {
/* 187 */                 msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 188 */                 if (msg != null)
/*     */                 {
/* 190 */                   ++msgcount;
/* 191 */                   rt.add(msg);
/*     */                 }
/* 193 */                 pos += curlen;
/* 194 */                 dnum = 1;
/* 195 */                 curlen = 2 + itemlen[j];
/*     */               }
/*     */               else
/*     */               {
/* 201 */                 ++dnum;
/* 202 */                 curlen += 2 + itemlen[j];
/*     */ 
/* 205 */                 if ((keysinpara[j] > 33024) && (keysinpara[j] <= 33278)) {
/* 206 */                   msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 207 */                   if (msg != null)
/*     */                   {
/* 209 */                     ++msgcount;
/* 210 */                     rt.add(msg);
/*     */                   }
/* 212 */                   dnum = 0;
/* 213 */                   pos += curlen;
/* 214 */                   curlen = 0;
/*     */                 }
/*     */               }
/*     */             }
/*     */ 
/* 219 */             if (dnum > 0) {
/* 220 */               MessageZj msg = createMessageZj(fdata, rtu, pos, curlen, cmdIds.get(iter));
/* 221 */               if (msg != null)
/*     */               {
/* 223 */                 ++msgcount;
/* 224 */                 rt.add(msg);
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 229 */             setMsgcount(rt, msgcount);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 235 */       throw new MessageEncodeException(e);
/*     */     }
/* 237 */     if (rt != null) {
/* 238 */       IMessage[] msgs = new IMessage[rt.size()];
/* 239 */       rt.toArray(msgs);
/* 240 */       return msgs;
/*     */     }
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   private MessageZjHead createHead(BizRtu rtu)
/*     */   {
/* 247 */     MessageZjHead head = new MessageZjHead();
/* 248 */     head.c_dir = 0;
/* 249 */     head.c_expflag = 0;
/* 250 */     head.c_func = 8;
/*     */ 
/* 254 */     head.rtua = rtu.getRtua();
/*     */ 
/* 256 */     head.iseq = 0;
/*     */ 
/* 259 */     return head;
/*     */   }
/*     */ 
/*     */   private MessageZj createMessageZj(byte[] rowdata, BizRtu rtu, int pos, int dlen, Object cmdid)
/*     */   {
/* 264 */     MessageZjHead head = createHead(rtu);
/* 265 */     head.dlen = (short)(dlen + 5);
/*     */ 
/* 267 */     byte[] frameA = new byte[head.dlen];
/* 268 */     System.arraycopy(rowdata, 0, frameA, 0, 5);
/* 269 */     System.arraycopy(rowdata, 5 + pos, frameA, 5, dlen);
/*     */ 
/* 271 */     String pwd = rtu.getHiAuthPassword();
/* 272 */     if (pwd == null) {
/* 273 */       throw new MessageEncodeException("rtu password missing");
/*     */     }
/* 275 */     ParseTool.HexsToBytesAA(frameA, 2, pwd, 3, -86);
/*     */ 
/* 277 */     MessageZj msg = new MessageZj();
/* 278 */     msg.setCmdId((Long)cmdid);
/*     */ 
/* 280 */     msg.data = ByteBuffer.wrap(frameA);
/* 281 */     msg.head = head;
/* 282 */     return msg;
/*     */   }
/*     */ 
/*     */   private void setMsgcount(List msgs, int msgcount) {
/* 286 */     for (Iterator iter = msgs.iterator(); iter.hasNext(); ) {
/* 287 */       MessageZj msg = (MessageZj)iter.next();
/* 288 */       if (msg.getMsgCount() == 0)
/* 289 */         msg.setMsgCount(msgcount);
/*     */     }
/*     */   }
/*     */ }