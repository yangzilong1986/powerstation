/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser48
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 18 */     Object rt = null;
/*    */     try {
/* 20 */       boolean ok = true;
/* 21 */       int pos = loc;
/* 22 */       if (ok) {
/* 23 */         StringBuffer sb = new StringBuffer();
/* 24 */         for (int i = 0; i < 3; ++i) {
/* 25 */           Object v = Parser01.parsevalue(data, pos, 2, fraction);
/* 26 */           if (v != null)
/* 27 */             sb.append(v.toString());
/*    */           else {
/* 29 */             sb.append("null");
/*    */           }
/* 31 */           sb.append(",");
/* 32 */           pos += 2;
/*    */         }
/* 34 */         rt = sb.toString().substring(0, sb.length() - 1);
/*    */       }
/*    */     } catch (Exception e) {
/* 37 */       throw new MessageDecodeException(e);
/*    */     }
/* 39 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 53 */       NumberFormat nf = NumberFormat.getInstance();
/* 54 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 56 */       String[] vs = value.split(",");
/*    */ 
/* 58 */       int pos = loc;
/* 59 */       for (int i = 0; i < 3; ++i) {
/* 60 */         Parser01.constructor(frame, vs[i], pos, 2, fraction);
/* 61 */         pos += 2;
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       throw new MessageEncodeException("invalid string:" + value);
/*    */     }
/* 67 */     return len;
/*    */   }
/*    */ }