/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class Parser42
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 20 */     Object rt = null;
/*    */     try {
/* 22 */       boolean ok = true;
/*    */ 
/* 26 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 27 */       if (ok) {
/* 28 */         StringBuffer sb = new StringBuffer();
/* 29 */         sb.append(ParseTool.ByteToHex(data[(loc + 2)]));
/* 30 */         sb.append(",");
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 1)]));
/* 32 */         sb.append(":");
/* 33 */         sb.append(ParseTool.ByteToHex(data[loc]));
/* 34 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 37 */       e.printStackTrace();
/*    */     }
/* 39 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 54 */       for (int i = 0; i < value.length(); ++i) {
/* 55 */         char c = value.charAt(i);
/* 56 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 59 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 62 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 65 */         throw new MessageEncodeException("错误的 NN hh:mm 组帧参数:" + value);
/*    */       }
/*    */ 
/* 68 */       String[] para = value.split(",");
/* 69 */       String[] time = para[1].split(":");
/*    */ 
/* 71 */       frame[(loc + 2)] = ParseTool.StringToBcd(para[0]);
/* 72 */       frame[(loc + 1)] = ParseTool.StringToBcd(time[0]);
/* 73 */       frame[loc] = ParseTool.StringToBcd(time[1]);
/*    */     } catch (Exception e) {
/* 75 */       throw new MessageEncodeException("错误的 NN hh:mm 组帧参数:" + value);
/*    */     }
/*    */ 
/* 78 */     return len;
/*    */   }
/*    */ }