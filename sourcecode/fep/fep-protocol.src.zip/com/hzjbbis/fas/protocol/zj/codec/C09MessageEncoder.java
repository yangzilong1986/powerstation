/*    */ package com.hzjbbis.fas.protocol.zj.codec;
/*    */ 
/*    */ import com.hzjbbis.fas.model.FaalReadAlertRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequestParam;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.zj.MessageZj;
/*    */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*    */ import com.hzjbbis.fk.model.BizRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Calendar;
/*    */ import java.util.List;
/*    */ 
/*    */ public class C09MessageEncoder extends AbstractMessageEncoder
/*    */ {
/*    */   public IMessage[] encode(Object obj)
/*    */   {
/* 21 */     List rt = null;
/*    */     try {
/* 23 */       if (obj instanceof FaalReadAlertRequest)
/*    */       {
/*    */         int point;
/* 24 */         FaalReadAlertRequest para = (FaalReadAlertRequest)obj;
/*    */ 
/* 26 */         Calendar stime = para.getStartTime();
/*    */ 
/* 28 */         if (para.getTn().equals("FF"))
/* 29 */           point = Integer.parseInt(para.getTn(), 16);
/*    */         else
/* 31 */           point = Integer.parseInt(para.getTn());
/* 32 */         int num = para.getCount();
/* 33 */         int alr = ParseTool.HexToDecimal(((FaalRequestParam)para.getParams().get(0)).getName());
/*    */ 
/* 36 */         int len = 9;
/*    */ 
/* 38 */         List rtuid = para.getRtuIds();
/* 39 */         List cmdIds = para.getCmdIds();
/* 40 */         rt = new ArrayList();
/* 41 */         for (int iter = 0; iter < rtuid.size(); ++iter) {
/* 42 */           String id = (String)rtuid.get(iter);
/* 43 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/*    */ 
/* 48 */           MessageZjHead head = new MessageZjHead();
/* 49 */           head.c_dir = 0;
/* 50 */           head.c_expflag = 0;
/* 51 */           head.c_func = 9;
/*    */ 
/* 55 */           head.rtua = rtu.getRtua();
/*    */ 
/* 57 */           head.iseq = 0;
/*    */ 
/* 60 */           head.dlen = (short)len;
/*    */ 
/* 64 */           byte[] frame = new byte[len];
/* 65 */           frame[0] = (byte)point;
/* 66 */           frame[1] = (byte)(alr & 0xFF);
/* 67 */           frame[2] = (byte)((alr & 0xFF00) >>> 8);
/* 68 */           frame[3] = ParseTool.IntToBcd(stime.get(1) % 100);
/* 69 */           frame[4] = ParseTool.IntToBcd(stime.get(2) + 1);
/* 70 */           frame[5] = ParseTool.IntToBcd(stime.get(5));
/* 71 */           frame[6] = ParseTool.IntToBcd(stime.get(11));
/* 72 */           frame[7] = ParseTool.IntToBcd(stime.get(12));
/* 73 */           frame[8] = (byte)num;
/*    */ 
/* 75 */           MessageZj msg = new MessageZj();
/* 76 */           msg.data = ByteBuffer.wrap(frame);
/*    */ 
/* 82 */           msg.setCmdId((Long)cmdIds.get(iter));
/*    */ 
/* 84 */           msg.head = head;
/* 85 */           msg.setMsgCount(1);
/*    */ 
/* 87 */           rt.add(msg);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 91 */       e.printStackTrace();
/*    */     }
/* 93 */     if (rt != null) {
/* 94 */       IMessage[] msgs = new IMessage[rt.size()];
/* 95 */       rt.toArray(msgs);
/* 96 */       return msgs;
/*    */     }
/* 98 */     return null;
/*    */   }
/*    */ }