/*    */ package com.hzjbbis.fas.protocol.zj.codec;
/*    */ 
/*    */ import com.hzjbbis.fas.model.FaalReadProgramLogRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequest;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.zj.MessageZj;
/*    */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*    */ import com.hzjbbis.fk.model.BizRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Calendar;
/*    */ import java.util.List;
/*    */ 
/*    */ public class C04MessageEncoder extends AbstractMessageEncoder
/*    */ {
/*    */   public IMessage[] encode(Object obj)
/*    */   {
/* 22 */     List rt = null;
/*    */     try
/*    */     {
/* 25 */       if (obj instanceof FaalRequest) {
/* 26 */         FaalReadProgramLogRequest para = (FaalReadProgramLogRequest)obj;
/*    */ 
/* 29 */         Calendar stime = para.getStartTime();
/* 30 */         if (stime == null) {
/* 31 */           stime = Calendar.getInstance();
/*    */         }
/* 33 */         int point = Integer.parseInt(para.getTn());
/* 34 */         int num = para.getCount();
/*    */ 
/* 37 */         int len = 7;
/*    */ 
/* 39 */         List rtuid = para.getRtuIds();
/* 40 */         rt = new ArrayList();
/* 41 */         List cmdIds = para.getCmdIds();
/* 42 */         for (int iter = 0; iter < rtuid.size(); ++iter) {
/* 43 */           String id = (String)rtuid.get(iter);
/*    */ 
/* 45 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(id);
/*    */ 
/* 50 */           MessageZjHead head = new MessageZjHead();
/* 51 */           head.c_dir = 0;
/* 52 */           head.c_expflag = 0;
/* 53 */           head.c_func = 4;
/*    */ 
/* 57 */           head.rtua = rtu.getRtua();
/*    */ 
/* 59 */           head.iseq = 0;
/*    */ 
/* 62 */           head.dlen = (short)len;
/*    */ 
/* 66 */           byte[] frame = new byte[len];
/* 67 */           frame[0] = (byte)point;
/* 68 */           frame[1] = ParseTool.IntToBcd(stime.get(1) % 100);
/* 69 */           frame[2] = ParseTool.IntToBcd(stime.get(2) + 1);
/* 70 */           frame[3] = ParseTool.IntToBcd(stime.get(5));
/* 71 */           frame[4] = ParseTool.IntToBcd(stime.get(11));
/* 72 */           frame[5] = ParseTool.IntToBcd(stime.get(12));
/* 73 */           frame[6] = (byte)num;
/*    */ 
/* 75 */           MessageZj msg = new MessageZj();
/* 76 */           msg.data = ByteBuffer.wrap(frame);
/* 77 */           HostCommand hcmd = new HostCommand();
/* 78 */           hcmd.setId((Long)cmdIds.get(iter));
/* 79 */           hcmd.setMessageCount(1);
/*    */ 
/* 81 */           msg.setCmdId(hcmd.getId());
/* 82 */           msg.head = head;
/*    */ 
/* 84 */           rt.add(msg);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 88 */       e.printStackTrace();
/*    */     }
/* 90 */     if (rt != null) {
/* 91 */       IMessage[] msgs = new IMessage[rt.size()];
/* 92 */       rt.toArray(msgs);
/* 93 */       return msgs;
/*    */     }
/* 95 */     return null;
/*    */   }
/*    */ }