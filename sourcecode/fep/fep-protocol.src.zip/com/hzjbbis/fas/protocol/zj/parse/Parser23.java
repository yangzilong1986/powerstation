/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser23
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 22 */     Object rt = null;
/*    */     try {
/* 24 */       boolean ok = true;
/*    */ 
/* 28 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 29 */       if (ok) {
/* 30 */         StringBuffer sb = new StringBuffer();
/* 31 */         sb.append(ParseTool.ByteToHex(data[(loc + 6)]));
/* 32 */         sb.append(":");
/* 33 */         sb.append(ParseTool.ByteToHex(data[(loc + 5)]));
/* 34 */         sb.append(",");
/* 35 */         sb.append(ParseTool.ByteToHex(data[(loc + 4)]));
/* 36 */         sb.append(",");
/* 37 */         int val = ParseTool.nBcdToDecimal(data, loc, 4);
/* 38 */         sb.append(String.valueOf(val / ParseTool.fraction[2]));
/* 39 */         rt = sb.toString();
/*    */       }
/*    */     } catch (Exception e) {
/* 42 */       e.printStackTrace();
/*    */     }
/* 44 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 59 */       for (int i = 0; i < value.length(); ++i) {
/* 60 */         char c = value.charAt(i);
/* 61 */         if (c == ',') {
/*    */           continue;
/*    */         }
/* 64 */         if (c == ':') {
/*    */           continue;
/*    */         }
/* 67 */         if (c == '.') {
/*    */           continue;
/*    */         }
/* 70 */         if ((c >= '0') && (c <= '9')) {
/*    */           continue;
/*    */         }
/* 73 */         throw new MessageEncodeException("错误的 HH:mm NN XXXXXX.XX 组帧参数:" + value);
/*    */       }
/*    */ 
/* 76 */       String[] para = value.split(",");
/* 77 */       String[] time = para[0].split(":");
/*    */ 
/* 79 */       frame[(loc + 6)] = ParseTool.StringToBcd(time[0]);
/* 80 */       frame[(loc + 5)] = ParseTool.StringToBcd(time[1]);
/* 81 */       frame[(loc + 4)] = ParseTool.StringToBcd(para[1]);
/*    */ 
/* 83 */       NumberFormat nf = NumberFormat.getInstance();
/* 84 */       nf.setMaximumFractionDigits(4);
/* 85 */       double val = nf.parse(para[2]).doubleValue();
/* 86 */       val *= ParseTool.fraction[2];
/* 87 */       ParseTool.IntToBcd(frame, (int)val, loc, 4);
/*    */     } catch (Exception e) {
/* 89 */       throw new MessageEncodeException("错误的 HH:mm NN XXXXXX.XX 组帧参数:" + value);
/*    */     }
/*    */ 
/* 92 */     return len;
/*    */   }
/*    */ }