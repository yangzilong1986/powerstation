/*    */ package com.hzjbbis.fas.protocol.zj.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class Parser02
/*    */ {
/*    */   public static Object parsevalue(byte[] data, int loc, int len, int fraction)
/*    */   {
/* 23 */     Object rt = null;
/*    */     try {
/* 25 */       boolean ok = true;
/*    */ 
/* 29 */       ok = ParseTool.isValidBCD(data, loc, len);
/* 30 */       if (ok) {
/* 31 */         boolean bn = (data[(loc + len - 1)] & 0x10) > 0;
/* 32 */         int val = ParseTool.nBcdToDecimalS(data, loc, len);
/* 33 */         if (val >= 0) {
/* 34 */           if (bn) {
/* 35 */             val = -val;
/*    */           }
/* 37 */           if (fraction > 0) {
/* 38 */             NumberFormat snf = NumberFormat.getInstance();
/* 39 */             snf.setMinimumFractionDigits(fraction);
/* 40 */             snf.setMinimumIntegerDigits(1);
/* 41 */             snf.setGroupingUsed(false);
/* 42 */             rt = snf.format(val / ParseTool.fraction[fraction]);
/*    */           } else {
/* 44 */             rt = new Integer(val);
/*    */           }
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 49 */       e.printStackTrace();
/*    */     }
/* 51 */     return rt;
/*    */   }
/*    */ 
/*    */   public static int constructor(byte[] frame, String value, int loc, int len, int fraction)
/*    */   {
/*    */     try
/*    */     {
/* 65 */       NumberFormat nf = NumberFormat.getInstance();
/* 66 */       nf.setMaximumFractionDigits(4);
/*    */ 
/* 68 */       double val = nf.parse(value).doubleValue();
/* 69 */       if (fraction > 0) {
/* 70 */         val *= ParseTool.fraction[fraction];
/*    */       }
/* 72 */       boolean bn = val < 0.0D;
/* 73 */       if (bn) {
/* 74 */         val = -val;
/*    */       }
/* 76 */       ParseTool.IntToBcd(frame, (int)val, loc, len);
/* 77 */       if (bn)
/* 78 */         frame[(loc + len - 1)] = (byte)(frame[(loc + len - 1)] & 0xF | 0x10);
/*    */     }
/*    */     catch (Exception e) {
/* 81 */       throw new MessageEncodeException("错误的BCD码组帧参数:" + value);
/*    */     }
/* 83 */     return len;
/*    */   }
/*    */ }