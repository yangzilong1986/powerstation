/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.model.HostCommandResult;
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.meter.BbMeterFrame;
/*     */ import com.hzjbbis.fas.protocol.meter.IMeterParser;
/*     */ import com.hzjbbis.fas.protocol.meter.MeterParserFactory;
/*     */ import com.hzjbbis.fas.protocol.meter.ZjMeterFrame;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C00MessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  30 */     HostCommand hc = new HostCommand();
/*  31 */     List value = new ArrayList();
/*     */     try {
/*  33 */       if (ParseTool.getOrientation(message) == 1) {
/*  34 */         int rtype = ParseTool.getErrCode(message);
/*  35 */         if (0 == rtype) {
/*  36 */           byte[] data = ParseTool.getData(message);
/*  37 */           if ((data != null) && (data.length > 1)) {
/*  38 */             int rtua = ((MessageZj)message).head.rtua;
/*  39 */             BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rtua);
/*  40 */             if (rtu == null) {
/*  41 */               throw new MessageDecodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtua));
/*     */             }
/*     */ 
/*  44 */             String pm = getMeterProtocol(data, 1, data.length - 1);
/*  45 */             IMeterParser mparser = MeterParserFactory.getMeterParser(pm);
/*  46 */             if (mparser == null) {
/*  47 */               throw new MessageDecodeException("不支持的表规约：" + pm);
/*     */             }
/*  49 */             Object[] dis = mparser.parser(data, 1, data.length - 1);
/*  50 */             if ((dis != null) && (dis.length > 0)) {
/*  51 */               for (int i = 0; i < dis.length; ++i) {
/*  52 */                 DataItem di = (DataItem)dis[i];
/*  53 */                 String key = (String)di.getProperty("datakey");
/*  54 */                 if (key == null) continue; if (key.length() < 4) {
/*     */                   continue;
/*     */                 }
/*  57 */                 boolean called = true;
/*  58 */                 if (called) {
/*  59 */                   HostCommandResult hcr = new HostCommandResult();
/*  60 */                   hcr.setCode(key);
/*  61 */                   if (di.getProperty("value") == null)
/*  62 */                     hcr.setValue(null);
/*     */                   else {
/*  64 */                     hcr.setValue(di.getProperty("value").toString());
/*     */                   }
/*  66 */                   hcr.setCommandId(hc.getId());
/*  67 */                   value.add(hcr);
/*     */                 }
/*     */               }
/*     */             }
/*  71 */             hc.setStatus("1");
/*  72 */             hc.setResults(value);
/*     */           }
/*     */           else {
/*  75 */             hc.setStatus("16");
/*  76 */             hc.setResults(null);
/*     */           }
/*     */         }
/*     */         else {
/*  80 */           hc.setStatus("2");
/*  81 */           hc.setResults(null);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  87 */       throw new MessageDecodeException(e);
/*     */     }
/*  89 */     return hc;
/*     */   }
/*     */ 
/*     */   private String getMeterProtocol(byte[] data, int loc, int len) {
/*  93 */     String Protocol = "";
/*  94 */     BbMeterFrame bbFrame = new BbMeterFrame();
/*  95 */     bbFrame.parse(data, loc, len);
/*  96 */     if (bbFrame.getDatalen() > 0) {
/*  97 */       Protocol = "BBMeter";
/*     */     } else {
/*  99 */       ZjMeterFrame zjFrame = new ZjMeterFrame();
/* 100 */       zjFrame.parse(data, loc, len);
/* 101 */       if (zjFrame.getDatalen() > 0) {
/* 102 */         Protocol = "ZJMeter";
/*     */       }
/*     */     }
/* 105 */     return Protocol;
/*     */   }
/*     */ }