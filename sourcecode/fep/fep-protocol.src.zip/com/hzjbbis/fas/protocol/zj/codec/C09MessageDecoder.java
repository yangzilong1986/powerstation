/*     */ package com.hzjbbis.fas.protocol.zj.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.RtuAlert;
/*     */ import com.hzjbbis.fas.model.RtuAlertArg;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuAlertCode;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C09MessageDecoder extends AbstractMessageDecoder
/*     */ {
/*  28 */   private static final Log log = LogFactory.getLog(C09MessageDecoder.class);
/*     */ 
/*     */   public Object decode(IMessage message) {
/*  31 */     List rt = null;
/*     */     try {
/*  33 */       if (ParseTool.getOrientation(message) == 1) {
/*  34 */         int rtype = ParseTool.getErrCode(message);
/*  35 */         if (rtype == 0)
/*     */         {
/*  37 */           byte[] data = ParseTool.getData(message);
/*     */ 
/*  39 */           if (data != null) {
/*  40 */             int num = data[0] & 0xFF;
/*  41 */             int loc = 1;
/*     */ 
/*  43 */             int rtu = ((MessageZj)message).head.rtua;
/*  44 */             BizRtu ortu = RtuManage.getInstance().getBizRtuInCache(rtu);
/*  45 */             if (ortu == null)
/*     */             {
/*  47 */               throw new MessageDecodeException("无法获取终端信息--" + ParseTool.IntToHex4(rtu));
/*     */             }
/*  49 */             NumberFormat nf = NumberFormat.getInstance();
/*  50 */             nf.setMaximumFractionDigits(4);
/*  51 */             rt = new ArrayList();
/*  52 */             Calendar date = Calendar.getInstance();
/*     */ 
/*  54 */             date.setTimeInMillis(((MessageZj)message).getIoTime());
/*     */             do { if (loc >= data.length) break label1236;
/*  56 */               if (8 <= data.length - loc) {
/*  57 */                 int point = data[loc] & 0xFF;
/*  58 */                 Calendar stime = getTime(data, loc + 1);
/*  59 */                 int alr = (data[(loc + 6)] & 0xFF) + ((data[(loc + 7)] & 0xFF) << 8);
/*  60 */                 loc += 8;
/*  61 */                 List rac = getRtuAlertCode(alr);
/*  62 */                 if (rac != null) {
/*  63 */                   RtuAlert ra = new RtuAlert();
/*  64 */                   ra.setRtuId(ortu.getRtuId());
/*  65 */                   ra.setCorpNo(ortu.getDeptCode());
/*  66 */                   String tn = String.valueOf(point);
/*  67 */                   ra.setTn(tn);
/*  68 */                   if (ortu.getMeasuredPoint(tn) != null) {
/*  69 */                     ra.setDataSaveID(ortu.getMeasuredPoint(tn).getDataSaveID());
/*  70 */                     ra.setCustomerNo(ortu.getMeasuredPoint(tn).getCustomerNo());
/*  71 */                     ra.setStationNo(ortu.getMeasuredPoint(tn).getCustomerNo());
/*     */                   } else {
/*  73 */                     log.warn("rtu=" + ParseTool.IntToHex4(rtu) + ",tn=" + tn + "未建档！"); }
/*  74 */                   ra.setAlertCode(alr);
/*  75 */                   ra.setAlertTime(stime.getTime());
/*     */ 
/*  77 */                   ra.setReceiveTime(new Date(((MessageZj)message).getIoTime()));
/*  78 */                   List alertdatas = new ArrayList();
/*  79 */                   String olddi = "";
/*  80 */                   Hashtable databag = new Hashtable();
/*  81 */                   for (Iterator iter = rac.iterator(); iter.hasNext(); ) {
/*  82 */                     String di = (String)iter.next();
/*  83 */                     boolean is8ffe = false;
/*  84 */                     if ((di.equals("8FFE")) || (di.equals("8ffe")))
/*     */                     {
/*  86 */                       if (olddi.length() <= 0)
/*     */                       {
/*  88 */                         throw new MessageDecodeException("告警配置错误：终端--" + ParseTool.IntToHex4(rtu) + " 告警编码--" + ParseTool.IntToHex(alr));
/*     */                       }
/*  90 */                       is8ffe = true;
/*  91 */                       di = olddi;
/*     */                     } else {
/*  93 */                       is8ffe = false;
/*  94 */                       olddi = di;
/*     */                     }
/*  96 */                     ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(di);
/*  97 */                     if (pdc != null) {
/*  98 */                       if (pdc.getLength() <= data.length - loc)
/*     */                       {
/*     */                         Iterator iterc;
/*  99 */                         List childs = pdc.getChildItems();
/* 100 */                         if ((childs != null) && (childs.size() > 0)) {
/* 101 */                           for (iterc = childs.iterator(); iterc.hasNext(); ) {
/* 102 */                             ProtocolDataItemConfig cpdc = (ProtocolDataItemConfig)iterc.next();
/* 103 */                             Object dt = null;
/*     */                             try {
/* 105 */                               dt = DataItemParser.parsevalue(data, loc, cpdc.getLength(), cpdc.getFraction(), cpdc.getParserno());
/*     */                             }
/*     */                             catch (Exception e) {
/* 108 */                               log.error("告警数据解析错误", e);
/*     */                             }
/* 110 */                             RtuAlertArg arg = null;
/* 111 */                             if (dt != null) {
/* 112 */                               if (is8ffe) {
/* 113 */                                 arg = (RtuAlertArg)databag.get(cpdc.getCode());
/* 114 */                                 arg.setCorrelValue(dt.toString());
/*     */                               } else {
/* 116 */                                 arg = new RtuAlertArg();
/* 117 */                                 arg.setCode(cpdc.getCode());
/* 118 */                                 arg.setValue(dt.toString());
/* 119 */                                 databag.put(cpdc.getCode(), arg);
/* 120 */                                 alertdatas.add(arg);
/*     */                               }
/*     */ 
/*     */                             }
/* 124 */                             else if (!(is8ffe)) {
/* 125 */                               arg = new RtuAlertArg();
/* 126 */                               arg.setCode(cpdc.getCode());
/* 127 */                               arg.setValue(null);
/* 128 */                               alertdatas.add(arg);
/* 129 */                               databag.put(cpdc.getCode(), arg);
/*     */                             }
/*     */ 
/* 132 */                             loc += cpdc.getLength();
/*     */                           }
/*     */                         } else {
/* 135 */                           Object dt = DataItemParser.parsevalue(data, loc, pdc.getLength(), pdc.getFraction(), pdc.getParserno());
/* 136 */                           RtuAlertArg arg = null;
/* 137 */                           if (dt != null) {
/* 138 */                             if (is8ffe) {
/* 139 */                               arg = (RtuAlertArg)databag.get(pdc.getCode());
/* 140 */                               arg.setCorrelValue(dt.toString());
/*     */                             } else {
/* 142 */                               arg = new RtuAlertArg();
/* 143 */                               arg.setCode(pdc.getCode());
/* 144 */                               arg.setValue(dt.toString());
/* 145 */                               alertdatas.add(arg);
/* 146 */                               databag.put(pdc.getCode(), arg);
/*     */                             }
/*     */                           }
/* 149 */                           else if (!(is8ffe)) {
/* 150 */                             arg = new RtuAlertArg();
/* 151 */                             arg.setCode(pdc.getCode());
/* 152 */                             arg.setValue(null);
/* 153 */                             alertdatas.add(arg);
/* 154 */                             databag.put(pdc.getCode(), arg);
/*     */                           }
/*     */ 
/* 157 */                           loc += pdc.getLength();
/*     */                         }
/* 159 */                         break label1107:
/*     */                       }
/* 161 */                       log.info("数据长度不对,数据项：" + pdc.getCode() + " 期望数据长度：" + pdc.getLength() + " 解析长度：" + (data.length - loc));
/* 162 */                       loc = data.length;
/* 163 */                       break;
/*     */                     }
/*     */ 
/* 167 */                     throw new MessageDecodeException("无法识别的数据项");
/*     */                   }
/*     */ 
/* 170 */                   label1107: ra.setArgs(alertdatas);
/* 171 */                   rt.add(ra);
/*     */                 } else {
/* 173 */                   throw new MessageDecodeException("无法获取告警配置 告警编码--" + ParseTool.IntToHex(alr));
/*     */                 }
/*     */               }
/*     */               else {
/* 177 */                 throw new MessageDecodeException("数据长度不对");
/*     */               }
/* 179 */               --num; }
/* 180 */             while ((num > 0) || (loc >= data.length));
/*     */ 
/* 183 */             log.info("数据长度不对,预期长度：" + loc + " 解析长度：" + data.length);
/* 184 */             label1236: loc = data.length;
/*     */           }
/*     */           else
/*     */           {
/* 190 */             throw new MessageDecodeException("数据长度不对");
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 198 */       throw new MessageDecodeException(e);
/*     */     }
/*     */ 
/* 201 */     if (rt != null) {
/* 202 */       for (int i = 0; i < rt.size(); ++i) {
/* 203 */         RtuAlert rtuAlert = (RtuAlert)rt.get(i);
/* 204 */         rtuAlertSetSbcs(rtuAlert);
/*     */       }
/*     */     }
/* 207 */     return rt; }
/*     */ 
/*     */   private void rtuAlertSetSbcs(RtuAlert rtuAlert) {
/*     */     try {
/* 211 */       StringBuffer sb = new StringBuffer();
/* 212 */       List args = rtuAlert.getArgs();
/* 213 */       if ((args != null) && (args.size() > 0)) {
/* 214 */         RtuAlertArg arg = (RtuAlertArg)args.get(0);
/* 215 */         sb.append(arg.getCode());
/* 216 */         sb.append("=");
/* 217 */         if (arg.getValue() != null) {
/* 218 */           sb.append(arg.getValue());
/*     */         }
/* 220 */         sb.append("@");
/* 221 */         if (arg.getCorrelValue() != null) {
/* 222 */           sb.append(arg.getCorrelValue());
/*     */         }
/* 224 */         for (int i = 1; i < args.size(); ++i) {
/* 225 */           arg = (RtuAlertArg)args.get(i);
/* 226 */           sb.append(";");
/* 227 */           sb.append(arg.getCode());
/* 228 */           sb.append("=");
/* 229 */           if (arg.getValue() != null) {
/* 230 */             sb.append(arg.getValue());
/*     */           }
/* 232 */           sb.append("@");
/* 233 */           if (arg.getCorrelValue() != null) {
/* 234 */             sb.append(arg.getCorrelValue());
/*     */           }
/*     */         }
/* 237 */         rtuAlert.setSbcs(sb.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private Calendar getTime(byte[] data, int offset)
/*     */   {
/* 251 */     Calendar rt = null;
/*     */     try {
/* 253 */       int month = ParseTool.BCDToDecimal(data[(1 + offset)]);
/* 254 */       int year = ParseTool.BCDToDecimal(data[offset]);
/* 255 */       if ((month > 0) && (year >= 0) && 
/* 256 */         (ParseTool.isValidMonth(data[(1 + offset)])) && (ParseTool.isValidDay(data[(2 + offset)], month, year + 2000)) && (ParseTool.isValidHHMMSS(data[(3 + offset)])) && (ParseTool.isValidHHMMSS(data[(4 + offset)])))
/*     */       {
/* 259 */         rt = Calendar.getInstance();
/* 260 */         rt.set(1, year + 2000);
/* 261 */         rt.set(2, month - 1);
/* 262 */         int num = ParseTool.BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 263 */         rt.set(5, num);
/* 264 */         num = ParseTool.BCDToDecimal((byte)(data[(3 + offset)] & 0x3F));
/* 265 */         rt.set(11, num);
/* 266 */         num = ParseTool.BCDToDecimal((byte)(data[(4 + offset)] & 0x7F));
/* 267 */         if (num >= 60) {
/* 268 */           rt.add(11, 1);
/* 269 */           num = 0;
/*     */         }
/* 271 */         rt.set(12, num);
/* 272 */         rt.set(13, 0);
/* 273 */         rt.set(14, 0);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 277 */       log.error("alert decode", e);
/*     */     }
/* 279 */     return rt;
/*     */   }
/*     */ 
/*     */   private List getRtuAlertCode(int alert)
/*     */   {
/* 288 */     List rt = null;
/*     */     try {
/* 290 */       rt = RtuManage.getInstance().getRtuAlertCode(alert).getArgs();
/*     */     } catch (Exception e) {
/* 292 */       log.error("get alert code", e);
/*     */     }
/* 294 */     return rt;
/*     */   }
/*     */ }