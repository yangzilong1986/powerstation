/*    */ package com.hzjbbis.fas.protocol.codec;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MessageCodecContext
/*    */ {
/* 13 */   private static final ThreadLocal task = new ThreadLocal();
/*    */ 
/* 15 */   private static final ThreadLocal codes = new ThreadLocal();
/*    */ 
/*    */   public static void setTaskNum(String taskNum)
/*    */   {
/* 22 */     task.set(taskNum);
/*    */   }
/*    */ 
/*    */   public static String getTaskNum()
/*    */   {
/* 30 */     return ((String)task.get());
/*    */   }
/*    */ 
/*    */   public static String pollTaskNum()
/*    */   {
/* 38 */     String taskNum = (String)task.get();
/* 39 */     if (taskNum != null) {
/* 40 */       task.set(null);
/*    */     }
/*    */ 
/* 43 */     return taskNum;
/*    */   }
/*    */ 
/*    */   public static void addAlertCode(int alertCode)
/*    */   {
/* 51 */     List alertCodes = (List)codes.get();
/* 52 */     if (alertCodes == null) {
/* 53 */       alertCodes = new ArrayList(1);
/* 54 */       codes.set(alertCodes);
/*    */     }
/* 56 */     alertCodes.add(new Integer(alertCode));
/*    */   }
/*    */ 
/*    */   public static List getAlertCodes()
/*    */   {
/* 64 */     return ((List)codes.get());
/*    */   }
/*    */ 
/*    */   public static List pollAlertCodes()
/*    */   {
/* 72 */     List alertCodes = (List)codes.get();
/* 73 */     if (alertCodes != null) {
/* 74 */       codes.set(null);
/*    */     }
/*    */ 
/* 77 */     return alertCodes;
/*    */   }
/*    */ }