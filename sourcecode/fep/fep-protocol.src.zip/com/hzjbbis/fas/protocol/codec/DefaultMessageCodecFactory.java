/*    */ package com.hzjbbis.fas.protocol.codec;
/*    */ 
/*    */ import com.hzjbbis.fas.protocol.conf.CodecConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.CodecFactoryConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.util.CastorUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class DefaultMessageCodecFactory
/*    */   implements MessageCodecFactory
/*    */ {
/* 20 */   private static final Log log = LogFactory.getLog(DefaultMessageCodecFactory.class);
/*    */   private ProtocolDataConfig dataConfig;
/*    */   private Map encoders;
/*    */   private Map decoders;
/*    */ 
/*    */   public void setConfig(CodecFactoryConfig config)
/*    */   {
/* 32 */     init(config);
/*    */   }
/*    */ 
/*    */   public MessageEncoder getEncoder(int funCode)
/*    */   {
/* 39 */     return ((MessageEncoder)this.encoders.get(new Integer(funCode)));
/*    */   }
/*    */ 
/*    */   public MessageDecoder getDecoder(int funCode)
/*    */   {
/* 46 */     return ((MessageDecoder)this.decoders.get(new Integer(funCode)));
/*    */   }
/*    */ 
/*    */   private void init(CodecFactoryConfig config)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       this.dataConfig = ((ProtocolDataConfig)CastorUtil.unmarshal(config.getDataConfigMapping(), config.getDataConfigResource()));
/*    */ 
/* 57 */       this.dataConfig.fillMap();
/* 58 */       this.encoders = new HashMap();
/* 59 */       this.decoders = new HashMap();
/* 60 */       List codecConfigs = config.getCodecs();
/* 61 */       if (codecConfigs != null)
/* 62 */         for (int i = 0; i < codecConfigs.size(); ++i) {
/* 63 */           CodecConfig codecConfig = (CodecConfig)codecConfigs.get(i);
/* 64 */           Integer funCode = new Integer(codecConfig.getFunCode());
/*    */ 
/* 66 */           if (codecConfig.getEncoderClass() != null) {
/* 67 */             MessageEncoder encoder = (MessageEncoder)newInstance(codecConfig.getEncoderClass());
/*    */ 
/* 69 */             encoder.setDataConfig(this.dataConfig);
/* 70 */             this.encoders.put(funCode, encoder);
/*    */           }
/*    */ 
/* 73 */           if (codecConfig.getDecoderClass() != null) {
/* 74 */             MessageDecoder decoder = (MessageDecoder)newInstance(codecConfig.getDecoderClass());
/*    */ 
/* 76 */             decoder.setDataConfig(this.dataConfig);
/* 77 */             this.decoders.put(funCode, decoder);
/*    */           }
/*    */         }
/*    */     }
/*    */     catch (Exception e) {
/* 82 */       log.error("load protocol setting", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private Object newInstance(String className)
/*    */   {
/*    */     try
/*    */     {
/* 93 */       Class clazz = Class.forName(className);
/* 94 */       return clazz.newInstance();
/*    */     }
/*    */     catch (Exception ex) {
/* 97 */       throw new RuntimeException("Error to instantiating class: " + className, ex);
/*    */     }
/*    */   }
/*    */ }