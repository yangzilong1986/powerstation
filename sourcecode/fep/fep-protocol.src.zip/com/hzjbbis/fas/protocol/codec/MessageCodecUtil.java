/*    */ package com.hzjbbis.fas.protocol.codec;
/*    */ 
/*    */ import com.hzjbbis.fas.protocol.handler.ProtocolHandler;
/*    */ import com.hzjbbis.fas.protocol.handler.ProtocolHandlerFactory;
/*    */ 
/*    */ public abstract class MessageCodecUtil
/*    */ {
/* 14 */   private static final ProtocolHandlerFactory handlerFactory = ProtocolHandlerFactory.getInstance();
/*    */ 
/*    */   private static MessageEncoder getEncoder(Class messageType, int funCode)
/*    */   {
/* 23 */     ProtocolHandler handler = handlerFactory.getProtocolHandler(messageType);
/* 24 */     return handler.getCodecFactory().getEncoder(funCode);
/*    */   }
/*    */ 
/*    */   private static MessageDecoder getDecoder(Class messageType, int funCode)
/*    */   {
/* 34 */     ProtocolHandler handler = handlerFactory.getProtocolHandler(messageType);
/* 35 */     return handler.getCodecFactory().getDecoder(funCode);
/*    */   }
/*    */ }