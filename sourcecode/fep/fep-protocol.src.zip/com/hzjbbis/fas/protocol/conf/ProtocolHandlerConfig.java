/*    */ package com.hzjbbis.fas.protocol.conf;
/*    */ 
/*    */ public class ProtocolHandlerConfig
/*    */ {
/*    */   private String messageType;
/*    */   private String handlerClass;
/*    */   private CodecFactoryConfig codecFactory;
/*    */ 
/*    */   public String getMessageType()
/*    */   {
/* 20 */     return this.messageType;
/*    */   }
/*    */ 
/*    */   public void setMessageType(String messageType)
/*    */   {
/* 26 */     this.messageType = messageType;
/*    */   }
/*    */ 
/*    */   public String getHandlerClass()
/*    */   {
/* 32 */     return this.handlerClass;
/*    */   }
/*    */ 
/*    */   public void setHandlerClass(String handlerClass)
/*    */   {
/* 38 */     this.handlerClass = handlerClass;
/*    */   }
/*    */ 
/*    */   public CodecFactoryConfig getCodecFactory()
/*    */   {
/* 44 */     return this.codecFactory;
/*    */   }
/*    */ 
/*    */   public void setCodecFactory(CodecFactoryConfig codecFactory)
/*    */   {
/* 50 */     this.codecFactory = codecFactory;
/*    */   }
/*    */ }