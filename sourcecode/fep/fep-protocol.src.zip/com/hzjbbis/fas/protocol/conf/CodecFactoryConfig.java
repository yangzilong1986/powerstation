/*    */ package com.hzjbbis.fas.protocol.conf;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class CodecFactoryConfig
/*    */ {
/*    */   private String factoryClass;
/*    */   private String dataConfigMapping;
/*    */   private String dataConfigResource;
/*    */   private List codecs;
/*    */ 
/*    */   public String getFactoryClass()
/*    */   {
/* 24 */     return this.factoryClass;
/*    */   }
/*    */ 
/*    */   public void setFactoryClass(String factoryClass)
/*    */   {
/* 30 */     this.factoryClass = factoryClass;
/*    */   }
/*    */ 
/*    */   public String getDataConfigMapping()
/*    */   {
/* 36 */     return this.dataConfigMapping;
/*    */   }
/*    */ 
/*    */   public void setDataConfigMapping(String dataConfigMapping)
/*    */   {
/* 42 */     this.dataConfigMapping = dataConfigMapping;
/*    */   }
/*    */ 
/*    */   public String getDataConfigResource()
/*    */   {
/* 48 */     return this.dataConfigResource;
/*    */   }
/*    */ 
/*    */   public void setDataConfigResource(String dataConfigResource)
/*    */   {
/* 54 */     this.dataConfigResource = dataConfigResource;
/*    */   }
/*    */ 
/*    */   public List getCodecs()
/*    */   {
/* 60 */     return this.codecs;
/*    */   }
/*    */ 
/*    */   public void setCodecs(List codecs)
/*    */   {
/* 66 */     this.codecs = codecs;
/*    */   }
/*    */ }