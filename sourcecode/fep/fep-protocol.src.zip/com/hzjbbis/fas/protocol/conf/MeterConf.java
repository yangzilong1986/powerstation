package com.hzjbbis.fas.protocol.conf;

import java.util.List;

public abstract interface MeterConf
{
  public abstract List getMeterConf(String paramString);
}