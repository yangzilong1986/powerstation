/*     */ package com.hzjbbis.fas.protocol.conf;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ProtocolDataItemConfig
/*     */   implements IDataItem
/*     */ {
/*     */   private String code;
/*     */   private String parentCode;
/*     */   private int length;
/*     */   private String type;
/*     */   private String format;
/*     */   private int parserno;
/*     */   private int fraction;
/*     */   private String keychar;
/*     */   private String bean;
/*     */   private String property;
/*     */   private List childItems;
/*     */   private int datakey;
/*     */   private List items;
/*     */   private int dkey;
/*     */ 
/*     */   public ProtocolDataItemConfig()
/*     */   {
/*  25 */     this.parserno = 0;
/*     */ 
/*  27 */     this.fraction = 0;
/*     */   }
/*     */ 
/*     */   public int getDataKey()
/*     */   {
/*  48 */     return this.datakey;
/*     */   }
/*     */ 
/*     */   public int getDatakey() {
/*  52 */     return this.datakey;
/*     */   }
/*     */ 
/*     */   public String getCode()
/*     */   {
/*  59 */     return this.code;
/*     */   }
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/*  65 */     this.code = code;
/*  66 */     this.datakey = ParseTool.HexToDecimal(code);
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  72 */     if ((this.length == 0) && (this.childItems != null)) {
/*  73 */       for (int i = 0; i < this.childItems.size(); ++i) {
/*  74 */         this.length += ((ProtocolDataItemConfig)this.childItems.get(i)).getLength();
/*     */       }
/*     */     }
/*  77 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void setLength(int length)
/*     */   {
/*  83 */     this.length = length;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  89 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(String type)
/*     */   {
/*  95 */     this.type = type;
/*     */     try {
/*  97 */       if ((type != null) && 
/*  98 */         (type.length() > 3)) {
/*  99 */         this.parserno = Integer.parseInt(type.substring(0, 2));
/* 100 */         this.fraction = Integer.parseInt(type.substring(2, 4));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 104 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getBean()
/*     */   {
/* 111 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public String getProperty()
/*     */   {
/* 118 */     return this.property;
/*     */   }
/*     */ 
/*     */   public void setProperty(String property)
/*     */   {
/* 124 */     this.property = property;
/*     */   }
/*     */ 
/*     */   public List getChildItems()
/*     */   {
/* 130 */     return this.childItems;
/*     */   }
/*     */ 
/*     */   public void setChildItems(List childItems)
/*     */   {
/* 136 */     this.childItems = childItems;
/* 137 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   public int getFraction()
/*     */   {
/* 144 */     return this.fraction;
/*     */   }
/*     */ 
/*     */   public int getParserno()
/*     */   {
/* 151 */     return this.parserno;
/*     */   }
/*     */ 
/*     */   public String getSdRobot() {
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   public List getStandardDatas() {
/* 159 */     return this.items;
/*     */   }
/*     */ 
/*     */   public boolean isMe(String dataid)
/*     */   {
/*     */     Iterator iter;
/* 163 */     boolean rt = false;
/* 164 */     if (this.items != null) {
/* 165 */       for (iter = this.items.iterator(); iter.hasNext(); ) {
/* 166 */         String dk = (String)iter.next();
/* 167 */         if (dk.equalsIgnoreCase(dataid)) {
/* 168 */           rt = true;
/* 169 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 173 */     return rt;
/*     */   }
/*     */ 
/*     */   public List getItems() {
/* 177 */     return this.items;
/*     */   }
/*     */ 
/*     */   public void setItems(List items) {
/* 181 */     this.items = items;
/*     */   }
/*     */ 
/*     */   public String getKeychar() {
/* 185 */     return this.keychar;
/*     */   }
/*     */ 
/*     */   public void setKeychar(String keychar) {
/* 189 */     this.keychar = keychar;
/*     */   }
/*     */ 
/*     */   public int getDkey() {
/* 193 */     return this.dkey;
/*     */   }
/*     */ 
/*     */   public void setDkey(int dkey) {
/* 197 */     this.dkey = dkey;
/*     */   }
/*     */ 
/*     */   public String getFormat() {
/* 201 */     return this.format;
/*     */   }
/*     */ 
/*     */   public void setFormat(String format) {
/* 205 */     this.format = format;
/*     */   }
/*     */ 
/*     */   public String getParentCode() {
/* 209 */     return this.parentCode;
/*     */   }
/*     */ 
/*     */   public void setParentCode(String parentCode) {
/* 213 */     this.parentCode = parentCode;
/*     */   }
/*     */ }