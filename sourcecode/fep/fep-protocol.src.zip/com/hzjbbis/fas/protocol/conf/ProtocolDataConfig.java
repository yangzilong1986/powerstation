/*     */ package com.hzjbbis.fas.protocol.conf;
/*     */ 
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProtocolDataConfig
/*     */   implements IDataSets
/*     */ {
/*  18 */   private static final Log log = LogFactory.getLog(ProtocolDataConfig.class);
/*     */   private List dataItems;
/*     */   private Map dataset;
/*     */   private HashMap sdataset;
/*     */   private HashMap parsers;
/*     */ 
/*     */   public ProtocolDataItemConfig getDataItemConfig(String code)
/*     */   {
/*  35 */     if (this.dataset == null) {
/*  36 */       synchronized (this) {
/*  37 */         if (this.dataset == null) {
/*  38 */           this.dataset = new HashMap();
/*  39 */           this.sdataset = new HashMap();
/*  40 */           this.parsers = new HashMap();
/*  41 */           addToItemMap(this.dataItems);
/*     */         }
/*     */       }
/*     */     }
/*  45 */     return ((ProtocolDataItemConfig)this.dataset.get(code));
/*     */   }
/*     */ 
/*     */   public synchronized void fillMap() {
/*  49 */     this.dataset = new HashMap();
/*  50 */     this.sdataset = new HashMap();
/*  51 */     this.parsers = new HashMap();
/*  52 */     addToItemMap(this.dataItems);
/*     */   }
/*     */ 
/*     */   private void addToItemMap(List items)
/*     */   {
/*  60 */     if ((items == null) || (items.isEmpty())) {
/*  61 */       return;
/*     */     }
/*     */ 
/*  64 */     for (int i = 0; i < items.size(); ++i)
/*     */     {
/*     */       Iterator iter;
/*  65 */       ProtocolDataItemConfig item = (ProtocolDataItemConfig)items.get(i);
/*  66 */       this.dataset.put(item.getCode(), item);
/*  67 */       if (item.getBean() != null) {
/*  68 */         loadParser(item.getCode(), item.getBean());
/*     */       }
/*  70 */       if (item.getItems() != null) {
/*  71 */         List sitems = item.getItems();
/*  72 */         for (iter = sitems.iterator(); iter.hasNext(); ) {
/*  73 */           String si = (String)iter.next();
/*  74 */           String keychar = item.getKeychar();
/*  75 */           if (keychar != null) {
/*  76 */             int index = keychar.indexOf(":");
/*  77 */             if (index > 0) {
/*  78 */               String[] keys = keychar.split(":");
/*  79 */               for (int j = 0; j < keys.length; ++j) {
/*  80 */                 String key = si + "|" + keys[j];
/*  81 */                 this.sdataset.put(key, item.getCode());
/*     */               }
/*     */             } else {
/*  84 */               String key = si + "|" + item.getKeychar();
/*  85 */               this.sdataset.put(key, item.getCode());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  90 */       addToItemMap(item.getChildItems());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadParser(String key, String name) {
/*  95 */     if (name == null) return;
/*     */     try {
/*  97 */       if (!(this.parsers.containsKey(name))) {
/*  98 */         Class clazz = Class.forName(name);
/*  99 */         this.parsers.put(key, clazz.newInstance());
/*     */       }
/*     */     } catch (Exception e) {
/* 102 */       log.error("load parser", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getDataItems()
/*     */   {
/* 111 */     return this.dataItems;
/*     */   }
/*     */ 
/*     */   public void setDataItems(List dataItems)
/*     */   {
/* 117 */     this.dataItems = dataItems;
/*     */   }
/*     */ 
/*     */   public String getLocal(String key, Object para) {
/* 121 */     String local = null;
/* 122 */     if (para instanceof DataItem) {
/* 123 */       DataItem di = (DataItem)para;
/* 124 */       String pt = (String)di.getProperty("point");
/* 125 */       if (pt != null) {
/* 126 */         String skey = key + "|" + pt;
/* 127 */         local = (String)this.sdataset.get(skey);
/*     */       }
/* 129 */     } else if (para instanceof String) {
/* 130 */       String skey = key + "|" + ((String)para);
/* 131 */       local = (String)this.sdataset.get(skey);
/*     */     }
/* 133 */     return local;
/*     */   }
/*     */ 
/*     */   public IItemParser getParser(String key) {
/* 137 */     IItemParser parser = null;
/* 138 */     if (key != null) {
/* 139 */       parser = (IItemParser)this.parsers.get(key);
/*     */     }
/* 141 */     return parser; }
/*     */ 
/*     */   public List getMConf(String key) {
/* 144 */     List conf = null;
/* 145 */     if (key != null);
/* 148 */     return conf;
/*     */   }
/*     */ }