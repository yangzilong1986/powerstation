/*    */ package com.hzjbbis.fas.protocol.conf;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class ProtocolProviderConfig
/*    */ {
/*    */   private List handlers;
/*    */ 
/*    */   public ProtocolHandlerConfig getProtocolHandlerConfig(String messageType)
/*    */   {
/* 20 */     if (this.handlers == null) {
/* 21 */       return null;
/*    */     }
/*    */ 
/* 24 */     for (int i = 0; i < this.handlers.size(); ++i) {
/* 25 */       ProtocolHandlerConfig handler = (ProtocolHandlerConfig)this.handlers.get(i);
/* 26 */       if (handler.getMessageType().equals(messageType)) {
/* 27 */         return handler;
/*    */       }
/*    */     }
/*    */ 
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   public List getHandlers()
/*    */   {
/* 38 */     return this.handlers;
/*    */   }
/*    */ 
/*    */   public void setHandlers(List handlers)
/*    */   {
/* 45 */     this.handlers = handlers;
/*    */   }
/*    */ }