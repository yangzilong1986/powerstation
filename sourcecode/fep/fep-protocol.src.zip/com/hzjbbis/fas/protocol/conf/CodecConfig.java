/*    */ package com.hzjbbis.fas.protocol.conf;
/*    */ 
/*    */ public class CodecConfig
/*    */ {
/*    */   private int funCode;
/*    */   private String encoderClass;
/*    */   private String decoderClass;
/*    */ 
/*    */   public int getFunCode()
/*    */   {
/* 20 */     return this.funCode;
/*    */   }
/*    */ 
/*    */   public void setFunCode(int funCode)
/*    */   {
/* 26 */     this.funCode = funCode;
/*    */   }
/*    */ 
/*    */   public String getEncoderClass()
/*    */   {
/* 32 */     return this.encoderClass;
/*    */   }
/*    */ 
/*    */   public void setEncoderClass(String encoderClass)
/*    */   {
/* 38 */     this.encoderClass = encoderClass;
/*    */   }
/*    */ 
/*    */   public String getDecoderClass()
/*    */   {
/* 44 */     return this.decoderClass;
/*    */   }
/*    */ 
/*    */   public void setDecoderClass(String decoderClass)
/*    */   {
/* 50 */     this.decoderClass = decoderClass;
/*    */   }
/*    */ }