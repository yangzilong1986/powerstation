/*    */ package com.hzjbbis.fas.protocol.gw.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import com.hzjbbis.fas.model.FaalGWAFN0ERequest;
/*    */ import com.hzjbbis.fas.model.FaalRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequestParam;
/*    */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ import com.hzjbbis.fk.model.BizRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import com.hzjbbis.util.HexDump;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class C0EMessageEncoder extends AbstractMessageEncoder
/*    */ {
/*    */   public IMessage[] encode(Object obj)
/*    */   {
/*    */     FaalGWAFN0ERequest request;
/*    */     String sdata;
/*    */     String tp;
/*    */     String param;
/* 27 */     List rt = new ArrayList();
/*    */     try {
/* 29 */       if (obj instanceof FaalRequest) {
/* 30 */         request = (FaalGWAFN0ERequest)obj;
/* 31 */         List rtuParams = request.getRtuParams();
/* 32 */         sdata = ""; tp = ""; param = "";
/*    */ 
/* 34 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/* 35 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*    */         }
/* 37 */         if ((request.getPm() > 0) && (request.getPn() > 0)) {
/* 38 */           param = DataItemCoder.constructor(new StringBuilder().append("").append(request.getPm()).toString(), "HTB1") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getPn()).toString(), "HTB1");
/*    */         }
/* 40 */         for (FaalRequestRtuParam rp : rtuParams) {
/* 41 */           int[] tn = rp.getTn();
/* 42 */           List params = rp.getParams();
/* 43 */           String codes = "";
/* 44 */           for (FaalRequestParam pm : params) {
/* 45 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(pm.getName());
/* 46 */             if (codes.indexOf(pdc.getParentCode()) < 0)
/* 47 */               codes = codes + "," + pdc.getParentCode();
/*    */           }
/* 49 */           if (codes.startsWith(","))
/* 50 */             codes = codes.substring(1);
/* 51 */           String[] codeList = codes.split(",");
/* 52 */           String[] sDADTList = DataItemCoder.getCodeFromNToN(tn, codeList);
/* 53 */           for (int i = 0; i < sDADTList.length; ++i)
/* 54 */             sdata = sdata + sDADTList[i] + param;
/* 55 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/* 56 */           MessageGwHead head = new MessageGwHead();
/*    */ 
/* 58 */           head.rtua = rtu.getRtua();
/*    */ 
/* 60 */           MessageGw msg = new MessageGw();
/* 61 */           msg.head = head;
/* 62 */           msg.setAFN((byte)request.getType());
/* 63 */           msg.data = HexDump.toByteBuffer(sdata);
/* 64 */           if (!(tp.equals("")))
/* 65 */             msg.setAux(HexDump.toByteBuffer(tp), true);
/* 66 */           msg.setCmdId(rp.getCmdId());
/* 67 */           msg.setMsgCount(1);
/* 68 */           rt.add(msg);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 72 */       throw new MessageEncodeException(e);
/*    */     }
/* 74 */     if ((rt != null) && (rt.size() > 0)) {
/* 75 */       IMessage[] msgs = new IMessage[rt.size()];
/*    */ 
/* 77 */       rt.toArray(msgs);
/* 78 */       return msgs;
/*    */     }
/*    */ 
/* 81 */     return null;
/*    */   }
/*    */ }