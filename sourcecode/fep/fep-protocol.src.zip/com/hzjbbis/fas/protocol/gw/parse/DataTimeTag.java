/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ public class DataTimeTag
/*    */ {
/*    */   private String dataTime;
/*    */   private int dataDensity;
/*    */   private int dataCount;
/*    */ 
/*    */   public String getDataTime()
/*    */   {
/* 11 */     return this.dataTime; }
/*    */ 
/*    */   public void setDataTime(String dataTime) {
/* 14 */     this.dataTime = dataTime; }
/*    */ 
/*    */   public int getDataDensity() {
/* 17 */     return this.dataDensity; }
/*    */ 
/*    */   public void setDataDensity(int dataDensity) {
/* 20 */     this.dataDensity = dataDensity; }
/*    */ 
/*    */   public int getDataCount() {
/* 23 */     return this.dataCount; }
/*    */ 
/*    */   public void setDataCount(int dataCount) {
/* 26 */     this.dataCount = dataCount;
/*    */   }
/*    */ }