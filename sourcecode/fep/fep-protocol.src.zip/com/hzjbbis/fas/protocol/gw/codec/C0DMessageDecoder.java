/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.model.HostCommandResult;
/*     */ import com.hzjbbis.fas.model.RtuData;
/*     */ import com.hzjbbis.fas.model.RtuDataItem;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataSwitch;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataTimeTag;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataValue;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C0DMessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  28 */     List datas = new ArrayList();
/*  29 */     HostCommand hc = new HostCommand();
/*     */ 
/*  31 */     int dataType = 0;
/*     */     try {
/*  33 */       String sTaskDateTime = ""; String sTaskNum = null;
/*  34 */       String data = ParseTool.getGwData(message);
/*  35 */       MessageGw msg = (MessageGw)message;
/*  36 */       if (msg.head.seq_tpv == 1)
/*  37 */         data = data.substring(0, data.length() - 12);
/*  38 */       if (msg.head.c_acd == 1)
/*  39 */         data = data.substring(0, data.length() - 4);
/*  40 */       BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(((MessageGw)message).head.rtua);
/*  41 */       DataValue dataValue = new DataValue();
/*  42 */       while (data.length() >= 12) {
/*  43 */         int[] tn = DataItemParser.measuredPointParser(data.substring(0, 4));
/*  44 */         String[] codes = DataItemParser.dataCodeParser(data.substring(4, 8), "0D");
/*  45 */         data = data.substring(8);
/*  46 */         DataTimeTag dataTimeTag = new DataTimeTag();
/*  47 */         List codesTemp = new ArrayList();
/*  48 */         for (int i = 0; i < tn.length; ++i) {
/*  49 */           for (int j = 0; j < codes.length; ++j)
/*     */           {
/*     */             int k;
/*  50 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(codes[j]);
/*  51 */             List childItems = pdc.getChildItems();
/*  52 */             dataType = getGw0DDataType(Integer.parseInt(codes[j].substring(3, 6)));
/*     */ 
/*  54 */             if (dataType == 0)
/*     */             {
/*  56 */               dataTimeTag = DataItemParser.getTaskDateTimeInfo(data.substring(0, 14), 2);
/*  57 */               data = data.substring(14);
/*  58 */               for (k = 0; k < dataTimeTag.getDataCount(); ++k)
/*  59 */                 if (childItems.size() > 0) {
/*  60 */                   dataValue = DataItemParser.parseValue(data.substring(0, ((ProtocolDataItemConfig)childItems.get(0)).getLength() * 2), ((ProtocolDataItemConfig)childItems.get(0)).getFormat());
/*  61 */                   data = data.substring(((ProtocolDataItemConfig)childItems.get(0)).getLength() * 2);
/*  62 */                   sTaskDateTime = DataSwitch.IncreaseDateTime(dataTimeTag.getDataTime(), dataTimeTag.getDataDensity() * k, 2);
/*  63 */                   if (message.isTask()) {
/*  64 */                     RtuData rd = new RtuData();
/*  65 */                     rd.setLogicAddress(rtu.getLogicAddress());
/*  66 */                     rd.setTn("" + tn[i]);
/*  67 */                     if (sTaskNum == null)
/*     */                     {
/*  69 */                       codesTemp.add(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  70 */                       sTaskNum = rtu.getTaskNum(codesTemp);
/*  71 */                       codesTemp.clear();
/*     */                     }
/*  73 */                     if (sTaskNum == null) {
/*  74 */                       String error = "终端：" + rtu.getLogicAddress() + "任务报文无法找到匹配的任务模版," + message.getRawPacketString();
/*  75 */                       throw new MessageDecodeException(error);
/*     */                     }
/*     */ 
/*  78 */                     rd.setTaskNum(sTaskNum);
/*  79 */                     rd.setTime(sTaskDateTime);
/*  80 */                     RtuDataItem rdItem = new RtuDataItem();
/*  81 */                     rdItem.setCode(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  82 */                     rdItem.setValue(dataValue.getValue());
/*  83 */                     rd.addDataList(rdItem);
/*  84 */                     datas.add(rd);
/*     */                   }
/*     */                   else {
/*  87 */                     HostCommandResult hcr = new HostCommandResult();
/*  88 */                     hcr.setCode(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  89 */                     hcr.setTn("" + tn[i]);
/*  90 */                     hcr.setValue(sTaskDateTime + "#" + dataValue.getValue());
/*  91 */                     hc.addResult(hcr);
/*  92 */                     hc.setStatus("1");
/*     */                   }
/*     */                 }
/*     */             }
/*     */             else
/*     */             {
/*  98 */               if (dataType == 1)
/*     */               {
/* 100 */                 dataTimeTag = DataItemParser.getTaskDateTimeInfo(data.substring(0, 6), 3);
/* 101 */                 data = data.substring(6);
/*     */               }
/*     */               else
/*     */               {
/* 105 */                 dataTimeTag = DataItemParser.getTaskDateTimeInfo(data.substring(0, 4), 4);
/* 106 */                 data = data.substring(4);
/*     */               }
/* 108 */               for (k = 0; k < childItems.size(); ++k)
/*     */               {
/*     */                 DataValue nValue;
/*     */                 int n;
/*     */                 int m;
/*     */                 HostCommandResult hcr;
/* 109 */                 ProtocolDataItemConfig pc = (ProtocolDataItemConfig)childItems.get(k);
/*     */ 
/* 111 */                 if (pc.getCode().equals("0000000000")) {
/* 112 */                   nValue = new DataValue();
/* 113 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 114 */                   data = data.substring(pc.getLength() * 2);
/* 115 */                   for (int m = k + 1; m < childItems.size(); ++m) {
/* 116 */                     pc = (ProtocolDataItemConfig)childItems.get(m);
/* 117 */                     for (int n = 0; n < Integer.parseInt(nValue.getValue()) + 1; ++n) {
/* 118 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 119 */                       data = data.substring(pc.getLength() * 2);
/* 120 */                       hcr = new HostCommandResult();
/* 121 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(new StringBuilder().append(pc.getCode().substring(0, 8)).append("00").toString()) + n), "left"));
/* 122 */                       hcr.setTn("" + tn[i]);
/* 123 */                       hcr.setValue(dataValue.getValue());
/* 124 */                       hc.addResult(hcr);
/* 125 */                       codesTemp.add(hcr.getCode());
/*     */                     }
/*     */                   }
/* 128 */                   break;
/*     */                 }
/*     */ 
/* 131 */                 if (pc.getCode().equals("0000000001")) {
/* 132 */                   nValue = new DataValue();
/* 133 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 134 */                   data = data.substring(pc.getLength() * 2);
/* 135 */                   for (n = 0; n < Integer.parseInt(nValue.getValue()) + 1; ++n) {
/* 136 */                     for (m = k + 1; m < childItems.size(); ++m) {
/* 137 */                       pc = (ProtocolDataItemConfig)childItems.get(m);
/* 138 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 139 */                       data = data.substring(pc.getLength() * 2);
/* 140 */                       hcr = new HostCommandResult();
/* 141 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(new StringBuilder().append(pc.getCode().substring(0, 8)).append("00").toString()) + n), "left"));
/* 142 */                       hcr.setTn("" + tn[i]);
/* 143 */                       hcr.setValue(dataValue.getValue());
/* 144 */                       hc.addResult(hcr);
/* 145 */                       codesTemp.add(hcr.getCode());
/*     */                     }
/*     */                   }
/* 148 */                   break;
/*     */                 }
/*     */ 
/* 151 */                 if (pc.getCode().indexOf("X") > 0) {
/* 152 */                   nValue = new DataValue();
/* 153 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 154 */                   data = data.substring(pc.getLength() * 2);
/* 155 */                   for (n = 0; n < Integer.parseInt(nValue.getValue()); ++n) {
/* 156 */                     for (m = k + 1; m < childItems.size(); ++m) {
/* 157 */                       pc = (ProtocolDataItemConfig)childItems.get(m);
/* 158 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 159 */                       data = data.substring(pc.getLength() * 2);
/* 160 */                       hcr = new HostCommandResult();
/* 161 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(pc.getCode()) + n * 10), "left"));
/* 162 */                       hcr.setTn("" + tn[i]);
/* 163 */                       hcr.setValue(dataValue.getValue());
/* 164 */                       hc.addResult(hcr);
/* 165 */                       codesTemp.add(hcr.getCode());
/*     */                     }
/*     */                   }
/* 168 */                   break;
/*     */                 }
/*     */ 
/* 171 */                 dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 172 */                 data = data.substring(pc.getLength() * 2);
/* 173 */                 HostCommandResult hcr = new HostCommandResult();
/* 174 */                 hcr.setCode(pc.getCode());
/* 175 */                 hcr.setTn("" + tn[i]);
/* 176 */                 hcr.setValue(dataValue.getValue());
/* 177 */                 hc.addResult(hcr);
/* 178 */                 codesTemp.add(hcr.getCode());
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 184 */           if ((dataType == 0) || 
/* 185 */             (codesTemp.size() <= 0)) continue;
/* 186 */           if (message.isTask()) {
/* 187 */             RtuData rd = new RtuData();
/* 188 */             rd.setLogicAddress(rtu.getLogicAddress());
/* 189 */             rd.setTn("" + tn[i]);
/*     */ 
/* 191 */             sTaskNum = rtu.getTaskNum(codesTemp);
/* 192 */             codesTemp.clear();
/* 193 */             if (sTaskNum == null) {
/* 194 */               String error = "终端：" + rtu.getLogicAddress() + "任务报文无法找到匹配的任务模版," + message.getRawPacketString();
/* 195 */               throw new MessageDecodeException(error);
/*     */             }
/*     */ 
/* 198 */             rd.setTaskNum(sTaskNum);
/* 199 */             rd.setTime(dataTimeTag.getDataTime());
/* 200 */             for (HostCommandResult hcr : hc.getResults()) {
/* 201 */               RtuDataItem rdItem = new RtuDataItem();
/* 202 */               rdItem.setCode(hcr.getCode());
/* 203 */               rdItem.setValue(hcr.getValue());
/* 204 */               rd.addDataList(rdItem);
/*     */             }
/* 206 */             datas.add(rd);
/*     */           }
/*     */           else {
/* 209 */             for (HostCommandResult hcr : hc.getResults()) {
/* 210 */               hcr.setValue(dataTimeTag.getDataTime() + "#" + hcr.getValue());
/*     */             }
/* 212 */             hc.setStatus("1");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 219 */       throw new MessageDecodeException(e);
/*     */     }
/* 221 */     if (message.isTask()) {
/* 222 */       return datas;
/*     */     }
/* 224 */     return hc;
/*     */   }
/*     */ 
/*     */   public int getGw0DDataType(int fn)
/*     */   {
/* 230 */     int type = 2;
/*     */ 
/* 232 */     if (((fn >= 1) && (fn <= 12)) || ((fn >= 25) && (fn <= 32)) || ((fn >= 41) && (fn <= 43)) || (fn == 45) || ((fn >= 49) && (fn <= 50)) || (fn == 53) || ((fn >= 57) && (fn <= 59)) || ((fn >= 113) && (fn <= 129)) || ((fn >= 153) && (fn <= 156)) || ((fn >= 161) && (fn <= 176)) || ((fn >= 185) && (fn <= 192)) || (fn == 209))
/*     */     {
/* 235 */       type = 1;
/*     */     }
/* 238 */     else if (((fn >= 73) && (fn <= 110)) || ((fn >= 138) && (fn <= 148)) || ((fn >= 217) && (fn <= 218))) {
/* 239 */       type = 0;
/*     */     }
/* 241 */     return type;
/*     */   }
/*     */ }