/*     */ package com.hzjbbis.fas.protocol.gw.parse;
/*     */ 
/*     */ import C;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataItemCoder
/*     */ {
/*  20 */   private static Log log = LogFactory.getLog(DataItemCoder.class);
/*     */ 
/*     */   public static String getCodeFrom1To1(int mt, String code)
/*     */   {
/*  28 */     String sDADT = ""; String sDA = ""; String sDT = "";
/*     */     try
/*     */     {
/*  31 */       char[] chr1 = { '0', '0', '0', '0', '0', '0', '0', '0' };
/*  32 */       if (mt == 0) {
/*  33 */         sDA = "0000";
/*  34 */       } else if ((mt > 0) && (mt <= 2040)) {
/*  35 */         if (mt % 8 == 0)
/*  36 */           chr1[0] = '1';
/*     */         else
/*  38 */           chr1[(8 - (mt % 8))] = '1';
/*  39 */         sDA = DataSwitch.Fun8BinTo2Hex(new String(chr1).trim()) + DataSwitch.IntToHex(new StringBuilder().append("").append((int)Math.floor((mt - 1) / 8)).append(1).toString(), 2);
/*     */       }
/*     */ 
/*  42 */       char[] chr2 = { '0', '0', '0', '0', '0', '0', '0', '0' };
/*  43 */       int fn = Integer.parseInt(code.substring(3, 6));
/*  44 */       if ((fn > 0) && (fn <= 2040)) {
/*  45 */         if (fn % 8 == 0)
/*  46 */           chr2[0] = '1';
/*     */         else {
/*  48 */           chr2[(8 - (fn % 8))] = '1';
/*     */         }
/*  50 */         sDT = DataSwitch.Fun8BinTo2Hex(new String(chr2).trim()) + DataSwitch.IntToHex(new StringBuilder().append("").append((int)Math.floor((fn - 1) / 8)).toString(), 2);
/*     */       }
/*  52 */       sDADT = sDA + sDT;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  56 */       log.error("getCodeFrom1To1 error:" + e.toString());
/*     */     }
/*  58 */     return sDADT;
/*     */   }
/*     */ 
/*     */   public static String[] getCodeFromNToN(int[] mts, String[] codes)
/*     */   {
/*  68 */     String[] sDADTList = null; String[] sDAList = null; String[] sDTList = null;
/*     */     try
/*     */     {
/*     */       char[] chr;
/*     */       Map.Entry entry;
/*  70 */       Map chrMap = new HashMap();
/*  71 */       char[] chr0 = { '0', '0', '0', '0', '0', '0', '0', '0' };
/*     */ 
/*  74 */       for (int i = 0; i < mts.length; ++i) {
/*  75 */         if (mts[i] == 0) {
/*  76 */           chr = chr0;
/*  77 */           chrMap.put(Integer.valueOf(0), chr);
/*     */         }
/*  79 */         else if ((mts[i] > 0) && (mts[i] <= 2040)) {
/*  80 */           int iDA2 = (int)Math.floor((mts[i] - 1) / 8) + 1;
/*  81 */           chr = (char[])chrMap.get(new Integer(iDA2));
/*  82 */           if (chr == null) {
/*  83 */             chr = (char[])chr0.clone();
/*     */           }
/*  85 */           if (mts[i] % 8 == 0)
/*  86 */             chr[0] = '1';
/*     */           else
/*  88 */             chr[(8 - (mts[i] % 8))] = '1';
/*  89 */           chrMap.put(new Integer(iDA2), chr);
/*     */         }
/*     */       }
/*  92 */       sDAList = new String[chrMap.size()];
/*  93 */       Iterator it = chrMap.entrySet().iterator();
/*  94 */       int icount = 0;
/*  95 */       while (it.hasNext()) {
/*  96 */         entry = (Map.Entry)it.next();
/*  97 */         sDAList[icount] = DataSwitch.Fun8BinTo2Hex(new String((char[])(char[])entry.getValue()).trim()) + DataSwitch.IntToHex(new StringBuilder().append("").append(entry.getKey()).toString(), 2);
/*  98 */         ++icount;
/*     */       }
/*     */ 
/* 101 */       chrMap.clear();
/*     */ 
/* 103 */       for (int i = 0; i < codes.length; ++i) {
/* 104 */         int fn = Integer.parseInt(codes[i].substring(3, 6));
/* 105 */         if ((fn > 0) && (fn <= 2040)) {
/* 106 */           int iDT2 = (int)Math.floor((fn - 1) / 8);
/* 107 */           chr = (char[])chrMap.get(new Integer(iDT2));
/* 108 */           if (chr == null) {
/* 109 */             chr = (char[])chr0.clone();
/*     */           }
/* 111 */           if (fn % 8 == 0)
/* 112 */             chr[0] = '1';
/*     */           else
/* 114 */             chr[(8 - (fn % 8))] = '1';
/* 115 */           chrMap.put(new Integer(iDT2), chr);
/*     */         }
/*     */       }
/* 118 */       sDTList = new String[chrMap.size()];
/* 119 */       it = chrMap.entrySet().iterator();
/* 120 */       icount = 0;
/* 121 */       while (it.hasNext()) {
/* 122 */         i = (Map.Entry)it.next();
/* 123 */         sDTList[icount] = DataSwitch.Fun8BinTo2Hex(new String((char[])(char[])i.getValue()).trim()) + DataSwitch.IntToHex(new StringBuilder().append("").append(i.getKey()).toString(), 2);
/* 124 */         ++icount;
/*     */       }
/* 126 */       sDADTList = new String[sDAList.length * sDTList.length];
/* 127 */       icount = 0;
/* 128 */       for (i = 0; i < sDAList.length; ++i) {
/* 129 */         for (int j = 0; j < sDTList.length; ++j) {
/* 130 */           sDADTList[icount] = sDAList[i] + sDTList[j];
/* 131 */           ++icount;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 137 */       log.error("getCodeFromNToN error:" + e.toString());
/*     */     }
/* 139 */     return sDADTList;
/*     */   }
/*     */ 
/*     */   public static String coder(String input, String format)
/*     */   {
/* 148 */     String output = "";
/*     */     try {
/* 150 */       String[] formatItems = format.split("#");
/* 151 */       String[] inputItems = input.split("#");
/* 152 */       if ((formatItems.length > 0) && (inputItems.length >= formatItems.length)) {
/* 153 */         for (int i = 0; i < formatItems.length; ++i)
/* 154 */           if (formatItems[i].startsWith("N")) {
/* 155 */             int num = Integer.parseInt(input.substring(0, input.indexOf("#")));
/* 156 */             output = output + constructor(input.substring(0, input.indexOf("#")), formatItems[i]);
/* 157 */             format = format.substring(format.indexOf("#") + 1);
/* 158 */             input = input.substring(input.indexOf("#") + 1);
/* 159 */             if (num > 1) {
/* 160 */               inputItems = input.split(";");
/* 161 */               if (num != inputItems.length) {
/* 162 */                 inputItems = input.split(",");
/*     */               }
/* 164 */               for (int j = 0; j < inputItems.length; ++j) {
/* 165 */                 output = output + coder(inputItems[j], format);
/*     */               }
/* 167 */               break;
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 179 */             if (i == formatItems.length - 1)
/* 180 */               output = output + constructor(input, formatItems[i]);
/*     */             else
/* 182 */               output = output + constructor(input.substring(0, input.indexOf("#")), formatItems[i]);
/* 183 */             format = format.substring(format.indexOf("#") + 1);
/* 184 */             input = input.substring(input.indexOf("#") + 1);
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 190 */       log.error("coder error:" + e.toString());
/*     */     }
/* 192 */     return output;
/*     */   }
/*     */ 
/*     */   public static String constructor(String input, String format)
/*     */   {
/* 201 */     String output = "";
/*     */     try {
/* 203 */       int len = 0;
/* 204 */       if (format.startsWith("HTB")) {
/* 205 */         len = Integer.parseInt(format.substring(3));
/* 206 */         output = ParserHTB.constructor(input, len * 2);
/* 207 */       } else if (format.startsWith("HEX")) {
/* 208 */         len = Integer.parseInt(format.substring(3));
/* 209 */         output = ParserHEX.constructor(input, len * 2);
/* 210 */       } else if (format.startsWith("STS")) {
/* 211 */         len = Integer.parseInt(format.substring(3));
/* 212 */         output = ParserString.constructor(input, len * 2);
/* 213 */       } else if (format.startsWith("ASC")) {
/* 214 */         len = Integer.parseInt(format.substring(3));
/* 215 */         output = ParserASC.constructor(input, len * 2);
/* 216 */       } else if (format.startsWith("SIM")) {
/* 217 */         len = Integer.parseInt(format.substring(3));
/* 218 */         output = ParserSIM.constructor(input, len * 2);
/* 219 */       } else if (format.startsWith("BS")) {
/* 220 */         len = Integer.parseInt(format.substring(2));
/* 221 */         output = ParserBS.constructor(input, len * 2);
/* 222 */       } else if (format.startsWith("IP")) {
/* 223 */         len = Integer.parseInt(format.substring(2));
/* 224 */         output = ParserIP.constructor(input, len * 2);
/* 225 */       } else if (format.startsWith("N")) {
/* 226 */         len = Integer.parseInt(format.substring(1));
/* 227 */         output = ParserHTB.constructor(input, len * 2);
/* 228 */       } else if (format.equals("A1")) {
/* 229 */         output = ParserA1.constructor(input, 12);
/* 230 */       } else if (format.equals("A2")) {
/* 231 */         output = ParserA2.constructor(input, 4);
/* 232 */       } else if (format.equals("A3")) {
/* 233 */         output = ParserA3.constructor(input, 8);
/* 234 */       } else if (format.equals("A4")) {
/* 235 */         output = ParserFTB.constructor(input, "CC", 2);
/* 236 */       } else if (format.equals("A5")) {
/* 237 */         output = ParserFTB.constructor(input, "CCC.C", 4);
/* 238 */       } else if (format.equals("A6")) {
/* 239 */         output = ParserFTB.constructor(input, "CC.CC", 4);
/* 240 */       } else if (format.equals("A7")) {
/* 241 */         output = ParserFTB.constructor(input, "000.0", 4);
/* 242 */       } else if (format.equals("A8")) {
/* 243 */         output = ParserFTB.constructor(input, "0000", 4);
/* 244 */       } else if (format.equals("A9")) {
/* 245 */         output = ParserFTB.constructor(input, "CC.CCCC", 6);
/* 246 */       } else if (format.equals("A10")) {
/* 247 */         output = ParserFTB.constructor(input, "000000", 6);
/* 248 */       } else if (format.equals("A11")) {
/* 249 */         output = ParserFTB.constructor(input, "000000.00", 8);
/* 250 */       } else if (format.equals("A12")) {
/* 251 */         output = ParserFTB.constructor(input, "000000000000", 12);
/* 252 */       } else if (format.equals("A13")) {
/* 253 */         output = ParserFTB.constructor(input, "0000.0000", 8);
/* 254 */       } else if (format.equals("A14")) {
/* 255 */         output = ParserFTB.constructor(input, "000000.0000", 10);
/* 256 */       } else if (format.equals("A15")) {
/* 257 */         output = ParserDATE.constructor(input, "yyyy-MM-dd HH:mm", "yyMMddHHmm", 10);
/* 258 */       } else if (format.equals("A16")) {
/* 259 */         output = ParserDATE.constructor(input, "dd HH:mm:ss", "ddHHmmss", 8);
/* 260 */       } else if (format.equals("A17")) {
/* 261 */         output = ParserDATE.constructor(input, "MM-dd HH:mm", "MMddHHmm", 8);
/* 262 */       } else if (format.equals("A18")) {
/* 263 */         output = ParserDATE.constructor(input, "dd HH:mm", "ddHHmm", 6);
/* 264 */       } else if (format.equals("A19")) {
/* 265 */         output = ParserDATE.constructor(input, "HH:mm", "HHmm", 4);
/* 266 */       } else if (format.equals("A20")) {
/* 267 */         output = ParserDATE.constructor(input, "yyyy-MM-dd", "yyMMdd", 6);
/* 268 */       } else if (format.equals("A21")) {
/* 269 */         output = ParserDATE.constructor(input, "yyyy-MM", "yyMM", 4);
/* 270 */       } else if (format.equals("A22")) {
/* 271 */         output = ParserFTB.constructor(input, "0.0", 2);
/* 272 */       } else if (format.equals("A23")) {
/* 273 */         output = ParserFTB.constructor(input, "00.0000", 6);
/* 274 */       } else if (format.equals("A24")) {
/* 275 */         output = ParserDATE.constructor(input, "dd HH", "ddHH", 4);
/* 276 */       } else if (format.equals("A25")) {
/* 277 */         output = ParserFTB.constructor(input, "CCC.CCC", 6);
/* 278 */       } else if (format.equals("A26")) {
/* 279 */         output = ParserFTB.constructor(input, "0.000", 4);
/* 280 */       } else if (format.equals("A27")) {
/* 281 */         output = ParserFTB.constructor(input, "00000000", 8);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 285 */       log.error("constructor error:" + e.toString());
/*     */     }
/* 287 */     return output;
/*     */   }
/*     */ }