/*    */ package com.hzjbbis.fas.protocol.gw.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import com.hzjbbis.fas.model.FaalGWNoParamRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequestParam;
/*    */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ import com.hzjbbis.fk.model.BizRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import com.hzjbbis.util.HexDump;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class C0CMessageEncoder extends AbstractMessageEncoder
/*    */ {
/*    */   public IMessage[] encode(Object obj)
/*    */   {
/*    */     FaalGWNoParamRequest request;
/*    */     String sdata;
/*    */     String tp;
/* 29 */     List rt = new ArrayList();
/*    */     try {
/* 31 */       if (obj instanceof FaalRequest) {
/* 32 */         request = (FaalGWNoParamRequest)obj;
/* 33 */         List rtuParams = request.getRtuParams();
/* 34 */         sdata = ""; tp = "";
/*    */ 
/* 36 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/* 37 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*    */         }
/* 39 */         for (FaalRequestRtuParam rp : rtuParams) {
/* 40 */           int[] tn = rp.getTn();
/* 41 */           List params = rp.getParams();
/* 42 */           String codes = "";
/* 43 */           for (FaalRequestParam pm : params) {
/* 44 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(pm.getName());
/* 45 */             if (pdc == null) {
/* 46 */               if ((!(pm.getName().substring(0, 2).equals("0C"))) && (pm.getName().length() == 10))
/* 47 */                 pm.setName(pm.getName().substring(0, 8) + "XX");
/* 48 */               pdc = this.dataConfig.getDataItemConfig(pm.getName());
/* 49 */               if (pdc == null)
/* 50 */                 throw new MessageEncodeException("can not find cmd:" + pm.getName());
/*    */             }
/* 52 */             if (codes.indexOf(pdc.getParentCode()) < 0)
/* 53 */               codes = codes + "," + pdc.getParentCode();
/*    */           }
/* 55 */           if (codes.startsWith(","))
/* 56 */             codes = codes.substring(1);
/* 57 */           String[] codeList = codes.split(",");
/* 58 */           String[] sDADTList = DataItemCoder.getCodeFromNToN(tn, codeList);
/* 59 */           for (int i = 0; i < sDADTList.length; ++i)
/* 60 */             sdata = sdata + sDADTList[i];
/* 61 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/* 62 */           if (rtu == null) {
/* 63 */             throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*    */           }
/* 65 */           MessageGwHead head = new MessageGwHead();
/*    */ 
/* 67 */           head.rtua = rtu.getRtua();
/*    */ 
/* 69 */           MessageGw msg = new MessageGw();
/* 70 */           msg.head = head;
/* 71 */           msg.setAFN((byte)request.getType());
/* 72 */           msg.data = HexDump.toByteBuffer(sdata);
/* 73 */           if (!(tp.equals("")))
/* 74 */             msg.setAux(HexDump.toByteBuffer(tp), true);
/* 75 */           msg.setCmdId(rp.getCmdId());
/* 76 */           msg.setMsgCount(1);
/* 77 */           rt.add(msg);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 81 */       throw new MessageEncodeException(e);
/*    */     }
/* 83 */     if ((rt != null) && (rt.size() > 0)) {
/* 84 */       IMessage[] msgs = new IMessage[rt.size()];
/* 85 */       rt.toArray(msgs);
/* 86 */       return msgs;
/*    */     }
/*    */ 
/* 89 */     return null;
/*    */   }
/*    */ }