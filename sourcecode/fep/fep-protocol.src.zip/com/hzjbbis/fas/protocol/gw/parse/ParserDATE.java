/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class ParserDATE
/*    */ {
/*    */   public static String parseValue(String data, String outputFormat, String inputFormat, int len)
/*    */   {
/* 23 */     String rt = "";
/*    */     try {
/* 25 */       SimpleDateFormat df = new SimpleDateFormat(inputFormat);
/* 26 */       data = DataSwitch.ReverseStringByByte(data.substring(0, len));
/* 27 */       Date dt = df.parse(data);
/* 28 */       df = new SimpleDateFormat(outputFormat);
/* 29 */       rt = df.format(dt);
/*    */     } catch (Exception e) {
/* 31 */       throw new MessageDecodeException(e);
/*    */     }
/* 33 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, String inputFormat, String outputFormat, int len)
/*    */   {
/* 45 */     String rt = "";
/*    */     try {
/* 47 */       SimpleDateFormat df = new SimpleDateFormat(inputFormat);
/* 48 */       Date dt = df.parse(data);
/* 49 */       df = new SimpleDateFormat(outputFormat);
/* 50 */       rt = df.format(dt);
/* 51 */       rt = DataSwitch.ReverseStringByByte(rt);
/*    */     } catch (Exception e) {
/* 53 */       throw new MessageEncodeException(e);
/*    */     }
/* 55 */     return rt;
/*    */   }
/*    */ }