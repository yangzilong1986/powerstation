/*     */ package com.hzjbbis.fas.protocol.gw.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataSwitch
/*     */ {
/*  16 */   private static final Log log = LogFactory.getLog(DataSwitch.class);
/*     */ 
/*     */   public static String IntToHex(String sInt, int len)
/*     */   {
/* 102 */     String sDataContent = "";
/*     */     try {
/* 104 */       sInt = Integer.toString(Integer.parseInt(sInt), 16).toUpperCase();
/* 105 */       sDataContent = StrStuff("0", len, sInt, "left");
/*     */     }
/*     */     catch (Exception e) {
/* 108 */       throw new MessageDecodeException(e);
/*     */     }
/* 110 */     return sDataContent;
/*     */   }
/*     */ 
/*     */   public static String ReverseStringByByte(String str) {
/* 114 */     String sOutput = "";
/*     */     try {
/* 116 */       if (str.length() % 2 == 0) {
/* 117 */         for (int i = 0; i < str.length() / 2; ++i) {
/* 118 */           sOutput = sOutput + str.substring(str.length() - ((i + 1) * 2), str.length() - (i * 2));
/*     */         }
/*     */       }
/*     */       else
/* 122 */         throw new MessageDecodeException("ReverseStringByByte() error,input:" + str);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 126 */       throw new MessageDecodeException(e);
/*     */     }
/* 128 */     return sOutput;
/*     */   }
/*     */ 
/*     */   public static String StrStuff(String str, int iLen, String sInput, String sSign) {
/* 132 */     String sOutput = "";
/*     */     try {
/* 134 */       int iLenStr = sInput.length();
/* 135 */       if (iLen > iLenStr) {
/* 136 */         for (int i = 0; i < iLen - iLenStr; ++i) {
/* 137 */           if (sSign.equals("left")) {
/* 138 */             sInput = str + sInput;
/*     */           }
/*     */           else {
/* 141 */             sInput = sInput + str;
/*     */           }
/*     */         }
/*     */       }
/* 145 */       else if (iLen < iLenStr) {
/* 146 */         if (sSign.equals("left")) {
/* 147 */           sInput = sInput.substring(iLenStr - iLen, iLenStr);
/*     */         }
/*     */         else {
/* 150 */           sInput = sInput.substring(0, iLen);
/*     */         }
/*     */       }
/* 153 */       sOutput = sInput;
/*     */     }
/*     */     catch (Exception e) {
/* 156 */       throw new MessageDecodeException(e);
/*     */     }
/* 158 */     return sOutput; }
/*     */ 
/*     */   public static String Fun8BinTo2Hex(String sBit8) {
/* 161 */     String sResult = "";
/* 162 */     String sTemp = "";
/*     */     try {
/*     */       try {
/* 165 */         for (int i = 0; i < 2; ++i) {
/* 166 */           sTemp = sBit8.substring(i * 4, i * 4 + 4);
/* 167 */           if (sTemp.equals("0000")) sTemp = "0";
/* 168 */           if (sTemp.equals("0001")) sTemp = "1";
/* 169 */           if (sTemp.equals("0010")) sTemp = "2";
/* 170 */           if (sTemp.equals("0011")) sTemp = "3";
/* 171 */           if (sTemp.equals("0100")) sTemp = "4";
/* 172 */           if (sTemp.equals("0101")) sTemp = "5";
/* 173 */           if (sTemp.equals("0110")) sTemp = "6";
/* 174 */           if (sTemp.equals("0111")) sTemp = "7";
/* 175 */           if (sTemp.equals("1000")) sTemp = "8";
/* 176 */           if (sTemp.equals("1001")) sTemp = "9";
/* 177 */           if (sTemp.equals("1010")) sTemp = "A";
/* 178 */           if (sTemp.equals("1011")) sTemp = "B";
/* 179 */           if (sTemp.equals("1100")) sTemp = "C";
/* 180 */           if (sTemp.equals("1101")) sTemp = "D";
/* 181 */           if (sTemp.equals("1110")) sTemp = "E";
/* 182 */           if (sTemp.equals("1111")) sTemp = "F";
/* 183 */           sResult = sResult + sTemp;
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 187 */         System.out.println("数据区解析出错Fun8BinTo2Hex:" + e.toString());
/*     */       }
/*     */ 
/* 191 */       return sResult; } finally {  }
/* 191 */     return sResult;
/*     */   }
/*     */ 
/*     */   public static String Fun2HexTo8Bin(String sBit8) {
/* 195 */     String sResult = "";
/* 196 */     String sTemp = "";
/*     */     try {
/*     */       try {
/* 199 */         for (int i = 0; i < 2; ++i) {
/* 200 */           sTemp = sBit8.substring(i, 1 + i);
/* 201 */           if (sTemp.toUpperCase().equals("0")) sTemp = "0000";
/* 202 */           if (sTemp.toUpperCase().equals("1")) sTemp = "0001";
/* 203 */           if (sTemp.toUpperCase().equals("2")) sTemp = "0010";
/* 204 */           if (sTemp.toUpperCase().equals("3")) sTemp = "0011";
/* 205 */           if (sTemp.toUpperCase().equals("4")) sTemp = "0100";
/* 206 */           if (sTemp.toUpperCase().equals("5")) sTemp = "0101";
/* 207 */           if (sTemp.toUpperCase().equals("6")) sTemp = "0110";
/* 208 */           if (sTemp.toUpperCase().equals("7")) sTemp = "0111";
/* 209 */           if (sTemp.toUpperCase().equals("8")) sTemp = "1000";
/* 210 */           if (sTemp.toUpperCase().equals("9")) sTemp = "1001";
/* 211 */           if (sTemp.toUpperCase().equals("A")) sTemp = "1010";
/* 212 */           if (sTemp.toUpperCase().equals("B")) sTemp = "1011";
/* 213 */           if (sTemp.toUpperCase().equals("C")) sTemp = "1100";
/* 214 */           if (sTemp.toUpperCase().equals("D")) sTemp = "1101";
/* 215 */           if (sTemp.toUpperCase().equals("E")) sTemp = "1110";
/* 216 */           if (sTemp.toUpperCase().equals("F")) sTemp = "1111";
/* 217 */           sResult = sResult + sTemp;
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 221 */         System.out.println("数据区解析出错Fun2HexTo8Bin:" + e.toString());
/*     */       }
/*     */ 
/* 225 */       return sResult; } finally {  }
/* 225 */     return sResult;
/*     */   }
/*     */ 
/*     */   public static String IncreaseDateTime(String sDateTime, int iIncreaseNo, int iIncreaseType) {
/* 229 */     String sResult = "";
/*     */     try {
/* 231 */       if (iIncreaseNo >= 0) {
/* 232 */         Calendar DateTime = Calendar.getInstance();
/*     */ 
/* 234 */         DateTime.set(Integer.parseInt(sDateTime.substring(0, 4)), Integer.parseInt(sDateTime.substring(4, 6)) - 1, Integer.parseInt(sDateTime.substring(6, 8)), Integer.parseInt(sDateTime.substring(8, 10)), Integer.parseInt(sDateTime.substring(10, 12)), 0);
/* 235 */         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*     */         try {
/* 237 */           switch (iIncreaseType)
/*     */           {
/*     */           case 2:
/* 238 */             DateTime.add(12, iIncreaseNo);
/* 239 */             break;
/*     */           case 3:
/* 240 */             DateTime.add(10, iIncreaseNo);
/* 241 */             break;
/*     */           case 4:
/* 242 */             DateTime.add(5, iIncreaseNo);
/* 243 */             break;
/*     */           case 5:
/* 244 */             DateTime.add(2, iIncreaseNo);
/*     */           }
/*     */ 
/* 247 */           sResult = formatter.format(DateTime.getTime());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 252 */           log.error("数据区解析IncreaseDateTime出错:" + e.toString());
/*     */         }
/*     */       } else {
/* 255 */         sResult = sDateTime;
/*     */       }
/*     */ 
/* 258 */       return sResult; } finally {  }
/* 258 */     return sResult;
/*     */   }
/*     */ }