/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserHTB
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       data = DataSwitch.ReverseStringByByte(data.substring(0, len));
/* 21 */       rt = "" + Integer.parseInt(data, 16);
/*    */     } catch (Exception e) {
/* 23 */       throw new MessageDecodeException(e);
/*    */     }
/* 25 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 35 */     String rt = "";
/*    */     try {
/* 37 */       rt = Integer.toString(Integer.parseInt(data), 16).toUpperCase();
/* 38 */       rt = DataSwitch.StrStuff("0", len, rt, "left");
/* 39 */       rt = DataSwitch.ReverseStringByByte(rt);
/*    */     } catch (Exception e) {
/* 41 */       throw new MessageEncodeException(e);
/*    */     }
/* 43 */     return rt;
/*    */   }
/*    */ }