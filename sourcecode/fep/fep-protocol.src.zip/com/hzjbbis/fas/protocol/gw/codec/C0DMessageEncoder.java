/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalGWAFN0DRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.util.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C0DMessageEncoder extends AbstractMessageEncoder
/*     */ {
/*     */   public IMessage[] encode(Object obj)
/*     */   {
/*     */     FaalGWAFN0DRequest request;
/*     */     String sdata;
/*     */     String tp;
/*     */     String date;
/*  28 */     List rt = new ArrayList();
/*     */     try {
/*  30 */       if (obj instanceof FaalRequest) {
/*  31 */         request = (FaalGWAFN0DRequest)obj;
/*  32 */         List rtuParams = request.getRtuParams();
/*  33 */         sdata = ""; tp = ""; date = "";
/*     */ 
/*  35 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/*  36 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*     */         }
/*  38 */         if ((request.getInterval() > 0) && (request.getCount() > 1)) {
/*  39 */           String interval = "";
/*  40 */           switch (request.getInterval())
/*     */           {
/*     */           case 1:
/*  41 */             interval = "FF"; break;
/*     */           case 5:
/*  42 */             interval = "FE"; break;
/*     */           case 15:
/*  43 */             interval = "01"; break;
/*     */           case 30:
/*  44 */             interval = "02"; break;
/*     */           case 60:
/*  45 */             interval = "03"; break;
/*     */           default:
/*  46 */             interval = "00";
/*     */           }
/*  48 */           date = DataItemCoder.constructor(request.getStartTime(), "A15") + interval + DataItemCoder.constructor(new StringBuilder().append("").append(request.getCount()).toString(), "HTB1");
/*     */         }
/*  51 */         else if (request.getStartTime().trim().length() == 10) {
/*  52 */           date = DataItemCoder.constructor(request.getStartTime(), "A20");
/*     */         } else {
/*  54 */           date = DataItemCoder.constructor(request.getStartTime(), "A21");
/*     */         }
/*  56 */         for (FaalRequestRtuParam rp : rtuParams) {
/*  57 */           int[] tn = rp.getTn();
/*  58 */           List params = rp.getParams();
/*  59 */           String codes = "";
/*  60 */           for (FaalRequestParam pm : params) {
/*  61 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(pm.getName());
/*  62 */             if (pdc == null) {
/*  63 */               if ((!(pm.getName().substring(0, 2).equals("0D"))) && (pm.getName().length() == 10))
/*  64 */                 pm.setName(pm.getName().substring(0, 8) + "XX");
/*  65 */               pdc = this.dataConfig.getDataItemConfig(pm.getName());
/*  66 */               if (pdc == null)
/*  67 */                 throw new MessageEncodeException("can not find cmd:" + pm.getName());
/*     */             }
/*  69 */             if (codes.indexOf(pdc.getParentCode()) < 0)
/*  70 */               codes = codes + "," + pdc.getParentCode();
/*     */           }
/*  72 */           if (codes.startsWith(","))
/*  73 */             codes = codes.substring(1);
/*  74 */           String[] codeList = codes.split(",");
/*  75 */           String[] sDADTList = DataItemCoder.getCodeFromNToN(tn, codeList);
/*  76 */           for (int i = 0; i < sDADTList.length; ++i) {
/*  77 */             int[] mps = DataItemParser.measuredPointParser(sDADTList[i].substring(0, 4));
/*  78 */             codeList = DataItemParser.dataCodeParser(sDADTList[i].substring(4, 8), "0D");
/*  79 */             sdata = sdata + sDADTList[i];
/*  80 */             for (int j = 0; j < mps.length; ++j) {
/*  81 */               for (int k = 0; k < codeList.length; ++k)
/*  82 */                 sdata = sdata + date;
/*     */             }
/*     */           }
/*  85 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/*  86 */           if (rtu == null) {
/*  87 */             throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */           }
/*  89 */           MessageGwHead head = new MessageGwHead();
/*     */ 
/*  91 */           head.rtua = rtu.getRtua();
/*     */ 
/*  93 */           MessageGw msg = new MessageGw();
/*  94 */           msg.head = head;
/*  95 */           msg.setAFN((byte)request.getType());
/*  96 */           msg.data = HexDump.toByteBuffer(sdata);
/*  97 */           if (!(tp.equals("")))
/*  98 */             msg.setAux(HexDump.toByteBuffer(tp), true);
/*  99 */           msg.setCmdId(rp.getCmdId());
/* 100 */           msg.setMsgCount(1);
/* 101 */           rt.add(msg);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 105 */       throw new MessageEncodeException(e);
/*     */     }
/* 107 */     if ((rt != null) && (rt.size() > 0)) {
/* 108 */       IMessage[] msgs = new IMessage[rt.size()];
/* 109 */       rt.toArray(msgs);
/* 110 */       return msgs;
/*     */     }
/*     */ 
/* 113 */     return null;
/*     */   }
/*     */ }