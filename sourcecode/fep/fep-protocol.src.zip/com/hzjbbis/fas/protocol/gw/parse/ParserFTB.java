/*     */ package com.hzjbbis.fas.protocol.gw.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class ParserFTB
/*     */ {
/*     */   public static String parseValue(String data, String format, int len)
/*     */   {
/*  19 */     String rt = "";
/*     */     try
/*     */     {
/*     */       int iLenSJGS;
/*  21 */       String tag = ""; String sZS = ""; String sXS = "";
/*  22 */       data = DataSwitch.ReverseStringByByte(data.substring(0, len));
/*  23 */       if (format.substring(0, 1).equals("C")) {
/*  24 */         tag = data.substring(0, 1);
/*  25 */         if ((Integer.parseInt(tag, 16) & 0x8) == 8) {
/*  26 */           tag = Integer.toString(Integer.parseInt(tag, 16) & 0x7);
/*  27 */           data = tag + data.substring(1, data.length());
/*  28 */           tag = "-";
/*     */         }
/*     */       }
/*     */ 
/*  32 */       int iPos = format.indexOf(46, 0);
/*  33 */       int iLenBCD = data.length();
/*  34 */       if (iPos != -1) {
/*  35 */         iLenSJGS = format.length() - 1;
/*  36 */         if ((iLenBCD == iLenSJGS) && (iLenBCD % 2 == 0)) {
/*  37 */           sZS = data.substring(0, iPos);
/*  38 */           if (iPos == 0) {
/*  39 */             sZS = "0";
/*     */           }
/*  41 */           sXS = data.substring(iPos, iLenBCD);
/*  42 */           rt = sZS + "." + sXS;
/*     */         }
/*     */         else {
/*  45 */           rt = "";
/*     */         }
/*     */       }
/*     */       else {
/*  49 */         iLenSJGS = format.length();
/*  50 */         if ((iLenBCD == iLenSJGS) && (iLenBCD % 2 == 0)) {
/*  51 */           rt = data;
/*     */         }
/*     */         else {
/*  54 */           rt = "";
/*     */         }
/*     */       }
/*  57 */       if ((tag.equals("-")) && (!(rt.equals(""))))
/*  58 */         rt = tag + rt;
/*     */     }
/*     */     catch (Exception e) {
/*  61 */       throw new MessageDecodeException(e);
/*     */     }
/*  63 */     return rt;
/*     */   }
/*     */ 
/*     */   public static String constructor(String data, String format, int len)
/*     */   {
/*  74 */     String rt = "";
/*     */     try {
/*  76 */       String tag = ""; String sZS = ""; String sXS = "";
/*  77 */       int iLenZS = 0; int iLenXS = 0;
/*  78 */       if (format.substring(0, 1).equals("C")) {
/*  79 */         if (data.substring(0, 1).equals("-")) {
/*  80 */           data = data.substring(1, data.length());
/*  81 */           tag = "-";
/*     */         }
/*     */         else {
/*  84 */           tag = "+";
/*     */         }
/*     */       }
/*  87 */       int iPos = format.indexOf(46, 0);
/*  88 */       if (iPos != -1) {
/*  89 */         iLenZS = format.substring(0, iPos).length();
/*  90 */         iLenXS = format.substring(iPos + 1, format.length()).length();
/*  91 */         iPos = data.indexOf(46, 0);
/*  92 */         if (iPos != -1) {
/*  93 */           sZS = DataSwitch.StrStuff("0", iLenZS, data.substring(0, iPos), "left");
/*  94 */           sXS = DataSwitch.StrStuff("0", iLenXS, data.substring(iPos + 1, data.length()), "right");
/*     */         }
/*     */         else {
/*  97 */           sZS = DataSwitch.StrStuff("0", iLenZS, data, "left");
/*  98 */           sXS = DataSwitch.StrStuff("0", iLenXS, sXS, "right");
/*     */         }
/* 100 */         rt = sZS + sXS;
/*     */       }
/*     */       else {
/* 103 */         iPos = data.indexOf(46, 0);
/* 104 */         iLenZS = format.length();
/* 105 */         if (iPos != -1) {
/* 106 */           sZS = DataSwitch.StrStuff("0", iLenZS, data.substring(0, iPos), "left");
/*     */         }
/*     */         else {
/* 109 */           sZS = DataSwitch.StrStuff("0", iLenZS, data, "left");
/*     */         }
/* 111 */         rt = sZS;
/*     */       }
/* 113 */       if (tag.equals("-")) {
/* 114 */         tag = Integer.toString(Integer.parseInt(rt.substring(0, 1), 16) | 0x8);
/* 115 */         rt = tag + rt.substring(1, rt.length());
/*     */       }
/* 117 */       else if (tag.equals("+")) {
/* 118 */         tag = Integer.toString(Integer.parseInt(rt.substring(0, 1), 16) & 0x7);
/* 119 */         rt = tag + rt.substring(1, rt.length());
/*     */       }
/* 121 */       rt = DataSwitch.ReverseStringByByte(rt);
/*     */     } catch (Exception e) {
/* 123 */       throw new MessageEncodeException(e);
/*     */     }
/* 125 */     return rt;
/*     */   }
/*     */ }