/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalGWAFN0ARequest;
/*     */ import com.hzjbbis.fas.model.FaalRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.util.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C0AMessageEncoder extends AbstractMessageEncoder
/*     */ {
/*     */   public IMessage[] encode(Object obj)
/*     */   {
/*     */     FaalGWAFN0ARequest request;
/*     */     String sdata;
/*     */     String tp;
/*     */     String param;
/*  30 */     List rt = new ArrayList();
/*     */     try {
/*  32 */       if (obj instanceof FaalRequest) {
/*  33 */         request = (FaalGWAFN0ARequest)obj;
/*  34 */         List rtuParams = request.getRtuParams();
/*  35 */         sdata = ""; tp = ""; param = "";
/*     */ 
/*  37 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/*  38 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*     */         }
/*  40 */         if ((request.getParam() != null) && (request.getParam().length >= 1)) {
/*  41 */           param = DataItemCoder.constructor("" + request.getParam().length, "HTB1");
/*  42 */           for (int i = 0; i < request.getParam().length; ++i) {
/*  43 */             param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getParam()[i]).toString(), "HTB1");
/*     */           }
/*     */         }
/*  46 */         for (FaalRequestRtuParam rp : rtuParams) {
/*  47 */           int[] tn = rp.getTn();
/*  48 */           List params = rp.getParams();
/*  49 */           String codes = "";
/*  50 */           for (Iterator i$ = params.iterator(); i$.hasNext(); )
/*     */           {
/*     */             int i;
/*  50 */             FaalRequestParam pm = (FaalRequestParam)i$.next();
/*  51 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(pm.getName());
/*  52 */             if ((pm.getName().equals("04F038")) || (pm.getName().equals("04F039"))) {
/*  53 */               if (!(param.equals(""))) {
/*  54 */                 param = DataItemCoder.constructor("" + request.getParam()[0], "HTB1");
/*  55 */                 param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getParam().length).toString(), "HTB1");
/*  56 */                 for (i = 1; i < request.getParam().length; ++i)
/*  57 */                   param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getParam()[i]).toString(), "HTB1");
/*     */               }
/*     */             }
/*  60 */             else if ((pm.getName().equals("04F010")) && 
/*  61 */               (!(param.equals("")))) {
/*  62 */               param = DataItemCoder.constructor("" + request.getParam().length, "HTB2");
/*  63 */               for (i = 0; i < request.getParam().length; ++i) {
/*  64 */                 param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getParam()[i]).toString(), "HTB2");
/*     */               }
/*     */             }
/*  67 */             if (codes.indexOf(pdc.getParentCode()) < 0)
/*  68 */               codes = codes + "," + pdc.getParentCode();
/*     */           }
/*  70 */           if (codes.startsWith(","))
/*  71 */             codes = codes.substring(1);
/*  72 */           String[] codeList = codes.split(",");
/*  73 */           String[] sDADTList = DataItemCoder.getCodeFromNToN(tn, codeList);
/*  74 */           for (int i = 0; i < sDADTList.length; ++i)
/*  75 */             sdata = sdata + sDADTList[i] + param;
/*  76 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/*  77 */           if (rtu == null) {
/*  78 */             throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */           }
/*  80 */           MessageGwHead head = new MessageGwHead();
/*     */ 
/*  82 */           head.rtua = rtu.getRtua();
/*     */ 
/*  84 */           MessageGw msg = new MessageGw();
/*  85 */           msg.head = head;
/*  86 */           msg.setAFN((byte)request.getType());
/*  87 */           msg.data = HexDump.toByteBuffer(sdata);
/*  88 */           if (!(tp.equals("")))
/*  89 */             msg.setAux(HexDump.toByteBuffer(tp), true);
/*  90 */           msg.setCmdId(rp.getCmdId());
/*  91 */           msg.setMsgCount(1);
/*  92 */           rt.add(msg);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  96 */       throw new MessageEncodeException(e);
/*     */     }
/*  98 */     if ((rt != null) && (rt.size() > 0)) {
/*  99 */       IMessage[] msgs = new IMessage[rt.size()];
/*     */ 
/* 101 */       rt.toArray(msgs);
/* 102 */       return msgs;
/*     */     }
/*     */ 
/* 105 */     return null;
/*     */   }
/*     */ }