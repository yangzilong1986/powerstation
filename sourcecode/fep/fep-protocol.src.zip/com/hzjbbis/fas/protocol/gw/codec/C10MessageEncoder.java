/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ import com.hzjbbis.fas.model.FaalGWAFN10Request;
/*     */ import com.hzjbbis.fas.model.FaalRequest;
/*     */ import com.hzjbbis.fas.model.FaalRequestParam;
/*     */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataSwitch;
/*     */ import com.hzjbbis.fas.protocol.meter.IMeterParser;
/*     */ import com.hzjbbis.fas.protocol.meter.MeterParserFactory;
/*     */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.util.HexDump;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class C10MessageEncoder extends AbstractMessageEncoder
/*     */ {
/*  33 */   private static Log log = LogFactory.getLog(C10MessageEncoder.class);
/*     */ 
/*     */   public IMessage[] encode(Object obj)
/*     */   {
/*     */     FaalGWAFN10Request request;
/*     */     String sdata;
/*     */     String tp;
/*     */     String param;
/*     */     String portstr;
/*     */     String pw;
/*     */     String sDADT;
/*  35 */     List rt = new ArrayList();
/*     */     try {
/*  37 */       if (obj instanceof FaalRequest) {
/*  38 */         request = (FaalGWAFN10Request)obj;
/*  39 */         List rtuParams = request.getRtuParams();
/*  40 */         sdata = ""; tp = ""; param = ""; portstr = ""; pw = "";
/*     */ 
/*  42 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/*  43 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*     */         }
/*  45 */         param = DataItemCoder.constructor("" + request.getPort(), "HTB1");
/*  46 */         param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getKzz()).toString(), "BS1");
/*  47 */         param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getMsgTimeout()).toString(), "BS1");
/*  48 */         param = param + DataItemCoder.constructor(new StringBuilder().append("").append(request.getByteTimeout()).toString(), "HTB1");
/*     */ 
/*  50 */         sDADT = DataItemCoder.getCodeFrom1To1(0, "10F001");
/*  51 */         for (FaalRequestRtuParam rp : rtuParams) {
/*  52 */           int[] tn = rp.getTn();
/*  53 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/*  54 */           if (rtu == null) {
/*  55 */             throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */           }
/*  57 */           if ((rtu.getHiAuthPassword() != null) && (rtu.getHiAuthPassword().length() == 32))
/*  58 */             pw = DataSwitch.ReverseStringByByte(rtu.getHiAuthPassword());
/*     */           else
/*  60 */             throw new MessageEncodeException("rtu HiAuthPassword is null");
/*  61 */           String[] codes = new String[rp.getParams().size()];
/*  62 */           for (int i = 0; i < rp.getParams().size(); ++i) {
/*  63 */             FaalRequestParam pm = (FaalRequestParam)rp.getParams().get(i);
/*  64 */             codes[i] = pm.getName();
/*     */           }
/*  66 */           for (i = 0; i < tn.length; ++i) {
/*  67 */             if (request.getPort() < 0) {
/*  68 */               portstr = getPortWithMpPara(rtu, "" + tn[i]);
/*     */ 
/*  70 */               param = DataItemCoder.constructor(portstr, "HTB1") + param.substring(2);
/*     */             }
/*  72 */             List meterFrames = createMeterFrame("" + tn[i], rtu, codes, request.getFixProto(), request.getFixAddre(), request.getBroadcastAddress(), request.getBroadcast());
/*  73 */             for (int j = 0; j < meterFrames.size(); ++j) {
/*  74 */               sdata = sDADT + param + DataItemCoder.constructor(new StringBuilder().append("").append(((String)meterFrames.get(j)).length() / 2).toString(), "HTB2") + ((String)meterFrames.get(j));
/*  75 */               MessageGwHead head = new MessageGwHead();
/*     */ 
/*  77 */               head.rtua = rtu.getRtua();
/*     */ 
/*  79 */               MessageGw msg = new MessageGw();
/*  80 */               msg.head = head;
/*  81 */               msg.setAFN((byte)request.getType());
/*  82 */               msg.data = HexDump.toByteBuffer(sdata + pw);
/*  83 */               if (!(tp.equals("")))
/*  84 */                 msg.setAux(HexDump.toByteBuffer(tp), true);
/*  85 */               msg.setCmdId(rp.getCmdId());
/*  86 */               msg.setMsgCount(meterFrames.size() * tn.length);
/*  87 */               rt.add(msg);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  93 */       throw new MessageEncodeException(e);
/*     */     }
/*  95 */     if ((rt != null) && (rt.size() > 0)) {
/*  96 */       IMessage[] msgs = new IMessage[rt.size()];
/*     */ 
/*  98 */       rt.toArray(msgs);
/*  99 */       return msgs;
/*     */     }
/*     */ 
/* 102 */     return null; }
/*     */ 
/*     */   private List<String> createMeterFrame(String tn, BizRtu rtu, String[] codes, String fixProto, String fixAddre, String broadcastAddress, boolean broadcast) {
/* 105 */     List meterFrame = new ArrayList();
/* 106 */     IMeterParser mparser = null;
/* 107 */     String pm = null;
/* 108 */     String maddr = null;
/* 109 */     if (fixProto == null)
/* 110 */       pm = getProtoWithMpPara(rtu, tn);
/*     */     else {
/* 112 */       pm = ParseTool.getMeterProtocol(fixProto);
/*     */     }
/* 114 */     if (fixAddre == null)
/* 115 */       maddr = getAddrWithMpPara(rtu, tn, broadcastAddress, broadcast);
/*     */     else {
/* 117 */       maddr = fixAddre;
/*     */     }
/*     */ 
/* 120 */     mparser = MeterParserFactory.getMeterParser(pm);
/* 121 */     if (mparser == null) {
/* 122 */       throw new MessageEncodeException("不支持的表规约");
/*     */     }
/*     */ 
/* 125 */     if ((pm.equalsIgnoreCase("20")) && 
/* 126 */       (maddr.length() > 2)) {
/* 127 */       String xxa = maddr.substring(maddr.length() - 2);
/* 128 */       if (xxa.equalsIgnoreCase("AA"))
/*     */       {
/* 130 */         maddr = maddr.substring(0, 2);
/*     */       }
/*     */       else maddr = xxa;
/*     */ 
/*     */     }
/*     */ 
/* 137 */     DataItem dipara = new DataItem();
/* 138 */     dipara.addProperty("point", maddr);
/* 139 */     String[] dks = null;
/* 140 */     if (fixProto.equals("30")) {
/* 141 */       dks = mparser.getMeterCode(codes);
/*     */     }
/*     */     else {
/* 144 */       dks = mparser.convertDataKey(codes);
/*     */     }
/* 146 */     int msgcount = 0;
/* 147 */     for (int k = 0; (k < dks.length) && 
/* 148 */       (dks[k] != null); ++k) {
/* 148 */       if (dks[k].length() <= 0) {
/*     */         break;
/*     */       }
/* 151 */       byte[] cmd = mparser.constructor(new String[] { dks[k] }, dipara);
/* 152 */       if (cmd == null) {
/* 153 */         StringBuffer se = new StringBuffer();
/* 154 */         for (int j = 0; j < codes.length; ++j) {
/* 155 */           se.append(codes[j]);
/* 156 */           se.append(" ");
/*     */         }
/* 158 */         throw new MessageEncodeException("不支持召测的表规约数据：" + se.toString() + "  RTU:" + ParseTool.IntToHex4(rtu.getRtua()));
/*     */       }
/*     */ 
/* 161 */       String frame = HexDump.hexDumpCompact(cmd, 0, cmd.length);
/* 162 */       if (!(fixProto.equals("20")))
/* 163 */         frame = "FEFEFEFE" + frame;
/* 164 */       meterFrame.add(frame);
/*     */ 
/* 166 */       ++msgcount;
/*     */     }
/* 168 */     return meterFrame;
/*     */   }
/*     */ 
/*     */   private String getProtoWithMpPara(BizRtu rtu, String tn) {
/* 172 */     String proto = null;
/*     */ 
/* 174 */     MeasuredPoint mp = rtu.getMeasuredPoint(tn);
/* 175 */     if (mp == null) {
/* 176 */       throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */     }
/*     */ 
/* 179 */     if (mp.getAtrProtocol() == null) {
/* 180 */       log.error("表规约缺失，将使用默认规约类型------RTU:" + ParseTool.IntToHex4(rtu.getRtua()));
/* 181 */       proto = ParseTool.getMeterProtocol("20");
/*     */     } else {
/* 183 */       proto = ParseTool.getMeterProtocol(mp.getAtrProtocol());
/*     */     }
/*     */ 
/* 186 */     return proto;
/*     */   }
/*     */ 
/*     */   private String getPortWithMpPara(BizRtu rtu, String tn) {
/* 190 */     String port = null;
/* 191 */     MeasuredPoint mp = rtu.getMeasuredPoint(tn);
/* 192 */     if (mp == null) {
/* 193 */       throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */     }
/* 195 */     port = mp.getAtrPort();
/* 196 */     return port;
/*     */   }
/*     */ 
/*     */   private String getAddrWithMpPara(BizRtu rtu, String tn, String broadcastAddress, boolean broadcast)
/*     */   {
/*     */     MeasuredPoint mp;
/* 200 */     String maddr = null;
/* 201 */     if (broadcast) {
/* 202 */       if (broadcastAddress != null) {
/* 203 */         maddr = broadcastAddress;
/*     */       } else {
/* 205 */         mp = rtu.getMeasuredPoint(tn);
/* 206 */         if (mp == null) {
/* 207 */           throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */         }
/* 209 */         maddr = getBroadcastAddress(mp);
/*     */       }
/*     */     } else {
/* 212 */       mp = rtu.getMeasuredPoint(tn);
/* 213 */       if (mp == null) {
/* 214 */         throw new MessageEncodeException("指定测量点不存在！终端--" + ParseTool.IntToHex4(rtu.getRtua()) + "  测量点--" + tn);
/*     */       }
/* 216 */       if (mp.getAtrAddress() == null)
/* 217 */         maddr = getBroadcastAddress(mp);
/*     */       else {
/* 219 */         maddr = mp.getAtrAddress();
/*     */       }
/*     */     }
/* 222 */     return maddr;
/*     */   }
/*     */ 
/*     */   private String getBroadcastAddress(MeasuredPoint mp) {
/* 226 */     String maddr = null;
/* 227 */     if (mp.getAtrProtocol() == null) {
/* 228 */       maddr = "FF";
/*     */     } else {
/* 230 */       if (mp.getAtrProtocol().equalsIgnoreCase("10")) {
/* 231 */         maddr = "999999999999";
/*     */       }
/* 233 */       if (mp.getAtrProtocol().equalsIgnoreCase("20")) {
/* 234 */         maddr = "FF";
/*     */       }
/* 236 */       if (mp.getAtrProtocol().equalsIgnoreCase("40")) {
/* 237 */         maddr = "FF";
/*     */       }
/*     */     }
/* 240 */     return maddr;
/*     */   }
/*     */ }