/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserA3
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       data = DataSwitch.ReverseStringByByte(data.substring(0, len));
/* 21 */       String tag = data.substring(0, 1);
/* 22 */       int unit = (Integer.parseInt(tag, 16) & 0x4) >> 2;
/* 23 */       if ((Integer.parseInt(tag, 16) & 0x1) == 1)
/* 24 */         tag = "-";
/*    */       else
/* 26 */         tag = "+";
/* 27 */       rt = "" + unit + tag + data.substring(1, 8);
/*    */     } catch (Exception e) {
/* 29 */       throw new MessageDecodeException(e);
/*    */     }
/* 31 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 41 */     String rt = "";
/*    */     try {
/* 43 */       int unit = Integer.parseInt(data.substring(0, 1)) << 2;
/* 44 */       if (data.substring(1, 2).equals("-"))
/* 45 */         unit += 1;
/* 46 */       data = data.substring(2);
/* 47 */       rt = unit + DataSwitch.StrStuff("0", len - 1, data, "left");
/* 48 */       rt = DataSwitch.ReverseStringByByte(rt);
/*    */     } catch (Exception e) {
/* 50 */       throw new MessageEncodeException(e);
/*    */     }
/* 52 */     return rt;
/*    */   }
/*    */ }