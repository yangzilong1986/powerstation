/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserIP
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       data = data.substring(0, len);
/* 21 */       for (int i = 0; i < 4; ++i)
/* 22 */         rt = rt + ParserHTB.parseValue(data.substring(i * 2, i * 2 + 2), 2) + ".";
/* 23 */       data = data.substring(8);
/* 24 */       rt = rt.substring(0, rt.length() - 1) + ":" + ParserHTB.parseValue(data.substring(0, 4), 4);
/*    */     } catch (Exception e) {
/* 26 */       throw new MessageDecodeException(e);
/*    */     }
/* 28 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 38 */     String rt = "";
/*    */     try {
/* 40 */       String[] strs = data.split(":");
/* 41 */       if (strs.length == 2) {
/* 42 */         String[] ips = strs[0].trim().split("\\.");
/* 43 */         for (int i = 0; i < ips.length; ++i)
/* 44 */           rt = rt + ParserHTB.constructor(ips[i].trim(), 2);
/* 45 */         rt = rt + ParserHTB.constructor(strs[1].trim(), 4);
/*    */       }
/*    */       else {
/* 48 */         throw new MessageEncodeException("IP is illegal:" + data); }
/*    */     } catch (Exception e) {
/* 50 */       throw new MessageEncodeException(e);
/*    */     }
/* 52 */     return rt;
/*    */   }
/*    */ }