/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.model.HostCommandResult;
/*     */ import com.hzjbbis.fas.protocol.data.DataItem;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataValue;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*     */ import com.hzjbbis.fas.protocol.meter.BbMeterFrame;
/*     */ import com.hzjbbis.fas.protocol.meter.IMeterParser;
/*     */ import com.hzjbbis.fas.protocol.meter.MeterParserFactory;
/*     */ import com.hzjbbis.fas.protocol.meter.ZjMeterFrame;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C10MessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  38 */     HostCommand hc = new HostCommand();
/*  39 */     List value = new ArrayList();
/*     */     try {
/*  41 */       String data = ParseTool.getGwData(message);
/*  42 */       MessageGw msg = (MessageGw)message;
/*  43 */       if (msg.head.seq_tpv == 1)
/*  44 */         data = data.substring(0, data.length() - 12);
/*  45 */       if (msg.head.c_acd == 1)
/*  46 */         data = data.substring(0, data.length() - 4);
/*  47 */       data = data.substring(8);
/*  48 */       data = data.substring(2);
/*  49 */       int len = Integer.parseInt(DataItemParser.parseValue(data.substring(0, 4), "HTB2").getValue());
/*  50 */       data = data.substring(4);
/*  51 */       data = data.substring(0, len * 2);
/*  52 */       byte[] datas = HexDump.toByteBuffer(data).array();
/*  53 */       if ((datas != null) && (datas.length > 0)) {
/*  54 */         int rtua = ((MessageGw)message).head.rtua;
/*  55 */         BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(((MessageGw)message).head.rtua);
/*  56 */         if (rtu == null) {
/*  57 */           throw new MessageDecodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtua));
/*     */         }
/*     */ 
/*  60 */         String pm = getMeterProtocol(datas, 0, datas.length);
/*  61 */         IMeterParser mparser = MeterParserFactory.getMeterParser(pm);
/*  62 */         if (mparser == null) {
/*  63 */           throw new MessageDecodeException("不支持的表规约：" + pm);
/*     */         }
/*  65 */         Object[] dis = mparser.parser(datas, 0, datas.length);
/*  66 */         if ((dis != null) && (dis.length > 0)) {
/*  67 */           for (int i = 0; i < dis.length; ++i) {
/*  68 */             DataItem di = (DataItem)dis[i];
/*  69 */             String key = (String)di.getProperty("datakey");
/*  70 */             if (key == null) continue; if (key.length() < 4) {
/*     */               continue;
/*     */             }
/*  73 */             boolean called = true;
/*  74 */             if (called) {
/*  75 */               HostCommandResult hcr = new HostCommandResult();
/*  76 */               hcr.setCode(key);
/*  77 */               if (di.getProperty("value") == null)
/*  78 */                 hcr.setValue(null);
/*     */               else {
/*  80 */                 hcr.setValue(di.getProperty("value").toString());
/*     */               }
/*  82 */               hcr.setCommandId(hc.getId());
/*  83 */               value.add(hcr);
/*     */             }
/*     */           }
/*     */         }
/*  87 */         hc.setStatus("1");
/*  88 */         hc.setResults(value);
/*     */       }
/*     */       else {
/*  91 */         hc.setStatus("16");
/*  92 */         hc.setResults(null);
/*     */       }
/*     */     } catch (Exception e) {
/*  95 */       throw new MessageDecodeException(e);
/*     */     }
/*  97 */     return hc;
/*     */   }
/*     */ 
/*     */   private String getMeterProtocol(byte[] data, int loc, int len) {
/* 101 */     String Protocol = "";
/* 102 */     BbMeterFrame bbFrame = new BbMeterFrame();
/* 103 */     bbFrame.parse(data, loc, len);
/* 104 */     if (bbFrame.getDatalen() > 0) {
/* 105 */       Protocol = "BBMeter";
/*     */     } else {
/* 107 */       ZjMeterFrame zjFrame = new ZjMeterFrame();
/* 108 */       zjFrame.parse(data, loc, len);
/* 109 */       if (zjFrame.getDatalen() > 0) {
/* 110 */         Protocol = "ZJMeter";
/*     */       }
/*     */     }
/* 113 */     return Protocol;
/*     */   }
/*     */ }