/*      */ package com.hzjbbis.fas.protocol.gw.parse;
/*      */ 
/*      */ import com.hzjbbis.fk.message.IMessage;
/*      */ import com.hzjbbis.fk.message.gw.MessageGw;
/*      */ import com.hzjbbis.fk.message.zj.MessageZj;
/*      */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*      */ import com.hzjbbis.util.HexDump;
/*      */ import java.net.Inet4Address;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class ParseTool
/*      */ {
/*   23 */   public static final String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
/*      */   public static final double FRACTION_TIMES_10 = 10.0D;
/*      */   public static final double FRACTION_TIMES_100 = 100.0D;
/*      */   public static final double FRACTION_TIMES_1000 = 1000.0D;
/*      */   public static final double FRACTION_TIMES_10000 = 10000.0D;
/*   28 */   public static final double[] fraction = { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D };
/*   29 */   public static final int[] days = { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*      */   public static final String METER_PROTOCOL_BB = "10";
/*      */   public static final String METER_PROTOCOL_ZJ = "20";
/*      */   public static final String METER_PROTOCOL_SM = "40";
/*   34 */   private static final Log log = LogFactory.getLog(ParseTool.class);
/*   35 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*      */ 
/*      */   public static String BytesToHex(byte[] data, int start, int len)
/*      */   {
/*   45 */     StringBuffer sb = new StringBuffer();
/*   46 */     for (int i = start; i < start + len; ++i) {
/*   47 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*   48 */       sb.append(hex[(data[i] & 0xF)]);
/*   49 */       sb.append(" ");
/*      */     }
/*   51 */     return sb.substring(0, sb.length() - 1);
/*      */   }
/*      */ 
/*      */   public static String ByteToHex(byte data) {
/*   55 */     String bt = "";
/*   56 */     bt = hex[((data & 0xF0) >> 4)] + hex[(data & 0xF)];
/*   57 */     return bt;
/*      */   }
/*      */ 
/*      */   public static String BytesToHexL(byte[] data, int start, int len)
/*      */   {
/*   68 */     StringBuffer sb = new StringBuffer();
/*   69 */     for (int i = start; i < start + len; ++i) {
/*   70 */       sb.append(hex[((data[i] & 0xF0) >> 4)]);
/*   71 */       sb.append(hex[(data[i] & 0xF)]);
/*      */     }
/*   73 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesToHexC(byte[] data, int start, int len)
/*      */   {
/*   84 */     StringBuffer sb = new StringBuffer();
/*   85 */     int loc = start + len - 1;
/*   86 */     for (int i = 0; i < len; ++i) {
/*   87 */       sb.append(hex[((data[loc] & 0xF0) >> 4)]);
/*   88 */       sb.append(hex[(data[loc] & 0xF)]);
/*   89 */       --loc;
/*      */     }
/*   91 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesToHexC(byte[] data, int start, int len, byte invalid)
/*      */   {
/*  103 */     StringBuffer sb = new StringBuffer();
/*  104 */     int loc = start + len - 1;
/*  105 */     for (int i = 0; i < len; ++i) {
/*  106 */       if (data[loc] != invalid) {
/*  107 */         sb.append(hex[((data[loc] & 0xF0) >> 4)]);
/*  108 */         sb.append(hex[(data[loc] & 0xF)]);
/*      */       }
/*  110 */       --loc;
/*      */     }
/*  112 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int BCDToDecimal(byte bcd)
/*      */   {
/*  121 */     int high = (bcd & 0xF0) >>> 4;
/*  122 */     int low = bcd & 0xF;
/*  123 */     if ((high > 9) || (low > 9)) {
/*  124 */       return -1;
/*      */     }
/*  126 */     return (high * 10 + low);
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimal(byte[] data, int start, int len)
/*      */   {
/*  137 */     int rt = 0;
/*  138 */     for (int i = 0; i < len; ++i) {
/*  139 */       rt *= 100;
/*      */ 
/*  141 */       int bval = BCDToDecimal(data[(start + len - i - 1)]);
/*  142 */       if (bval < 0) {
/*  143 */         rt = -1;
/*  144 */         break;
/*      */       }
/*  146 */       rt += bval;
/*      */     }
/*  148 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimalC(byte[] data, int start, int len)
/*      */   {
/*  159 */     int rt = 0;
/*  160 */     for (int i = start; i < start + len; ++i) {
/*  161 */       rt *= 100;
/*  162 */       int bval = BCDToDecimal(data[i]);
/*  163 */       if (bval < 0) {
/*  164 */         rt = -1;
/*  165 */         break;
/*      */       }
/*  167 */       rt += bval;
/*      */     }
/*  169 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nBcdToDecimalS(byte[] data, int start, int len)
/*      */   {
/*  180 */     NumberFormat nf = NumberFormat.getInstance();
/*  181 */     nf.setMaximumFractionDigits(2);
/*  182 */     int rt = 0;
/*      */ 
/*  184 */     int loc1 = start + len - 1;
/*  185 */     for (int i = 0; i < len; ++i)
/*      */     {
/*      */       int bval;
/*  186 */       rt *= 100;
/*      */ 
/*  193 */       if (i > 0)
/*  194 */         bval = BCDToDecimal(data[(loc1 - i)]);
/*      */       else {
/*  196 */         bval = BCDToDecimal((byte)(data[(loc1 - i)] & 0xF));
/*      */       }
/*  198 */       if (bval < 0) {
/*  199 */         rt = -1;
/*  200 */         break;
/*      */       }
/*  202 */       rt += bval;
/*      */     }
/*      */ 
/*  205 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nByteToInt(byte[] data, int start, int len)
/*      */   {
/*  216 */     int rt = 0;
/*  217 */     for (int i = 0; i < len; ++i) {
/*  218 */       rt <<= 8;
/*  219 */       rt += (data[(start + len - i - 1)] & 0xFF);
/*      */     }
/*  221 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int nByteToIntS(byte[] data, int start, int len)
/*      */   {
/*  232 */     int rt = 0;
/*  233 */     int loc = start + len - 1;
/*  234 */     for (int i = 0; i < len; ++i) {
/*  235 */       rt <<= 8;
/*  236 */       if (i > 0)
/*  237 */         rt += (data[(loc - i)] & 0xFF);
/*      */       else {
/*  239 */         rt += (data[(loc - i)] & 0x7F);
/*      */       }
/*      */     }
/*  242 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int HexToDecimal(String hex)
/*      */   {
/*  252 */     int rt = 0;
/*  253 */     for (int i = 0; i < hex.length(); ++i) {
/*  254 */       rt <<= 4;
/*  255 */       rt += CharToDecimal(hex.substring(i, i + 1));
/*      */     }
/*  257 */     return rt;
/*      */   }
/*      */ 
/*      */   public static String toPhoneCode(byte[] data, int index, int len, int invalid)
/*      */   {
/*  269 */     StringBuffer sb = new StringBuffer();
/*  270 */     int valid = index + len - 1;
/*  271 */     for (int i = index + len - 1; i >= index; --i) {
/*  272 */       if ((data[i] & 0xFF) != invalid) {
/*  273 */         valid = i;
/*  274 */         break;
/*      */       }
/*      */     }
/*  277 */     if (valid >= index) {
/*  278 */       if ((data[valid] & 0xF0) != 0) {
/*  279 */         sb.append(hex[((data[valid] & 0xF0) >> 4)]);
/*      */       }
/*  281 */       sb.append(hex[(data[valid] & 0xF)]);
/*  282 */       --valid;
/*      */     }
/*  284 */     for (int j = valid; j >= index; --j) {
/*  285 */       sb.append(hex[((data[j] & 0xF0) >> 4)]);
/*  286 */       sb.append(hex[(data[j] & 0xF)]);
/*      */     }
/*  288 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int CharToDecimalB(String c) {
/*  292 */     int rt = 0;
/*  293 */     int head = 0;
/*  294 */     int tail = 15;
/*  295 */     rt = head + tail >> 1;
/*  296 */     while (!(hex[rt].equals(c))) {
/*  297 */       if (head == tail) {
/*      */         break;
/*      */       }
/*      */ 
/*  301 */       int var = c.compareTo(hex[rt]);
/*  302 */       if (var == 0) {
/*      */         break;
/*      */       }
/*  305 */       if (var > 0) {
/*  306 */         if (rt == head) {
/*  307 */           rt = tail;
/*  308 */           break;
/*      */         }
/*  310 */         head = rt;
/*  311 */         rt = head + tail >> 1;
/*      */       } else {
/*  313 */         tail = rt;
/*  314 */         rt = head + tail >> 1;
/*      */       }
/*      */     }
/*  317 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int CharToDecimal(String hex) {
/*  321 */     int rt = 0;
/*  322 */     if (hex.equals("0")) {
/*  323 */       return 0;
/*      */     }
/*  325 */     if (hex.equals("1")) {
/*  326 */       return 1;
/*      */     }
/*  328 */     if (hex.equals("2")) {
/*  329 */       return 2;
/*      */     }
/*  331 */     if (hex.equals("3")) {
/*  332 */       return 3;
/*      */     }
/*  334 */     if (hex.equals("4")) {
/*  335 */       return 4;
/*      */     }
/*  337 */     if (hex.equals("5")) {
/*  338 */       return 5;
/*      */     }
/*  340 */     if (hex.equals("6")) {
/*  341 */       return 6;
/*      */     }
/*  343 */     if (hex.equals("7")) {
/*  344 */       return 7;
/*      */     }
/*  346 */     if (hex.equals("8")) {
/*  347 */       return 8;
/*      */     }
/*  349 */     if (hex.equals("9")) {
/*  350 */       return 9;
/*      */     }
/*  352 */     if ((hex.equals("A")) || (hex.equals("a"))) {
/*  353 */       return 10;
/*      */     }
/*  355 */     if ((hex.equals("B")) || (hex.equals("b"))) {
/*  356 */       return 11;
/*      */     }
/*  358 */     if ((hex.equals("C")) || (hex.equals("c"))) {
/*  359 */       return 12;
/*      */     }
/*  361 */     if ((hex.equals("D")) || (hex.equals("d"))) {
/*  362 */       return 13;
/*      */     }
/*  364 */     if ((hex.equals("E")) || (hex.equals("e"))) {
/*  365 */       return 14;
/*      */     }
/*  367 */     if ((hex.equals("F")) || (hex.equals("f"))) {
/*  368 */       return 15;
/*      */     }
/*  370 */     return rt;
/*      */   }
/*      */ 
/*      */   public static String IntToHex(int data)
/*      */   {
/*  379 */     StringBuffer sb = new StringBuffer();
/*  380 */     sb.append(hex[((data & 0xF000) >>> 12)]);
/*  381 */     sb.append(hex[((data & 0xF00) >>> 8)]);
/*  382 */     sb.append(hex[((data & 0xF0) >>> 4)]);
/*  383 */     sb.append(hex[(data & 0xF)]);
/*  384 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String IntToHex4(int data)
/*      */   {
/*  393 */     StringBuffer sb = new StringBuffer();
/*  394 */     sb.append(hex[((data & 0xF0000000) >>> 28)]);
/*  395 */     sb.append(hex[((data & 0xF000000) >>> 24)]);
/*  396 */     sb.append(hex[((data & 0xF00000) >>> 20)]);
/*  397 */     sb.append(hex[((data & 0xF0000) >>> 16)]);
/*  398 */     sb.append(hex[((data & 0xF000) >>> 12)]);
/*  399 */     sb.append(hex[((data & 0xF00) >>> 8)]);
/*  400 */     sb.append(hex[((data & 0xF0) >>> 4)]);
/*  401 */     sb.append(hex[(data & 0xF)]);
/*  402 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String ByteBit(byte data)
/*      */   {
/*  411 */     StringBuffer sb = new StringBuffer();
/*  412 */     int bd = data & 0xFF;
/*  413 */     for (int i = 0; i < 8; ++i) {
/*  414 */       if ((bd & 0x80) > 0)
/*  415 */         sb.append("1");
/*      */       else {
/*  417 */         sb.append("0");
/*      */       }
/*  419 */       bd <<= 1;
/*      */     }
/*  421 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String ByteBitC(byte data)
/*      */   {
/*  430 */     StringBuffer sb = new StringBuffer();
/*  431 */     int bd = data & 0xFF;
/*  432 */     for (int i = 0; i < 8; ++i) {
/*  433 */       if ((bd & 0x1) > 0)
/*  434 */         sb.append("1");
/*      */       else {
/*  436 */         sb.append("0");
/*      */       }
/*  438 */       bd >>>= 1;
/*      */     }
/*  440 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBit(byte[] data)
/*      */   {
/*  449 */     StringBuffer sb = new StringBuffer();
/*  450 */     int len = data.length;
/*  451 */     for (int i = 0; i < len; ++i) {
/*  452 */       sb.append(ByteBit(data[(len - i - 1)]));
/*      */     }
/*  454 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBit(byte[] data, int start, int len)
/*      */   {
/*  465 */     StringBuffer sb = new StringBuffer();
/*  466 */     int loc = start + len - 1;
/*  467 */     for (int i = 0; i < len; ++i) {
/*  468 */       sb.append(ByteBit(data[loc]));
/*  469 */       --loc;
/*      */     }
/*  471 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String BytesBitC(byte[] data, int start, int len)
/*      */   {
/*  482 */     StringBuffer sb = new StringBuffer();
/*  483 */     int loc = start;
/*  484 */     for (int i = 0; i < len; ++i) {
/*  485 */       sb.append(ByteBitC(data[loc]));
/*  486 */       ++loc;
/*      */     }
/*  488 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static int bitToBytes(byte[] frame, String bits, int pos)
/*      */   {
/*  499 */     int rt = -1;
/*      */     try {
/*  501 */       int vlen = bits.length();
/*  502 */       boolean valid = true;
/*  503 */       for (int i = 0; i < vlen; ++i) {
/*  504 */         if (bits.substring(i, i + 1).equals("0")) continue; if (bits.substring(i, i + 1).equals("1")) {
/*      */           continue;
/*      */         }
/*  507 */         valid = false;
/*  508 */         break;
/*      */       }
/*      */ 
/*  511 */       if ((valid) && ((vlen & 0x7) == 0)) {
/*  512 */         int blen = 0;
/*  513 */         int len = vlen >>> 3;
/*  514 */         int iloc = pos + len - 1;
/*  515 */         while (blen < vlen) {
/*  516 */           frame[iloc] = bitToByte(bits.substring(blen, blen + 8));
/*  517 */           blen += 8;
/*  518 */           --iloc;
/*      */         }
/*  520 */         rt = len;
/*      */       }
/*  522 */       return rt;
/*      */     } catch (Exception e) {
/*  524 */       log.error("bits to bytes", e);
/*      */     }
/*  526 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int bitToBytesC(byte[] frame, String bits, int pos)
/*      */   {
/*  537 */     int rt = -1;
/*      */     try {
/*  539 */       int vlen = bits.length();
/*  540 */       boolean valid = true;
/*  541 */       for (int i = 0; i < vlen; ++i) {
/*  542 */         if (bits.substring(i, i + 1).equals("0")) continue; if (bits.substring(i, i + 1).equals("1")) {
/*      */           continue;
/*      */         }
/*  545 */         valid = false;
/*  546 */         break;
/*      */       }
/*      */ 
/*  549 */       if ((valid) && ((vlen & 0x7) == 0)) {
/*  550 */         int blen = 0;
/*  551 */         int len = vlen >>> 3;
/*  552 */         int iloc = pos;
/*  553 */         while (blen < vlen) {
/*  554 */           frame[iloc] = bitToByteC(bits.substring(blen, blen + 8));
/*  555 */           blen += 8;
/*  556 */           ++iloc;
/*      */         }
/*  558 */         rt = len;
/*      */       }
/*  560 */       return rt;
/*      */     } catch (Exception e) {
/*  562 */       log.error("bits to bytes", e);
/*      */     }
/*  564 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte bitToByte(String value)
/*      */   {
/*  573 */     byte rt = 0;
/*  574 */     byte[] aa = value.getBytes();
/*  575 */     for (int i = 0; i < aa.length; ++i) {
/*  576 */       rt = (byte)(rt << 1);
/*  577 */       rt = (byte)(rt + AsciiToInt(aa[i]));
/*      */     }
/*  579 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte bitToByteC(String value)
/*      */   {
/*  588 */     byte rt = 0;
/*  589 */     byte[] aa = value.getBytes();
/*  590 */     for (int i = aa.length - 1; i >= 0; --i) {
/*  591 */       rt = (byte)(rt << 1);
/*  592 */       rt = (byte)(rt + AsciiToInt(aa[i]));
/*      */     }
/*  594 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte IntToBcd(int data)
/*      */   {
/*  603 */     byte rt = 0;
/*  604 */     int i = data;
/*  605 */     i %= 100;
/*  606 */     rt = (byte)(i % 10 + (i / 10 << 4));
/*  607 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void IntToBcd(byte[] frame, int value, int loc, int len)
/*      */   {
/*  618 */     int val = value;
/*  619 */     int valxx = val % 100;
/*  620 */     for (int i = 0; i < len; ++i) {
/*  621 */       frame[(loc + i)] = (byte)(valxx % 10 + (valxx / 10 << 4));
/*  622 */       val /= 100;
/*  623 */       valxx = val % 100;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void IntToBcdC(byte[] frame, int value, int loc, int len)
/*      */   {
/*  635 */     int val = value;
/*  636 */     int valxx = val % 100;
/*  637 */     int start = loc + len - 1;
/*  638 */     for (int i = 0; i < len; ++i) {
/*  639 */       frame[start] = (byte)(valxx % 10 + (valxx / 10 << 4));
/*  640 */       val /= 100;
/*  641 */       valxx = val % 100;
/*  642 */       --start;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte StringToBcd(String data)
/*      */   {
/*  652 */     byte rt = 0;
/*      */     try {
/*  654 */       int i = Integer.parseInt(data);
/*  655 */       rt = IntToBcd(i);
/*      */     } catch (Exception e) {
/*  657 */       e.printStackTrace();
/*      */     }
/*  659 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int ByteToFlag(byte data)
/*      */   {
/*  668 */     int rt = 0;
/*  669 */     int val = data & 0xFF;
/*  670 */     int flag = 1;
/*  671 */     if (data > 0) {
/*  672 */       rt = 1;
/*  673 */       while ((flag & val) <= 0) {
/*  674 */         ++rt;
/*  675 */         flag <<= 1;
/*      */       }
/*      */     }
/*  678 */     return rt;
/*      */   }
/*      */ 
/*      */   public static double ByteToPercent(byte data)
/*      */   {
/*  687 */     double rt = data & 0x7F;
/*  688 */     if ((data & 0x80) > 0) {
/*  689 */       rt *= -1.0D;
/*      */     }
/*  691 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void StringToBcds(byte[] frame, int loc, String data)
/*      */   {
/*  700 */     String row = data;
/*  701 */     if (row.length() > 0) {
/*  702 */       if (row.length() % 2 > 0) {
/*  703 */         row = "0" + row;
/*      */       }
/*  705 */       int len = row.length() / 2;
/*      */ 
/*  707 */       for (int i = 0; i < len; ++i) {
/*  708 */         frame[(loc + len - i - 1)] = StringToBcd(row.substring(i << 1, i + 1 << 1));
/*      */       }
/*  710 */       row = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void StringToBcds1(byte[] frame, int loc, String data)
/*      */   {
/*  720 */     String row = data;
/*  721 */     if (row.length() > 0) {
/*  722 */       if (row.length() % 2 > 0) {
/*  723 */         row = "0" + row;
/*      */       }
/*  725 */       int len = row.length() / 2;
/*      */ 
/*  727 */       for (int i = 0; i < len; ++i) {
/*  728 */         frame[(loc + len - i - 1)] = StringToBcd(row.substring(i << 1, i + 1 << 1));
/*      */       }
/*  730 */       row = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte[] StringToBcdDec(String data) {
/*  735 */     if ((null == data) || (0 == data.length()))
/*  736 */       return new byte[0];
/*  737 */     if (0 != data.length() % 2)
/*  738 */       data = "0" + data;
/*  739 */     byte[] ret = new byte[data.length() / 2];
/*  740 */     int j = ret.length - 1;
/*      */ 
/*  742 */     for (int i = 0; i < data.length() - 1; i += 2) {
/*  743 */       byte b1 = (byte)(data.charAt(i) - '0');
/*  744 */       byte b2 = (byte)(data.charAt(i + 1) - '0');
/*  745 */       ret[(j--)] = (byte)((b1 << 4) + b2);
/*      */     }
/*  747 */     return ret;
/*      */   }
/*      */ 
/*      */   public static void StringToBcds(byte[] frame, int loc, String data, int len, byte invalid)
/*      */   {
/*  759 */     int slen = (data.length() >>> 1) + (data.length() & 0x1);
/*  760 */     int iloc = slen + loc - 1;
/*  761 */     int head = 0;
/*  762 */     if ((data.length() & 0x1) > 0) {
/*  763 */       frame[iloc] = StringToBcd(data.substring(0, 1));
/*  764 */       head = 1;
/*      */     } else {
/*  766 */       frame[iloc] = StringToBcd(data.substring(0, 2));
/*  767 */       head = 2;
/*      */     }
/*  769 */     --iloc;
/*  770 */     for (int i = 1; i < slen; ++i) {
/*  771 */       frame[iloc] = StringToBcd(data.substring(head, head + 2));
/*  772 */       head += 2;
/*  773 */       --iloc;
/*      */     }
/*  775 */     iloc = slen + loc;
/*  776 */     for (i = slen; i < len; ++i) {
/*  777 */       frame[iloc] = invalid;
/*  778 */       ++iloc;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesC(byte[] frame, int loc, String data)
/*      */   {
/*      */     try
/*      */     {
/*  789 */       int len = (data.length() >>> 1) + (data.length() & 0x1);
/*  790 */       int head = 0;
/*  791 */       if ((data.length() & 0x1) > 0) {
/*  792 */         frame[loc] = HexToByte(data.substring(0, 1));
/*  793 */         head = 1;
/*      */       } else {
/*  795 */         frame[loc] = HexToByte(data.substring(0, 2));
/*  796 */         head = 2;
/*      */       }
/*  798 */       for (int i = 1; i < len; ++i) {
/*  799 */         frame[(i + loc)] = HexToByte(data.substring(head, head + 2));
/*  800 */         head += 2;
/*      */       }
/*      */     } catch (Exception e) {
/*  803 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte HexToByte(String data) {
/*  808 */     int rt = 0;
/*  809 */     if (data.length() <= 2) {
/*  810 */       for (int i = 0; i < data.length(); ++i) {
/*  811 */         rt <<= 4;
/*  812 */         rt += CharToDecimal(data.substring(i, i + 1));
/*      */       }
/*      */     }
/*  815 */     return (byte)rt;
/*      */   }
/*      */ 
/*      */   public static int AsciiToInt(byte val) {
/*  819 */     int rt = val & 0xFF;
/*  820 */     if (val < 58)
/*  821 */       rt -= 48;
/*  822 */     else if (rt < 71)
/*  823 */       rt -= 55;
/*      */     else {
/*  825 */       rt -= 87;
/*      */     }
/*  827 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesCB(byte[] frame, int loc, String hex)
/*      */   {
/*      */     try
/*      */     {
/*  837 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*      */ 
/*  839 */       byte[] bt = hex.getBytes();
/*  840 */       int head = 0;
/*  841 */       if ((hex.length() & 0x1) > 0) {
/*  842 */         frame[loc] = (byte)AsciiToInt(bt[0]);
/*  843 */         head = 1;
/*      */       } else {
/*  845 */         frame[loc] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  846 */         head = 2;
/*      */       }
/*  848 */       for (int i = 1; i < len; ++i) {
/*  849 */         frame[(loc + i)] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  850 */         head += 2;
/*      */       }
/*      */     } catch (Exception e) {
/*  853 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytes(byte[] frame, int loc, String hex)
/*      */   {
/*      */     try
/*      */     {
/*  864 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*  865 */       byte[] bt = hex.getBytes();
/*  866 */       int head = 0;
/*  867 */       if ((hex.length() & 0x1) > 0) {
/*  868 */         frame[(loc + len - 1)] = (byte)AsciiToInt(bt[0]);
/*  869 */         head = 1;
/*      */       } else {
/*  871 */         frame[(loc + len - 1)] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  872 */         head = 2;
/*      */       }
/*  874 */       int start = loc + len - 2;
/*  875 */       for (int i = 1; i < len; ++i) {
/*  876 */         frame[start] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  877 */         head += 2;
/*  878 */         --start;
/*      */       }
/*      */     } catch (Exception e) {
/*  881 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void HexsToBytesAA(byte[] frame, int loc, String hex, int flen, byte invalid)
/*      */   {
/*      */     try
/*      */     {
/*  892 */       int len = (hex.length() >>> 1) + (hex.length() & 0x1);
/*  893 */       byte[] bt = hex.getBytes();
/*  894 */       int head = 0;
/*  895 */       if ((hex.length() & 0x1) > 0) {
/*  896 */         frame[(loc + len - 1)] = (byte)AsciiToInt(bt[0]);
/*  897 */         head = 1;
/*      */       } else {
/*  899 */         frame[(loc + len - 1)] = (byte)((AsciiToInt(bt[0]) << 4) + AsciiToInt(bt[1]));
/*  900 */         head = 2;
/*      */       }
/*  902 */       int start = loc + len - 2;
/*  903 */       for (int i = 1; i < len; ++i) {
/*  904 */         frame[start] = (byte)((AsciiToInt(bt[head]) << 4) + AsciiToInt(bt[(head + 1)]));
/*  905 */         head += 2;
/*  906 */         --start;
/*      */       }
/*  908 */       start = len + loc;
/*  909 */       for (i = len; i < flen; ++i) {
/*  910 */         frame[start] = invalid;
/*  911 */         ++start;
/*      */       }
/*      */     } catch (Exception e) {
/*  914 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void DecimalToBytes(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  927 */       int vals = val;
/*  928 */       for (int i = 0; i < len; ++i) {
/*  929 */         frame[(loc + i)] = (byte)(vals & 0xFF);
/*  930 */         vals >>>= 8;
/*      */       }
/*      */     } catch (Exception e) {
/*  933 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void DecimalToBytesC(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  946 */       int vals = val;
/*  947 */       for (int i = 0; i < len; ++i) {
/*  948 */         frame[(loc + len - 1 - i)] = (byte)(vals & 0xFF);
/*  949 */         vals >>>= 8;
/*      */       }
/*      */     } catch (Exception e) {
/*  952 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void RtuaToBytesC(byte[] frame, int val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  965 */       frame[loc] = (byte)((val & 0xFF000000) >>> 24);
/*  966 */       frame[(loc + 1)] = (byte)((val & 0xFF0000) >>> 16);
/*  967 */       frame[(loc + 2)] = (byte)(val & 0xFF);
/*  968 */       frame[(loc + 3)] = (byte)((val & 0xFF00) >>> 8);
/*      */     } catch (Exception e) {
/*  970 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void RtuaToBytesC(byte[] frame, String val, int loc, int len)
/*      */   {
/*      */     try
/*      */     {
/*  983 */       int ival = Integer.parseInt(val);
/*  984 */       frame[loc] = (byte)((ival & 0xFF000000) >>> 24);
/*  985 */       frame[(loc + 1)] = (byte)((ival & 0xFF0000) >>> 16);
/*  986 */       frame[(loc + 2)] = (byte)(ival & 0xFF);
/*  987 */       frame[(loc + 3)] = (byte)((ival & 0xFF00) >>> 8);
/*      */     } catch (Exception e) {
/*  989 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static byte[] DateToBytes(String time, int len, int type)
/*      */   {
/* 1001 */     byte[] rt = null;
/*      */     try
/*      */     {
/*      */       SimpleDateFormat sdf;
/*      */       Date date;
/*      */       Calendar cd;
/* 1003 */       if (type == 0) {
/* 1004 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1005 */         date = sdf.parse(time);
/* 1006 */         cd = Calendar.getInstance();
/* 1007 */         cd.setTime(date);
/* 1008 */         rt = new byte[6];
/* 1009 */         rt[0] = IntToBcd(cd.get(13));
/* 1010 */         rt[1] = IntToBcd(cd.get(12));
/* 1011 */         rt[2] = IntToBcd(cd.get(11));
/* 1012 */         rt[3] = IntToBcd(cd.get(5));
/* 1013 */         rt[4] = IntToBcd(cd.get(2) + 1);
/* 1014 */         rt[5] = IntToBcd(cd.get(1));
/*      */       }
/* 1016 */       if (type == 1) {
/* 1017 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/* 1018 */         date = sdf.parse(time);
/* 1019 */         cd = Calendar.getInstance();
/* 1020 */         cd.setTime(date);
/* 1021 */         rt = new byte[5];
/* 1022 */         rt[0] = IntToBcd(cd.get(12));
/* 1023 */         rt[1] = IntToBcd(cd.get(11));
/* 1024 */         rt[2] = IntToBcd(cd.get(5));
/* 1025 */         rt[3] = IntToBcd(cd.get(2) + 1);
/* 1026 */         rt[4] = IntToBcd(cd.get(1));
/*      */       }
/*      */     } catch (Exception e) {
/* 1029 */       e.printStackTrace();
/*      */     }
/* 1031 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte[] TimeToBytes(String time, int len, int type)
/*      */   {
/* 1042 */     byte[] rt = null;
/*      */     try {
/* 1044 */       String[] cells = time.split(":");
/* 1045 */       if (type == 0) {
/* 1046 */         rt = new byte[3];
/* 1047 */         rt[0] = IntToBcd(Integer.parseInt(cells[2]));
/* 1048 */         rt[1] = IntToBcd(Integer.parseInt(cells[1]));
/* 1049 */         rt[2] = IntToBcd(Integer.parseInt(cells[0]));
/*      */       }
/* 1051 */       if (type == 1) {
/* 1052 */         rt = new byte[2];
/* 1053 */         rt[0] = IntToBcd(Integer.parseInt(cells[1]));
/* 1054 */         rt[1] = IntToBcd(Integer.parseInt(cells[0]));
/*      */       }
/*      */     } catch (Exception e) {
/* 1057 */       e.printStackTrace();
/*      */     }
/* 1059 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int getOrientation(IMessage message)
/*      */   {
/* 1068 */     int rt = 0;
/*      */     try {
/* 1070 */       byte reply = ((MessageZj)message).head.c_dir;
/* 1071 */       if ((reply & 0xFF) > 0)
/* 1072 */         rt = 1;
/*      */     }
/*      */     catch (Exception e) {
/* 1075 */       e.printStackTrace();
/*      */     }
/* 1077 */     return rt;
/*      */   }
/*      */ 
/*      */   public static int getErrCode(IMessage message)
/*      */   {
/* 1086 */     int rt = 0;
/*      */     try {
/* 1088 */       byte err = ((MessageZj)message).head.c_expflag;
/* 1089 */       rt = err & 0xFF;
/*      */     } catch (Exception e) {
/* 1091 */       e.printStackTrace();
/*      */     }
/* 1093 */     return rt;
/*      */   }
/*      */ 
/*      */   public static String getGwData(IMessage message)
/*      */   {
/* 1102 */     String rt = "";
/*      */     try {
/* 1104 */       ByteBuffer data = null;
/* 1105 */       if (message instanceof MessageGw) {
/* 1106 */         data = ((MessageGw)message).data;
/*      */       }
/* 1108 */       data.rewind();
/* 1109 */       rt = HexDump.hexDumpCompact(data);
/*      */     } catch (Exception e) {
/* 1111 */       e.printStackTrace();
/*      */     }
/* 1113 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte[] getData(IMessage message)
/*      */   {
/* 1121 */     byte[] rt = null;
/*      */     try {
/* 1123 */       ByteBuffer data = null;
/* 1124 */       if (message instanceof MessageZj) {
/* 1125 */         data = ((MessageZj)message).data;
/*      */       }
/* 1127 */       data.rewind();
/* 1128 */       int len = data.limit();
/* 1129 */       if (len > 0) {
/* 1130 */         rt = new byte[len];
/* 1131 */         data.get(rt);
/*      */       }
/*      */     } catch (Exception e) {
/* 1134 */       e.printStackTrace();
/*      */     }
/* 1136 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTime(byte[] data, int offset)
/*      */   {
/* 1145 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1147 */       int num = BCDToDecimal(data[(4 + offset)]);
/* 1148 */       rt.set(1, num + 2000);
/* 1149 */       num = BCDToDecimal((byte)(data[(3 + offset)] & 0x1F));
/* 1150 */       rt.set(2, num - 1);
/* 1151 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1152 */       rt.set(5, num);
/* 1153 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x3F));
/* 1154 */       rt.set(11, num);
/* 1155 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1156 */       rt.set(12, num);
/* 1157 */       rt.set(13, 0);
/* 1158 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1160 */       e.printStackTrace();
/*      */     }
/* 1162 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeW(byte[] data, int offset)
/*      */   {
/* 1172 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1174 */       int num = BCDToDecimal(data[(5 + offset)]);
/* 1175 */       rt.set(1, num + 2000);
/* 1176 */       num = BCDToDecimal((byte)(data[(4 + offset)] & 0x1F));
/* 1177 */       rt.set(2, num - 1);
/* 1178 */       num = BCDToDecimal((byte)(data[(3 + offset)] & 0x3F));
/* 1179 */       rt.set(5, num);
/* 1180 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1181 */       rt.set(11, num);
/* 1182 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x7F));
/* 1183 */       rt.set(12, num);
/* 1184 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1185 */       rt.set(13, num);
/* 1186 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1188 */       e.printStackTrace();
/*      */     }
/* 1190 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeM(byte[] data, int offset)
/*      */   {
/* 1200 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1202 */       int num = BCDToDecimal((byte)(data[(3 + offset)] & 0x1F));
/* 1203 */       rt.set(2, num - 1);
/* 1204 */       num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1205 */       rt.set(5, num);
/* 1206 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x3F));
/* 1207 */       rt.set(11, num);
/* 1208 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x7F));
/* 1209 */       rt.set(12, num);
/* 1210 */       rt.set(13, 0);
/* 1211 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1213 */       e.printStackTrace();
/*      */     }
/* 1215 */     return rt;
/*      */   }
/*      */ 
/*      */   public static Calendar getTimeL(byte[] data, int offset)
/*      */   {
/* 1225 */     Calendar rt = Calendar.getInstance();
/*      */     try {
/* 1227 */       int num = BCDToDecimal((byte)(data[(2 + offset)] & 0x3F));
/* 1228 */       rt.set(11, num);
/* 1229 */       num = BCDToDecimal((byte)(data[(1 + offset)] & 0x5F));
/* 1230 */       rt.set(12, num);
/* 1231 */       num = BCDToDecimal((byte)(data[(0 + offset)] & 0x5F));
/* 1232 */       rt.set(13, 0);
/* 1233 */       rt.set(14, 0);
/*      */     } catch (Exception e) {
/* 1235 */       e.printStackTrace();
/*      */     }
/* 1237 */     return rt;
/*      */   }
/*      */ 
/*      */   public static void IPToBytes(byte[] frame, int loc, String ip)
/*      */   {
/*      */     try
/*      */     {
/* 1248 */       String[] para = ip.split(":");
/* 1249 */       Inet4Address netaddress = (Inet4Address)Inet4Address.getByName(para[0]);
/* 1250 */       byte[] bip = netaddress.getAddress();
/* 1251 */       for (int i = 0; i < bip.length; ++i) {
/* 1252 */         frame[(loc + 2 + i)] = bip[(bip.length - i - 1)];
/*      */       }
/* 1254 */       int port = Integer.parseInt(para[1]);
/* 1255 */       frame[loc] = (byte)(port & 0xFF);
/* 1256 */       frame[(loc + 1)] = (byte)((port & 0xFF00) >> 8);
/*      */     } catch (Exception e) {
/* 1258 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean isValid(byte[] data, int start, int len)
/*      */   {
/* 1270 */     boolean rt = false;
/* 1271 */     for (int i = start; i < start + len; ++i) {
/* 1272 */       if ((data[i] & 0xFF) != 255) {
/* 1273 */         rt = true;
/* 1274 */         break;
/*      */       }
/*      */     }
/* 1277 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidBCD(byte[] data, int start, int len)
/*      */   {
/* 1288 */     boolean rt = true;
/* 1289 */     if ((data[start] & 0xFF) == 255) {
/* 1290 */       rt = !(isAllFF(data, start, len));
/*      */     }
/* 1292 */     if ((data[start] & 0xFF) == 238)
/*      */     {
/* 1294 */       rt = false;
/*      */     }
/* 1296 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isHaveValidBCD(byte[] data, int start, int len)
/*      */   {
/* 1306 */     boolean rt = true;
/* 1307 */     rt = !(isHaveFF(data, start, len));
/* 1308 */     if ((data[start] & 0xFF) == 238)
/*      */     {
/* 1310 */       rt = false;
/*      */     }
/* 1312 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isAllEE(byte[] data, int start, int len)
/*      */   {
/* 1322 */     boolean rt = true;
/* 1323 */     for (int i = start; i < start + len; ++i) {
/* 1324 */       if ((data[i] & 0xFF) != 238) {
/* 1325 */         rt = false;
/* 1326 */         break;
/*      */       }
/*      */     }
/* 1329 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isAllFF(byte[] data, int start, int len)
/*      */   {
/* 1339 */     boolean rt = true;
/* 1340 */     for (int i = start; i < start + len; ++i) {
/* 1341 */       if ((data[i] & 0xFF) != 255) {
/* 1342 */         rt = false;
/* 1343 */         break;
/*      */       }
/*      */     }
/* 1346 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isHaveFF(byte[] data, int start, int len)
/*      */   {
/* 1356 */     boolean rt = false;
/* 1357 */     for (int i = start; i < start + len; ++i) {
/* 1358 */       if ((data[i] & 0xFF) == 255) {
/* 1359 */         rt = true;
/* 1360 */         break;
/*      */       }
/*      */     }
/* 1363 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidMonth(byte data)
/*      */   {
/* 1371 */     boolean rt = false;
/* 1372 */     int hi = BCDToDecimal(data);
/* 1373 */     if ((hi >= 0) && (hi <= 12)) {
/* 1374 */       rt = true;
/*      */     }
/* 1376 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidDay(byte data, int month, int year)
/*      */   {
/* 1387 */     boolean rt = false;
/* 1388 */     int hi = BCDToDecimal(data);
/* 1389 */     if ((hi >= 0) && (hi <= 31)) {
/* 1390 */       if (month == 2) {
/* 1391 */         if (year < 0) {
/* 1392 */           if (hi < days[month]) {
/* 1393 */             rt = true;
/*      */           }
/*      */         }
/* 1396 */         else if (isLeapYear(year)) {
/* 1397 */           if (hi <= 29) {
/* 1398 */             rt = true;
/*      */           }
/*      */         }
/* 1401 */         else if (hi <= 28) {
/* 1402 */           rt = true;
/*      */         }
/*      */ 
/*      */       }
/* 1407 */       else if (hi <= days[month]) {
/* 1408 */         rt = true;
/*      */       }
/*      */     }
/*      */ 
/* 1412 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidHHMMSS(byte data)
/*      */   {
/* 1421 */     boolean rt = false;
/* 1422 */     int hi = BCDToDecimal(data);
/* 1423 */     if ((hi >= 0) && (hi <= 60)) {
/* 1424 */       rt = true;
/*      */     }
/* 1426 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isLeapYear(int year)
/*      */   {
/* 1435 */     boolean rt = false;
/* 1436 */     if (year >= 0) {
/* 1437 */       if (year % 100 == 0) {
/* 1438 */         if (year % 400 == 0) {
/* 1439 */           rt = true;
/*      */         }
/*      */       }
/* 1442 */       else if (year % 4 == 0) {
/* 1443 */         rt = true;
/*      */       }
/*      */     }
/*      */ 
/* 1447 */     return rt;
/*      */   }
/*      */ 
/*      */   public static byte calculateCS(byte[] data, int start, int len)
/*      */   {
/* 1452 */     int cs = 0;
/* 1453 */     for (int i = start; i < start + len; ++i) {
/* 1454 */       cs += (data[i] & 0xFF);
/* 1455 */       cs &= 255;
/*      */     }
/* 1457 */     return (byte)(cs & 0xFF);
/*      */   }
/*      */ 
/*      */   public static String getMeterProtocol(String type)
/*      */   {
/* 1466 */     if (type != null) {
/* 1467 */       if (type.equals("10")) {
/* 1468 */         return "BBMeter";
/*      */       }
/* 1470 */       if (type.equals("20")) {
/* 1471 */         return "ZJMeter";
/*      */       }
/* 1473 */       if (type.equals("40")) {
/* 1474 */         return "SMMeter";
/*      */       }
/*      */     }
/* 1477 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isTask(int datakey)
/*      */   {
/* 1486 */     boolean rt = false;
/* 1487 */     if ((datakey >= 33025) && (datakey < 33278)) {
/* 1488 */       rt = true;
/*      */     }
/* 1490 */     return rt;
/*      */   }
/*      */ 
/*      */   public static boolean isValidBCDString(String val) {
/* 1494 */     boolean rt = true;
/* 1495 */     if (val != null) {
/* 1496 */       for (int i = 0; i < val.length(); ++i) {
/* 1497 */         char c = val.charAt(i);
/* 1498 */         if ((c >= '0') && (c <= '9')) {
/*      */           continue;
/*      */         }
/* 1501 */         rt = false;
/* 1502 */         break;
/*      */       }
/*      */     }
/*      */     else {
/* 1506 */       rt = false;
/*      */     }
/* 1508 */     return rt;
/*      */   }
/*      */ }