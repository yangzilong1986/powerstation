/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.RtuAlert;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataSwitch;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataValue;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C0EMessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  24 */     List rt = new ArrayList();
/*     */     try {
/*  26 */       String data = ParseTool.getGwData(message);
/*  27 */       MessageGw msg = (MessageGw)message;
/*  28 */       if (msg.head.seq_tpv == 1)
/*  29 */         data = data.substring(0, data.length() - 12);
/*  30 */       if (msg.head.c_acd == 1)
/*  31 */         data = data.substring(0, data.length() - 4);
/*  32 */       String[] codes = DataItemParser.dataCodeParser(data.substring(4, 8), "0E");
/*  33 */       data = data.substring(8);
/*  34 */       if ((codes.length > 0) && ((
/*  36 */         (codes[0].equals("0EF001")) || (codes[0].equals("0EF002"))))) {
/*  37 */         data = data.substring(4);
/*  38 */         int pm = Integer.parseInt(data.substring(0, 2), 16);
/*  39 */         int pn = Integer.parseInt(data.substring(2, 4), 16);
/*  40 */         int count = 0;
/*  41 */         if (pm < pn)
/*  42 */           count = pn - pm;
/*  43 */         else if (pm > pn)
/*  44 */           count = 256 + pn - pm;
/*  45 */         data = data.substring(4);
/*  46 */         int rtua = ((MessageGw)message).head.rtua;
/*  47 */         BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rtua);
/*  48 */         for (int i = 0; i < count; ++i) {
/*  49 */           int alertCode = Integer.parseInt(data.substring(0, 2), 16);
/*  50 */           int len = Integer.parseInt(data.substring(2, 4), 16);
/*  51 */           data = data.substring(4);
/*  52 */           RtuAlert ra = alertParse(data.substring(0, len * 2), alertCode);
/*  53 */           ra.setRtuId(rtu.getRtuId());
/*  54 */           ra.setCorpNo(rtu.getDeptCode());
/*  55 */           if (rtu.getMeasuredPoint(ra.getTn()) != null) {
/*  56 */             ra.setDataSaveID(rtu.getMeasuredPoint(ra.getTn()).getDataSaveID());
/*  57 */             ra.setCustomerNo(rtu.getMeasuredPoint(ra.getTn()).getCustomerNo());
/*  58 */             ra.setStationNo(rtu.getMeasuredPoint(ra.getTn()).getCustomerNo());
/*     */           }
/*  60 */           rt.add(ra);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  65 */       throw new MessageDecodeException(e);
/*     */     }
/*  67 */     return rt;
/*     */   }
/*     */ 
/*     */   private RtuAlert alertParse(String data, int alertCode)
/*     */   {
/*     */     String tag;
/*     */     String value;
/*  70 */     RtuAlert ra = new RtuAlert();
/*  71 */     String alertCodeHex = "";
/*  72 */     String alertTime = data.substring(0, 10);
/*  73 */     data = data.substring(10);
/*  74 */     int tn = 0;
/*  75 */     switch (alertCode)
/*     */     {
/*     */     case 1:
/*  77 */       tag = data.substring(0, 2);
/*  78 */       DataValue param1 = DataItemParser.parseValue(data.substring(2, 10), "ASC4");
/*  79 */       DataValue param2 = DataItemParser.parseValue(data.substring(10, 18), "ASC4");
/*  80 */       ra.setSbcs(alertCodeHex + "01=" + param1.getValue() + "," + alertCodeHex + "02=" + param2.getValue() + ",");
/*  81 */       if ((Integer.parseInt(tag) & 0x1) == 1) {
/*  82 */         alertCodeHex = "C011";
/*  83 */         ra.setAlertCode(Integer.parseInt(alertCodeHex, 16));
/*     */       }
/*  85 */       else if ((Integer.parseInt(tag) & 0x2) == 2) {
/*  86 */         alertCodeHex = "C012";
/*  87 */         ra.setAlertCode(Integer.parseInt(alertCodeHex, 16)); } break;
/*     */     case 2:
/*  92 */       tag = data.substring(0, 2);
/*  93 */       if ((Integer.parseInt(tag) & 0x1) == 1) {
/*  94 */         alertCodeHex = "C021";
/*  95 */         ra.setAlertCode(Integer.parseInt(alertCodeHex, 16));
/*     */       }
/*  97 */       else if ((Integer.parseInt(tag) & 0x2) == 2) {
/*  98 */         alertCodeHex = "C022";
/*  99 */         ra.setAlertCode(Integer.parseInt(alertCodeHex, 16)); } break;
/*     */     case 3:
/* 104 */       alertCodeHex = "C030";
/* 105 */       ra.setAlertCode(Integer.parseInt(alertCodeHex, 16));
/* 106 */       value = alertCodeHex + "01=" + data.substring(0, 2) + ",";
/* 107 */       data = data.substring(2);
/* 108 */       for (int i = 0; i < data.length() / 8; ++i) {
/* 109 */         value = value + "C030" + DataSwitch.IntToHex(new StringBuilder().append("").append(i).append(2).toString(), 2) + "=" + data.substring(i * 8, i * 8 + 8) + ",";
/*     */       }
/* 111 */       value = value.substring(0, value.length() - 1);
/* 112 */       ra.setSbcs(value);
/* 113 */       break;
/*     */     case 14:
/* 116 */       String alertTime1 = data.substring(0, 10);
/*     */ 
/* 118 */       if (Integer.parseInt(DataSwitch.ReverseStringByByte(alertTime)) > Integer.parseInt(DataSwitch.ReverseStringByByte(alertTime1)))
/*     */       {
/* 120 */         alertCodeHex = "C141";
/*     */       }
/*     */       else {
/* 123 */         alertCodeHex = "C142";
/* 124 */         alertTime = alertTime1;
/*     */       }
/* 126 */       ra.setAlertCode(Integer.parseInt(alertCodeHex, 16));
/* 127 */       break;
/*     */     case 21:
/* 130 */       int tag = Integer.parseInt(data.substring(0, 2), 16);
/* 131 */       alertCodeHex = "C21" + tag;
/* 132 */       ra.setAlertCode(Integer.parseInt(alertCodeHex, 16));
/* 133 */       break;
/*     */     case 31:
/* 136 */       value = data.substring(3, 4);
/* 137 */       if ((Integer.parseInt(value) & 0x8) == 8) {
/* 138 */         alertCodeHex = "C310";
/* 139 */         tn = Integer.parseInt(data.substring(2, 3) + data.substring(0, 2), 16);
/* 140 */         data = data.substring(4);
/* 141 */         String value = "C31001" + DataItemParser.parseValue(data.substring(0, 10), "A15").getValue() + ",";
/* 142 */         value = value + "C31002" + DataItemParser.parseValue(data.substring(10, 20), "A14").getValue() + ",";
/* 143 */         value = value + "C31003" + DataItemParser.parseValue(data.substring(20, 28), "A11").getValue();
/* 144 */         ra.setSbcs(value); }
/* 145 */       break;
/*     */     case 32:
/* 149 */       alertCodeHex = "C320";
/* 150 */       value = "C32001" + DataItemParser.parseValue(data.substring(0, 8), "HTB4").getValue() + ",";
/* 151 */       value = value + "C32002" + DataItemParser.parseValue(data.substring(8, 16), "HTB4").getValue();
/* 152 */       ra.setSbcs(value);
/* 153 */       break;
/*     */     case 60:
/* 156 */       alertCodeHex = "C600";
/* 157 */       value = "C60001" + DataItemParser.parseValue(data.substring(0, 8), "BS4").getValue();
/* 158 */       ra.setSbcs(value);
/*     */     }
/*     */ 
/* 162 */     ra.setTn("" + tn);
/* 163 */     ra.setAlertTime(DataItemParser.parseValue(alertTime, "A15").getValue());
/* 164 */     return ra;
/*     */   }
/*     */ }