/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserHEX
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       rt = DataSwitch.ReverseStringByByte(data.substring(0, len));
/*    */     } catch (Exception e) {
/* 22 */       throw new MessageDecodeException(e);
/*    */     }
/* 24 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 34 */     String rt = "";
/*    */     try {
/* 36 */       rt = DataSwitch.StrStuff("0", len, data, "left");
/* 37 */       rt = DataSwitch.ReverseStringByByte(rt);
/*    */     } catch (Exception e) {
/* 39 */       throw new MessageEncodeException(e);
/*    */     }
/* 41 */     return rt;
/*    */   }
/*    */ }