/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserASC
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       data = data.substring(0, len);
/* 21 */       if (data.length() % 2 == 0) {
/* 22 */         int byteLen = data.length() / 2;
/* 23 */         char[] chrList = new char[byteLen];
/* 24 */         for (int i = 0; i < byteLen; ++i) {
/* 25 */           chrList[i] = (char)Integer.parseInt(ParserHTB.parseValue(data.substring(2 * i, 2 * i + 2), 2));
/*    */         }
/* 27 */         rt = new String(chrList).trim();
/*    */       }
/*    */     } catch (Exception e) {
/* 30 */       throw new MessageDecodeException(e);
/*    */     }
/* 32 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 42 */     String rt = "";
/*    */     try {
/* 44 */       byte[] bt = data.getBytes();
/* 45 */       for (int i = 0; i < bt.length; ++i) {
/* 46 */         rt = rt + Integer.toHexString(bt[i]);
/*    */       }
/* 48 */       rt = DataSwitch.StrStuff("0", len, rt, "right");
/*    */     } catch (Exception e) {
/* 50 */       throw new MessageEncodeException(e);
/*    */     }
/* 52 */     return rt;
/*    */   }
/*    */ }