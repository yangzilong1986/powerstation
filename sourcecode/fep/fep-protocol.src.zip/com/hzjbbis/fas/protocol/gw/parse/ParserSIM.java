/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ 
/*    */ public class ParserSIM
/*    */ {
/*    */   public static String parseValue(String data, int len)
/*    */   {
/* 18 */     String rt = "";
/*    */     try {
/* 20 */       data = data.substring(0, len);
/* 21 */       for (int i = 0; i < data.length(); ++i)
/* 22 */         if (data.substring(i, i + 1).equals("A"))
/* 23 */           rt = rt + ",";
/* 24 */         else if (data.substring(i, i + 1).equals("B"))
/* 25 */           rt = rt + "#";
/* 26 */         else if (data.substring(i, i + 1).equals("F"))
/* 27 */           rt = rt + "";
/*    */         else
/* 29 */           rt = rt + data.substring(i, i + 1);
/*    */     }
/*    */     catch (Exception e) {
/* 32 */       throw new MessageDecodeException(e);
/*    */     }
/* 34 */     return rt;
/*    */   }
/*    */ 
/*    */   public static String constructor(String data, int len)
/*    */   {
/* 44 */     String rt = "";
/*    */     try {
/* 46 */       rt = DataSwitch.StrStuff("F", len, data, "right");
/*    */     } catch (Exception e) {
/* 48 */       throw new MessageEncodeException(e);
/*    */     }
/* 50 */     return rt;
/*    */   }
/*    */ }