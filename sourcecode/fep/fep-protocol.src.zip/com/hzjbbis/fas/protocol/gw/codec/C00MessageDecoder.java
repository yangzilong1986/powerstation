/*    */ package com.hzjbbis.fas.protocol.gw.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.model.HostCommandResult;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ 
/*    */ public class C00MessageDecoder extends AbstractMessageDecoder
/*    */ {
/*    */   public Object decode(IMessage message)
/*    */   {
/* 18 */     HostCommand hc = new HostCommand();
/*    */     try {
/* 20 */       String data = ParseTool.getGwData(message);
/* 21 */       MessageGw msg = (MessageGw)message;
/* 22 */       if (msg.head.seq_tpv == 1)
/* 23 */         data = data.substring(0, data.length() - 12);
/* 24 */       if (msg.head.c_acd == 1) {
/* 25 */         data = data.substring(0, data.length() - 4);
/*    */       }
/* 27 */       String[] codes = DataItemParser.dataCodeParser(data.substring(4, 8), "00");
/* 28 */       data = data.substring(8);
/* 29 */       if (codes.length == 1)
/*    */       {
/* 31 */         if ((codes[0].equals("00F001")) || (codes[0].equals("00F002"))) {
/* 32 */           HostCommandResult hcr = new HostCommandResult();
/* 33 */           hcr.setCode(codes[0]);
/* 34 */           hcr.setTn("0");
/* 35 */           hcr.setValue("00");
/* 36 */           hc.addResult(hcr);
/* 37 */           if (codes[0].equals("00F001"))
/* 38 */             hc.setStatus("1");
/*    */           else
/* 40 */             hc.setStatus("2");
/*    */         }
/*    */         else {
/* 43 */           String sAFN = data.substring(0, 2);
/* 44 */           data = data.substring(2);
/* 45 */           while (data.length() >= 10) {
/* 46 */             int[] tn = DataItemParser.measuredPointParser(data.substring(0, 4));
/* 47 */             codes = DataItemParser.dataCodeParser(data.substring(4, 8), sAFN);
/* 48 */             data = data.substring(8);
/* 49 */             String sValue = data.substring(0, 2);
/* 50 */             for (int i = 0; i < tn.length; ++i) {
/* 51 */               for (int j = 0; j < codes.length; ++j) {
/* 52 */                 HostCommandResult hcr = new HostCommandResult();
/* 53 */                 hcr.setCode(codes[j]);
/* 54 */                 hcr.setTn("" + tn[i]);
/* 55 */                 hcr.setValue(sValue);
/* 56 */                 hc.addResult(hcr);
/*    */               }
/*    */             }
/*    */           }
/* 60 */           hc.setStatus("1");
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 64 */       throw new MessageDecodeException(e);
/*    */     }
/* 66 */     return hc;
/*    */   }
/*    */ }