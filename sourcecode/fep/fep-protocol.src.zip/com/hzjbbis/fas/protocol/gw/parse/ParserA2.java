/*     */ package com.hzjbbis.fas.protocol.gw.parse;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.exception.MessageEncodeException;
/*     */ 
/*     */ public class ParserA2
/*     */ {
/*     */   public static String parseValue(String data, int len)
/*     */   {
/*  18 */     String rt = "";
/*     */     try {
/*  20 */       data = DataSwitch.ReverseStringByByte(data.substring(0, len));
/*  21 */       String tag = data.substring(0, 1);
/*  22 */       int iMB = Integer.parseInt(tag, 16) & 0xE;
/*  23 */       if ((Integer.parseInt(tag, 16) & 0x1) == 1)
/*  24 */         tag = "-";
/*     */       else
/*  26 */         tag = "";
/*  27 */       float iBCD = Integer.parseInt(data.substring(1, data.length()));
/*  28 */       switch (iMB)
/*     */       {
/*     */       case 0:
/*  30 */         iBCD *= 10000.0F;
/*  31 */         break;
/*     */       case 2:
/*  34 */         iBCD *= 1000.0F;
/*  35 */         break;
/*     */       case 4:
/*  38 */         iBCD *= 100.0F;
/*  39 */         break;
/*     */       case 6:
/*  42 */         iBCD *= 10.0F;
/*  43 */         break;
/*     */       case 8:
/*  46 */         iBCD *= 1.0F;
/*  47 */         break;
/*     */       case 10:
/*  50 */         iBCD /= 10.0F;
/*  51 */         break;
/*     */       case 12:
/*  54 */         iBCD /= 100.0F;
/*  55 */         break;
/*     */       case 14:
/*  58 */         iBCD /= 1000.0F;
/*     */       case 1:
/*     */       case 3:
/*     */       case 5:
/*     */       case 7:
/*     */       case 9:
/*     */       case 11:
/*     */       case 13:
/*     */       }
/*     */ 
/*  62 */       rt = tag + "" + iBCD;
/*     */     } catch (Exception e) {
/*  64 */       throw new MessageDecodeException(e);
/*     */     }
/*  66 */     return rt;
/*     */   }
/*     */ 
/*     */   public static String constructor(String data, int len)
/*     */   {
/*  76 */     String rt = "";
/*     */     try {
/*  78 */       Double d = new Double(data);
/*  79 */       String sFH = "";
/*  80 */       String sZSSjz = "";
/*  81 */       String sMB = "";
/*  82 */       if (d.doubleValue() >= 0.0D) {
/*  83 */         sFH = "+";
/*  84 */         if (d.doubleValue() < 9990000.0D) break label104;
/*  85 */         return "0999";
/*     */       }
/*     */ 
/*  88 */       if (d.doubleValue() < 0.0D) {
/*  89 */         sFH = "-";
/*  90 */         if (d.doubleValue() > -0.0001D)
/*  91 */           return "8001";
/*     */         try
/*     */         {
/*  94 */           data = d.toString().substring(1);
/*     */         }
/*     */         catch (Exception ex7) {
/*  97 */           return "0000";
/*     */         }
/*  99 */         d = new Double(data);
/*     */       }
/*     */       try {
/* 102 */         label104: char[] cFloat = d.toString().toCharArray();
/* 103 */         for (int i = 0; i < cFloat.length; ++i) {
/* 104 */           if ((cFloat[i] >= '0') && (cFloat[i] <= '9')) continue; if (cFloat[i] != '.')
/*     */           {
/* 108 */             return "0000";
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex6) {
/* 113 */         return "0000";
/*     */       }
/* 115 */       int iDotPos = data.indexOf(".");
/* 116 */       if (iDotPos == -1) {
/*     */         try {
/* 118 */           if (data.length() >= 7) {
/* 119 */             sZSSjz = data.substring(0, 3);
/* 120 */             sMB = "10000";
/*     */           }
/*     */         }
/*     */         catch (Exception ex4) {
/* 124 */           return "0000";
/*     */         }
/* 126 */         if ((data.length() < 7) && (data.length() > 3)) {
/*     */           try {
/* 128 */             sZSSjz = data.substring(0, 3);
/*     */           }
/*     */           catch (Exception ex5) {
/* 131 */             return "0000";
/*     */           }
/* 133 */           switch (data.length() - 3)
/*     */           {
/*     */           case 1:
/* 135 */             sMB = "10";
/* 136 */             break;
/*     */           case 2:
/* 139 */             sMB = "100";
/* 140 */             break;
/*     */           case 3:
/* 143 */             sMB = "1000";
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 149 */           while (data.length() < 3) {
/* 150 */             data = "0" + data;
/*     */           }
/* 152 */           sZSSjz = data;
/* 153 */           sMB = "1";
/*     */         }
/*     */       }
/*     */       try {
/* 157 */         if ((iDotPos == 1) && (data.substring(0, 1).equals("0"))) {
/* 158 */           sMB = "0.001";
/* 159 */           if (data.length() - iDotPos < 4) {
/* 160 */             sZSSjz = data.substring(iDotPos + 1, data.length());
/*     */             while (true) { if (sZSSjz.length() >= 3) break label440;
/* 162 */               sZSSjz = sZSSjz + "0";
/*     */             }
/*     */           }
/*     */ 
/* 166 */           sZSSjz = data.substring(iDotPos + 1, iDotPos + 4);
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 171 */         label440: throw new MessageEncodeException(e);
/*     */       }
/*     */       try {
/* 174 */         if ((iDotPos >= 0) && (iDotPos <= 2) && (!(data.substring(0, 1).equals("0"))))
/*     */         {
/* 176 */           if (data.length() < 4) {
/* 177 */             data = data + "0";
/*     */           }
/* 179 */           data = data.substring(0, 4);
/* 180 */           sZSSjz = data.substring(0, iDotPos) + data.substring(iDotPos + 1, 4);
/*     */ 
/* 182 */           if (data.length() - iDotPos == 2) {
/* 183 */             sMB = "0.1";
/*     */           }
/*     */           else
/* 186 */             sMB = "0.01";
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 191 */         throw new MessageEncodeException(e);
/*     */       }
/* 193 */       if ((iDotPos >= 3) && (iDotPos < 7)) {
/*     */         try {
/* 195 */           data = data.substring(0, 3);
/*     */         }
/*     */         catch (Exception e) {
/* 198 */           throw new MessageEncodeException(e);
/*     */         }
/* 200 */         switch (iDotPos + 1 - data.length())
/*     */         {
/*     */         case 1:
/* 202 */           sMB = "1";
/* 203 */           break;
/*     */         case 2:
/* 206 */           sMB = "10";
/* 207 */           break;
/*     */         case 3:
/* 210 */           sMB = "100";
/* 211 */           break;
/*     */         case 4:
/* 214 */           sMB = "1000";
/*     */         }
/*     */ 
/* 218 */         sZSSjz = data;
/*     */       }
/* 220 */       if (iDotPos >= 7) {
/*     */         try {
/* 222 */           data = data.substring(0, 3);
/*     */         }
/*     */         catch (Exception ex) {
/* 225 */           return "0000";
/*     */         }
/* 227 */         sMB = "10000";
/* 228 */         sZSSjz = data;
/*     */       }
/* 230 */       if (sFH.equals("+")) {
/* 231 */         if (sMB.equals("10000")) {
/* 232 */           sMB = "0";
/*     */         }
/* 234 */         else if (sMB.equals("1000")) {
/* 235 */           sMB = "2";
/*     */         }
/* 237 */         else if (sMB.equals("100")) {
/* 238 */           sMB = "4";
/*     */         }
/* 240 */         else if (sMB.equals("10")) {
/* 241 */           sMB = "6";
/*     */         }
/* 243 */         else if (sMB.equals("1")) {
/* 244 */           sMB = "8";
/*     */         }
/* 246 */         else if (sMB.equals("0.1")) {
/* 247 */           sMB = "A";
/*     */         }
/* 249 */         else if (sMB.equals("0.01")) {
/* 250 */           sMB = "C";
/*     */         }
/* 252 */         else if (sMB.equals("0.001")) {
/* 253 */           sMB = "E";
/*     */         }
/*     */ 
/*     */       }
/* 257 */       else if (sMB.equals("10000")) {
/* 258 */         sMB = "1";
/*     */       }
/* 260 */       else if (sMB.equals("1000")) {
/* 261 */         sMB = "3";
/*     */       }
/* 263 */       else if (sMB.equals("100")) {
/* 264 */         sMB = "5";
/*     */       }
/* 266 */       else if (sMB.equals("10")) {
/* 267 */         sMB = "7";
/*     */       }
/* 269 */       else if (sMB.equals("1")) {
/* 270 */         sMB = "9";
/*     */       }
/* 272 */       else if (sMB.equals("0.1")) {
/* 273 */         sMB = "B";
/*     */       }
/* 275 */       else if (sMB.equals("0.01")) {
/* 276 */         sMB = "D";
/*     */       }
/* 278 */       else if (sMB.equals("0.001")) {
/* 279 */         sMB = "F";
/*     */       }
/*     */ 
/* 282 */       rt = sMB + sZSSjz;
/* 283 */       rt = DataSwitch.ReverseStringByByte(rt);
/*     */     } catch (Exception e) {
/* 285 */       throw new MessageEncodeException(e);
/*     */     }
/* 287 */     return rt;
/*     */   }
/*     */ }