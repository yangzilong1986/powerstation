/*    */ package com.hzjbbis.fas.protocol.gw.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageDecodeException;
/*    */ import com.hzjbbis.fas.model.HostCommand;
/*    */ import com.hzjbbis.fas.model.HostCommandResult;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataValue;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ 
/*    */ public class C09MessageDecoder extends AbstractMessageDecoder
/*    */ {
/*    */   public Object decode(IMessage message)
/*    */   {
/* 19 */     HostCommand hc = new HostCommand();
/*    */     try {
/* 21 */       String data = ParseTool.getGwData(message);
/* 22 */       MessageGw msg = (MessageGw)message;
/* 23 */       if (msg.head.seq_tpv == 1)
/* 24 */         data = data.substring(0, data.length() - 12);
/* 25 */       if (msg.head.c_acd == 1)
/* 26 */         data = data.substring(0, data.length() - 4);
/* 27 */       DataValue dataValue = new DataValue();
/* 28 */       while (data.length() >= 8) {
/* 29 */         int[] tn = DataItemParser.measuredPointParser(data.substring(0, 4));
/* 30 */         String[] codes = DataItemParser.dataCodeParser(data.substring(4, 8), "09");
/* 31 */         data = data.substring(8);
/* 32 */         for (int i = 0; i < tn.length; ++i) {
/* 33 */           for (int j = 0; j < codes.length; ++j) {
/* 34 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(codes[j]);
/* 35 */             dataValue = DataItemParser.parser(data, pdc.getFormat());
/* 36 */             data = data.substring(dataValue.getLen());
/* 37 */             HostCommandResult hcr = new HostCommandResult();
/* 38 */             hcr.setCode(codes[j]);
/* 39 */             hcr.setTn("" + tn[i]);
/* 40 */             hcr.setValue(dataValue.getValue());
/* 41 */             hc.addResult(hcr);
/*    */           }
/*    */         }
/*    */       }
/* 45 */       hc.setStatus("1");
/*    */     } catch (Exception e) {
/* 47 */       throw new MessageDecodeException(e);
/*    */     }
/* 49 */     return hc;
/*    */   }
/*    */ }