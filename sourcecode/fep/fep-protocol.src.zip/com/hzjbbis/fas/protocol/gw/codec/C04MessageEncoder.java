/*    */ package com.hzjbbis.fas.protocol.gw.codec;
/*    */ 
/*    */ import com.hzjbbis.exception.MessageEncodeException;
/*    */ import com.hzjbbis.fas.model.FaalGWNoParamRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequestParam;
/*    */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataItemCoder;
/*    */ import com.hzjbbis.fas.protocol.gw.parse.DataSwitch;
/*    */ import com.hzjbbis.fas.protocol.zj.parse.ParseTool;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*    */ import com.hzjbbis.fk.model.BizRtu;
/*    */ import com.hzjbbis.fk.model.RtuManage;
/*    */ import com.hzjbbis.util.HexDump;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class C04MessageEncoder extends AbstractMessageEncoder
/*    */ {
/* 31 */   private static Log log = LogFactory.getLog(C04MessageEncoder.class);
/*    */ 
/*    */   public IMessage[] encode(Object obj)
/*    */   {
/*    */     FaalGWNoParamRequest request;
/*    */     String sDADT;
/*    */     String sValue;
/*    */     String sdata;
/*    */     String tp;
/*    */     String pw;
/* 33 */     List rt = new ArrayList();
/*    */     try
/*    */     {
/* 36 */       if (obj instanceof FaalRequest) {
/* 37 */         request = (FaalGWNoParamRequest)obj;
/* 38 */         List rtuParams = request.getRtuParams();
/* 39 */         sDADT = ""; sValue = ""; sdata = ""; tp = ""; pw = "";
/*    */ 
/* 41 */         if ((request.getTpSendTime() != null) && (request.getTpTimeout() > 0)) {
/* 42 */           tp = "00" + DataItemCoder.constructor(request.getTpSendTime(), "A16") + DataItemCoder.constructor(new StringBuilder().append("").append(request.getTpTimeout()).toString(), "HTB1");
/*    */         }
/* 44 */         for (FaalRequestRtuParam rp : rtuParams) {
/* 45 */           int[] tn = rp.getTn();
/* 46 */           List params = rp.getParams();
/* 47 */           for (int i = 0; i < tn.length; ++i) {
/* 48 */             for (FaalRequestParam pm : params) {
/* 49 */               sDADT = DataItemCoder.getCodeFrom1To1(tn[i], pm.getName());
/* 50 */               ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(pm.getName());
/* 51 */               sValue = DataItemCoder.coder(pm.getValue(), pdc.getFormat());
/* 52 */               sdata = sdata + sDADT + sValue;
/*    */             }
/*    */           }
/* 55 */           BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(rp.getRtuId());
/* 56 */           if (rtu == null) {
/* 57 */             throw new MessageEncodeException("终端信息未在缓存列表：" + ParseTool.IntToHex4(rtu.getRtua()));
/*    */           }
/* 59 */           if ((rtu.getHiAuthPassword() != null) && (rtu.getHiAuthPassword().length() == 32))
/* 60 */             pw = DataSwitch.ReverseStringByByte(rtu.getHiAuthPassword());
/*    */           else
/* 62 */             throw new MessageEncodeException("rtu HiAuthPassword is null");
/* 63 */           MessageGwHead head = new MessageGwHead();
/*    */ 
/* 65 */           head.rtua = rtu.getRtua();
/*    */ 
/* 67 */           MessageGw msg = new MessageGw();
/* 68 */           msg.head = head;
/* 69 */           msg.setAFN((byte)request.getType());
/* 70 */           msg.data = HexDump.toByteBuffer(sdata + pw);
/* 71 */           if (!(tp.equals("")))
/* 72 */             msg.setAux(HexDump.toByteBuffer(tp), true);
/* 73 */           msg.setCmdId(rp.getCmdId());
/* 74 */           msg.setMsgCount(1);
/* 75 */           rt.add(msg);
/*    */         }
/*    */       }
/*    */     } catch (MessageEncodeException e) {
/* 79 */       throw e;
/*    */     }
/*    */     catch (Exception e) {
/* 82 */       throw new MessageEncodeException(e);
/*    */     }
/* 84 */     if ((rt != null) && (rt.size() > 0)) {
/* 85 */       IMessage[] msgs = new IMessage[rt.size()];
/* 86 */       rt.toArray(msgs);
/* 87 */       return msgs;
/*    */     }
/* 89 */     return null;
/*    */   }
/*    */ }