/*    */ package com.hzjbbis.fas.protocol.gw.parse;
/*    */ 
/*    */ public class DataValue
/*    */ {
/*    */   private String value;
/*    */   private int len;
/*    */ 
/*    */   public String getValue()
/*    */   {
/*  9 */     return this.value; }
/*    */ 
/*    */   public void setValue(String value) {
/* 12 */     this.value = value; }
/*    */ 
/*    */   public int getLen() {
/* 15 */     return this.len; }
/*    */ 
/*    */   public void setLen(int len) {
/* 18 */     this.len = len;
/*    */   }
/*    */ }