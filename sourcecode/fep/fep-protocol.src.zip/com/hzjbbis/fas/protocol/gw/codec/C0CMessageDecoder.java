/*     */ package com.hzjbbis.fas.protocol.gw.codec;
/*     */ 
/*     */ import com.hzjbbis.exception.MessageDecodeException;
/*     */ import com.hzjbbis.fas.model.HostCommand;
/*     */ import com.hzjbbis.fas.model.HostCommandResult;
/*     */ import com.hzjbbis.fas.model.RtuData;
/*     */ import com.hzjbbis.fas.model.RtuDataItem;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataConfig;
/*     */ import com.hzjbbis.fas.protocol.conf.ProtocolDataItemConfig;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataItemParser;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataSwitch;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataTimeTag;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.DataValue;
/*     */ import com.hzjbbis.fas.protocol.gw.parse.ParseTool;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.gw.MessageGwHead;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class C0CMessageDecoder extends AbstractMessageDecoder
/*     */ {
/*     */   public Object decode(IMessage message)
/*     */   {
/*  30 */     List datas = new ArrayList();
/*  31 */     HostCommand hc = new HostCommand();
/*     */ 
/*  33 */     int taskTag = 0;
/*     */     try {
/*  35 */       String sTaskDateTime = ""; String sTaskNum = null;
/*  36 */       String data = ParseTool.getGwData(message);
/*  37 */       MessageGw msg = (MessageGw)message;
/*  38 */       if (msg.head.seq_tpv == 1)
/*  39 */         data = data.substring(0, data.length() - 12);
/*  40 */       if (msg.head.c_acd == 1)
/*  41 */         data = data.substring(0, data.length() - 4);
/*  42 */       DataValue dataValue = new DataValue();
/*  43 */       while (data.length() >= 8) {
/*  44 */         int[] tn = DataItemParser.measuredPointParser(data.substring(0, 4));
/*  45 */         String[] codes = DataItemParser.dataCodeParser(data.substring(4, 8), "0C");
/*  46 */         data = data.substring(8);
/*  47 */         for (int i = 0; i < tn.length; ++i)
/*  48 */           for (int j = 0; j < codes.length; ++j)
/*     */           {
/*     */             HostCommandResult hcr;
/*  49 */             ProtocolDataItemConfig pdc = this.dataConfig.getDataItemConfig(codes[j]);
/*  50 */             List childItems = pdc.getChildItems();
/*     */ 
/*  52 */             if ((Integer.parseInt(codes[j].substring(3, 6)) >= 81) && (Integer.parseInt(codes[j].substring(3, 6)) <= 121))
/*     */             {
/*  55 */               DataTimeTag dataTimeTag = DataItemParser.getTaskDateTimeInfo(data.substring(0, 4), 1);
/*  56 */               data = data.substring(4);
/*  57 */               for (int k = 0; k < dataTimeTag.getDataCount(); ++k)
/*  58 */                 if (childItems.size() > 0) {
/*  59 */                   dataValue = DataItemParser.parseValue(data.substring(0, ((ProtocolDataItemConfig)childItems.get(0)).getLength() * 2), ((ProtocolDataItemConfig)childItems.get(0)).getFormat());
/*  60 */                   data = data.substring(((ProtocolDataItemConfig)childItems.get(0)).getLength() * 2);
/*  61 */                   sTaskDateTime = DataSwitch.IncreaseDateTime(dataTimeTag.getDataTime(), dataTimeTag.getDataDensity() * k, 2);
/*  62 */                   if (taskTag == 1) {
/*  63 */                     BizRtu rtu = RtuManage.getInstance().getBizRtuInCache(((MessageGw)message).head.rtua);
/*  64 */                     RtuData rd = new RtuData();
/*  65 */                     rd.setLogicAddress(rtu.getLogicAddress());
/*  66 */                     rd.setTn("" + tn[i]);
/*     */ 
/*  68 */                     if (sTaskNum == null)
/*     */                     {
/*  70 */                       List codesTemp = new ArrayList();
/*  71 */                       codesTemp.add(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  72 */                       sTaskNum = rtu.getTaskNum(codesTemp);
/*  73 */                       codesTemp.clear();
/*     */                     }
/*  75 */                     if (sTaskNum == null) {
/*  76 */                       String error = "终端：" + rtu.getLogicAddress() + "任务报文无法找到匹配的任务模版," + message.getRawPacketString();
/*  77 */                       throw new MessageDecodeException(error);
/*     */                     }
/*     */ 
/*  80 */                     rd.setTaskNum(sTaskNum);
/*  81 */                     rd.setTime(sTaskDateTime);
/*  82 */                     RtuDataItem rdItem = new RtuDataItem();
/*  83 */                     rdItem.setCode(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  84 */                     rdItem.setValue(dataValue.getValue());
/*  85 */                     rd.addDataList(rdItem);
/*  86 */                     datas.add(rd);
/*     */                   }
/*     */                   else {
/*  89 */                     hcr = new HostCommandResult();
/*  90 */                     hcr.setCode(((ProtocolDataItemConfig)childItems.get(0)).getCode());
/*  91 */                     hcr.setTn("" + tn[i]);
/*  92 */                     hcr.setValue(sTaskDateTime + "#" + dataValue.getValue());
/*  93 */                     hc.addResult(hcr);
/*  94 */                     hc.setStatus("1");
/*     */                   }
/*     */                 }
/*     */             }
/*     */             else
/*     */             {
/* 100 */               for (int k = 0; k < childItems.size(); ++k)
/*     */               {
/*     */                 DataValue nValue;
/*     */                 int n;
/*     */                 int m;
/*     */                 HostCommandResult hcr;
/* 101 */                 ProtocolDataItemConfig pc = (ProtocolDataItemConfig)childItems.get(k);
/*     */ 
/* 103 */                 if (pc.getCode().equals("0000000000")) {
/* 104 */                   nValue = new DataValue();
/* 105 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 106 */                   data = data.substring(pc.getLength() * 2);
/* 107 */                   for (int m = k + 1; m < childItems.size(); ++m) {
/* 108 */                     pc = (ProtocolDataItemConfig)childItems.get(m);
/* 109 */                     for (int n = 0; n < Integer.parseInt(nValue.getValue()) + 1; ++n) {
/* 110 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 111 */                       data = data.substring(pc.getLength() * 2);
/* 112 */                       hcr = new HostCommandResult();
/* 113 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(new StringBuilder().append(pc.getCode().substring(0, 8)).append("00").toString()) + n), "left"));
/* 114 */                       hcr.setTn("" + tn[i]);
/* 115 */                       hcr.setValue(dataValue.getValue());
/* 116 */                       hc.addResult(hcr);
/*     */                     }
/*     */                   }
/* 119 */                   break;
/*     */                 }
/*     */ 
/* 122 */                 if (pc.getCode().equals("0000000001")) {
/* 123 */                   nValue = new DataValue();
/* 124 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 125 */                   data = data.substring(pc.getLength() * 2);
/* 126 */                   for (n = 0; n < Integer.parseInt(nValue.getValue()) + 1; ++n) {
/* 127 */                     for (m = k + 1; m < childItems.size(); ++m) {
/* 128 */                       pc = (ProtocolDataItemConfig)childItems.get(m);
/* 129 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 130 */                       data = data.substring(pc.getLength() * 2);
/* 131 */                       hcr = new HostCommandResult();
/* 132 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(new StringBuilder().append(pc.getCode().substring(0, 8)).append("00").toString()) + n), "left"));
/* 133 */                       hcr.setTn("" + tn[i]);
/* 134 */                       hcr.setValue(dataValue.getValue());
/* 135 */                       hc.addResult(hcr);
/*     */                     }
/*     */                   }
/* 138 */                   break;
/*     */                 }
/*     */ 
/* 141 */                 if (pc.getCode().indexOf("XX") > 0) {
/* 142 */                   nValue = new DataValue();
/* 143 */                   nValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 144 */                   data = data.substring(pc.getLength() * 2);
/* 145 */                   for (n = 0; n < Integer.parseInt(nValue.getValue()); ++n) {
/* 146 */                     for (m = k + 1; m < childItems.size(); ++m) {
/* 147 */                       pc = (ProtocolDataItemConfig)childItems.get(m);
/* 148 */                       dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 149 */                       data = data.substring(pc.getLength() * 2);
/* 150 */                       hcr = new HostCommandResult();
/* 151 */                       hcr.setCode(DataSwitch.StrStuff("0", 10, "" + (Long.parseLong(pc.getCode()) + n * 10), "left"));
/* 152 */                       hcr.setTn("" + tn[i]);
/* 153 */                       hcr.setValue(dataValue.getValue());
/* 154 */                       hc.addResult(hcr);
/*     */                     }
/*     */                   }
/* 157 */                   break;
/*     */                 }
/*     */ 
/* 160 */                 dataValue = DataItemParser.parseValue(data.substring(0, pc.getLength() * 2), pc.getFormat());
/* 161 */                 data = data.substring(pc.getLength() * 2);
/* 162 */                 hcr = new HostCommandResult();
/* 163 */                 hcr.setCode(pc.getCode());
/* 164 */                 hcr.setTn("" + tn[i]);
/* 165 */                 hcr.setValue(dataValue.getValue());
/* 166 */                 hc.addResult(hcr);
/*     */               }
/*     */ 
/* 169 */               hc.setStatus("1");
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 175 */       throw new MessageDecodeException(e);
/*     */     }
/* 177 */     if (taskTag == 1) {
/* 178 */       return datas;
/*     */     }
/* 180 */     return hc;
/*     */   }
/*     */ }