/*     */ package com.hzjbbis.fas.protocol.gw.parse;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataItemParser
/*     */ {
/*  18 */   private static Log log = LogFactory.getLog(DataItemCoder.class);
/*     */ 
/*     */   public static DataValue parseValue(String input, String format)
/*     */   {
/*  27 */     DataValue dataValue = new DataValue();
/*     */     try {
/*  29 */       String output = "";
/*  30 */       int len = 0;
/*     */       try {
/*  32 */         if (format.startsWith("HTB")) {
/*  33 */           len = Integer.parseInt(format.substring(3));
/*  34 */           output = ParserHTB.parseValue(input, len * 2);
/*  35 */         } else if (format.startsWith("HEX")) {
/*  36 */           len = Integer.parseInt(format.substring(3));
/*  37 */           output = ParserHEX.parseValue(input, len * 2);
/*  38 */         } else if (format.startsWith("STS")) {
/*  39 */           len = Integer.parseInt(format.substring(3));
/*  40 */           output = ParserString.parseValue(input, len * 2);
/*  41 */         } else if (format.startsWith("ASC")) {
/*  42 */           len = Integer.parseInt(format.substring(3));
/*  43 */           output = ParserASC.parseValue(input, len * 2);
/*  44 */         } else if (format.startsWith("SIM")) {
/*  45 */           len = Integer.parseInt(format.substring(3));
/*  46 */           output = ParserSIM.parseValue(input, len * 2);
/*  47 */         } else if (format.startsWith("BS")) {
/*  48 */           len = Integer.parseInt(format.substring(2));
/*  49 */           output = ParserBS.parseValue(input, len * 2);
/*  50 */         } else if (format.startsWith("IP")) {
/*  51 */           len = Integer.parseInt(format.substring(2));
/*  52 */           output = ParserIP.parseValue(input, len * 2);
/*  53 */         } else if (format.startsWith("N")) {
/*  54 */           len = Integer.parseInt(format.substring(1));
/*  55 */           output = ParserHTB.parseValue(input, len * 2);
/*  56 */         } else if (format.equals("A1")) {
/*  57 */           len = 6;
/*  58 */           output = ParserA1.parseValue(input, len * 2);
/*  59 */         } else if (format.equals("A2")) {
/*  60 */           len = 2;
/*  61 */           output = ParserA2.parseValue(input, len * 2);
/*  62 */         } else if (format.equals("A3")) {
/*  63 */           len = 4;
/*  64 */           output = ParserA3.parseValue(input, len * 2);
/*  65 */         } else if (format.equals("A4")) {
/*  66 */           len = 1;
/*  67 */           output = ParserFTB.parseValue(input, "CC", len * 2);
/*  68 */         } else if (format.equals("A5")) {
/*  69 */           len = 2;
/*  70 */           output = ParserFTB.parseValue(input, "CCC.C", len * 2);
/*  71 */         } else if (format.equals("A6")) {
/*  72 */           len = 2;
/*  73 */           output = ParserFTB.parseValue(input, "CC.CC", len * 2);
/*  74 */         } else if (format.equals("A7")) {
/*  75 */           len = 2;
/*  76 */           output = ParserFTB.parseValue(input, "000.0", len * 2);
/*  77 */         } else if (format.equals("A8")) {
/*  78 */           len = 2;
/*  79 */           output = ParserFTB.parseValue(input, "0000", len * 2);
/*  80 */         } else if (format.equals("A9")) {
/*  81 */           len = 3;
/*  82 */           output = ParserFTB.parseValue(input, "CC.CCCC", len * 2);
/*  83 */         } else if (format.equals("A10")) {
/*  84 */           len = 3;
/*  85 */           output = ParserFTB.parseValue(input, "000000", len * 2);
/*  86 */         } else if (format.equals("A11")) {
/*  87 */           len = 4;
/*  88 */           output = ParserFTB.parseValue(input, "000000.00", len * 2);
/*  89 */         } else if (format.equals("A12")) {
/*  90 */           len = 6;
/*  91 */           output = ParserFTB.parseValue(input, "000000000000", len * 2);
/*  92 */         } else if (format.equals("A13")) {
/*  93 */           len = 4;
/*  94 */           output = ParserFTB.parseValue(input, "0000.0000", len * 2);
/*  95 */         } else if (format.equals("A14")) {
/*  96 */           len = 5;
/*  97 */           output = ParserFTB.parseValue(input, "000000.0000", len * 2);
/*  98 */         } else if (format.equals("A15")) {
/*  99 */           len = 5;
/* 100 */           output = ParserDATE.parseValue(input, "yyyy-MM-dd HH:mm", "yyMMddHHmm", len * 2);
/* 101 */         } else if (format.equals("A16")) {
/* 102 */           len = 4;
/* 103 */           output = ParserDATE.parseValue(input, "dd HH:mm:ss", "ddHHmmss", len * 2);
/* 104 */         } else if (format.equals("A17")) {
/* 105 */           len = 4;
/* 106 */           output = ParserDATE.parseValue(input, "MM-dd HH:mm", "MMddHHmm", len * 2);
/* 107 */         } else if (format.equals("A18")) {
/* 108 */           len = 3;
/* 109 */           output = ParserDATE.parseValue(input, "dd HH:mm", "ddHHmm", len * 2);
/* 110 */         } else if (format.equals("A19")) {
/* 111 */           len = 2;
/* 112 */           output = ParserDATE.parseValue(input, "HH:mm", "HHmm", len * 2);
/* 113 */         } else if (format.equals("A20")) {
/* 114 */           len = 3;
/* 115 */           output = ParserDATE.parseValue(input, "yyyy-MM-dd", "yyMMdd", len * 2);
/* 116 */         } else if (format.equals("A21")) {
/* 117 */           len = 2;
/* 118 */           output = ParserDATE.parseValue(input, "yyyy-MM", "yyMM", len * 2);
/* 119 */         } else if (format.equals("A22")) {
/* 120 */           len = 1;
/* 121 */           output = ParserFTB.parseValue(input, "0.0", len * 2);
/* 122 */         } else if (format.equals("A23")) {
/* 123 */           len = 3;
/* 124 */           output = ParserFTB.parseValue(input, "00.0000", len * 2);
/* 125 */         } else if (format.equals("A24")) {
/* 126 */           len = 2;
/* 127 */           output = ParserDATE.parseValue(input, "dd HH", "ddHH", len * 2);
/* 128 */         } else if (format.equals("A25")) {
/* 129 */           len = 3;
/* 130 */           output = ParserFTB.parseValue(input, "CCC.CCC", len * 2);
/* 131 */         } else if (format.equals("A26")) {
/* 132 */           len = 2;
/* 133 */           output = ParserFTB.parseValue(input, "0.000", len * 2);
/* 134 */         } else if (format.equals("A27")) {
/* 135 */           len = 4;
/* 136 */           output = ParserFTB.parseValue(input, "00000000", len * 2);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 140 */         log.error("constructor error:" + e.toString());
/*     */       }
/* 142 */       dataValue.setValue(output);
/* 143 */       dataValue.setLen(len * 2);
/*     */     }
/*     */     catch (Exception e) {
/* 146 */       log.equals("parsevalue error:" + e.toString());
/*     */     }
/* 148 */     return dataValue;
/*     */   }
/*     */ 
/*     */   public static int[] measuredPointParser(String sDA)
/*     */   {
/* 154 */     int iCount = 0;
/* 155 */     int[] measuredListTemp = new int[8];
/*     */     try {
/* 157 */       String sDA1 = sDA.substring(0, 2);
/* 158 */       String sDA2 = sDA.substring(2, 4);
/* 159 */       if (sDA.equals("0000")) {
/* 160 */         iCount = 1;
/* 161 */         measuredListTemp[0] = 0;
/*     */       }
/*     */       else {
/* 164 */         int iDA2 = Integer.parseInt(sDA2, 16);
/* 165 */         char[] cDA1 = DataSwitch.Fun2HexTo8Bin(sDA1).toCharArray();
/* 166 */         for (int i = 7; i >= 0; --i)
/* 167 */           if (cDA1[i] == '1') {
/* 168 */             measuredListTemp[iCount] = ((iDA2 - 1) * 8 + 8 - i);
/*     */ 
/* 170 */             iCount += 1;
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 176 */       log.error("MeasuredPointParser error:" + e.toString());
/*     */     }
/* 178 */     int[] measuredList = new int[iCount];
/* 179 */     for (int i = 0; i < iCount; ++i) {
/* 180 */       measuredList[i] = measuredListTemp[i];
/*     */     }
/* 182 */     return measuredList;
/*     */   }
/*     */ 
/*     */   public static String[] dataCodeParser(String sDT, String sAFN) {
/* 186 */     int iCount = 0;
/* 187 */     int[] codeListTemp = new int[8];
/*     */     try {
/* 189 */       String sDT1 = sDT.substring(0, 2);
/* 190 */       String sDT2 = sDT.substring(2, 4);
/*     */ 
/* 192 */       int iDT2 = Integer.parseInt(sDT2, 16);
/* 193 */       char[] cDT1 = DataSwitch.Fun2HexTo8Bin(sDT1).toCharArray();
/* 194 */       for (int i = 7; i >= 0; --i) {
/* 195 */         if (cDT1[i] == '1') {
/* 196 */           codeListTemp[iCount] = (iDT2 * 8 + 8 - i);
/*     */ 
/* 198 */           iCount += 1;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 204 */       log.error("dataCodeParser error:" + e.toString());
/*     */     }
/* 206 */     String[] codeList = new String[iCount];
/* 207 */     for (int i = 0; i < iCount; ++i) {
/* 208 */       codeList[i] = sAFN + "F" + DataSwitch.StrStuff("0", 3, new StringBuilder().append("").append(codeListTemp[i]).toString(), "left");
/*     */     }
/* 210 */     return codeList;
/*     */   }
/*     */ 
/*     */   public static DataTimeTag getTaskDateTimeInfo(String sDateTimeLabel, int DateType) {
/* 214 */     DataTimeTag dataTimeTag = new DataTimeTag();
/*     */     try {
/* 216 */       String sDateTime = ""; String sNowDateTime = "";
/* 217 */       int iDataDensity = 0; int iDataCount = 0;
/* 218 */       if (DateType == 1)
/*     */       {
/* 220 */         sDateTime = "" + (Integer.parseInt(sDateTimeLabel.substring(0, 1)) & 0x3) + sDateTimeLabel.substring(1, 2);
/*     */ 
/* 222 */         iDataDensity = Integer.parseInt(sDateTimeLabel.substring(2, 4), 16);
/*     */ 
/* 224 */         Calendar cLogTime = Calendar.getInstance();
/* 225 */         SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmm");
/* 226 */         sNowDateTime = formatter.format(cLogTime.getTime());
/*     */       }
/* 232 */       else if (DateType == 2)
/*     */       {
/* 234 */         sDateTime = "20" + DataSwitch.ReverseStringByByte(sDateTimeLabel.substring(0, 10));
/*     */ 
/* 236 */         iDataDensity = Integer.parseInt(sDateTimeLabel.substring(10, 12), 16);
/*     */ 
/* 238 */         iDataCount = Integer.parseInt(sDateTimeLabel.substring(12, 14), 16);
/* 239 */       } else if (DateType == 3)
/*     */       {
/* 241 */         sDateTime = parseValue(sDateTimeLabel.substring(0, 6), "A20").getValue();
/* 242 */       } else if (DateType == 4)
/*     */       {
/* 244 */         sDateTime = parseValue(sDateTimeLabel.substring(0, 4), "A21").getValue();
/*     */       }
/* 246 */       switch (iDataDensity)
/*     */       {
/*     */       case 1:
/* 248 */         iDataDensity = 15;
/* 249 */         if (DateType == 1)
/*     */         {
/* 251 */           sDateTime = sNowDateTime.substring(0, 8) + sDateTime + "15";
/* 252 */           iDataCount = 4; } break;
/*     */       case 2:
/* 257 */         iDataDensity = 30;
/* 258 */         if (DateType == 1)
/*     */         {
/* 260 */           sDateTime = sNowDateTime.substring(0, 8) + sDateTime + "30";
/* 261 */           iDataCount = 2; } break;
/*     */       case 3:
/* 266 */         iDataDensity = 60;
/* 267 */         if (DateType == 1) {
/* 268 */           sDateTime = sNowDateTime.substring(0, 8) + sDateTime + "00";
/* 269 */           iDataCount = 1; } break;
/*     */       case 254:
/* 274 */         iDataDensity = 5;
/* 275 */         if (DateType == 1) {
/* 276 */           sDateTime = sNowDateTime.substring(0, 8) + sDateTime + "05";
/* 277 */           iDataCount = 12; } break;
/*     */       case 255:
/* 282 */         iDataDensity = 1;
/* 283 */         if (DateType == 1) {
/* 284 */           sDateTime = sNowDateTime.substring(0, 8) + sDateTime + "01";
/* 285 */           iDataCount = 60; } break;
/*     */       default:
/* 290 */         iDataDensity = 0;
/* 291 */         iDataCount = 1;
/*     */       }
/*     */ 
/* 294 */       dataTimeTag.setDataTime(sDateTime);
/* 295 */       dataTimeTag.setDataDensity(iDataDensity);
/* 296 */       dataTimeTag.setDataCount(iDataCount);
/*     */     } catch (Exception e) {
/* 298 */       log.error("getTaskDateTimeInfo error：" + e.toString());
/*     */     }
/* 300 */     return dataTimeTag;
/*     */   }
/*     */ 
/*     */   public static DataValue parser(String input, String format)
/*     */   {
/* 310 */     DataValue dataItem = new DataValue();
/*     */     try {
/* 312 */       String[] formatItems = format.split("#");
/* 313 */       String value = "";
/* 314 */       int len = 0;
/* 315 */       DataValue dataItemTemp = new DataValue();
/* 316 */       if (formatItems.length > 0) {
/* 317 */         for (int i = 0; i < formatItems.length; ++i) {
/* 318 */           if (formatItems[i].startsWith("N")) {
/* 319 */             DataValue nValue = new DataValue();
/* 320 */             nValue = parseValue(input, formatItems[i]);
/* 321 */             input = input.substring(nValue.getLen());
/* 322 */             format = format.substring(format.indexOf("#") + 1);
/* 323 */             value = value + nValue.getValue() + "#";
/* 324 */             len += nValue.getLen();
/* 325 */             for (int j = 0; j < Integer.parseInt(nValue.getValue()); ++j) {
/* 326 */               dataItemTemp = parser(input, format);
/* 327 */               input = input.substring(dataItemTemp.getLen());
/* 328 */               if (format.indexOf("N") >= 0) {
/* 329 */                 value = value + dataItemTemp.getValue() + ";";
/*     */               }
/*     */               else {
/* 332 */                 value = value + dataItemTemp.getValue() + ",";
/*     */               }
/* 334 */               len += dataItemTemp.getLen();
/*     */             }
/* 336 */             if ((!(value.endsWith(","))) && (!(value.endsWith(";")))) break;
/* 337 */             value = value.substring(0, value.length() - 1); break;
/*     */           }
/*     */ 
/* 342 */           dataItemTemp = parseValue(input, formatItems[i]);
/* 343 */           input = input.substring(dataItemTemp.getLen());
/* 344 */           format = format.substring(format.indexOf("#") + 1);
/* 345 */           value = value + dataItemTemp.getValue() + "#";
/* 346 */           len += dataItemTemp.getLen();
/*     */         }
/*     */ 
/* 349 */         if (value.endsWith("#"))
/* 350 */           value = value.substring(0, value.length() - 1);
/* 351 */         dataItem.setValue(value);
/* 352 */         dataItem.setLen(len);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 356 */       log.error("coder error:" + e.toString());
/*     */     }
/* 358 */     return dataItem;
/*     */   }
/*     */ }