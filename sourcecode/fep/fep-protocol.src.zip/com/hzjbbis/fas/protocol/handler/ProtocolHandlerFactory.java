/*    */ package com.hzjbbis.fas.protocol.handler;
/*    */ 
/*    */ import com.hzjbbis.fas.protocol.codec.MessageCodecFactory;
/*    */ import com.hzjbbis.fas.protocol.conf.CodecFactoryConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolHandlerConfig;
/*    */ import com.hzjbbis.fas.protocol.conf.ProtocolProviderConfig;
/*    */ import com.hzjbbis.fas.protocol.meter.MeterProtocolFactory;
/*    */ import com.hzjbbis.util.CastorUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ProtocolHandlerFactory
/*    */ {
/*    */   private static final String CONFIG_MAPPING = "/com/hzjbbis/fas/protocol/conf/protocol-provider-config-mapping.xml";
/*    */   private static final String CONFIG_RESOURCE = "/com/hzjbbis/fas/protocol/conf/protocol-provider-config.xml";
/*    */   private static ProtocolHandlerFactory instance;
/* 29 */   private Map handlers = new HashMap();
/*    */ 
/*    */   private ProtocolHandlerFactory()
/*    */   {
/* 36 */     init();
/*    */   }
/*    */ 
/*    */   public static ProtocolHandlerFactory getInstance()
/*    */   {
/* 44 */     if (instance == null) {
/* 45 */       synchronized (ProtocolHandlerFactory.class) {
/* 46 */         if (instance == null) {
/* 47 */           instance = new ProtocolHandlerFactory();
/*    */         }
/*    */       }
/*    */     }
/* 51 */     return instance;
/*    */   }
/*    */ 
/*    */   public ProtocolHandler getProtocolHandler(Class messageType)
/*    */   {
/* 60 */     return ((ProtocolHandler)this.handlers.get(messageType.getName()));
/*    */   }
/*    */ 
/*    */   private void init()
/*    */   {
/* 67 */     ProtocolProviderConfig config = (ProtocolProviderConfig)CastorUtil.unmarshal("/com/hzjbbis/fas/protocol/conf/protocol-provider-config-mapping.xml", "/com/hzjbbis/fas/protocol/conf/protocol-provider-config.xml");
/*    */ 
/* 69 */     List handlerConfigs = config.getHandlers();
/* 70 */     for (int i = 0; i < handlerConfigs.size(); ++i) {
/* 71 */       ProtocolHandlerConfig handlerConfig = (ProtocolHandlerConfig)handlerConfigs.get(i);
/* 72 */       ProtocolHandler handler = (ProtocolHandler)newInstance(handlerConfig.getHandlerClass());
/* 73 */       CodecFactoryConfig codecFactoryConfig = handlerConfig.getCodecFactory();
/* 74 */       if (codecFactoryConfig != null) {
/* 75 */         MessageCodecFactory codecFactory = (MessageCodecFactory)newInstance(codecFactoryConfig.getFactoryClass());
/*    */ 
/* 77 */         codecFactory.setConfig(codecFactoryConfig);
/* 78 */         handler.setCodecFactory(codecFactory);
/*    */       }
/*    */ 
/* 81 */       this.handlers.put(handlerConfig.getMessageType(), handler);
/*    */     }
/*    */ 
/* 85 */     MeterProtocolFactory.createMeterProtocolDataSet("ZJMeter");
/* 86 */     MeterProtocolFactory.createMeterProtocolDataSet("BBMeter");
/*    */   }
/*    */ 
/*    */   private Object newInstance(String className)
/*    */   {
/*    */     try
/*    */     {
/* 96 */       Class clazz = Class.forName(className);
/* 97 */       return clazz.newInstance();
/*    */     }
/*    */     catch (Exception ex) {
/* 100 */       throw new RuntimeException("Error to instantiating class: " + className, ex);
/*    */     }
/*    */   }
/*    */ }