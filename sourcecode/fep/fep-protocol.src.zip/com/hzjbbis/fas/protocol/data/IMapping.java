package com.hzjbbis.fas.protocol.data;

public abstract interface IMapping
{
  public abstract DataItem getDataItem(String paramString);
}