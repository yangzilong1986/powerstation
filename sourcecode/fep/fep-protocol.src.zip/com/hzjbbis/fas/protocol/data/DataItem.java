/*    */ package com.hzjbbis.fas.protocol.data;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class DataItem
/*    */ {
/*    */   private Hashtable property;
/*    */ 
/*    */   public DataItem()
/*    */   {
/*  9 */     this.property = new Hashtable();
/*    */   }
/*    */ 
/*    */   public Hashtable getPropertys() {
/* 13 */     return this.property;
/*    */   }
/*    */ 
/*    */   public Object getProperty(String key)
/*    */   {
/* 22 */     if ((this.property != null) && 
/* 23 */       (this.property.containsKey(key))) {
/* 24 */       return this.property.get(key);
/*    */     }
/*    */ 
/* 27 */     return null;
/*    */   }
/*    */ 
/*    */   public void addProperty(String key, Object value) {
/*    */     try {
/* 32 */       if (this.property != null) {
/* 33 */         if (this.property.containsKey(key)) {
/* 34 */           this.property.remove(key);
/*    */         }
/* 36 */         this.property.put(key, value);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/*    */     }
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 44 */     return ((String)this.property.get("des"));
/*    */   }
/*    */ }