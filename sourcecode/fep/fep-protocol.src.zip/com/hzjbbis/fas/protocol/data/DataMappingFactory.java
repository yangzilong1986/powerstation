/*    */ package com.hzjbbis.fas.protocol.data;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class DataMappingFactory
/*    */ {
/*    */   private static Hashtable datamappings;
/* 12 */   private static Object lock = new Object();
/*    */ 
/*    */   public static IMapping createDataMapping(String key)
/*    */   {
/* 20 */     synchronized (lock) {
/* 21 */       if (datamappings == null) {
/* 22 */         datamappings = new Hashtable();
/*    */       }
/* 24 */       if (!(datamappings.containsKey(key)))
/*    */       {
/* 26 */         datamappings.put(key, createMapping(key));
/*    */       }
/* 28 */       return ((IMapping)datamappings.get(key));
/*    */     }
/*    */   }
/*    */ 
/*    */   private static IMapping createMapping(String key)
/*    */   {
/* 38 */     if (key.equals("ZJ")) {
/* 39 */       return new DataMappingZJ();
/*    */     }
/* 41 */     return null;
/*    */   }
/*    */ }