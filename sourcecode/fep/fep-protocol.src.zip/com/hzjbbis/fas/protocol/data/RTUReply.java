/*    */ package com.hzjbbis.fas.protocol.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RTUReply
/*    */ {
/*    */   private int type;
/*    */   private List data;
/*    */   private String des;
/*    */ 
/*    */   public RTUReply()
/*    */   {
/* 12 */     this(0, null);
/*    */   }
/*    */ 
/*    */   public RTUReply(int type, List data) {
/* 16 */     this.type = type;
/* 17 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public void addDataItem(DataItem item)
/*    */   {
/* 25 */     if (this.data == null) {
/* 26 */       this.data = new ArrayList();
/*    */     }
/* 28 */     this.data.add(item);
/*    */   }
/*    */ 
/*    */   public List getData()
/*    */   {
/* 35 */     return this.data;
/*    */   }
/*    */ 
/*    */   public void setData(List data)
/*    */   {
/* 43 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public int getType()
/*    */   {
/* 51 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(int type)
/*    */   {
/* 59 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 64 */     return this.des;
/*    */   }
/*    */ }