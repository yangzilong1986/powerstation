/*     */ package com.hzjbbis.fas.startup;
/*     */ 
/*     */ import com.hzjbbis.util.PathUtil;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import sun.misc.Launcher;
/*     */ import sun.misc.URLClassPath;
/*     */ 
/*     */ public class ClassLoaderUtil
/*     */ {
/*     */   private static Method addURL;
/*     */   private static URLClassLoader system;
/*     */   private static URLClassLoader ext;
/*     */ 
/*     */   public static ClassLoader getSystemClassLoader()
/*     */   {
/*  41 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */ 
/*     */   public static ClassLoader getExtClassLoader() {
/*  45 */     return getSystemClassLoader().getParent();
/*     */   }
/*     */ 
/*     */   public static URL[] getBootstrapURLs() {
/*  49 */     return Launcher.getBootstrapClassPath().getURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getSystemURLs() {
/*  53 */     return system.getURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getExtURLs() {
/*  57 */     return ext.getURLs();
/*     */   }
/*     */ 
/*     */   private static void list(PrintStream ps, URL[] classPath) {
/*  61 */     for (int i = 0; i < classPath.length; ++i)
/*  62 */       ps.println(classPath[i]);
/*     */   }
/*     */ 
/*     */   public static void listBootstrapClassPath()
/*     */   {
/*  67 */     listBootstrapClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listBootstrapClassPath(PrintStream ps) {
/*  71 */     ps.println("BootstrapClassPath:");
/*  72 */     list(ps, getBootstrapClassPath());
/*     */   }
/*     */ 
/*     */   public static void listSystemClassPath() {
/*  76 */     listSystemClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listSystemClassPath(PrintStream ps) {
/*  80 */     ps.println("SystemClassPath:");
/*  81 */     list(ps, getSystemClassPath());
/*     */   }
/*     */ 
/*     */   public static void listExtClassPath() {
/*  85 */     listExtClassPath(System.out);
/*     */   }
/*     */ 
/*     */   public static void listExtClassPath(PrintStream ps) {
/*  89 */     ps.println("ExtClassPath:");
/*  90 */     list(ps, getExtClassPath());
/*     */   }
/*     */ 
/*     */   public static URL[] getBootstrapClassPath() {
/*  94 */     return getBootstrapURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getSystemClassPath() {
/*  98 */     return getSystemURLs();
/*     */   }
/*     */ 
/*     */   public static URL[] getExtClassPath() {
/* 102 */     return getExtURLs();
/*     */   }
/*     */ 
/*     */   public static void addURL2SystemClassLoader(URL url) {
/*     */     try {
/* 107 */       addURL.invoke(system, new Object[] { url });
/*     */     } catch (Exception e) {
/* 109 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addURL2ExtClassLoader(URL url) {
/*     */     try {
/* 115 */       addURL.invoke(ext, new Object[] { url });
/*     */     } catch (Exception e) {
/* 117 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addClassPath(String path) {
/* 122 */     addClassPath(new File(path));
/*     */   }
/*     */ 
/*     */   public static void addExtClassPath(String path) {
/* 126 */     addExtClassPath(new File(path));
/*     */   }
/*     */ 
/*     */   public static void addClassPath(File dirOrJar) {
/*     */     try {
/* 131 */       addURL2SystemClassLoader(dirOrJar.toURL());
/*     */     } catch (MalformedURLException e) {
/* 133 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addExtClassPath(File dirOrJar) {
/*     */     try {
/* 139 */       addURL2ExtClassLoader(dirOrJar.toURL());
/*     */     } catch (MalformedURLException e) {
/* 141 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initializeClassPath() {
/* 146 */     String workDir = System.getProperty("user.dir");
/* 147 */     String classRootPath = PathUtil.getRootPath(Application.class);
/*     */ 
/* 149 */     int cnt = 1;
/* 150 */     if ((null != classRootPath) && (cnt-- > 0)) {
/*     */       try
/*     */       {
/* 153 */         File froot = new File(classRootPath);
/* 154 */         File fwork = new File(workDir);
/* 155 */         boolean same = froot.getCanonicalPath().equalsIgnoreCase(fwork.getCanonicalPath());
/* 156 */         if (!(same))
/*     */         {
/* 159 */           File fup = froot.getParentFile();
/* 160 */           boolean upsame = fup.getCanonicalPath().equalsIgnoreCase(fwork.getCanonicalPath());
/* 161 */           if (!(upsame))
/*     */           {
/* 165 */             boolean rootIsPlugins = froot.getName().equalsIgnoreCase("plugins");
/* 166 */             if (rootIsPlugins) {
/* 167 */               System.setProperty("user.dir", fup.getCanonicalPath());
/* 168 */               workDir = fup.getCanonicalPath();
/*     */             }
/* 173 */             else if ((froot.getName().equalsIgnoreCase("lib")) || (froot.getName().equalsIgnoreCase("libs")))
/*     */             {
/* 175 */               addDir2ClassPath(froot.getAbsolutePath(), true);
/* 176 */               addClassPath(fup.getAbsolutePath());
/*     */ 
/* 178 */               System.setProperty("user.dir", fup.getCanonicalPath());
/* 179 */               workDir = fup.getCanonicalPath();
/*     */             }
/* 183 */             else if ((fup.getName().equalsIgnoreCase("lib")) || (fup.getName().equalsIgnoreCase("libs")))
/*     */             {
/* 185 */               File fupup = fup.getParentFile();
/*     */ 
/* 187 */               addDir2ClassPath(fup.getAbsolutePath(), true);
/* 188 */               addClassPath(fupup.getAbsolutePath());
/*     */ 
/* 190 */               System.setProperty("user.dir", fupup.getCanonicalPath());
/* 191 */               workDir = fupup.getCanonicalPath();
/*     */             }
/*     */             else
/*     */             {
/* 196 */               boolean upIsPlugins = fup.getName().equalsIgnoreCase("plugins");
/* 197 */               if (upIsPlugins) {
/* 198 */                 System.setProperty("user.dir", fup.getParentFile().getCanonicalPath());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception exp)
/*     */       {
/* 206 */         exp.printStackTrace();
/* 207 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 211 */     File file = new File("log");
/* 212 */     if ((null != file) && 
/* 214 */       (!(file.isDirectory()))) {
/* 215 */       file.mkdir();
/*     */     }
/*     */ 
/* 218 */     addDir2ClassPath(".", false);
/* 219 */     addDir2ClassPath(workDir + File.separator + "classess", false);
/* 220 */     addDir2ClassPath(workDir + File.separator + "lib", true);
/* 221 */     addDir2ClassPath(workDir + File.separator + "libs", true);
/* 222 */     addDir2ClassPath(workDir + File.separator + "config", false);
/* 223 */     addDir2ClassPath(workDir + File.separator + "images", false);
/* 224 */     addDir2ClassPath(workDir + File.separator + "icons", false);
/* 225 */     addDir2ClassPath(workDir + File.separator + "configuration", false);
/* 226 */     addDir2ClassPath(workDir + File.separator + "cfg", false);
/* 227 */     listSystemClassPath();
/*     */   }
/*     */ 
/*     */   private static void addFile2ClassPath(String filename) {
/* 231 */     File file = new File(filename);
/* 232 */     if (!(file.isFile()))
/* 233 */       return;
/* 234 */     if (filename.toLowerCase().endsWith(".jar")) {
/* 235 */       addClassPath(file);
/*     */     }
/* 237 */     if (filename.toLowerCase().endsWith(".zip"))
/* 238 */       addClassPath(file);
/*     */   }
/*     */ 
/*     */   private static void addDir2ClassPath(String dir, boolean includeSub)
/*     */   {
/* 243 */     File file = new File(dir);
/* 244 */     if (!(file.isDirectory())) {
/* 245 */       return;
/*     */     }
/* 247 */     if (dir.equalsIgnoreCase("."))
/*     */     {
/* 249 */       classPath = null;
/*     */       try {
/* 251 */         classPath = file.getCanonicalPath();
/*     */       }
/*     */       catch (Exception exp) {
/* 254 */         return;
/*     */       }
/* 256 */       addClassPath(classPath);
/* 257 */       return;
/*     */     }
/*     */ 
/* 260 */     dir = file.getName();
/* 261 */     String classPath = null;
/*     */     try {
/* 263 */       classPath = file.getCanonicalPath();
/*     */     }
/*     */     catch (Exception exp) {
/* 266 */       return;
/*     */     }
/*     */ 
/* 269 */     if ((dir.equalsIgnoreCase("com")) || (dir.equalsIgnoreCase("org")))
/*     */     {
/* 272 */       addClassPath(file.getParent());
/* 273 */       return;
/*     */     }
/* 275 */     if ((dir.equalsIgnoreCase("config")) || (dir.equalsIgnoreCase("configuration")) || (dir.equalsIgnoreCase("classes")) || (dir.equalsIgnoreCase("cfg")))
/*     */     {
/* 280 */       addClassPath(classPath);
/* 281 */       return;
/*     */     }
/*     */ 
/* 292 */     if (!(includeSub)) {
/* 293 */       return;
/*     */     }
/* 295 */     File[] files = file.listFiles();
/* 296 */     for (int i = 0; i < files.length; ++i)
/* 297 */       if (files[i].isFile()) {
/* 298 */         addFile2ClassPath(files[i].getPath()); } else {
/* 299 */         if (!(files[i].isDirectory()))
/*     */           continue;
/* 301 */         addDir2ClassPath(files[i].getPath(), includeSub);
/*     */       }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  26 */       addURL = URLClassLoader.class.getDeclaredMethod("addURL", new Class[] { URL.class });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  30 */       throw new RuntimeException(e);
/*     */     }
/*  32 */     addURL.setAccessible(true);
/*     */ 
/*  35 */     system = (URLClassLoader)getSystemClassLoader();
/*     */ 
/*  37 */     ext = (URLClassLoader)getExtClassLoader();
/*     */   }
/*     */ }