/*    */ package com.hzjbbis.fas.startup;
/*    */ 
/*    */ import com.hzjbbis.fas.model.FaalGWNoParamRequest;
/*    */ import com.hzjbbis.fas.model.FaalRequestRtuParam;
/*    */ import com.hzjbbis.fas.protocol.handler.ProtocolHandler;
/*    */ import com.hzjbbis.fas.protocol.handler.ProtocolHandlerFactory;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.gw.MessageGw;
/*    */ 
/*    */ public class Application
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 25 */     initialize();
/* 26 */     IMessage msg = new MessageGw();
/* 27 */     ProtocolHandlerFactory factory = ProtocolHandlerFactory.getInstance();
/* 28 */     ProtocolHandler handler = factory.getProtocolHandler(MessageGw.class);
/*    */ 
/* 30 */     FaalGWNoParamRequest request = new FaalGWNoParamRequest();
/* 31 */     FaalRequestRtuParam rtuParam = new FaalRequestRtuParam();
/* 32 */     int[] tn = { 9 };
/* 33 */     rtuParam.setTn(tn);
/* 34 */     rtuParam.addParam("04F003", "10.137.253.8:8101#127.0.0.1:10000#zjdl.zj");
/* 35 */     request.setType(4);
/* 36 */     request.addRtuParam(rtuParam);
/* 37 */     IMessage[] messages = handler.createMessage(request);
/*    */   }
/*    */ 
/*    */   public static void initialize() {
/* 41 */     ClassLoaderUtil.initializeClassPath();
/*    */   }
/*    */ }