/*   */ package com.hzjbbis.fas.framework.message;
/*   */ 
/*   */ import com.hzjbbis.fk.message.MessageType;
/*   */ import com.hzjbbis.fk.message.zj.MessageZj;
/*   */ 
/*   */ public class MessageZjpb extends MessageZj
/*   */ {
/* 7 */   private static final MessageType type = MessageType.MSG_ZJPB;
/*   */ }