/*     */ package com.hzjbbis.fas.framework.spi;
/*     */ 
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ 
/*     */ public abstract class AbstractMessage
/*     */   implements IMessage
/*     */ {
/*  13 */   public MessageType msgType = MessageType.MSG_INVAL;
/*  14 */   protected int state = -1;
/*     */   private Object attachment;
/*  19 */   protected HashMap hmAttributes = new HashMap();
/*  20 */   protected int priority = 0;
/*     */   public ByteBuffer dataOut;
/*     */   public ByteBuffer dataIn;
/*  30 */   public String upRawString = "";
/*  31 */   public String downRawString = "";
/*     */   public AbstractMessage nextMessage;
/*  34 */   public long key = 0L;
/*  35 */   public long reqTime = System.currentTimeMillis();
/*  36 */   public long repTime = 0L;
/*  37 */   public int accesstime = 0;
/*  38 */   private boolean multiReply = false;
/*     */ 
/*  44 */   private Stack modulerStack = new Stack();
/*     */ 
/*     */   public AbstractMessage() {
/*  47 */     this.nextMessage = null;
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/*  51 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority) {
/*  55 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public boolean hasNextModule()
/*     */   {
/*  64 */     return (this.modulerStack.size() > 0);
/*     */   }
/*     */ 
/*     */   public Object getAttachment() {
/*  68 */     return this.attachment;
/*     */   }
/*     */ 
/*     */   public void setAttachment(Object obj) {
/*  72 */     this.attachment = obj;
/*     */   }
/*     */ 
/*     */   public MessageType getMessageType()
/*     */   {
/*  77 */     return this.msgType;
/*     */   }
/*     */ 
/*     */   public IMessage getNextMessage()
/*     */   {
/*  82 */     return this.nextMessage;
/*     */   }
/*     */ 
/*     */   public String getUpRawString() {
/*  86 */     return this.upRawString;
/*     */   }
/*     */ 
/*     */   public String getDownRawString() {
/*  90 */     return this.downRawString;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(Object key) {
/*  94 */     return this.hmAttributes.get(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(Object key, Object value) {
/*  98 */     if (this.hmAttributes.containsKey(key)) {
/*  99 */       this.hmAttributes.remove(key);
/*     */     }
/* 101 */     this.hmAttributes.put(key, value);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(Object key) {
/* 105 */     this.hmAttributes.remove(key);
/*     */   }
/*     */ 
/*     */   public void copyAttributes(AbstractMessage src) {
/* 109 */     Iterator it = src.hmAttributes.keySet().iterator();
/*     */ 
/* 111 */     while (it.hasNext()) {
/* 112 */       Object key = it.next();
/* 113 */       setAttribute(key, src.getAttribute(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getRtuaIn()
/*     */   {
/* 122 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getRtuaOut() {
/* 126 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getState() {
/* 130 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int state) {
/* 134 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public boolean isMultiReply() {
/* 138 */     return this.multiReply;
/*     */   }
/*     */ 
/*     */   public void setMultiReply(boolean multiReply) {
/* 142 */     this.multiReply = multiReply;
/*     */   }
/*     */ }