/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class FaalRequestResponse
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Long cmdId;
/*    */   private String rtuId;
/*    */   private String rtuType;
/*    */   private String cmdStatus;
/*    */   private Map<String, String> params;
/*    */ 
/*    */   public Long getCmdId()
/*    */   {
/* 25 */     return this.cmdId; }
/*    */ 
/*    */   public void setCmdId(Long cmdId) {
/* 28 */     this.cmdId = cmdId; }
/*    */ 
/*    */   public String getCmdStatus() {
/* 31 */     return this.cmdStatus; }
/*    */ 
/*    */   public void setCmdStatus(String cmdStatus) {
/* 34 */     this.cmdStatus = cmdStatus; }
/*    */ 
/*    */   public String getRtuId() {
/* 37 */     return this.rtuId; }
/*    */ 
/*    */   public void setRtuId(String rtuId) {
/* 40 */     this.rtuId = rtuId; }
/*    */ 
/*    */   public Map<String, String> getParams() {
/* 43 */     return this.params; }
/*    */ 
/*    */   public void setParams(Map<String, String> params) {
/* 46 */     this.params = params; }
/*    */ 
/*    */   public String getRtuType() {
/* 49 */     return this.rtuType; }
/*    */ 
/*    */   public void setRtuType(String rtuType) {
/* 52 */     this.rtuType = rtuType;
/*    */   }
/*    */ }