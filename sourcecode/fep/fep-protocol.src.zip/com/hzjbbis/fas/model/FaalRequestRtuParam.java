/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class FaalRequestRtuParam
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 8826872062189860710L;
/*    */   private String rtuId;
/*    */   private Long cmdId;
/*    */   private int[] tn;
/*    */   private List<FaalRequestParam> params;
/*    */ 
/*    */   public void addParam(String name, String value)
/*    */   {
/* 33 */     addParam(new FaalRequestParam(name, value));
/*    */   }
/*    */ 
/*    */   public void addParam(FaalRequestParam param)
/*    */   {
/* 40 */     if (this.params == null) {
/* 41 */       this.params = new ArrayList();
/*    */     }
/* 43 */     this.params.add(param); }
/*    */ 
/*    */   public String getRtuId() {
/* 46 */     return this.rtuId; }
/*    */ 
/*    */   public void setRtuId(String rtuId) {
/* 49 */     this.rtuId = rtuId; }
/*    */ 
/*    */   public Long getCmdId() {
/* 52 */     return this.cmdId; }
/*    */ 
/*    */   public void setCmdId(Long cmdId) {
/* 55 */     this.cmdId = cmdId; }
/*    */ 
/*    */   public int[] getTn() {
/* 58 */     return this.tn; }
/*    */ 
/*    */   public void setTn(int[] tn) {
/* 61 */     this.tn = tn; }
/*    */ 
/*    */   public List<FaalRequestParam> getParams() {
/* 64 */     return this.params; }
/*    */ 
/*    */   public void setParams(List<FaalRequestParam> params) {
/* 67 */     this.params = params;
/*    */   }
/*    */ }