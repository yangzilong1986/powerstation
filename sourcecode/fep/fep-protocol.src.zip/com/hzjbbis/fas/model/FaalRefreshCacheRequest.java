/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalRefreshCacheRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -5642795098417472194L;
/*    */   private String taskNum;
/*    */ 
/*    */   public FaalRefreshCacheRequest()
/*    */   {
/* 16 */     this.type = 254;
/*    */   }
/*    */ 
/*    */   public String getTaskNum()
/*    */   {
/* 23 */     return this.taskNum;
/*    */   }
/*    */ 
/*    */   public void setTaskNum(String taskNum)
/*    */   {
/* 29 */     this.taskNum = taskNum;
/*    */   }
/*    */ }