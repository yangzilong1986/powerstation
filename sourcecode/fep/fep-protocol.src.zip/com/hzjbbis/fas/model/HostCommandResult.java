/*     */ package com.hzjbbis.fas.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class HostCommandResult
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 278266439182006204L;
/*     */   public static final int STATUS_SUCCESS = 0;
/*     */   public static final int STATUS_AMBIGUOUS = 1;
/*     */   public static final int STATUS_FAILED = 2;
/*     */   private Long commandId;
/*     */   private String tn;
/*     */   private String alertCode;
/*     */   private String code;
/*     */   private String value;
/*     */   private Date time;
/*     */   private Date programTime;
/*     */   private String channel;
/*     */   private int status;
/*     */ 
/*     */   public Long getCommandId()
/*     */   {
/*  44 */     return this.commandId;
/*     */   }
/*     */ 
/*     */   public void setCommandId(Long commandId)
/*     */   {
/*  50 */     this.commandId = commandId;
/*     */   }
/*     */ 
/*     */   public String getTn()
/*     */   {
/*  56 */     return this.tn;
/*     */   }
/*     */ 
/*     */   public void setTn(String tn)
/*     */   {
/*  62 */     this.tn = tn;
/*     */   }
/*     */ 
/*     */   public String getAlertCode()
/*     */   {
/*  68 */     return this.alertCode;
/*     */   }
/*     */ 
/*     */   public void setAlertCode(String alertCode)
/*     */   {
/*  74 */     this.alertCode = alertCode;
/*     */   }
/*     */ 
/*     */   public String getCode()
/*     */   {
/*  80 */     return this.code;
/*     */   }
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/*  86 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  92 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/*  98 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public Date getTime()
/*     */   {
/* 104 */     return this.time;
/*     */   }
/*     */ 
/*     */   public void setTime(Date time)
/*     */   {
/* 110 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public Date getProgramTime()
/*     */   {
/* 116 */     return this.programTime;
/*     */   }
/*     */ 
/*     */   public void setProgramTime(Date programTime)
/*     */   {
/* 122 */     this.programTime = programTime;
/*     */   }
/*     */ 
/*     */   public String getChannel()
/*     */   {
/* 128 */     return this.channel;
/*     */   }
/*     */ 
/*     */   public void setChannel(String channel)
/*     */   {
/* 134 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 140 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 146 */     this.status = status;
/*     */   }
/*     */ }