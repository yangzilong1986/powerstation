/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class FaalRereadTaskResponse
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   private String logicAddress;
/*    */   private String taskNum;
/*    */   private String taskTemplateID;
/*    */   private Date SJSJ;
/*    */   private int rereadTag;
/*    */ 
/*    */   public String getLogicAddress()
/*    */   {
/* 24 */     return this.logicAddress; }
/*    */ 
/*    */   public void setLogicAddress(String logicAddress) {
/* 27 */     this.logicAddress = logicAddress; }
/*    */ 
/*    */   public String getTaskNum() {
/* 30 */     return this.taskNum; }
/*    */ 
/*    */   public void setTaskNum(String taskNum) {
/* 33 */     this.taskNum = taskNum; }
/*    */ 
/*    */   public Date getSJSJ() {
/* 36 */     return this.SJSJ; }
/*    */ 
/*    */   public void setSJSJ(Date sjsj) {
/* 39 */     this.SJSJ = sjsj; }
/*    */ 
/*    */   public int getRereadTag() {
/* 42 */     return this.rereadTag; }
/*    */ 
/*    */   public void setRereadTag(int rereadTag) {
/* 45 */     this.rereadTag = rereadTag; }
/*    */ 
/*    */   public String getTaskTemplateID() {
/* 48 */     return this.taskTemplateID; }
/*    */ 
/*    */   public void setTaskTemplateID(String taskTemplateID) {
/* 51 */     this.taskTemplateID = taskTemplateID;
/*    */   }
/*    */ }