/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class FaalReadAlertRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -654318745767829688L;
/*    */   private String tn;
/*    */   private Calendar startTime;
/*    */   private int count;
/*    */   private boolean doUpdate;
/*    */ 
/*    */   public FaalReadAlertRequest()
/*    */   {
/* 24 */     this.type = 9;
/*    */   }
/*    */ 
/*    */   public String getTn()
/*    */   {
/* 31 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String tn)
/*    */   {
/* 37 */     this.tn = tn;
/*    */   }
/*    */ 
/*    */   public Calendar getStartTime()
/*    */   {
/* 43 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public void setStartTime(Calendar startTime)
/*    */   {
/* 49 */     this.startTime = startTime;
/*    */   }
/*    */ 
/*    */   public int getCount()
/*    */   {
/* 55 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setCount(int count)
/*    */   {
/* 61 */     this.count = count;
/*    */   }
/*    */ 
/*    */   public boolean isDoUpdate()
/*    */   {
/* 67 */     return this.doUpdate;
/*    */   }
/*    */ 
/*    */   public void setDoUpdate(boolean doUpdate)
/*    */   {
/* 73 */     this.doUpdate = doUpdate;
/*    */   }
/*    */ }