/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class FaalWriteParamsRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = 6624139932292640887L;
/*    */   private String tn;
/*    */   private HashMap map;
/*    */ 
/*    */   public void setMap(String key, String value)
/*    */   {
/* 20 */     if (this.map == null)
/* 21 */       this.map = new HashMap();
/* 22 */     this.map.put(key, value);
/*    */   }
/*    */ 
/*    */   public String getValue(String key) {
/* 26 */     return ((String)this.map.get(key));
/*    */   }
/*    */ 
/*    */   public FaalWriteParamsRequest()
/*    */   {
/* 31 */     this.type = 8;
/*    */   }
/*    */ 
/*    */   public String getTn()
/*    */   {
/* 38 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String tn)
/*    */   {
/* 44 */     this.tn = tn;
/*    */   }
/*    */ }