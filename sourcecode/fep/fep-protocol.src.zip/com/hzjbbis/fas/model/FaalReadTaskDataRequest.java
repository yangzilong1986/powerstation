/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class FaalReadTaskDataRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -4362982183058685616L;
/*    */   private String taskNum;
/*    */   private Date startTime;
/*    */   private int count;
/*    */   private int frequence;
/*    */   private boolean doUpdate;
/*    */ 
/*    */   public FaalReadTaskDataRequest()
/*    */   {
/* 27 */     this.type = 2;
/*    */   }
/*    */ 
/*    */   public String getTaskNum()
/*    */   {
/* 34 */     return this.taskNum;
/*    */   }
/*    */ 
/*    */   public void setTaskNum(String taskNum)
/*    */   {
/* 40 */     this.taskNum = taskNum;
/*    */   }
/*    */ 
/*    */   public Date getStartTime()
/*    */   {
/* 46 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public void setStartTime(Date startTime)
/*    */   {
/* 52 */     this.startTime = startTime;
/*    */   }
/*    */ 
/*    */   public int getCount()
/*    */   {
/* 58 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setCount(int count)
/*    */   {
/* 64 */     this.count = count;
/*    */   }
/*    */ 
/*    */   public int getFrequence()
/*    */   {
/* 70 */     return this.frequence;
/*    */   }
/*    */ 
/*    */   public void setFrequence(int frequence)
/*    */   {
/* 76 */     this.frequence = frequence;
/*    */   }
/*    */ 
/*    */   public boolean isDoUpdate()
/*    */   {
/* 82 */     return this.doUpdate;
/*    */   }
/*    */ 
/*    */   public void setDoUpdate(boolean doUpdate)
/*    */   {
/* 88 */     this.doUpdate = doUpdate;
/*    */   }
/*    */ }