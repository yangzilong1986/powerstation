/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class RtuParam
/*    */ {
/*    */   private String rtuid;
/*    */   private Date opttime;
/*    */   private int curve;
/*    */ 
/*    */   public int getCurve()
/*    */   {
/* 18 */     return this.curve; }
/*    */ 
/*    */   public Date getOpttime() {
/* 21 */     return this.opttime; }
/*    */ 
/*    */   public String getRtuid() {
/* 24 */     return this.rtuid; }
/*    */ 
/*    */   public void setCurve(int curve) {
/* 27 */     this.curve = curve; }
/*    */ 
/*    */   public void setOpttime(Date opttime) {
/* 30 */     this.opttime = opttime; }
/*    */ 
/*    */   public void setRtuid(String rtuid) {
/* 33 */     this.rtuid = rtuid;
/*    */   }
/*    */ }