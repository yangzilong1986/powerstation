/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalGWAFN10Request extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -462982183058685616L;
/*    */   private String tpSendTime;
/*    */   private int tpTimeout;
/*    */   private int port;
/*    */   private String kzz;
/*    */   private String msgTimeout;
/*    */   private int byteTimeout;
/*    */   private String fixProto;
/*    */   private String fixAddre;
/* 26 */   private boolean broadcast = false;
/*    */   private String broadcastAddress;
/*    */ 
/*    */   public String getTpSendTime()
/*    */   {
/* 32 */     return this.tpSendTime; }
/*    */ 
/*    */   public void setTpSendTime(String tpSendTime) {
/* 35 */     this.tpSendTime = tpSendTime; }
/*    */ 
/*    */   public int getTpTimeout() {
/* 38 */     return this.tpTimeout; }
/*    */ 
/*    */   public void setTpTimeout(int tpTimeout) {
/* 41 */     this.tpTimeout = tpTimeout; }
/*    */ 
/*    */   public int getPort() {
/* 44 */     return this.port; }
/*    */ 
/*    */   public void setPort(int port) {
/* 47 */     this.port = port; }
/*    */ 
/*    */   public String getKzz() {
/* 50 */     return this.kzz; }
/*    */ 
/*    */   public void setKzz(String kzz) {
/* 53 */     this.kzz = kzz; }
/*    */ 
/*    */   public String getMsgTimeout() {
/* 56 */     return this.msgTimeout; }
/*    */ 
/*    */   public void setMsgTimeout(String msgTimeout) {
/* 59 */     this.msgTimeout = msgTimeout; }
/*    */ 
/*    */   public int getByteTimeout() {
/* 62 */     return this.byteTimeout; }
/*    */ 
/*    */   public void setByteTimeout(int byteTimeout) {
/* 65 */     this.byteTimeout = byteTimeout; }
/*    */ 
/*    */   public String getFixProto() {
/* 68 */     return this.fixProto; }
/*    */ 
/*    */   public void setFixProto(String fixProto) {
/* 71 */     this.fixProto = fixProto; }
/*    */ 
/*    */   public String getFixAddre() {
/* 74 */     return this.fixAddre; }
/*    */ 
/*    */   public void setFixAddre(String fixAddre) {
/* 77 */     this.fixAddre = fixAddre; }
/*    */ 
/*    */   public String getBroadcastAddress() {
/* 80 */     return this.broadcastAddress; }
/*    */ 
/*    */   public void setBroadcastAddress(String broadcastAddress) {
/* 83 */     this.broadcastAddress = broadcastAddress; }
/*    */ 
/*    */   public boolean getBroadcast() {
/* 86 */     return this.broadcast; }
/*    */ 
/*    */   public void setBroadcast(boolean broadcast) {
/* 89 */     this.broadcast = broadcast;
/*    */   }
/*    */ }