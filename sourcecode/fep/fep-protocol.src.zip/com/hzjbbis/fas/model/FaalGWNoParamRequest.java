/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalGWNoParamRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -162982183058685616L;
/*    */   private String tpSendTime;
/*    */   private int tpTimeout;
/*    */ 
/*    */   public String getTpSendTime()
/*    */   {
/* 16 */     return this.tpSendTime; }
/*    */ 
/*    */   public void setTpSendTime(String tpSendTime) {
/* 19 */     this.tpSendTime = tpSendTime; }
/*    */ 
/*    */   public int getTpTimeout() {
/* 22 */     return this.tpTimeout; }
/*    */ 
/*    */   public void setTpTimeout(int tpTimeout) {
/* 25 */     this.tpTimeout = tpTimeout;
/*    */   }
/*    */ }