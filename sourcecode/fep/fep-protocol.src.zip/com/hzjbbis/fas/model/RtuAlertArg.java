/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class RtuAlertArg
/*    */ {
/*    */   private Long alertId;
/*    */   private String code;
/*    */   private String value;
/*    */   private String correlValue;
/*    */ 
/*    */   public Long getAlertId()
/*    */   {
/* 22 */     return this.alertId;
/*    */   }
/*    */ 
/*    */   public void setAlertId(Long alertId)
/*    */   {
/* 28 */     this.alertId = alertId;
/*    */   }
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 34 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code)
/*    */   {
/* 40 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 46 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value)
/*    */   {
/* 52 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getCorrelValue()
/*    */   {
/* 58 */     return this.correlValue;
/*    */   }
/*    */ 
/*    */   public void setCorrelValue(String correlValue)
/*    */   {
/* 64 */     this.correlValue = correlValue;
/*    */   }
/*    */ }