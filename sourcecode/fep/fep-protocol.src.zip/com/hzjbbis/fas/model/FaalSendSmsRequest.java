/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class FaalSendSmsRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = 1559576885378604677L;
/*    */   private String[] mobiles;
/*    */   private String content;
/*    */   private int ctype;
/*    */   private List<String> smsids;
/*    */ 
/*    */   public FaalSendSmsRequest()
/*    */   {
/* 24 */     this.type = 40;
/*    */   }
/*    */ 
/*    */   public String[] getMobiles()
/*    */   {
/* 31 */     return this.mobiles;
/*    */   }
/*    */ 
/*    */   public void setMobiles(String[] mobiles)
/*    */   {
/* 37 */     this.mobiles = mobiles;
/*    */   }
/*    */ 
/*    */   public String getContent()
/*    */   {
/* 43 */     return this.content;
/*    */   }
/*    */ 
/*    */   public void setContent(String content)
/*    */   {
/* 49 */     this.content = content;
/*    */   }
/*    */ 
/*    */   public int getCtype() {
/* 53 */     return this.ctype;
/*    */   }
/*    */ 
/*    */   public void setCtype(int ctype) {
/* 57 */     this.ctype = ctype;
/*    */   }
/*    */ 
/*    */   public List<String> getSmsids() {
/* 61 */     return this.smsids;
/*    */   }
/*    */ 
/*    */   public void setSmsids(List<String> smsids) {
/* 65 */     this.smsids = smsids;
/*    */   }
/*    */ }