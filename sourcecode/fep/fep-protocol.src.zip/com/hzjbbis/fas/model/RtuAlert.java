/*     */ package com.hzjbbis.fas.model;
/*     */ 
/*     */ import com.hzjbbis.util.HexDump;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RtuAlert
/*     */ {
/*  15 */   private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*     */   public static final String FLAG_UNPROCESSED = "00";
/*     */   public static final String FLAG_PROCESSED = "01";
/*     */   private String dataSaveID;
/*     */   private String corpNo;
/*     */   private String customerNo;
/*     */   private String rtuId;
/*     */   private String tn;
/*     */   private String stationNo;
/*     */   private int alertCode;
/*     */   private String alertCodeHex;
/*     */   private Date alertTime;
/*     */   private Date receiveTime;
/*     */   private String processFlag;
/*     */   private List args;
/*     */   private String sbcs;
/*     */   private String txfs;
/*     */ 
/*     */   public RtuAlert()
/*     */   {
/*  42 */     this.processFlag = "00";
/*     */   }
/*     */ 
/*     */   public void addAlertArg(RtuAlertArg arg)
/*     */   {
/*  54 */     if (this.args == null) {
/*  55 */       this.args = new ArrayList();
/*     */     }
/*  57 */     this.args.add(arg);
/*     */   }
/*     */ 
/*     */   public String getAlertCodeHex()
/*     */   {
/*  65 */     if (this.alertCodeHex == null) {
/*  66 */       this.alertCodeHex = HexDump.toHex((short)this.alertCode);
/*     */     }
/*  68 */     return this.alertCodeHex;
/*     */   }
/*     */ 
/*     */   public String getDataSaveID()
/*     */   {
/*  73 */     return this.dataSaveID;
/*     */   }
/*     */ 
/*     */   public void setDataSaveID(String dataSaveID) {
/*  77 */     this.dataSaveID = dataSaveID;
/*     */   }
/*     */ 
/*     */   public String getCorpNo()
/*     */   {
/*  84 */     return this.corpNo;
/*     */   }
/*     */ 
/*     */   public void setCorpNo(String corpNo)
/*     */   {
/*  90 */     this.corpNo = corpNo;
/*     */   }
/*     */ 
/*     */   public String getCustomerNo()
/*     */   {
/*  96 */     return this.customerNo;
/*     */   }
/*     */ 
/*     */   public void setCustomerNo(String customerNo)
/*     */   {
/* 102 */     this.customerNo = customerNo;
/*     */   }
/*     */ 
/*     */   public String getRtuId()
/*     */   {
/* 108 */     return this.rtuId;
/*     */   }
/*     */ 
/*     */   public void setRtuId(String rtuId)
/*     */   {
/* 114 */     this.rtuId = rtuId;
/*     */   }
/*     */ 
/*     */   public String getTn()
/*     */   {
/* 120 */     return this.tn;
/*     */   }
/*     */ 
/*     */   public void setTn(String tn)
/*     */   {
/* 126 */     this.tn = tn;
/*     */   }
/*     */ 
/*     */   public String getStationNo()
/*     */   {
/* 132 */     return this.stationNo;
/*     */   }
/*     */ 
/*     */   public void setStationNo(String stationNo)
/*     */   {
/* 138 */     this.stationNo = stationNo;
/*     */   }
/*     */ 
/*     */   public int getAlertCode()
/*     */   {
/* 144 */     return this.alertCode;
/*     */   }
/*     */ 
/*     */   public void setAlertCode(int alertCode)
/*     */   {
/* 150 */     this.alertCode = alertCode;
/*     */   }
/*     */ 
/*     */   public Date getAlertTime()
/*     */   {
/* 156 */     return this.alertTime;
/*     */   }
/*     */ 
/*     */   public void setAlertTime(Date alertTime)
/*     */   {
/* 162 */     this.alertTime = alertTime; }
/*     */ 
/*     */   public void setAlertTime(String alertTime) {
/*     */     try {
/* 166 */       this.alertTime = df.parse(alertTime);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Date getReceiveTime()
/*     */   {
/* 176 */     return this.receiveTime;
/*     */   }
/*     */ 
/*     */   public void setReceiveTime(Date receiveTime)
/*     */   {
/* 182 */     this.receiveTime = receiveTime;
/*     */   }
/*     */ 
/*     */   public String getProcessFlag()
/*     */   {
/* 188 */     return this.processFlag;
/*     */   }
/*     */ 
/*     */   public void setProcessFlag(String processFlag)
/*     */   {
/* 194 */     this.processFlag = processFlag;
/*     */   }
/*     */ 
/*     */   public List getArgs()
/*     */   {
/* 200 */     return this.args;
/*     */   }
/*     */ 
/*     */   public void setArgs(List args)
/*     */   {
/* 206 */     this.args = args;
/*     */   }
/*     */ 
/*     */   public String getSbcs() {
/* 210 */     return this.sbcs;
/*     */   }
/*     */ 
/*     */   public void setSbcs(String sbcs) {
/* 214 */     this.sbcs = sbcs;
/*     */   }
/*     */ 
/*     */   public String getTxfs()
/*     */   {
/* 222 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs)
/*     */   {
/* 228 */     this.txfs = txfs;
/*     */   }
/*     */ }