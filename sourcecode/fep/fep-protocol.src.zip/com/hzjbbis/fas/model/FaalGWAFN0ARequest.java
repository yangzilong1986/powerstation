/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalGWAFN0ARequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -362982183058685616L;
/*    */   private String tpSendTime;
/*    */   private int tpTimeout;
/*    */   private int[] param;
/*    */ 
/*    */   public String getTpSendTime()
/*    */   {
/* 18 */     return this.tpSendTime; }
/*    */ 
/*    */   public void setTpSendTime(String tpSendTime) {
/* 21 */     this.tpSendTime = tpSendTime; }
/*    */ 
/*    */   public int getTpTimeout() {
/* 24 */     return this.tpTimeout; }
/*    */ 
/*    */   public void setTpTimeout(int tpTimeout) {
/* 27 */     this.tpTimeout = tpTimeout; }
/*    */ 
/*    */   public int[] getParam() {
/* 30 */     return this.param; }
/*    */ 
/*    */   public void setParam(int[] param) {
/* 33 */     this.param = param;
/*    */   }
/*    */ }