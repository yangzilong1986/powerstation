/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RtuData
/*    */ {
/* 13 */   private static final SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/* 14 */   private static final SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
/* 15 */   private static final SimpleDateFormat df3 = new SimpleDateFormat("yyyy-MM");
/*    */   private String taskNum;
/*    */   private String logicAddress;
/*    */   private String tn;
/*    */   private Date time;
/*    */   private List<RtuDataItem> dataList;
/*    */ 
/*    */   public RtuData()
/*    */   {
/* 36 */     this.dataList = new ArrayList();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 40 */     StringBuffer sb = new StringBuffer();
/* 41 */     sb.append("[logicAddress=").append(getLogicAddress()).append(", taskNum=").append(getTaskNum()).append(", time=").append(df1.format(getTime())).append("]");
/*    */ 
/* 44 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public void addDataList(RtuDataItem rtuDataItem)
/*    */   {
/* 51 */     this.dataList.add(rtuDataItem);
/*    */   }
/*    */ 
/*    */   public String getLogicAddress() {
/* 55 */     return this.logicAddress; }
/*    */ 
/*    */   public void setLogicAddress(String logicAddress) {
/* 58 */     this.logicAddress = logicAddress; }
/*    */ 
/*    */   public String getTaskNum() {
/* 61 */     return this.taskNum; }
/*    */ 
/*    */   public void setTaskNum(String taskNum) {
/* 64 */     this.taskNum = taskNum; }
/*    */ 
/*    */   public Date getTime() {
/* 67 */     return this.time; }
/*    */ 
/*    */   public void setTime(Date time) {
/* 70 */     this.time = time; }
/*    */ 
/*    */   public void setTime(String time) {
/*    */     try {
/* 74 */       if (time.trim().length() == 16)
/* 75 */         this.time = df1.parse(time);
/* 76 */       else if (time.trim().length() == 10)
/* 77 */         this.time = df2.parse(time);
/* 78 */       else if (time.trim().length() == 7)
/* 79 */         this.time = df3.parse(time);
/*    */     } catch (Exception e) {
/*    */     }
/*    */   }
/*    */ 
/*    */   public List<RtuDataItem> getDataList() {
/* 85 */     return this.dataList; }
/*    */ 
/*    */   public String getTn() {
/* 88 */     return this.tn; }
/*    */ 
/*    */   public void setTn(String tn) {
/* 91 */     this.tn = tn;
/*    */   }
/*    */ }