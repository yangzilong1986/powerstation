/*     */ package com.hzjbbis.fas.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class FaalRequest
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2937756926363569712L;
/*     */   public static final int TYPE_READ_FORWARD_DATA = 0;
/*     */   public static final int TYPE_READ_CURRENT_DATA = 1;
/*     */   public static final int TYPE_READ_TASK_DATA = 2;
/*     */   public static final int TYPE_READ_PROGRAM_LOG = 4;
/*     */   public static final int TYPE_REALTIME_WRITE_PARAMS = 7;
/*     */   public static final int TYPE_WRITE_PARAMS = 8;
/*     */   public static final int TYPE_READ_ALERT = 9;
/*     */   public static final int TYPE_CONFIRM_ALERT = 10;
/*     */   public static final int TYPE_SEND_SMS = 40;
/*     */   public static final int TYPE_REFRESH_CACHE = 254;
/*     */   public static final int TYPE_OTHER = 255;
/*     */   protected String protocol;
/*     */   protected int type;
/*     */   private List<FaalRequestParam> params;
/*     */   private List<String> rtuIds;
/*     */   private List<Long> cmdIds;
/*     */   private List<FaalRequestRtuParam> rtuParams;
/*     */   private String operator;
/*     */   private boolean scheduled;
/*     */   private Date scheduledTime;
/*     */   private boolean taskflag;
/*     */   private long timetag;
/*     */ 
/*     */   public FaalRequest()
/*     */   {
/*  63 */     this.scheduled = false;
/*     */ 
/*  67 */     this.taskflag = false;
/*     */   }
/*     */ 
/*     */   public void addParam(FaalRequestParam param)
/*     */   {
/*  74 */     if (this.params == null) {
/*  75 */       this.params = new ArrayList();
/*     */     }
/*  77 */     this.params.add(param);
/*     */   }
/*     */ 
/*     */   public void addRtuParam(FaalRequestRtuParam rtuParam)
/*     */   {
/*  84 */     if (this.rtuParams == null) {
/*  85 */       this.rtuParams = new ArrayList();
/*     */     }
/*  87 */     this.rtuParams.add(rtuParam);
/*     */   }
/*     */ 
/*     */   public List<FaalRequestRtuParam> getRtuParams() {
/*  91 */     return this.rtuParams; }
/*     */ 
/*     */   public void setRtuParams(List<FaalRequestRtuParam> rtuParams) {
/*  94 */     this.rtuParams = rtuParams;
/*     */   }
/*     */ 
/*     */   public void addParam(String name, String value)
/*     */   {
/* 102 */     addParam(new FaalRequestParam(name, value));
/*     */   }
/*     */ 
/*     */   public void setRtuIds(String[] ids)
/*     */   {
/* 110 */     this.rtuIds = Arrays.asList(ids);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 114 */     StringBuffer sb = new StringBuffer();
/* 115 */     sb.append(", type=").append(this.type).append(", rtuCount=").append((this.rtuIds == null) ? 0 : this.rtuIds.size()).append(", rtuIds=").append(this.rtuIds).append(", cmdIds=").append(this.cmdIds).append("]");
/*     */ 
/* 120 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 127 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 133 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public void setProtocol(String protocol)
/*     */   {
/* 139 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public String getOperator()
/*     */   {
/* 149 */     return this.operator;
/*     */   }
/*     */ 
/*     */   public void setOperator(String operator)
/*     */   {
/* 155 */     this.operator = operator;
/*     */   }
/*     */ 
/*     */   public List<FaalRequestParam> getParams()
/*     */   {
/* 161 */     return this.params;
/*     */   }
/*     */ 
/*     */   public void setParams(List<FaalRequestParam> params)
/*     */   {
/* 167 */     this.params = params;
/*     */   }
/*     */ 
/*     */   public List<String> getRtuIds()
/*     */   {
/* 173 */     return this.rtuIds;
/*     */   }
/*     */ 
/*     */   public void setRtuIds(List<String> rtuIds)
/*     */   {
/* 179 */     this.rtuIds = rtuIds;
/*     */   }
/*     */ 
/*     */   public List<Long> getCmdIds()
/*     */   {
/* 185 */     return this.cmdIds;
/*     */   }
/*     */ 
/*     */   public void setCmdIds(List<Long> cmdIds)
/*     */   {
/* 191 */     this.cmdIds = cmdIds;
/*     */   }
/*     */ 
/*     */   public boolean isScheduled()
/*     */   {
/* 197 */     return this.scheduled;
/*     */   }
/*     */ 
/*     */   public void setScheduled(boolean scheduled)
/*     */   {
/* 203 */     this.scheduled = scheduled;
/*     */   }
/*     */ 
/*     */   public Date getScheduledTime()
/*     */   {
/* 209 */     return this.scheduledTime;
/*     */   }
/*     */ 
/*     */   public void setScheduledTime(Date scheduledTime)
/*     */   {
/* 215 */     this.scheduledTime = scheduledTime;
/*     */   }
/*     */ 
/*     */   public boolean isTaskflag() {
/* 219 */     return this.taskflag;
/*     */   }
/*     */ 
/*     */   public void setTaskflag(boolean taskflag) {
/* 223 */     this.taskflag = taskflag;
/*     */   }
/*     */ 
/*     */   public long getTimetag() {
/* 227 */     return this.timetag;
/*     */   }
/*     */ 
/*     */   public void setTimetag(long timetag) {
/* 231 */     this.timetag = timetag; }
/*     */ 
/*     */   public void setType(int type) {
/* 234 */     this.type = type;
/*     */   }
/*     */ }