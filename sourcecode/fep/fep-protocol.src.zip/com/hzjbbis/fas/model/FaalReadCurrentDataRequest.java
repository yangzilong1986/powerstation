/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class FaalReadCurrentDataRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -6192523704322578814L;
/*    */   private String[] tn;
/*    */   private HashMap map;
/*    */ 
/*    */   public void setMap(String key, String value)
/*    */   {
/* 20 */     if (this.map == null)
/* 21 */       this.map = new HashMap();
/* 22 */     this.map.put(key, value);
/*    */   }
/*    */ 
/*    */   public String getValue(String key) {
/* 26 */     return ((String)this.map.get(key));
/*    */   }
/*    */ 
/*    */   public FaalReadCurrentDataRequest()
/*    */   {
/* 31 */     this.type = 1;
/*    */   }
/*    */ 
/*    */   public String[] getTn()
/*    */   {
/* 38 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String[] tn)
/*    */   {
/* 45 */     this.tn = tn;
/*    */   }
/*    */ }