/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalGWAFN0ERequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -562982183058685616L;
/*    */   private String tpSendTime;
/*    */   private int tpTimeout;
/*    */   private int pm;
/*    */   private int pn;
/*    */ 
/*    */   public String getTpSendTime()
/*    */   {
/* 20 */     return this.tpSendTime; }
/*    */ 
/*    */   public void setTpSendTime(String tpSendTime) {
/* 23 */     this.tpSendTime = tpSendTime; }
/*    */ 
/*    */   public int getTpTimeout() {
/* 26 */     return this.tpTimeout; }
/*    */ 
/*    */   public void setTpTimeout(int tpTimeout) {
/* 29 */     this.tpTimeout = tpTimeout; }
/*    */ 
/*    */   public int getPm() {
/* 32 */     return this.pm; }
/*    */ 
/*    */   public void setPm(int pm) {
/* 35 */     this.pm = pm; }
/*    */ 
/*    */   public int getPn() {
/* 38 */     return this.pn; }
/*    */ 
/*    */   public void setPn(int pn) {
/* 41 */     this.pn = pn;
/*    */   }
/*    */ }