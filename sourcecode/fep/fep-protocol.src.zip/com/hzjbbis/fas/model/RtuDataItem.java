/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class RtuDataItem
/*    */ {
/*    */   private String code;
/*    */   private String value;
/*    */ 
/*    */   public String getCode()
/*    */   {
/*  9 */     return this.code; }
/*    */ 
/*    */   public void setCode(String code) {
/* 12 */     this.code = code; }
/*    */ 
/*    */   public String getValue() {
/* 15 */     return this.value; }
/*    */ 
/*    */   public void setValue(String value) {
/* 18 */     this.value = value;
/*    */   }
/*    */ }