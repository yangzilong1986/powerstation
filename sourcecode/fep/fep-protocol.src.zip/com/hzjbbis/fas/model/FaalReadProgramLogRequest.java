/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class FaalReadProgramLogRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -2603907087782103968L;
/*    */   private String tn;
/*    */   private Calendar startTime;
/*    */   private int count;
/*    */ 
/*    */   public FaalReadProgramLogRequest()
/*    */   {
/* 22 */     this.type = 4;
/*    */   }
/*    */ 
/*    */   public String getTn()
/*    */   {
/* 29 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String tn)
/*    */   {
/* 35 */     this.tn = tn;
/*    */   }
/*    */ 
/*    */   public Calendar getStartTime()
/*    */   {
/* 41 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public void setStartTime(Calendar startTime)
/*    */   {
/* 47 */     this.startTime = startTime;
/*    */   }
/*    */ 
/*    */   public int getCount()
/*    */   {
/* 53 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setCount(int count)
/*    */   {
/* 59 */     this.count = count;
/*    */   }
/*    */ }