/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class FaalRequestParam
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 8826872062189860703L;
/*    */   private String name;
/*    */   private String value;
/*    */ 
/*    */   public FaalRequestParam()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FaalRequestParam(String name, String value)
/*    */   {
/* 34 */     this.name = name;
/* 35 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 39 */     return "DI" + this.name + "=" + this.value;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 46 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 52 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 58 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value)
/*    */   {
/* 64 */     this.value = value;
/*    */   }
/*    */ }