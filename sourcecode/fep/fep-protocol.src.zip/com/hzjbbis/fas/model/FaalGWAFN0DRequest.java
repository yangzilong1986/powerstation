/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalGWAFN0DRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -262982183058685616L;
/*    */   private String tpSendTime;
/*    */   private int tpTimeout;
/*    */   private String startTime;
/*    */   private int interval;
/*    */   private int count;
/*    */ 
/*    */   public String getTpSendTime()
/*    */   {
/* 22 */     return this.tpSendTime; }
/*    */ 
/*    */   public void setTpSendTime(String tpSendTime) {
/* 25 */     this.tpSendTime = tpSendTime; }
/*    */ 
/*    */   public int getTpTimeout() {
/* 28 */     return this.tpTimeout; }
/*    */ 
/*    */   public void setTpTimeout(int tpTimeout) {
/* 31 */     this.tpTimeout = tpTimeout; }
/*    */ 
/*    */   public String getStartTime() {
/* 34 */     return this.startTime; }
/*    */ 
/*    */   public void setStartTime(String startTime) {
/* 37 */     this.startTime = startTime; }
/*    */ 
/*    */   public int getInterval() {
/* 40 */     return this.interval; }
/*    */ 
/*    */   public void setInterval(int interval) {
/* 43 */     this.interval = interval; }
/*    */ 
/*    */   public int getCount() {
/* 46 */     return this.count; }
/*    */ 
/*    */   public void setCount(int count) {
/* 49 */     this.count = count;
/*    */   }
/*    */ }