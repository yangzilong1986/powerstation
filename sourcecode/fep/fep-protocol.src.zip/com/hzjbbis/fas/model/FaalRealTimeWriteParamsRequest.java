/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class FaalRealTimeWriteParamsRequest extends FaalWriteParamsRequest
/*    */ {
/*    */   private static final long serialVersionUID = 2234597531372736773L;
/*    */   private Calendar cmdTime;
/*    */   private int timeout;
/*    */ 
/*    */   public FaalRealTimeWriteParamsRequest()
/*    */   {
/* 20 */     this.type = 7;
/*    */   }
/*    */ 
/*    */   public Calendar getCmdTime()
/*    */   {
/* 27 */     return this.cmdTime;
/*    */   }
/*    */ 
/*    */   public void setCmdTime(Calendar cmdTime)
/*    */   {
/* 33 */     this.cmdTime = cmdTime;
/*    */   }
/*    */ 
/*    */   public int getTimeout()
/*    */   {
/* 39 */     return this.timeout;
/*    */   }
/*    */ 
/*    */   public void setTimeout(int timeout)
/*    */   {
/* 45 */     this.timeout = timeout;
/*    */   }
/*    */ }