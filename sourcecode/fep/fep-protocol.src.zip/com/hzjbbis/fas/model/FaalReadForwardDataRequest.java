/*    */ package com.hzjbbis.fas.model;
/*    */ 
/*    */ public class FaalReadForwardDataRequest extends FaalRequest
/*    */ {
/*    */   private static final long serialVersionUID = -6840264166731727088L;
/*    */   private String tn;
/*    */   private int timeout;
/* 16 */   private boolean broadcast = false;
/*    */   private String broadcastAddress;
/*    */   private String fixProto;
/*    */   private String fixAddre;
/*    */   private String fixPort;
/*    */ 
/*    */   public FaalReadForwardDataRequest()
/*    */   {
/* 26 */     this.type = 0;
/*    */   }
/*    */ 
/*    */   public String getTn()
/*    */   {
/* 33 */     return this.tn;
/*    */   }
/*    */ 
/*    */   public void setTn(String tn)
/*    */   {
/* 39 */     this.tn = tn;
/*    */   }
/*    */ 
/*    */   public int getTimeout()
/*    */   {
/* 45 */     return this.timeout;
/*    */   }
/*    */ 
/*    */   public void setTimeout(int timeout)
/*    */   {
/* 51 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */   public boolean isBroadcast()
/*    */   {
/* 57 */     return this.broadcast;
/*    */   }
/*    */ 
/*    */   public void setBroadcast(boolean broadcast)
/*    */   {
/* 63 */     this.broadcast = broadcast;
/*    */   }
/*    */ 
/*    */   public String getBroadcastAddress()
/*    */   {
/* 69 */     return this.broadcastAddress;
/*    */   }
/*    */ 
/*    */   public void setBroadcastAddress(String broadcastAddress)
/*    */   {
/* 75 */     this.broadcastAddress = broadcastAddress;
/*    */   }
/*    */ 
/*    */   public String getFixAddre() {
/* 79 */     return this.fixAddre;
/*    */   }
/*    */ 
/*    */   public String getFixProto() {
/* 83 */     return this.fixProto;
/*    */   }
/*    */ 
/*    */   public void setFixAddre(String fixAddre) {
/* 87 */     this.fixAddre = fixAddre;
/*    */   }
/*    */ 
/*    */   public void setFixProto(String fixProto) {
/* 91 */     this.fixProto = fixProto;
/*    */   }
/*    */ 
/*    */   public String getFixPort() {
/* 95 */     return this.fixPort;
/*    */   }
/*    */ 
/*    */   public void setFixPort(String fixPort) {
/* 99 */     this.fixPort = fixPort;
/*    */   }
/*    */ }