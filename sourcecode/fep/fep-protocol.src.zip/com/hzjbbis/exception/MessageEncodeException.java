/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ public class MessageEncodeException extends RuntimeException
/*    */ {
/*    */   private int errcode;
/*    */   private String code;
/*    */   private static final long serialVersionUID = -2488563605733447133L;
/*    */ 
/*    */   public MessageEncodeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessageEncodeException(String code, String message)
/*    */   {
/* 21 */     super(message);
/* 22 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public MessageEncodeException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }
/*    */ 
/*    */   public MessageEncodeException(Throwable cause)
/*    */   {
/* 34 */     super(cause);
/*    */   }
/*    */ 
/*    */   public MessageEncodeException(String message, Throwable cause)
/*    */   {
/* 42 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public int getErrcode() {
/* 46 */     return this.errcode;
/*    */   }
/*    */ 
/*    */   public void setErrcode(int errcode) {
/* 50 */     this.errcode = errcode;
/*    */   }
/*    */ 
/*    */   public String getCode() {
/* 54 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code) {
/* 58 */     this.code = code;
/*    */   }
/*    */ }