/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ public class ProtocolHandleException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -5056449095935802236L;
/*    */ 
/*    */   public ProtocolHandleException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ProtocolHandleException(String message, Throwable cause)
/*    */   {
/* 21 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ProtocolHandleException(String message)
/*    */   {
/* 29 */     super(message);
/*    */   }
/*    */ 
/*    */   public ProtocolHandleException(Throwable cause)
/*    */   {
/* 37 */     super(cause);
/*    */   }
/*    */ }