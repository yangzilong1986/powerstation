/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ public class MessageDecodeException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 3337569199562775364L;
/*    */ 
/*    */   public MessageDecodeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessageDecodeException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public MessageDecodeException(Throwable cause)
/*    */   {
/* 25 */     super(cause);
/*    */   }
/*    */ 
/*    */   public MessageDecodeException(String message, Throwable cause)
/*    */   {
/* 33 */     super(message, cause);
/*    */   }
/*    */ }