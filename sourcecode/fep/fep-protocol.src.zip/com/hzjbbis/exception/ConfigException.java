/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ public class ConfigException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8071053409130303967L;
/*    */ 
/*    */   public ConfigException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConfigException(String message, Throwable cause)
/*    */   {
/* 20 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConfigException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConfigException(Throwable cause)
/*    */   {
/* 34 */     super(cause);
/*    */   }
/*    */ }