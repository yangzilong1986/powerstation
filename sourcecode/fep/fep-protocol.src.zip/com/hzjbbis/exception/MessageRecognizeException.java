/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ import com.hzjbbis.util.HexDump;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class MessageRecognizeException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 200603141603L;
/*    */   private ByteBuffer buffer;
/*    */ 
/*    */   public MessageRecognizeException(String msg, ByteBuffer buff)
/*    */   {
/* 12 */     super(msg);
/* 13 */     if (null == buff)
/* 14 */       return;
/* 15 */     if (buff.position() > 0)
/* 16 */       buff.rewind();
/* 17 */     this.buffer = buff.slice(); }
/*    */ 
/*    */   public MessageRecognizeException(ByteBuffer buff) {
/* 20 */     super("消息不能识别。");
/* 21 */     if (null == buff)
/* 22 */       return;
/* 23 */     if (buff.position() > 0)
/* 24 */       buff.rewind();
/* 25 */     this.buffer = buff.slice();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 29 */     String message = super.getMessage();
/*    */ 
/* 31 */     if (this.buffer != null) {
/* 32 */       return message + ((message.length() > 0) ? " " : "") + "(Hexdump: " + HexDump.hexDump(this.buffer) + ')';
/*    */     }
/*    */ 
/* 35 */     return message;
/*    */   }
/*    */ }