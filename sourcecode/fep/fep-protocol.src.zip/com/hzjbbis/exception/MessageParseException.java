/*    */ package com.hzjbbis.exception;
/*    */ 
/*    */ import com.hzjbbis.util.HexDump;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class MessageParseException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 200603141603L;
/*    */   private ByteBuffer buffer;
/*    */ 
/*    */   public MessageParseException(String message, ByteBuffer buff)
/*    */   {
/* 27 */     super(message);
/* 28 */     if (null == buff)
/* 29 */       return;
/* 30 */     if (buff.position() > 0)
/* 31 */       buff.rewind();
/* 32 */     this.buffer = buff.slice();
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 39 */     String message = super.getMessage();
/*    */ 
/* 41 */     if (message == null) {
/* 42 */       message = "";
/*    */     }
/*    */ 
/* 45 */     if (this.buffer != null) {
/* 46 */       return message + ((message.length() > 0) ? " " : "") + "(Hexdump: " + HexDump.hexDump(this.buffer) + ')';
/*    */     }
/*    */ 
/* 49 */     return message;
/*    */   }
/*    */ }