/*     */ package com.hzjbbis.fk.monitor.client.biz;
/*     */ 
/*     */ import com.hzjbbis.fk.monitor.exception.MonitorHandleException;
/*     */ import com.hzjbbis.fk.utils.PathUtil;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class ClientHandleFile
/*     */ {
/*  19 */   private static final ClientHandleFile handleFile = new ClientHandleFile();
/*  20 */   private static String tmpPath = ".";
/*     */ 
/*     */   static
/*     */   {
/*  26 */     String root = PathUtil.getRootPath(ClientHandleFile.class);
/*  27 */     File f = new File(root);
/*  28 */     if (("bin".equals(f.getName())) || ("classes".equals(f.getName()))) {
/*  29 */       f = f.getParentFile();
/*  30 */       root = f.getPath();
/*     */     }
/*  32 */     if ("plugins".equalsIgnoreCase(f.getName())) {
/*  33 */       f = f.getParentFile();
/*  34 */       root = f.getPath();
/*     */     }
/*  36 */     tmpPath = root + File.separator + "tmp";
/*  37 */     f = new File(tmpPath);
/*  38 */     if (!(f.exists()))
/*  39 */       f.mkdir();
/*  40 */     tmpPath += File.separator;
/*  41 */     System.out.println("tmp=" + tmpPath);
/*     */   }
/*     */ 
/*     */   public static final ClientHandleFile getHandleFile()
/*     */   {
/*  22 */     return handleFile;
/*     */   }
/*     */ 
/*     */   public ByteBuffer getFile(ByteBuffer inputBody)
/*     */   {
/*  51 */     String path = "";
/*  52 */     byte[] btPath = (byte[])null;
/*  53 */     long position = -1L;
/*  54 */     int index = 0;
/*  55 */     for (index = 0; index < inputBody.limit(); ++index) {
/*  56 */       if (inputBody.get(index) == 0) {
/*  57 */         btPath = new byte[index];
/*  58 */         inputBody.get(btPath);
/*  59 */         path = new String(btPath);
/*  60 */         inputBody.get();
/*  61 */         position = inputBody.getLong();
/*  62 */         break;
/*     */       }
/*     */     }
/*  65 */     if ((position < 0L) || (btPath == null)) {
/*  66 */       throw new MonitorHandleException("监控管理：获取文件异常，输入非法。");
/*     */     }
/*  68 */     path = path.replace('\\', File.separatorChar);
/*  69 */     path = path.replace('/', File.separatorChar);
/*     */ 
/*  71 */     if (path.lastIndexOf(File.separatorChar) > 0) {
/*  72 */       int index1 = path.lastIndexOf(File.separatorChar);
/*  73 */       String subDir = path.substring(0, index1);
/*  74 */       File subFile = new File(tmpPath + subDir);
/*  75 */       if (!(subFile.exists()))
/*  76 */         subFile.mkdirs();
/*     */     }
/*  78 */     path = tmpPath + path;
/*     */ 
/*  80 */     int offset = inputBody.position();
/*  81 */     int dataLen = inputBody.remaining();
/*  82 */     if (dataLen == 0)
/*  83 */       return null;
/*     */     try {
/*  85 */       RandomAccessFile raf = new RandomAccessFile(path, "rwd");
/*  86 */       if (position > raf.length()) {
/*  87 */         raf.close();
/*  88 */         throw new MonitorHandleException("监控管理：写文件命令异常，写文件起始位置>文件实际长度。");
/*     */       }
/*  90 */       raf.setLength(position);
/*  91 */       raf.seek(position);
/*  92 */       raf.write(inputBody.array(), offset, dataLen);
/*  93 */       raf.close();
/*  94 */       position += dataLen;
/*  95 */       if (dataLen < 1048576) {
/*  96 */         return null;
/*     */       }
/*  98 */       inputBody.clear();
/*  99 */       inputBody.put(btPath); inputBody.put(0);
/* 100 */       inputBody.putLong(position);
/* 101 */       inputBody.flip();
/* 102 */       return inputBody;
/*     */     } catch (Exception exp) {
/* 104 */       throw new MonitorHandleException(exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ByteBuffer putFile(ByteBuffer inputBody)
/*     */   {
/* 115 */     String path = "";
/* 116 */     byte[] btPath = (byte[])null;
/* 117 */     long position = -1L;
/* 118 */     int index = 0;
/* 119 */     for (index = 0; index < inputBody.limit(); ++index) {
/* 120 */       if (inputBody.get(index) == 0) {
/* 121 */         btPath = new byte[index];
/* 122 */         inputBody.get(btPath);
/* 123 */         path = new String(btPath);
/* 124 */         inputBody.get();
/* 125 */         position = inputBody.getLong();
/* 126 */         inputBody.limit(inputBody.position());
/* 127 */         inputBody.rewind();
/* 128 */         break;
/*     */       }
/*     */     }
/* 131 */     if (position < 0L) {
/* 132 */       throw new MonitorHandleException("监控管理：上传文件命令异常，输入非法。");
/*     */     }
/* 134 */     path = path.replace('\\', File.separatorChar);
/* 135 */     path = path.replace('/', File.separatorChar);
/* 136 */     path = tmpPath + path;
/*     */     try
/*     */     {
/* 139 */       RandomAccessFile raf = new RandomAccessFile(path, "r");
/* 140 */       if (position > raf.length()) {
/* 141 */         raf.close();
/* 142 */         throw new MonitorHandleException("监控管理：写文件命令异常，读文件起始位置>文件实际长度。");
/*     */       }
/* 144 */       int len = (int)(raf.length() - position);
/* 145 */       if (len <= 0) {
/* 146 */         return null;
/*     */       }
/* 148 */       int toRead = 1048576;
/* 149 */       toRead = Math.min(len, toRead);
/* 150 */       ByteBuffer body = ByteBuffer.allocate(inputBody.remaining() + toRead);
/*     */ 
/* 152 */       raf.seek(position);
/* 153 */       body.put(inputBody);
/* 154 */       inputBody.rewind();
/* 155 */       raf.read(body.array(), inputBody.limit(), toRead);
/* 156 */       body.position(0);
/* 157 */       raf.close();
/* 158 */       return body;
/*     */     } catch (Exception exp) {
/* 160 */       throw new MonitorHandleException(exp);
/*     */     }
/*     */   }
/*     */ }