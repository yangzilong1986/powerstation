/*    */ package com.hzjbbis.fk.monitor.client.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*    */ import com.hzjbbis.fk.sockclient.JSocket;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class FileCommand
/*    */ {
/*    */   public void listLog(JSocket client)
/*    */   {
/* 12 */     fileList("log", client);
/*    */   }
/*    */ 
/*    */   public void listConfig(JSocket client) {
/* 16 */     fileList("config", client);
/*    */   }
/*    */ 
/*    */   public void fileList(String type, JSocket client)
/*    */   {
/*    */     short cmd;
/* 21 */     if (type.equalsIgnoreCase("config"))
/* 22 */       cmd = 2;
/*    */     else
/* 24 */       cmd = 1;
/* 25 */     MonitorMessage msg = new MonitorMessage();
/* 26 */     msg.setCommand(cmd);
/* 27 */     ByteBuffer body = ByteBuffer.allocate(0);
/* 28 */     msg.setBody(body);
/* 29 */     client.sendMessage(msg);
/*    */   }
/*    */ 
/*    */   public void getFile(JSocket client, String path) {
/* 33 */     MonitorMessage msg = new MonitorMessage();
/* 34 */     msg.setCommand(3);
/* 35 */     byte[] btPath = path.getBytes();
/* 36 */     ByteBuffer body = ByteBuffer.allocate(btPath.length + 1 + 8);
/* 37 */     body.put(btPath).put(0);
/* 38 */     body.putLong(0L);
/* 39 */     body.flip();
/* 40 */     msg.setBody(body);
/* 41 */     client.sendMessage(msg);
/*    */   }
/*    */ 
/*    */   public void putFile(JSocket client, String path) {
/* 45 */     MonitorMessage msg = new MonitorMessage();
/* 46 */     msg.setCommand(4);
/* 47 */     byte[] btPath = path.getBytes();
/* 48 */     ByteBuffer body = ByteBuffer.allocate(btPath.length + 1 + 8);
/* 49 */     body.put(btPath).put(0);
/* 50 */     body.putLong(0L);
/* 51 */     body.flip();
/* 52 */     body = ClientHandleFile.getHandleFile().putFile(body);
/* 53 */     if (body == null)
/* 54 */       return;
/* 55 */     msg.setBody(body);
/* 56 */     client.sendMessage(msg);
/*    */   }
/*    */ }