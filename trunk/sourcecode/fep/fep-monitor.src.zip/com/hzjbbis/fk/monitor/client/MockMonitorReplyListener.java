/*    */ package com.hzjbbis.fk.monitor.client;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MockMonitorReplyListener
/*    */   implements IMonitorReplyListener
/*    */ {
/*  6 */   private static final Logger log = Logger.getLogger(MockMonitorReplyListener.class);
/*    */ 
/*    */   public void onClose() {
/*  9 */     log.debug("监控服务连接关闭。");
/*    */   }
/*    */ 
/*    */   public void onConnect() {
/* 13 */     log.debug("监控服务连接成功。");
/*    */   }
/*    */ 
/*    */   public void onEventHookProfile(String profile) {
/* 17 */     log.info(profile);
/*    */   }
/*    */ 
/*    */   public void onGetFile() {
/* 21 */     log.info("下载文件成功");
/*    */   }
/*    */ 
/*    */   public void onListConfig(String result) {
/* 25 */     log.info(result);
/*    */   }
/*    */ 
/*    */   public void onListLog(String result) {
/* 29 */     log.info(result);
/*    */   }
/*    */ 
/*    */   public void onMultiSysProfile(String profile) {
/* 33 */     log.info(profile);
/*    */   }
/*    */ 
/*    */   public void onModuleProfile(String profile) {
/* 37 */     log.info(profile);
/*    */   }
/*    */ 
/*    */   public void onPutFile() {
/* 41 */     log.info("上传文件成功");
/*    */   }
/*    */ 
/*    */   public void onReplyFailed(String reason) {
/* 45 */     log.info(reason);
/*    */   }
/*    */ 
/*    */   public void onReplyOK() {
/* 49 */     log.info("成功");
/*    */   }
/*    */ 
/*    */   public void onSystemProfile(String profile) {
/* 53 */     log.info(profile);
/*    */   }
/*    */ 
/*    */   public void onRtuMessageInd(String ind) {
/* 57 */     log.info(ind);
/*    */   }
/*    */ }