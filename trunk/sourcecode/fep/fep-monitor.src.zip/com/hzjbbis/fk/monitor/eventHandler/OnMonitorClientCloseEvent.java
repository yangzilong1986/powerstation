/*    */ package com.hzjbbis.fk.monitor.eventHandler;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.biz.HandleRtuTrace;
/*    */ import com.hzjbbis.fk.sockserver.event.ClientCloseEvent;
/*    */ import com.hzjbbis.fk.sockserver.event.adapt.ClientCloseEventAdapt;
/*    */ 
/*    */ public class OnMonitorClientCloseEvent extends ClientCloseEventAdapt
/*    */ {
/*    */   protected void process(ClientCloseEvent event)
/*    */   {
/* 16 */     super.process(event);
/* 17 */     HandleRtuTrace.getHandleRtuTrace().onClientClose(event);
/*    */   }
/*    */ }