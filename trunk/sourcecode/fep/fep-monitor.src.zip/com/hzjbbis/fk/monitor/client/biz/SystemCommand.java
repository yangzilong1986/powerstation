/*    */ package com.hzjbbis.fk.monitor.client.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*    */ import com.hzjbbis.fk.sockclient.JSocket;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class SystemCommand
/*    */ {
/*    */   public void shutdown(JSocket client)
/*    */   {
/* 18 */     MonitorMessage msg = new MonitorMessage();
/* 19 */     msg.setCommand(22);
/* 20 */     ByteBuffer body = ByteBuffer.allocate(0);
/* 21 */     msg.setBody(body);
/* 22 */     client.sendMessage(msg);
/*    */   }
/*    */ }