/*    */ package com.hzjbbis.fk.monitor.biz;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ public class HandleListFile
/*    */ {
/* 16 */   private static final HandleListFile listFile = new HandleListFile();
/*    */ 
/*    */   public static final HandleListFile getListFile() { return listFile;
/*    */   }
/*    */ 
/*    */   public String list(String path) {
/* 22 */     StringBuffer sb = new StringBuffer(1024);
/* 23 */     File file = new File(path);
/* 24 */     if ((!(file.exists())) || (!(file.isDirectory())))
/* 25 */       return "";
/* 26 */     File[] files = file.listFiles();
/* 27 */     for (int i = 0; i < files.length; ++i) {
/* 28 */       if (files[i].isDirectory())
/*    */         continue;
/* 30 */       sb.append(path).append(File.separator).append(files[i].getName());
/* 31 */       sb.append(",").append(files[i].length());
/* 32 */       sb.append(";");
/*    */     }
/* 34 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public String list(String path, String postFix)
/*    */   {
/* 44 */     StringTokenizer st = new StringTokenizer(postFix, "*,.");
/* 45 */     ArrayList suffixs = new ArrayList(5);
/* 46 */     while (st.hasMoreTokens()) {
/* 47 */       String name = st.nextToken();
/* 48 */       if (name.length() == 0)
/*    */         continue;
/* 50 */       suffixs.add(name);
/*    */     }
/* 52 */     FilenameFilter filter = new ListFileFilter(suffixs);
/* 53 */     StringBuffer sb = new StringBuffer(1024);
/* 54 */     File file = new File(path);
/* 55 */     if ((!(file.exists())) || (!(file.isDirectory())))
/* 56 */       return "";
/* 57 */     File[] files = file.listFiles(filter);
/* 58 */     for (int i = 0; i < files.length; ++i) {
/* 59 */       if (files[i].isDirectory())
/*    */         continue;
/* 61 */       sb.append(path).append(File.separator).append(files[i].getName());
/* 62 */       sb.append(";");
/*    */     }
/* 64 */     return sb.toString(); }
/*    */ 
/*    */   class ListFileFilter implements FilenameFilter {
/*    */     ArrayList<String> filters;
/*    */ 
/*    */     public ListFileFilter() {
/* 70 */       this.filters = filters;
/*    */     }
/*    */ 
/*    */     public boolean accept(File dir, String name) {
/* 74 */       for (String suffix : this.filters) {
/* 75 */         if (name.endsWith(suffix))
/* 76 */           return true;
/*    */       }
/* 78 */       return false;
/*    */     }
/*    */   }
/*    */ }