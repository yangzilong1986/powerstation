/*    */ package com.hzjbbis.fk.monitor.client;
/*    */ 
/*    */ public class ShutdownApp
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     int j;
/* 18 */     String ip = "127.0.0.1";
/* 19 */     int port = 10006;
/* 20 */     for (String arg : args) {
/* 21 */       if (arg.startsWith("-ip=")) {
/* 22 */         ip = arg.substring(4).trim();
/*    */       }
/* 24 */       else if (arg.startsWith("-port=")) {
/* 25 */         port = Integer.parseInt(arg.substring(6).trim());
/*    */       }
/*    */     }
/* 28 */     MonitorClient client = new MonitorClient();
/* 29 */     client.setHostIp(ip);
/* 30 */     client.setHostPort(port);
/* 31 */     client.connect();
/* 32 */     int j = 5;
/* 33 */     while ((!(client.isConnected())) && (j-- > 0))
/*    */       try {
/* 35 */         Thread.sleep(1000L);
/*    */       } catch (Exception localException2) {
/*    */       }
/* 38 */     if (client.isConnected())
/* 39 */       client.shutdownApplication();
/*    */     try {
/* 41 */       Thread.sleep(100L); } catch (Exception localException3) {
/*    */     }
/* 43 */     client.close();
/*    */   }
/*    */ }