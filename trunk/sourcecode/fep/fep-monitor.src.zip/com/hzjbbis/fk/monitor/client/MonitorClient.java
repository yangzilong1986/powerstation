/*     */ package com.hzjbbis.fk.monitor.client;
/*     */ 
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.monitor.client.biz.FileCommand;
/*     */ import com.hzjbbis.fk.monitor.client.biz.ProfileCommand;
/*     */ import com.hzjbbis.fk.monitor.client.biz.SystemCommand;
/*     */ import com.hzjbbis.fk.monitor.client.biz.TraceRTUCommand;
/*     */ import com.hzjbbis.fk.monitor.message.MonitorMessageCreator;
/*     */ import com.hzjbbis.fk.sockclient.JSocket;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MonitorClient
/*     */ {
/*  16 */   private JSocket socket = new JSocket();
/*  17 */   private String hostIp = "127.0.0.1";
/*  18 */   private int hostPort = 10006;
/*  19 */   private int bufLength = 32768;
/*  20 */   private IMessageCreator messageCreator = new MonitorMessageCreator();
/*  21 */   private int timeout = 2;
/*  22 */   private MonitorSocketListener listener = new MonitorSocketListener();
/*  23 */   private IMonitorReplyListener replyListener = null;
/*     */ 
/*  26 */   private final ProfileCommand profileCommand = new ProfileCommand();
/*  27 */   private final FileCommand fileCommand = new FileCommand();
/*  28 */   private final TraceRTUCommand traceCommand = new TraceRTUCommand();
/*  29 */   private final SystemCommand sysCommand = new SystemCommand();
/*     */ 
/*     */   public void shutdownApplication() {
/*  32 */     if (!(isConnected()))
/*  33 */       return;
/*  34 */     this.sysCommand.shutdown(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdListLog() {
/*  38 */     if (!(isConnected()))
/*  39 */       return;
/*  40 */     this.fileCommand.listLog(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdListConfig() {
/*  44 */     if (!(isConnected()))
/*  45 */       return;
/*  46 */     this.fileCommand.listConfig(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdGetFile(String path) {
/*  50 */     if (!(isConnected()))
/*  51 */       return;
/*  52 */     this.fileCommand.getFile(this.socket, path);
/*     */   }
/*     */ 
/*     */   public void cmdPutFile(String path) {
/*  56 */     if (!(isConnected()))
/*  57 */       return;
/*  58 */     this.fileCommand.putFile(this.socket, path);
/*     */   }
/*     */ 
/*     */   public void cmdGetProfile() {
/*  62 */     if (!(isConnected()))
/*  63 */       return;
/*  64 */     this.profileCommand.getSystemProfile(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdGetModuleProfile() {
/*  68 */     if (!(isConnected()))
/*  69 */       return;
/*  70 */     this.profileCommand.getModuleProfile(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdGetEventHookProfile() {
/*  74 */     if (!(isConnected()))
/*  75 */       return;
/*  76 */     this.profileCommand.getEventHookProfile(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdGatherProfile() {
/*  80 */     if (!(isConnected()))
/*  81 */       return;
/*  82 */     this.profileCommand.gatherProfile(this.socket);
/*     */   }
/*     */ 
/*     */   public void cmdTraceRTUs(String rtus) {
/*  86 */     if (!(isConnected()))
/*  87 */       return;
/*  88 */     String[] result = rtus.split(",");
/*  89 */     ArrayList array = new ArrayList();
/*  90 */     for (int i = 0; i < result.length; ++i) {
/*  91 */       if (result[i].length() != 8) continue;
/*     */       try {
/*  93 */         int rtua = (int)Long.parseLong(result[i], 16);
/*  94 */         array.add(Integer.valueOf(rtua));
/*     */       } catch (Exception e) {
/*  96 */         Logger log = Logger.getLogger(MonitorClient.class);
/*  97 */         log.error(e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */ 
/* 101 */     if (array.size() == 0)
/* 102 */       return;
/* 103 */     int[] rtuParams = new int[array.size()];
/* 104 */     for (int i = 0; i < array.size(); ++i)
/* 105 */       rtuParams[i] = ((Integer)array.get(i)).intValue();
/* 106 */     this.traceCommand.startTrace(this.socket, rtuParams);
/*     */   }
/*     */ 
/*     */   public void cmdAbortTrace() {
/* 110 */     if (!(isConnected()))
/* 111 */       return;
/* 112 */     this.traceCommand.stopTrace(this.socket);
/*     */   }
/*     */ 
/*     */   public MonitorClient() {
/*     */   }
/*     */ 
/*     */   public MonitorClient(String ip, int port) {
/* 119 */     this.hostIp = ip;
/* 120 */     this.hostPort = port;
/*     */   }
/*     */ 
/*     */   public void connect(String ip, int port) {
/* 124 */     this.hostIp = ip;
/* 125 */     this.hostPort = port;
/* 126 */     init();
/*     */   }
/*     */ 
/*     */   public void connect() {
/* 130 */     init();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 134 */     this.socket.close();
/*     */   }
/*     */ 
/*     */   public void init() {
/* 138 */     if (this.replyListener == null) {
/* 139 */       Logger log = Logger.getLogger(MonitorClient.class);
/* 140 */       log.warn("MonitorClient对象必须设置IMonitorReplyListener接口实现.");
/* 141 */       this.replyListener = new MockMonitorReplyListener();
/*     */     }
/* 143 */     this.socket.setHostIp(this.hostIp);
/* 144 */     this.socket.setHostPort(this.hostPort);
/* 145 */     this.socket.setBufLength(this.bufLength);
/* 146 */     this.socket.setMessageCreator(this.messageCreator);
/* 147 */     this.socket.setListener(this.listener);
/* 148 */     this.socket.setTimeout(this.timeout);
/* 149 */     this.socket.init();
/*     */   }
/*     */ 
/*     */   public JSocket getSocket() {
/* 153 */     return this.socket;
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/* 157 */     return this.socket.isConnected(); }
/*     */ 
/*     */   public String getHostIp() {
/* 160 */     return this.hostIp; }
/*     */ 
/*     */   public void setHostIp(String hostIp) {
/* 163 */     this.hostIp = hostIp; }
/*     */ 
/*     */   public int getHostPort() {
/* 166 */     return this.hostPort; }
/*     */ 
/*     */   public void setHostPort(int hostPort) {
/* 169 */     this.hostPort = hostPort; }
/*     */ 
/*     */   public int getBufLength() {
/* 172 */     return this.bufLength; }
/*     */ 
/*     */   public void setBufLength(int bufLength) {
/* 175 */     this.bufLength = bufLength; }
/*     */ 
/*     */   public int getTimeout() {
/* 178 */     return this.timeout; }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 181 */     this.timeout = timeout; }
/*     */ 
/*     */   public IMonitorReplyListener getReplyListener() {
/* 184 */     return this.replyListener; }
/*     */ 
/*     */   public void setReplyListener(IMonitorReplyListener replyListener) {
/* 187 */     this.replyListener = replyListener;
/* 188 */     this.listener.replyListener = this.replyListener;
/*     */   }
/*     */ }