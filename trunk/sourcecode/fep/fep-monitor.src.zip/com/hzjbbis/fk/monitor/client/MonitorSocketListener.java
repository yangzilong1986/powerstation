/*    */ package com.hzjbbis.fk.monitor.client;
/*    */ 
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.monitor.client.biz.ClientHandleFile;
/*    */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*    */ import com.hzjbbis.fk.sockclient.JSocket;
/*    */ import com.hzjbbis.fk.sockclient.JSocketListener;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MonitorSocketListener
/*    */   implements JSocketListener
/*    */ {
/* 15 */   private static final Logger log = Logger.getLogger(MonitorSocketListener.class);
/*    */ 
/* 17 */   public IMonitorReplyListener replyListener = null;
/*    */ 
/*    */   public void onClose(JSocket client) {
/* 20 */     if (this.replyListener != null)
/* 21 */       this.replyListener.onClose();
/* 22 */     log.info("监控服务连接断开:" + client);
/*    */   }
/*    */ 
/*    */   public void onConnected(JSocket client) {
/* 26 */     if (this.replyListener != null)
/* 27 */       this.replyListener.onConnect();
/* 28 */     log.info("监控服务连接成功:" + client);
/*    */   }
/*    */ 
/*    */   public void onReceive(JSocket client, IMessage message)
/*    */   {
/*    */     String result;
/* 32 */     MonitorMessage msg = (MonitorMessage)message;
/* 33 */     msg.resetMessageState();
/* 34 */     ByteBuffer body = null;
/* 35 */     switch (msg.getCommand())
/*    */     {
/*    */     case 2:
/* 37 */       body = msg.getBody();
/*    */ 
/* 39 */       result = new String(body.array());
/* 40 */       if (this.replyListener == null) return;
/* 41 */       this.replyListener.onListConfig(result);
/*    */ 
/* 43 */       break;
/*    */     case 1:
/* 45 */       body = msg.getBody();
/*    */ 
/* 47 */       result = new String(body.array());
/* 48 */       if (this.replyListener == null) return;
/* 49 */       this.replyListener.onListLog(result);
/*    */ 
/* 51 */       break;
/*    */     case 3:
/* 53 */       body = ClientHandleFile.getHandleFile().getFile(msg.getBody());
/* 54 */       if (body == null) {
/* 55 */         if (this.replyListener != null)
/* 56 */           this.replyListener.onGetFile();
/* 57 */         return;
/*    */       }
/* 59 */       msg.setBody(body);
/* 60 */       client.sendMessage(msg);
/* 61 */       break;
/*    */     case 4:
/* 63 */       body = ClientHandleFile.getHandleFile().putFile(msg.getBody());
/* 64 */       if (body == null) {
/* 65 */         if (this.replyListener != null)
/* 66 */           this.replyListener.onPutFile();
/* 67 */         return;
/*    */       }
/* 69 */       msg.setBody(body);
/* 70 */       client.sendMessage(msg);
/* 71 */       break;
/*    */     case 16:
/* 73 */       body = msg.getBody();
/*    */ 
/* 75 */       result = new String(body.array());
/* 76 */       if (this.replyListener == null) return;
/* 77 */       this.replyListener.onSystemProfile(result);
/*    */ 
/* 79 */       break;
/*    */     case 17:
/* 81 */       body = msg.getBody();
/*    */ 
/* 83 */       result = new String(body.array());
/* 84 */       if (this.replyListener == null) return;
/* 85 */       this.replyListener.onModuleProfile(result);
/*    */ 
/* 87 */       break;
/*    */     case 18:
/* 89 */       body = msg.getBody();
/*    */ 
/* 91 */       result = new String(body.array());
/* 92 */       if (this.replyListener == null) return;
/* 93 */       this.replyListener.onEventHookProfile(result);
/*    */ 
/* 95 */       break;
/*    */     case 31:
/* 97 */       body = msg.getBody();
/*    */ 
/* 99 */       String profile = new String(body.array());
/* 100 */       if (this.replyListener == null) return;
/* 101 */       this.replyListener.onMultiSysProfile(profile);
/*    */ 
/* 103 */       break;
/*    */     case 25:
/* 105 */       body = msg.getBody();
/*    */ 
/* 107 */       result = new String(body.array());
/* 108 */       if (this.replyListener == null) return;
/* 109 */       this.replyListener.onRtuMessageInd(result);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void onSend(JSocket client, IMessage msg)
/*    */   {
/*    */   }
/*    */ }