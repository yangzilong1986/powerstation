/*    */ package com.hzjbbis.fk.monitor.client.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*    */ import com.hzjbbis.fk.sockclient.JSocket;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class ProfileCommand
/*    */ {
/*    */   public void getSystemProfile(JSocket client)
/*    */   {
/* 12 */     getProfile(client, "system");
/*    */   }
/*    */ 
/*    */   public void getModuleProfile(JSocket client) {
/* 16 */     getProfile(client, "module");
/*    */   }
/*    */ 
/*    */   public void getEventHookProfile(JSocket client) {
/* 20 */     getProfile(client, "eventhook");
/*    */   }
/*    */ 
/*    */   public void gatherProfile(JSocket client) {
/* 24 */     getProfile(client, "gather");
/*    */   }
/*    */ 
/*    */   public void getProfile(JSocket client, String type)
/*    */   {
/*    */     short cmd;
/* 29 */     if ("module".equalsIgnoreCase(type))
/* 30 */       cmd = 17;
/* 31 */     else if ("eventhook".equalsIgnoreCase(type))
/* 32 */       cmd = 18;
/* 33 */     else if ("gather".equalsIgnoreCase(type))
/* 34 */       cmd = 31;
/*    */     else
/* 36 */       cmd = 16;
/* 37 */     MonitorMessage msg = new MonitorMessage();
/* 38 */     msg.setCommand(cmd);
/* 39 */     ByteBuffer body = ByteBuffer.allocate(0);
/* 40 */     msg.setBody(body);
/* 41 */     client.sendMessage(msg);
/*    */   }
/*    */ }