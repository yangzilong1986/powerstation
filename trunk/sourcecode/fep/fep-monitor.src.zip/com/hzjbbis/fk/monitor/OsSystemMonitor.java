/*     */ package com.hzjbbis.fk.monitor;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class OsSystemMonitor
/*     */ {
/*  24 */   private static final Logger log = Logger.getLogger(OsSystemMonitor.class);
/*     */ 
/*  27 */   private long lastUsed = 0L;
/*  28 */   private long lastTotal = 0L;
/*     */ 
/*  31 */   private int sampleCount = 600;
/*  32 */   private final Object lock = new Object();
/*  33 */   private long maxMemory = 0L;
/*  34 */   private boolean autoMonitor = true;
/*  35 */   private Vector<MonitorDataItem> queue = new Vector();
/*     */ 
/*  38 */   private boolean isWindows = false;
/*     */ 
/*  40 */   private Timer timer = null;
/*     */ 
/*  42 */   private static final OsSystemMonitor cpuMonitor = new OsSystemMonitor();
/*     */ 
/*     */   private OsSystemMonitor() {
/*  45 */     this.maxMemory = (Runtime.getRuntime().maxMemory() >>> 20);
/*  46 */     String osName = System.getProperty("os.name");
/*  47 */     if (osName.indexOf("Windows") > -1)
/*  48 */       this.isWindows = true;
/*     */   }
/*     */ 
/*     */   public static final OsSystemMonitor getInstance()
/*     */   {
/*  53 */     return cpuMonitor;
/*     */   }
/*     */ 
/*     */   public MonitorDataItem[] getAllItems() {
/*  57 */     return ((MonitorDataItem[])this.queue.toArray(new MonitorDataItem[this.queue.size()]));
/*     */   }
/*     */ 
/*     */   public MonitorDataItem getCurrentData() {
/*  61 */     MonitorDataItem item = new MonitorDataItem();
/*  62 */     item.cpuUsage = getCPUUsage();
/*  63 */     item.totalMemory = (Runtime.getRuntime().totalMemory() >>> 20);
/*  64 */     item.freeMemory = (Runtime.getRuntime().freeMemory() >>> 20);
/*  65 */     item.freeDisk = getFreeDisk();
/*  66 */     return item;
/*     */   }
/*     */ 
/*     */   public void initialize() {
/*  70 */     if (this.autoMonitor) {
/*  71 */       this.timer = new Timer(true);
/*  72 */       this.timer.scheduleAtFixedRate(new TimerTask()
/*     */       {
/*     */         public void run() {
/*  75 */           synchronized (OsSystemMonitor.this.lock) {
/*  76 */             MonitorDataItem item = null;
/*  77 */             if (OsSystemMonitor.this.queue.size() < OsSystemMonitor.this.sampleCount) {
/*  78 */               item = new MonitorDataItem();
/*     */             }
/*     */             else {
/*  81 */               item = (MonitorDataItem)OsSystemMonitor.this.queue.remove(0);
/*     */             }
/*  83 */             OsSystemMonitor.this.queue.add(item);
/*  84 */             item.cpuUsage = OsSystemMonitor.this.getCPUUsage();
/*  85 */             item.totalMemory = (Runtime.getRuntime().totalMemory() >>> 20);
/*  86 */             item.freeMemory = (Runtime.getRuntime().freeMemory() >>> 20);
/*  87 */             item.freeDisk = OsSystemMonitor.this.getFreeDisk();
/*  88 */             OsSystemMonitor.this.updateOsProfile(item);
/*  89 */             if (OsSystemMonitor.log.isDebugEnabled())
/*  90 */               OsSystemMonitor.log.debug(item);
/*     */           }
/*     */         }
/*     */       }
/*     */       , 1000L, 60000L);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateOsProfile(MonitorDataItem item) {
/*  98 */     StringBuffer sb = new StringBuffer(1024);
/*  99 */     sb.append("<os-profile>\r\n");
/* 100 */     sb.append("      <cpu>").append(item.cpuUsage).append("</cpu>\r\n");
/* 101 */     sb.append("      <totalMemory>").append(item.totalMemory).append("</totalMemory>\r\n");
/* 102 */     sb.append("      <freeMemory>").append(item.freeMemory).append("</freeMemory>\r\n");
/* 103 */     sb.append("      <freeDisk>").append(item.freeDisk).append("</freeDisk>\r\n");
/* 104 */     sb.append("    </os-profile>\r\n");
/* 105 */     FasSystem.getFasSystem().setOsProfile(sb.toString());
/*     */   }
/*     */ 
/*     */   private String[] execute(String[] commands) {
/* 109 */     String[] strs = (String[])null;
/* 110 */     File scriptFile = null;
/*     */     try {
/* 112 */       List cmdList = new ArrayList();
/* 113 */       if (this.isWindows) {
/* 114 */         scriptFile = new File("monitor.vbs");
/* 115 */         cmdList.add("CMD.EXE");
/* 116 */         cmdList.add("/C");
/* 117 */         cmdList.add("CSCRIPT.EXE");
/* 118 */         cmdList.add("//NoLogo");
/*     */       } else {
/* 120 */         scriptFile = new File("monitor.sh");
/* 121 */         cmdList.add("/bin/bash");
/*     */       }
/* 123 */       if ((!(scriptFile.exists())) || (scriptFile.length() == 0L)) {
/* 124 */         PrintWriter writer = new PrintWriter(scriptFile);
/* 125 */         for (int i = 0; i < commands.length; ++i) {
/* 126 */           writer.println(commands[i]);
/*     */         }
/* 128 */         writer.flush();
/* 129 */         writer.close();
/*     */       }
/* 131 */       String fileName = scriptFile.getCanonicalPath();
/* 132 */       cmdList.add(fileName);
/*     */ 
/* 134 */       ProcessBuilder pb = new ProcessBuilder(cmdList);
/* 135 */       Process p = pb.start();
/* 136 */       p.waitFor();
/*     */ 
/* 138 */       String line = null;
/* 139 */       BufferedReader stdout = new BufferedReader(
/* 140 */         new InputStreamReader(p.getInputStream()));
/* 141 */       List stdoutList = new ArrayList();
/* 142 */       while ((line = stdout.readLine()) != null) {
/* 143 */         stdoutList.add(line);
/*     */       }
/* 145 */       if (log.isDebugEnabled()) {
/* 146 */         log.debug("CPUMonitor stdout:" + stdoutList);
/*     */       }
/*     */ 
/* 149 */       BufferedReader stderr = new BufferedReader(new InputStreamReader(p.getErrorStream()));
/* 150 */       List stderrList = new ArrayList();
/* 151 */       while ((line = stderr.readLine()) != null) {
/* 152 */         stderrList.add(line);
/*     */       }
/* 154 */       if (stderrList.size() > 0) {
/* 155 */         log.warn("CPUMonitor stderr=" + stderrList);
/*     */       }
/* 157 */       strs = (String[])stdoutList.toArray(new String[0]);
/*     */     } catch (Exception e) {
/* 159 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 165 */     return strs;
/*     */   }
/*     */ 
/*     */   private double parseResult(String[] strs)
/*     */   {
/*     */     String strValue;
/* 169 */     double value = 0.0D;
/* 170 */     if (this.isWindows) {
/* 171 */       strValue = strs[0];
/*     */       try {
/* 173 */         value = Double.parseDouble(strValue);
/*     */       } catch (Exception e) {
/* 175 */         log.debug("parse double error.", e);
/*     */       }
/*     */     } else {
/* 178 */       strValue = strs[0];
/* 179 */       String[] values = strValue.split(" ");
/* 180 */       Vector vv = new Vector(10);
/* 181 */       for (String v : values) {
/* 182 */         if (v.length() != 0)
/* 183 */           vv.add(v);
/*     */       }
/* 185 */       values = (String[])vv.toArray(new String[vv.size()]);
/* 186 */       if (values.length == 2) {
/* 187 */         long used = Long.parseLong(values[0]);
/* 188 */         long total = Long.parseLong(values[1]);
/*     */ 
/* 190 */         if ((this.lastUsed > 0L) && (this.lastTotal > 0L)) {
/* 191 */           long deltaUsed = used - this.lastUsed;
/* 192 */           long deltaTotal = total - this.lastTotal;
/* 193 */           if (deltaTotal > 0L) {
/* 194 */             value = deltaUsed * 100L / deltaTotal * 10L / 10L;
/*     */           }
/*     */         }
/* 197 */         this.lastUsed = used;
/* 198 */         this.lastTotal = total;
/*     */       }
/* 200 */       else if (values.length >= 8) {
/* 201 */         int index = 1;
/* 202 */         long _user = Long.parseLong(values[(index++)]);
/* 203 */         long _nice = Long.parseLong(values[(index++)]);
/* 204 */         long _system = Long.parseLong(values[(index++)]);
/* 205 */         long _idle = Long.parseLong(values[(index++)]);
/* 206 */         long _iowait = Long.parseLong(values[(index++)]);
/* 207 */         long _irq = Long.parseLong(values[(index++)]);
/* 208 */         long _softirq = Long.parseLong(values[(index++)]);
/* 209 */         long used = _user + _nice + _system + _iowait + _irq + _softirq;
/* 210 */         long total = used + _idle;
/* 211 */         if ((this.lastUsed > 0L) && (this.lastTotal > 0L)) {
/* 212 */           long deltaUsed = used - this.lastUsed;
/* 213 */           long deltaTotal = total - this.lastTotal;
/* 214 */           if (deltaTotal > 0L) {
/* 215 */             value = deltaUsed * 100L / deltaTotal * 10L / 10L;
/*     */           }
/*     */         }
/* 218 */         this.lastUsed = used;
/* 219 */         this.lastTotal = total;
/*     */       }
/*     */     }
/* 222 */     return value;
/*     */   }
/*     */ 
/*     */   private double getCPUUsage() {
/* 226 */     String[] scriptCmds = (String[])null;
/* 227 */     if (this.isWindows)
/* 228 */       scriptCmds = new String[] { 
/* 229 */         "strComputer = \".\"", 
/* 230 */         "Set objWMIService = GetObject(\"winmgmts:\" _", 
/* 231 */         " & \"{impersonationLevel=impersonate}!\\\\\" & strComputer & \"\\root\\cimv2\")", 
/* 232 */         "Set colItems = objWMIService.ExecQuery(\"Select * from Win32_Processor \",,48)", 
/* 233 */         "load = 0", "n = 0", "For Each objItem in colItems", 
/* 234 */         " load = load + objItem.LoadPercentage", " n = n + 1", 
/* 235 */         "Next", "Wscript.Echo (load/n)" };
/*     */     else {
/* 237 */       scriptCmds = new String[] { 
/* 238 */         "cat /proc/stat | head -n 1" };
/*     */     }
/*     */ 
/* 250 */     return parseResult(execute(scriptCmds));
/*     */   }
/*     */ 
/*     */   private long getFreeDisk()
/*     */   {
/* 255 */     if (this.isWindows);
/*     */     try
/*     */     {
/*     */       char c;
/* 257 */       List cmdList = new ArrayList();
/* 258 */       cmdList.add("CMD.EXE");
/* 259 */       cmdList.add("/C");
/* 260 */       cmdList.add("dir");
/* 261 */       cmdList.add(System.getProperty("user.dir"));
/*     */ 
/* 263 */       ProcessBuilder pb = new ProcessBuilder(cmdList);
/* 264 */       Process p = pb.start();
/*     */ 
/* 266 */       BufferedReader stdout = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 267 */       String lastLine = null; String str = null;
/* 268 */       while ((str = stdout.readLine()) != null) {
/* 269 */         lastLine = str;
/*     */       }
/* 271 */       if (lastLine == null)
/*     */         break label279;
/* 273 */       lastLine = lastLine.trim();
/* 274 */       int index = lastLine.lastIndexOf(",");
/* 275 */       if (index <= 0)
/* 276 */         return 0L;
/* 277 */       int pos0 = 0;
/* 278 */       while (--index >= 0) {
/* 279 */         char c = lastLine.charAt(index);
/* 280 */         if (Character.isDigit(c)) continue; if (c == ',')
/*     */           continue;
/* 282 */         pos0 = index + 1;
/* 283 */         break;
/*     */       }
/* 285 */       StringBuffer sb = new StringBuffer();
/*     */ 
/* 290 */       while ((c == ',') && (pos0 < lastLine.length())) {
/* 287 */         c = lastLine.charAt(pos0++);
/* 288 */         if (Character.isDigit(c)) {
/* 289 */           sb.append(c);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 295 */       long freeBytes = Long.parseLong(sb.toString());
/* 296 */       return (freeBytes >>> 20);
/*     */     }
/*     */     catch (Exception e) {
/* 299 */       e.printStackTrace(); break label279:
/*     */ 
/* 303 */       return 0L;
/*     */     }
/* 305 */     label279: return 0L;
/*     */   }
/*     */ 
/*     */   public final void setSampleCount(int sampleCount)
/*     */   {
/* 310 */     this.sampleCount = sampleCount;
/*     */   }
/*     */ 
/*     */   public final long getMaxMemory() {
/* 314 */     return this.maxMemory;
/*     */   }
/*     */ 
/*     */   public final void setAutoMonitor(boolean autoMonitor) {
/* 318 */     this.autoMonitor = autoMonitor;
/*     */   }
/*     */ }