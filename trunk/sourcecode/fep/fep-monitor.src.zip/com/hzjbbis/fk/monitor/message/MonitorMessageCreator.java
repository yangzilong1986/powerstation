/*    */ package com.hzjbbis.fk.monitor.message;
/*    */ 
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.message.IMessageCreator;
/*    */ 
/*    */ public class MonitorMessageCreator
/*    */   implements IMessageCreator
/*    */ {
/*    */   public IMessage createHeartBeat(int reqNum)
/*    */   {
/*  9 */     return null;
/*    */   }
/*    */ 
/*    */   public IMessage create() {
/* 13 */     return new MonitorMessage();
/*    */   }
/*    */ }