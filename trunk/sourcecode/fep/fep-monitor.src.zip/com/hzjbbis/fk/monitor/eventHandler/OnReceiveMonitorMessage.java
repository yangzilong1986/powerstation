/*     */ package com.hzjbbis.fk.monitor.eventHandler;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.monitor.biz.HandleFile;
/*     */ import com.hzjbbis.fk.monitor.biz.HandleListFile;
/*     */ import com.hzjbbis.fk.monitor.biz.HandleRtuTrace;
/*     */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.adapt.ReceiveMessageEventAdapt;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class OnReceiveMonitorMessage extends ReceiveMessageEventAdapt
/*     */ {
/*  23 */   private static final Logger log = Logger.getLogger(OnReceiveMonitorMessage.class);
/*  24 */   private static final byte[] Reply_Success = "成功".getBytes();
/*  25 */   private static final byte[] Reply_Failed = "失败".getBytes();
/*     */   private static final String configPath = ".";
/*     */   private static final String logPath = "log";
/*     */ 
/*     */   protected void process(ReceiveMessageEvent event)
/*     */   {
/*     */     String name;
/*     */     byte[] result;
/*  31 */     MonitorMessage msg = (MonitorMessage)event.getMessage();
/*  32 */     msg.resetMessageState();
/*     */ 
/*  35 */     switch (msg.getCommand()) { case 0:
/*  37 */       log.error("OnReceiveMonitorMessage: CMD_INVALID");
/*  38 */       break;
/*     */     case 2:
/*  40 */       result = HandleListFile.getListFile().list(".", "*.xml,*.properties").getBytes();
/*  41 */       _reply(event, result);
/*  42 */       break;
/*     */     case 1:
/*  44 */       result = HandleListFile.getListFile().list("log").getBytes();
/*  45 */       _reply(event, result);
/*  46 */       break;
/*     */     case 3:
/*  48 */       _reply(event, HandleFile.getHandleFile().getFile(msg.getBody()));
/*  49 */       break;
/*     */     case 4:
/*  51 */       _reply(event, HandleFile.getHandleFile().putFile(msg.getBody()));
/*  52 */       break;
/*     */     case 16:
/*  54 */       onProfileEvent(event, "system");
/*  55 */       break;
/*     */     case 17:
/*  57 */       onProfileEvent(event, "module");
/*  58 */       break;
/*     */     case 18:
/*  60 */       onProfileEvent(event, "eventhook");
/*  61 */       break;
/*     */     case 31:
/*  63 */       onProfileEvent(event, "gather");
/*  64 */       break;
/*     */     case 19:
/*  66 */       name = new String(msg.getBody().array());
/*  67 */       onBooleanReply(event, FasSystem.getFasSystem().startModule(name));
/*  68 */       break;
/*     */     case 20:
/*  70 */       name = new String(msg.getBody().array());
/*  71 */       onBooleanReply(event, FasSystem.getFasSystem().stopModule(name));
/*  72 */       break;
/*     */     case 21:
/*  74 */       break;
/*     */     case 22:
/*  76 */       FasSystem.getFasSystem().stopSystem();
/*  77 */       break;
/*     */     case 23:
/*  79 */       onBooleanReply(event, HandleRtuTrace.getHandleRtuTrace().startTraceRtu(event, msg.getBody()));
/*  80 */       break;
/*     */     case 24:
/*  82 */       onBooleanReply(event, HandleRtuTrace.getHandleRtuTrace().stopTrace(event));
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 25:
/*     */     case 26:
/*     */     case 27:
/*     */     case 28:
/*     */     case 29:
/*     */     case 30: }  } 
/*     */   private void onProfileEvent(ReceiveMessageEvent event, String eType) { FasSystem fas = FasSystem.getFasSystem();
/*  89 */     String profile = fas.getProfile(eType);
/*  90 */     if (profile == null)
/*  91 */       return;
/*  92 */     byte[] ret = profile.getBytes();
/*     */ 
/*  94 */     _reply(event, ret);
/*     */   }
/*     */ 
/*     */   private void onBooleanReply(ReceiveMessageEvent event, boolean ret)
/*     */   {
/*     */     byte[] result;
/*  99 */     if (ret)
/* 100 */       result = Reply_Success;
/*     */     else
/* 102 */       result = Reply_Failed;
/* 103 */     _reply(event, result);
/*     */   }
/*     */ 
/*     */   private void _reply(ReceiveMessageEvent event, byte[] result) {
/* 107 */     MonitorMessage msg = (MonitorMessage)event.getMessage();
/* 108 */     ByteBuffer body = ByteBuffer.wrap(result);
/* 109 */     msg.setBody(body);
/* 110 */     event.getClient().send(msg);
/*     */   }
/*     */ 
/*     */   private void _reply(ReceiveMessageEvent event, ByteBuffer result) {
/* 114 */     MonitorMessage msg = (MonitorMessage)event.getMessage();
/* 115 */     msg.setBody(result);
/* 116 */     event.getClient().send(msg);
/*     */   }
/*     */ }