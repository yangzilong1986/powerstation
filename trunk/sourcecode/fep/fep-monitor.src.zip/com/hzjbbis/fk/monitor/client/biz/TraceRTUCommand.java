/*    */ package com.hzjbbis.fk.monitor.client.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*    */ import com.hzjbbis.fk.sockclient.JSocket;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class TraceRTUCommand
/*    */ {
/* 13 */   private static final Logger log = Logger.getLogger(TraceRTUCommand.class);
/*    */ 
/*    */   public void startTrace(JSocket client, int[] rtus) { short cmd = 23;
/* 16 */     MonitorMessage msg = new MonitorMessage();
/* 17 */     msg.setCommand(cmd);
/* 18 */     ByteBuffer body = ByteBuffer.allocate(rtus.length * 4);
/* 19 */     for (int i = 0; i < rtus.length; ++i) {
/* 20 */       log.debug("TRACE RTUA=" + HexDump.toHex(rtus[i]));
/* 21 */       body.putInt(rtus[i]);
/*    */     }
/* 23 */     body.flip();
/* 24 */     msg.setBody(body);
/* 25 */     client.sendMessage(msg);
/*    */   }
/*    */ 
/*    */   public void stopTrace(JSocket client) {
/* 29 */     short cmd = 24;
/* 30 */     MonitorMessage msg = new MonitorMessage();
/* 31 */     msg.setCommand(cmd);
/* 32 */     ByteBuffer body = ByteBuffer.allocate(0);
/* 33 */     msg.setBody(body);
/* 34 */     client.sendMessage(msg);
/*    */   }
/*    */ }