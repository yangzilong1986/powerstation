/*    */ package com.hzjbbis.fk.monitor;
/*    */ 
/*    */ public class MonitorDataItem
/*    */ {
/*  4 */   public double cpuUsage = 0.0D;
/*  5 */   public long freeDisk = 0L;
/*  6 */   public long totalMemory = 0L;
/*  7 */   public long freeMemory = 0L;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 11 */     StringBuffer sb = new StringBuffer();
/* 12 */     sb.append("cpu=").append(this.cpuUsage).append("%;  ");
/* 13 */     sb.append("freeDisk=").append(this.freeDisk).append("M;  ");
/* 14 */     sb.append("totalMemory=").append(this.totalMemory).append("M;  ");
/* 15 */     sb.append("freeMemory=").append(this.freeMemory).append("M");
/* 16 */     return sb.toString();
/*    */   }
/*    */ }