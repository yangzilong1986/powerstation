/*    */ package com.hzjbbis.fk.monitor.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.monitor.exception.MonitorHandleException;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class HandleFile
/*    */ {
/*    */   public static final int MAX_BLOCK = 1048576;
/* 17 */   private static final HandleFile handleFile = new HandleFile();
/*    */ 
/*    */   public static final HandleFile getHandleFile() { return handleFile;
/*    */   }
/*    */ 
/*    */   public ByteBuffer getFile(ByteBuffer inputBody)
/*    */   {
/* 29 */     String path = "";
/* 30 */     byte[] btPath = (byte[])null;
/* 31 */     long position = -1L;
/* 32 */     int index = 0;
/* 33 */     for (index = 0; index < inputBody.limit(); ++index) {
/* 34 */       if (inputBody.get(index) == 0) {
/* 35 */         btPath = new byte[index];
/* 36 */         inputBody.get(btPath);
/* 37 */         path = new String(btPath);
/* 38 */         inputBody.get();
/* 39 */         position = inputBody.getLong();
/* 40 */         inputBody.rewind();
/* 41 */         break;
/*    */       }
/*    */     }
/* 44 */     if ((-1L == position) || (btPath == null))
/* 45 */       throw new MonitorHandleException("监控管理：获取文件异常，输入非法。");
/*    */     try {
/* 47 */       RandomAccessFile raf = new RandomAccessFile(path, "r");
/* 48 */       int len = (int)(raf.length() - position);
/* 49 */       if (len <= 0) {
/* 50 */         return inputBody;
/*    */       }
/* 52 */       int toRead = 1048576;
/* 53 */       toRead = Math.min(len, toRead);
/* 54 */       ByteBuffer body = ByteBuffer.allocate(inputBody.remaining() + toRead);
/* 55 */       raf.seek(position);
/* 56 */       body.put(inputBody);
/* 57 */       inputBody.rewind();
/* 58 */       raf.read(body.array(), inputBody.remaining(), toRead);
/* 59 */       body.position(0);
/* 60 */       raf.close();
/* 61 */       return body;
/*    */     } catch (Exception exp) {
/* 63 */       throw new MonitorHandleException(exp);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ByteBuffer putFile(ByteBuffer inputBody)
/*    */   {
/* 74 */     String path = "";
/* 75 */     byte[] btPath = (byte[])null;
/* 76 */     long position = -1L;
/* 77 */     int index = 0;
/* 78 */     for (index = 0; index < inputBody.limit(); ++index) {
/* 79 */       if (inputBody.get(index) == 0) {
/* 80 */         btPath = new byte[index];
/* 81 */         inputBody.get(btPath);
/* 82 */         path = new String(btPath);
/* 83 */         inputBody.get();
/* 84 */         position = inputBody.getLong();
/* 85 */         break;
/*    */       }
/*    */     }
/* 88 */     int offset = inputBody.position();
/* 89 */     int dataLen = inputBody.remaining();
/* 90 */     if ((-1L == position) || (btPath == null))
/* 91 */       throw new MonitorHandleException("监控管理：写文件命令异常，输入非法。");
/*    */     try
/*    */     {
/* 94 */       RandomAccessFile raf = new RandomAccessFile(path, "rwd");
/* 95 */       if (position > raf.length()) {
/* 96 */         raf.close();
/* 97 */         throw new MonitorHandleException("监控管理：写文件命令异常，写文件起始位置>文件实际长度。");
/*    */       }
/*    */ 
/* 100 */       raf.setLength(position);
/* 101 */       raf.seek(position);
/* 102 */       raf.write(inputBody.array(), offset, dataLen);
/* 103 */       raf.close();
/* 104 */       position += dataLen;
/*    */ 
/* 106 */       inputBody.clear();
/* 107 */       inputBody.put(btPath); inputBody.put(0);
/* 108 */       inputBody.putLong(position);
/* 109 */       inputBody.flip();
/* 110 */       return inputBody;
/*    */     } catch (Exception exp) {
/* 112 */       throw new MonitorHandleException(exp);
/*    */     }
/*    */   }
/*    */ }