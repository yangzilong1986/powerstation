/*     */ package com.hzjbbis.fk.monitor.message;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.exception.SocketClientCloseException;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MonitorMessage
/*     */   implements IMessage
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(MonitorMessage.class);
/*  22 */   private static final MessageType msgType = MessageType.MSG_MONITOR;
/*  23 */   private static final byte[] FLAG = "JBMONITOR".getBytes();
/*  24 */   private static final ByteBuffer voidBody = ByteBuffer.allocate(0);
/*     */ 
/*  26 */   private long ioTime = System.currentTimeMillis();
/*     */   private String peerAddr;
/*     */   private String serverAddress;
/*  29 */   private String txfs = "tcp";
/*     */   private IChannel source;
/*  31 */   private int priority = 0;
/*  32 */   private short command = 0;
/*  33 */   private int bodyLen = 0;
/*  34 */   private ByteBuffer body = voidBody;
/*     */ 
/*  36 */   private int state = -1;
/*     */ 
/*     */   public long getIoTime() {
/*  39 */     return this.ioTime;
/*     */   }
/*     */ 
/*     */   public MessageType getMessageType() {
/*  43 */     return msgType;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/*  47 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/*  51 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public byte[] getRawPacket() {
/*  55 */     return this.body.array();
/*     */   }
/*     */ 
/*     */   public String getRawPacketString() {
/*  59 */     return "un implemented";
/*     */   }
/*     */ 
/*     */   public IChannel getSource() {
/*  63 */     return this.source;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/*  67 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public boolean read(ByteBuffer readBuffer) {
/*  71 */     if ((this.state == -1) && (readBuffer.remaining() < 15)) {
/*  72 */       if (log.isDebugEnabled())
/*  73 */         log.debug("长度不足读取监控报文头，等会儿继续读取。readBuffer.remaining=" + readBuffer.remaining());
/*  74 */       return false;
/*     */     }
/*  76 */     if (this.state == -1) {
/*  77 */       for (int i = 0; i < FLAG.length; ++i) {
/*  78 */         if (readBuffer.get() != FLAG[i])
/*  79 */           throw new SocketClientCloseException("报文标志不匹配。必须关闭通讯连接");
/*     */       }
/*  81 */       this.command = readBuffer.getShort();
/*  82 */       this.bodyLen = readBuffer.getInt();
/*  83 */       this.body = ByteBuffer.allocate(this.bodyLen);
/*  84 */       this.state = 2;
/*  85 */       if (readBuffer.remaining() >= this.body.remaining()) {
/*  86 */         readBuffer.get(this.body.array());
/*  87 */         this.state = 15;
/*  88 */         return true;
/*     */       }
/*  90 */       this.body.put(readBuffer);
/*  91 */       return false;
/*     */     }
/*  93 */     if (this.state == 2) {
/*  94 */       if (readBuffer.remaining() >= this.body.remaining()) {
/*  95 */         readBuffer.get(this.body.array(), this.body.position(), this.body.remaining());
/*  96 */         this.body.position(0);
/*  97 */         this.state = 15;
/*  98 */         return true;
/*     */       }
/* 100 */       this.body.put(readBuffer);
/* 101 */       return false;
/*     */     }
/*     */ 
/* 104 */     log.error("状态非法。不是读取信息状态。关闭通信连接。请检查程序BUG。");
/* 105 */     throw new SocketClientCloseException("状态非法。不是读取信息状态。关闭通信连接。请检查程序BUG。");
/*     */   }
/*     */ 
/*     */   public void setIoTime(long time)
/*     */   {
/* 110 */     this.ioTime = time;
/*     */   }
/*     */ 
/*     */   public void setPeerAddr(String peer) {
/* 114 */     this.peerAddr = peer;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority) {
/* 118 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public void setSource(IChannel src) {
/* 122 */     this.source = src;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String fs) {
/* 126 */     this.txfs = fs;
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer writeBuffer) {
/* 130 */     if (47 == this.state)
/* 131 */       return true;
/* 132 */     if (-1 == this.state) {
/* 133 */       if (writeBuffer.remaining() < 15) {
/* 134 */         log.debug("缓冲区长度不足，不能发送监控报文头。writeBuffer.len=" + writeBuffer.remaining());
/* 135 */         return false;
/*     */       }
/* 137 */       writeBuffer.put(FLAG);
/* 138 */       writeBuffer.putShort(this.command);
/* 139 */       writeBuffer.putInt(this.body.remaining());
/* 140 */       this.state = 18;
/* 141 */       return sendDataSection(writeBuffer);
/*     */     }
/* 143 */     if (18 == this.state) {
/* 144 */       return sendDataSection(writeBuffer);
/*     */     }
/* 146 */     log.error("状态非法。不是发送监控消息状态。关闭通信连接。请检查程序BUG。");
/* 147 */     throw new SocketClientCloseException("状态非法。不是发送监控消息状态。关闭通信连接。请检查程序BUG。");
/*     */   }
/*     */ 
/*     */   private boolean sendDataSection(ByteBuffer writeBuffer)
/*     */   {
/* 152 */     if (writeBuffer.remaining() > this.body.remaining()) {
/* 153 */       writeBuffer.put(this.body);
/* 154 */       this.body.rewind();
/* 155 */       this.state = 47;
/* 156 */       this.ioTime = System.currentTimeMillis();
/* 157 */       return true;
/*     */     }
/*     */ 
/* 160 */     int limit = this.body.limit();
/* 161 */     this.body.limit(this.body.position() + writeBuffer.remaining());
/* 162 */     writeBuffer.put(this.body);
/* 163 */     this.body.limit(limit);
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   public short getCommand() {
/* 168 */     return this.command;
/*     */   }
/*     */ 
/*     */   public void setCommand(short command) {
/* 172 */     this.command = command;
/*     */   }
/*     */ 
/*     */   public ByteBuffer getBody() {
/* 176 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(ByteBuffer body) {
/* 180 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public void resetMessageState() {
/* 184 */     this.state = -1;
/*     */   }
/*     */ 
/*     */   public Long getCmdId() {
/* 188 */     return new Long(0L);
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 192 */     return "";
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 196 */     return this.serverAddress;
/*     */   }
/*     */ 
/*     */   public void setServerAddress(String serverAddress) {
/* 200 */     this.serverAddress = serverAddress;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */   public int getRtua() {
/* 208 */     return 0;
/*     */   }
/*     */ 
/*     */   public int length() {
/* 212 */     return 0;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/*     */   }
/*     */ 
/*     */   public boolean isTask() {
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */   public void setTask(boolean isTask)
/*     */   {
/*     */   }
/*     */ }