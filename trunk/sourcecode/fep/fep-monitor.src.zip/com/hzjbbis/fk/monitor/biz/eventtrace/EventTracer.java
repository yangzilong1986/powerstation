/*     */ package com.hzjbbis.fk.monitor.biz.eventtrace;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventTrace;
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.monitor.message.MonitorMessage;
/*     */ import com.hzjbbis.fk.utils.CalendarUtil;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class EventTracer
/*     */   implements IEventTrace
/*     */ {
/*  23 */   private ArrayList<IChannel> monitorClients = new ArrayList();
/*  24 */   private int[] rtus = null;
/*     */ 
/*     */   public EventTracer(IChannel client) {
/*  27 */     this.monitorClients.add(client);
/*     */   }
/*     */ 
/*     */   public void addClient(IChannel client) {
/*  31 */     synchronized (this.monitorClients) {
/*  32 */       this.monitorClients.remove(client);
/*  33 */       this.monitorClients.add(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int removeClient(IChannel client) {
/*  38 */     synchronized (this.monitorClients) {
/*  39 */       this.monitorClients.remove(client);
/*  40 */       if (this.monitorClients.size() == 0)
/*  41 */         this.rtus = null;
/*  42 */       return this.monitorClients.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void traceRtus(int[] tobeTraced) {
/*  47 */     if (tobeTraced == null)
/*  48 */       return;
/*  49 */     if (this.rtus == null) {
/*  50 */       this.rtus = tobeTraced;
/*  51 */       return;
/*     */     }
/*  53 */     int count = 0;
/*  54 */     int[] tp = new int[tobeTraced.length];
/*  55 */     for (int i = 0; i < tobeTraced.length; ++i) {
/*  56 */       boolean found = false;
/*  57 */       for (int j = 0; j < this.rtus.length; ++j) {
/*  58 */         if (this.rtus[j] == tobeTraced[i]) {
/*  59 */           found = true;
/*  60 */           break;
/*     */         }
/*     */       }
/*  63 */       if (!(found)) {
/*  64 */         tp[count] = tobeTraced[i];
/*  65 */         ++count;
/*     */       }
/*     */     }
/*  68 */     if (count == 0)
/*  69 */       return;
/*  70 */     int[] newRtus = new int[this.rtus.length + count];
/*  71 */     System.arraycopy(this.rtus, 0, newRtus, 0, this.rtus.length);
/*  72 */     System.arraycopy(tp, 0, newRtus, this.rtus.length, count);
/*  73 */     this.rtus = newRtus;
/*     */   }
/*     */ 
/*     */   public void traceEvent(IEvent e)
/*     */   {
/*     */     IMessage msg;
/*     */     IChannel client;
/*     */     MessageZj message;
/*     */     StringBuffer sb;
/*  80 */     if (e.getType() == EventType.MSG_RECV) {
/*  81 */       msg = e.getMessage();
/*  82 */       client = msg.getSource();
/*     */ 
/*  84 */       message = null;
/*  85 */       if (msg instanceof MessageZj) {
/*  86 */         message = (MessageZj)msg;
/*     */       }
/*  88 */       else if (msg.getMessageType() == MessageType.MSG_GATE) {
/*  89 */         message = (MessageZj)((MessageGate)msg).getInnerMessage();
/*  90 */         if (message == null)
/*  91 */           return;
/*  92 */         message.setIoTime(msg.getIoTime());
/*     */       }
/*     */       else {
/*  95 */         return;
/*     */       }
/*  97 */       if (!(_isMonited(message.head.rtua)))
/*  98 */         return;
/*  99 */       sb = new StringBuffer(400);
/* 100 */       sb.append("收到:【").append(client.getServer().getName()).append("】,时间=");
/* 101 */       sb.append(CalendarUtil.getMilliDateTimeString(message.getIoTime()));
/* 102 */       sb.append(", 报文=").append(message.getRawPacketString()).append("\r\n");
/* 103 */       _sendIndication(sb.toString());
/*     */     }
/* 105 */     else if (e.getType() == EventType.MSG_SENT) {
/* 106 */       msg = e.getMessage();
/* 107 */       client = msg.getSource();
/*     */ 
/* 109 */       message = null;
/* 110 */       if (msg instanceof MessageZj) {
/* 111 */         message = (MessageZj)msg;
/*     */       }
/* 113 */       else if (msg.getMessageType() == MessageType.MSG_GATE) {
/* 114 */         message = (MessageZj)((MessageGate)msg).getInnerMessage();
/* 115 */         if (message == null)
/* 116 */           return;
/* 117 */         message.setIoTime(msg.getIoTime());
/*     */       }
/*     */       else {
/* 120 */         return;
/*     */       }
/* 122 */       if (!(_isMonited(message.head.rtua))) {
/* 123 */         return;
/*     */       }
/* 125 */       sb = new StringBuffer(400);
/* 126 */       sb.append("发送:【").append(client.getServer().getName()).append("】,时间=");
/* 127 */       sb.append(CalendarUtil.getMilliDateTimeString(message.getIoTime()));
/* 128 */       sb.append(", 报文=").append(message.getRawPacketString()).append("\r\n");
/* 129 */       _sendIndication(sb.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void _sendIndication(String info)
/*     */   {
/* 138 */     MonitorMessage msg = new MonitorMessage();
/* 139 */     msg.setCommand(25);
/* 140 */     ByteBuffer body = ByteBuffer.wrap(info.getBytes());
/* 141 */     msg.setBody(body);
/* 142 */     synchronized (this.monitorClients) {
/* 143 */       for (IChannel client : this.monitorClients)
/* 144 */         client.send(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean _isMonited(int rtua) {
/*     */     try {
/* 150 */       for (int i = 0; i < this.rtus.length; ++i)
/* 151 */         if (this.rtus[i] == rtua)
/* 152 */           return true;
/*     */     } catch (Exception localException) {
/*     */     }
/* 155 */     return false;
/*     */   }
/*     */ }