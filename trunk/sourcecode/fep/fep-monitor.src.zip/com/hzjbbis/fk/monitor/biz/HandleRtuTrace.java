/*    */ package com.hzjbbis.fk.monitor.biz;
/*    */ 
/*    */ import com.hzjbbis.fk.FasSystem;
/*    */ import com.hzjbbis.fk.common.spi.IEventHook;
/*    */ import com.hzjbbis.fk.monitor.biz.eventtrace.EventTracer;
/*    */ import com.hzjbbis.fk.sockserver.event.ClientCloseEvent;
/*    */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class HandleRtuTrace
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(HandleRtuTrace.class);
/* 20 */   private static final HandleRtuTrace handleRtuTrace = new HandleRtuTrace();
/* 21 */   private static EventTracer tracer = null;
/*    */ 
/*    */   public static final HandleRtuTrace getHandleRtuTrace() { return handleRtuTrace;
/*    */   }
/*    */ 
/*    */   public boolean startTraceRtu(ReceiveMessageEvent event, ByteBuffer inputBody)
/*    */   {
/* 33 */     int count = inputBody.remaining() / 4;
/* 34 */     if (count == 0)
/* 35 */       return false;
/* 36 */     int[] rtus = new int[count];
/* 37 */     for (int i = 0; i < count; ++i) {
/* 38 */       rtus[i] = inputBody.getInt();
/* 39 */       log.info("跟踪：RTUA=" + HexDump.toHex(rtus[i]));
/*    */     }
/*    */ 
/* 42 */     if (tracer == null) {
/* 43 */       synchronized (this) {
/* 44 */         tracer = new EventTracer(event.getClient());
/*    */ 
/* 46 */         for (IEventHook hook : FasSystem.getFasSystem().getEventHooks()) {
/* 47 */           hook.setEventTrace(tracer);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 52 */     tracer.addClient(event.getClient());
/* 53 */     tracer.traceRtus(rtus);
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean stopTrace(ReceiveMessageEvent event) {
/* 58 */     if (tracer == null)
/* 59 */       return false;
/* 60 */     synchronized (this) {
/* 61 */       int monitorCount = tracer.removeClient(event.getClient());
/* 62 */       if (monitorCount == 0)
/*    */       {
/* 64 */         for (IEventHook hook : FasSystem.getFasSystem().getEventHooks()) {
/* 65 */           hook.setEventTrace(null);
/*    */         }
/*    */       }
/*    */     }
/* 69 */     return true;
/*    */   }
/*    */ 
/*    */   public void onClientClose(ClientCloseEvent event) {
/* 73 */     if (tracer == null)
/* 74 */       return;
/* 75 */     synchronized (this) {
/* 76 */       int monitorCount = tracer.removeClient(event.getClient());
/* 77 */       if (monitorCount == 0)
/*    */       {
/* 79 */         for (IEventHook hook : FasSystem.getFasSystem().getEventHooks()) {
/* 80 */           hook.setEventTrace(null);
/*    */         }
/* 82 */         tracer = null;
/*    */       }
/*    */     }
/*    */   }
/*    */ }