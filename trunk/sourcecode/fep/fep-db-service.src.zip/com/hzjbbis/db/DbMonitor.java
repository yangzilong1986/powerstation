/*     */ package com.hzjbbis.db;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DbMonitor
/*     */ {
/*  25 */   private static final Logger log = Logger.getLogger(DbMonitor.class);
/*  26 */   private static final TraceLog tracer = TraceLog.getTracer();
/*  27 */   private static final ArrayList<DbMonitor> dbMonitors = new ArrayList();
/*     */ 
/*  29 */   private String name = "defaultDbMonitor";
/*     */   private String serverIp;
/*     */   private int serverPort;
/*     */   private DataSource dataSource;
/*  33 */   private String testSql = "select * from dual";
/*  34 */   private int connectTimeout = 2;
/*  35 */   private int testInterval = 90;
/*  36 */   private FasSystem fasSystem = null;
/*     */ 
/*  39 */   private boolean dbAvailable = false;
/*     */ 
/*  41 */   private boolean initialized = false;
/*     */ 
/*  43 */   private static final DbMonitorThread daemonThread = new DbMonitorThread();
/*     */ 
/*     */   public static final DbMonitor createInstance()
/*     */   {
/*  48 */     DbMonitor monitor = new DbMonitor();
/*  49 */     dbMonitors.add(monitor);
/*  50 */     return monitor;
/*     */   }
/*     */ 
/*     */   public static final DbMonitor getMonitor(String name) {
/*  54 */     if ((name == null) || (name.length() == 0))
/*  55 */       name = "defaultDbMonitor";
/*  56 */     for (int i = 0; i < dbMonitors.size(); ++i)
/*  57 */       if (((DbMonitor)dbMonitors.get(i)).name.equals(name))
/*  58 */         return ((DbMonitor)dbMonitors.get(i));
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   public static final DbMonitor getMonitor(DataSource ds) {
/*  63 */     for (DbMonitor dm : dbMonitors) {
/*  64 */       if (dm.dataSource == ds)
/*  65 */         return dm;
/*     */     }
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   public static final DbMonitor getMasterMonitor() {
/*  71 */     return getMonitor(null);
/*     */   }
/*     */ 
/*     */   public void initialize() {
/*  75 */     testDbConnection();
/*  76 */     daemonThread.add(this);
/*     */   }
/*     */ 
/*     */   public boolean testSocketConnectable()
/*     */   {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean testDbConnection() {
/* 104 */     this.initialized = true;
/* 105 */     Assert.notNull(this.dataSource, "dataSource must not be null");
/* 106 */     isAvailable();
/*     */ 
/* 111 */     if ((this.testSql == null) || (this.testSql.length() < 5)) {
/* 112 */       return true;
/*     */     }
/* 114 */     Connection con = null;
/*     */     try {
/* 116 */       con = DataSourceUtils.getConnection(this.dataSource);
/* 117 */       con.createStatement().executeQuery(this.testSql);
/* 118 */       setAvailable(true);
/*     */     } catch (Exception e) {
/* 120 */       setAvailable(false);
/*     */     }
/*     */     finally {
/* 123 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */     }
/* 125 */     return isAvailable();
/*     */   }
/*     */ 
/*     */   public final boolean isAvailable() {
/* 129 */     if (!(this.initialized))
/* 130 */       testDbConnection();
/* 131 */     return this.dbAvailable;
/*     */   }
/*     */ 
/*     */   public final void setAvailable(boolean available) {
/* 135 */     if (this.fasSystem == null)
/* 136 */       this.fasSystem = FasSystem.getFasSystem();
/* 137 */     if (this.fasSystem != null)
/* 138 */       this.fasSystem.setDbAvailable(available);
/* 139 */     if (this.dbAvailable != available) {
/* 140 */       tracer.trace(this.name + " detect DB available is:" + available);
/*     */     }
/* 142 */     this.dbAvailable = available;
/*     */   }
/*     */ 
/*     */   public final void setServerIp(String serverIp) {
/* 146 */     this.serverIp = serverIp;
/*     */   }
/*     */ 
/*     */   public final void setServerPort(int serverPort) {
/* 150 */     this.serverPort = serverPort;
/*     */   }
/*     */ 
/*     */   public final void setTestSql(String testSql) {
/* 154 */     this.testSql = testSql;
/*     */   }
/*     */ 
/*     */   public final void setJdbcUrl(String url)
/*     */   {
/*     */   }
/*     */ 
/*     */   public final void setDataSource(DataSource dataSource)
/*     */   {
/* 222 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public final void setName(String name) {
/* 226 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public final void setConnectTimeout(int connectTimeout) {
/* 230 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */   public final void setTestInterval(int testInterval) {
/* 234 */     this.testInterval = testInterval;
/*     */   }
/*     */ 
/*     */   public final void setFasSystem(FasSystem fasSystem)
/*     */   {
/* 278 */     this.fasSystem = fasSystem;
/*     */   }
/*     */ 
/*     */   static class DbMonitorThread extends Thread
/*     */   {
/* 238 */     private final ArrayList<DbMonitor> monitors = new ArrayList();
/*     */ 
/*     */     public DbMonitorThread() { super("DbMonitorDaemonThread");
/* 241 */       setDaemon(true);
/* 242 */       start();
/*     */     }
/*     */ 
/*     */     public void add(DbMonitor monitor) {
/* 246 */       this.monitors.add(monitor);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*     */         DbMonitor m;
/* 253 */         while (this.monitors.size() == 0) {
/* 254 */           Thread.sleep(3000L);
/*     */         }
/*     */ 
/* 257 */         int interval = 3600;
/* 258 */         for (Iterator localIterator = this.monitors.iterator(); localIterator.hasNext(); ) { m = (DbMonitor)localIterator.next();
/* 259 */           if (m.testInterval > 60) {
/* 260 */             if (m.testInterval < interval)
/* 261 */               interval = m.testInterval;
/*     */           }
/*     */           else
/* 264 */             interval = 60;
/*     */         }
/* 266 */         Thread.sleep(interval * 1000);
/* 267 */         for (localIterator = this.monitors.iterator(); localIterator.hasNext(); ) { m = (DbMonitor)localIterator.next();
/* 268 */           m.testDbConnection();
/*     */         }
/*     */       } catch (Exception e) {
/* 271 */         DbMonitor.log.warn("dbMonitor test exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }