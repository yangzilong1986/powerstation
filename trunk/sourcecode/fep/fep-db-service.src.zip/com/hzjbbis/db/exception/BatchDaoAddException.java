package com.hzjbbis.db.exception;

public class BatchDaoAddException extends Exception
{
  private static final long serialVersionUID = -3257157300332484834L;
}