/*     */ package com.hzjbbis.db.batch.dao.jdbc;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*     */ 
/*     */ public class BatchSimpleJdbcTemplate extends SimpleJdbcTemplate
/*     */ {
/*     */   private final BatchNamedParameterJdbcTemplate namedParameterJdbcOperations;
/*     */ 
/*     */   public BatchSimpleJdbcTemplate(DataSource dataSource)
/*     */   {
/*  24 */     super(dataSource);
/*  25 */     this.namedParameterJdbcOperations = new BatchNamedParameterJdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, List<Object[]> batchArgs, String additiveSql) {
/*  29 */     return doExecuteBatchUpdate(sql, batchArgs, new int[0], additiveSql);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs, String additiveSql) {
/*  33 */     return doExecuteBatchUpdateWithNamedParameters(sql, batchArgs, additiveSql);
/*     */   }
/*     */ 
/*     */   public BatchJdbcTemplate getJdbcOperations()
/*     */   {
/*  41 */     return this.namedParameterJdbcOperations.getJdbcOperations();
/*     */   }
/*     */ 
/*     */   public NamedParameterJdbcOperations getNamedParameterJdbcOperations()
/*     */   {
/*  49 */     return this.namedParameterJdbcOperations;
/*     */   }
/*     */ 
/*     */   private int[] doExecuteBatchUpdateWithNamedParameters(String sql, SqlParameterSource[] batchArgs, String additiveSql) {
/*  53 */     if (batchArgs.length <= 0) {
/*  54 */       return new int[1];
/*     */     }
/*  56 */     ParsedSql parsedSql = NamedParameterUtils.parseSqlStatement(sql);
/*  57 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, batchArgs[0]);
/*  58 */     BatchJdbcTemplate jdbcOperation = getJdbcOperations();
/*  59 */     return jdbcOperation.batchUpdate(
/*  60 */       sqlToUse, 
/*  61 */       new BatchPreparedStatementSetter(parsedSql, batchArgs)
/*     */     {
/*     */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/*  64 */         Object[] values = NamedParameterUtils.buildValueArray(this.val$parsedSql, this.val$batchArgs[i], null);
/*  65 */         int[] columnTypes = NamedParameterUtils.buildSqlTypeArray(this.val$parsedSql, this.val$batchArgs[i]);
/*  66 */         BatchSimpleJdbcTemplate.this.doSetStatementParameters(values, ps, columnTypes);
/*     */       }
/*     */ 
/*     */       public int getBatchSize() {
/*  70 */         return this.val$batchArgs.length;
/*     */       }
/*     */     }
/*     */     , additiveSql);
/*     */   }
/*     */ 
/*     */   private void doSetStatementParameters(Object[] values, PreparedStatement ps, int[] columnTypes) throws SQLException {
/*  76 */     int colIndex = 0;
/*  77 */     for (Object value : values) {
/*  78 */       ++colIndex;
/*  79 */       if (value instanceof SqlParameterValue) {
/*  80 */         SqlParameterValue paramValue = (SqlParameterValue)value;
/*  81 */         StatementCreatorUtils.setParameterValue(ps, colIndex, paramValue, paramValue.getValue());
/*     */       }
/*     */       else
/*     */       {
/*     */         int colType;
/*  85 */         if ((columnTypes == null) || (columnTypes.length < colIndex)) {
/*  86 */           colType = -2147483648;
/*     */         }
/*     */         else {
/*  89 */           colType = columnTypes[(colIndex - 1)];
/*     */         }
/*  91 */         StatementCreatorUtils.setParameterValue(ps, colIndex, colType, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private int[] doExecuteBatchUpdate(String sql, List<Object[]> batchValues, int[] columnTypes, String additiveSql) {
/*  97 */     return getJdbcOperations().batchUpdate(
/*  98 */       sql, 
/*  99 */       new BatchPreparedStatementSetter(batchValues, columnTypes)
/*     */     {
/*     */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/* 102 */         Object[] values = (Object[])this.val$batchValues.get(i);
/* 103 */         BatchSimpleJdbcTemplate.this.doSetStatementParameters(values, ps, this.val$columnTypes);
/*     */       }
/*     */ 
/*     */       public int getBatchSize() {
/* 107 */         return this.val$batchValues.size();
/*     */       }
/*     */     }
/*     */     , additiveSql);
/*     */   }
/*     */ }