/*    */ package com.hzjbbis.db.batch.dao.jdbc;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
/*    */ 
/*    */ public class BatchNamedParameterJdbcTemplate extends NamedParameterJdbcTemplate
/*    */ {
/*    */   private final BatchJdbcTemplate batchJdbcTemplate;
/*    */ 
/*    */   public BatchNamedParameterJdbcTemplate(DataSource dataSource)
/*    */   {
/* 12 */     super(dataSource);
/* 13 */     this.batchJdbcTemplate = new BatchJdbcTemplate(dataSource);
/*    */   }
/*    */ 
/*    */   public BatchJdbcTemplate getJdbcOperations()
/*    */   {
/* 21 */     return this.batchJdbcTemplate;
/*    */   }
/*    */ }