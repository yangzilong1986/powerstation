/*     */ package com.hzjbbis.db.batch;
/*     */ 
/*     */ import com.hzjbbis.db.batch.dao.IBatchDao;
/*     */ import com.hzjbbis.db.batch.event.BpBatchDelayEvent;
/*     */ import com.hzjbbis.db.batch.event.BpExpAlarmEvent;
/*     */ import com.hzjbbis.db.batch.event.BpLog2DbEvent;
/*     */ import com.hzjbbis.db.batch.event.BpReadTaskEvent;
/*     */ import com.hzjbbis.db.batch.event.FeUpdateRtuStatus;
/*     */ import com.hzjbbis.db.batch.event.adapt.BatchDelayHandler;
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.events.BasicEventHook;
/*     */ import com.hzjbbis.fk.common.events.EventQueue;
/*     */ import com.hzjbbis.fk.common.queue.CacheQueue;
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.abstra.BaseModule;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gw.MessageGw;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.message.zj.MessageZjHead;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class AsyncService extends BaseModule
/*     */   implements ITimerFunctor
/*     */ {
/*  51 */   protected static final Logger log = Logger.getLogger(AsyncService.class);
/*  52 */   private static final TraceLog tracer = TraceLog.getTracer();
/*     */   private static final int DEFAULT_QUEUE_SIZE = 10000;
/*  56 */   private int maxQueueSize = 10000;
/*  57 */   private int minThreadSize = 4;
/*  58 */   private int maxThreadSize = 20;
/*  59 */   private int delaySecond = 5;
/*  60 */   private String name = "batchService";
/*     */   private List<IBatchDao> daoList;
/*     */   private Map<EventType, BaseBpEventHandler> bpHandlerMap;
/*  65 */   private EventQueue queue = new EventQueue(???.maxQueueSize);
/*     */   private BasicEventHook eventHook;
/*  67 */   private BatchDelayHandler batchDelayHandler = new BatchDelayHandler();
/*  68 */   private Map<Integer, IBatchDao> daoMap = new HashMap(127);
/*  69 */   private CacheQueue msgLogCacheQueue = null;
/*     */ 
/*     */   public void init() {
/*  72 */     if (this.eventHook == null) {
/*  73 */       this.eventHook = new BasicEventHook();
/*  74 */       if (!(this.eventHook.isActive())) {
/*  75 */         this.eventHook.setMinSize(this.minThreadSize);
/*  76 */         this.eventHook.setMaxSize(this.maxThreadSize);
/*  77 */         this.eventHook.setName(this.name);
/*  78 */         this.eventHook.setQueue(this.queue);
/*     */       }
/*     */     }
/*  81 */     if (this.msgLogCacheQueue == null) {
/*  82 */       this.msgLogCacheQueue = new CacheQueue();
/*  83 */       this.msgLogCacheQueue.setKey("rawmsg");
/*  84 */       this.msgLogCacheQueue.setMaxFileSize(100);
/*  85 */       this.msgLogCacheQueue.setFileCount(20);
/*  86 */       this.msgLogCacheQueue.setMaxSize(100);
/*  87 */       this.msgLogCacheQueue.setMinSize(10);
/*     */     }
/*  89 */     for (EventType type : this.bpHandlerMap.keySet()) {
/*  90 */       this.eventHook.addHandler(type, (IEventHandler)this.bpHandlerMap.get(type));
/*     */     }
/*  92 */     this.eventHook.addHandler(this.batchDelayHandler.type(), this.batchDelayHandler);
/*  93 */     this.eventHook.start();
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  97 */     return ((this.eventHook == null) || (!(this.eventHook.isActive())) || (!(FasSystem.getFasSystem().isDbAvailable())));
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 101 */     return this.name;
/*     */   }
/*     */ 
/*     */   public boolean start() {
/* 105 */     init();
/* 106 */     for (IBatchDao dao : this.daoList) {
/* 107 */       dao.setDelaySecond(this.delaySecond);
/*     */     }
/* 109 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, this.delaySecond));
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 114 */     TimerScheduler.getScheduler().removeTimer(this, 0);
/* 115 */     if (this.eventHook != null)
/* 116 */       this.eventHook.stop();
/*     */   }
/*     */ 
/*     */   public String getModuleType()
/*     */   {
/* 121 */     return "dbService";
/*     */   }
/*     */ 
/*     */   public boolean addMessage(IMessage msg)
/*     */   {
/*     */     IEvent event;
/* 131 */     if (this.queue.size() >= this.maxQueueSize)
/* 132 */       return false;
/* 133 */     if (msg.getMessageType() == MessageType.MSG_ZJ) {
/* 134 */       MessageZj zjmsg = (MessageZj)msg;
/*     */ 
/* 136 */       if (zjmsg.head.c_func == 2)
/* 137 */         event = new BpReadTaskEvent(this, zjmsg);
/* 138 */       else if (zjmsg.head.c_func == 9)
/* 139 */         event = new BpExpAlarmEvent(this, zjmsg);
/*     */       else
/* 141 */         return false;
/*     */       try {
/* 143 */         this.queue.offer(event);
/*     */       } catch (Exception exp) {
/* 145 */         tracer.trace(exp.getLocalizedMessage(), exp);
/* 146 */         return false;
/*     */       }
/* 148 */       return true;
/*     */     }
/* 150 */     if (msg.getMessageType() == MessageType.MSG_GW_10) {
/* 151 */       MessageGw gwmsg = (MessageGw)msg;
/*     */ 
/* 153 */       if ((gwmsg.afn() == 11) || (gwmsg.isTask()))
/* 154 */         event = new BpReadTaskEvent(this, msg);
/* 155 */       else if (gwmsg.afn() == 14)
/* 156 */         event = new BpExpAlarmEvent(this, msg);
/*     */       else
/* 158 */         return false;
/*     */       try {
/* 160 */         this.queue.offer(event);
/*     */       } catch (Exception exp) {
/* 162 */         tracer.trace(exp.getLocalizedMessage(), exp);
/* 163 */         return false;
/*     */       }
/* 165 */       return true;
/*     */     }
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean addRtu(Object rtu)
/*     */   {
/* 176 */     if (this.queue.size() >= this.maxQueueSize)
/* 177 */       return false;
/* 178 */     IEvent event = new FeUpdateRtuStatus(this, rtu);
/*     */     try {
/* 180 */       this.queue.offer(event);
/*     */     } catch (Exception exp) {
/* 182 */       tracer.trace(exp.getLocalizedMessage(), exp);
/*     */     }
/* 184 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean log2Db(IMessage msg) {
/* 188 */     if ((!(FasSystem.getFasSystem().isDbAvailable())) || (this.queue.size() >= this.maxQueueSize)) {
/* 189 */       this.msgLogCacheQueue.offer(msg);
/* 190 */       return true;
/*     */     }
/*     */     try {
/* 193 */       this.queue.offer(new BpLog2DbEvent(this, msg));
/* 194 */       if (this.queue.size() * 2 < this.queue.capacity())
/*     */       {
/* 196 */         for (int i = 0; i < 10; ++i) {
/* 197 */           msg = this.msgLogCacheQueue.poll();
/* 198 */           if (msg != null)
/*     */           {
/* 200 */             this.queue.offer(new BpLog2DbEvent(this, msg));
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception exp) {
/* 205 */       tracer.trace(exp.getLocalizedMessage(), exp);
/*     */     }
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */   public void addToDao(Object pojo, int key) {
/* 211 */     IBatchDao dao = (IBatchDao)this.daoMap.get(Integer.valueOf(key));
/* 212 */     if (dao == null) {
/* 213 */       log.error("数据保存到DAO错误，对象对应的KEY找不到DAO。key=" + key);
/* 214 */       return;
/*     */     }
/* 216 */     dao.add(pojo);
/*     */   }
/*     */ 
/*     */   public int getMaxQueueSize() {
/* 220 */     return this.maxQueueSize;
/*     */   }
/*     */ 
/*     */   public void setMaxQueueSize(int maxQueueSize) {
/* 224 */     this.maxQueueSize = maxQueueSize;
/* 225 */     if (this.maxQueueSize > this.queue.capacity())
/* 226 */       this.queue.setCapacity(maxQueueSize);
/*     */   }
/*     */ 
/*     */   public void setDaoList(List<IBatchDao> list) {
/* 230 */     this.daoList = list;
/* 231 */     for (IBatchDao dao : this.daoList)
/* 232 */       this.daoMap.put(Integer.valueOf(dao.getKey()), dao);
/*     */   }
/*     */ 
/*     */   public void setBpHandlerMap(Map<EventType, BaseBpEventHandler> handlers)
/*     */   {
/* 237 */     this.bpHandlerMap = handlers;
/* 238 */     for (BaseBpEventHandler handler : this.bpHandlerMap.values())
/* 239 */       handler.setService(this);
/*     */   }
/*     */ 
/*     */   public void setEventHook(BasicEventHook eventHook)
/*     */   {
/* 244 */     this.eventHook = eventHook;
/*     */   }
/*     */ 
/*     */   public void setMinThreadSize(int minThreadSize) {
/* 248 */     this.minThreadSize = minThreadSize;
/*     */   }
/*     */ 
/*     */   public void setMaxThreadSize(int maxThreadSize) {
/* 252 */     this.maxThreadSize = maxThreadSize;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 256 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void onTimer(int id) {
/* 260 */     if (id != 0)
/*     */       return;
/* 262 */     for (IBatchDao dao : this.daoList) {
/* 263 */       if (!(dao.hasDelayData()))
/*     */         continue;
/*     */       try {
/* 266 */         this.queue.offer(new BpBatchDelayEvent(dao));
/*     */       } catch (Exception exp) {
/* 268 */         tracer.trace(exp.getLocalizedMessage(), exp);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDelaySecond(int delaySecond)
/*     */   {
/* 276 */     if (delaySecond <= 1)
/* 277 */       delaySecond = 5;
/* 278 */     this.delaySecond = delaySecond;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 283 */     return "AsyncService";
/*     */   }
/*     */ 
/*     */   public Collection<IMessage> revokeEventQueue() {
/* 287 */     boolean takable = this.queue.enableTake();
/* 288 */     this.queue.enableTake(false);
/* 289 */     List events = new LinkedList();
/* 290 */     List msgs = new ArrayList();
/* 291 */     this.queue.drainTo(events, this.queue.size(), 0L);
/* 292 */     for (IEvent ev : events) {
/* 293 */       if (ev.getMessage() != null) {
/* 294 */         msgs.add(ev.getMessage());
/*     */       }
/*     */     }
/* 297 */     this.queue.enableTake(takable);
/* 298 */     if (this.msgLogCacheQueue != null)
/* 299 */       this.msgLogCacheQueue.asyncSaveQueue();
/* 300 */     return msgs;
/*     */   }
/*     */ }