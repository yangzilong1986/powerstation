/*     */ package com.hzjbbis.db.batch.dao.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.InterruptibleBatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.ParameterDisposer;
/*     */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.SqlProvider;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class BatchJdbcTemplate extends JdbcTemplate
/*     */ {
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor extractor)
/*     */   {
/*  29 */     super.setNativeJdbcExtractor(extractor);
/*  30 */     this.nativeJdbcExtractor = extractor;
/*     */   }
/*     */ 
/*     */   public NativeJdbcExtractor getNativeJdbcExtractor() {
/*  34 */     return this.nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public BatchJdbcTemplate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BatchJdbcTemplate(DataSource dataSource, boolean lazyInit) {
/*  42 */     super(dataSource, lazyInit);
/*     */   }
/*     */ 
/*     */   public BatchJdbcTemplate(DataSource dataSource) {
/*  46 */     super(dataSource);
/*     */   }
/*     */ 
/*     */   public Object execute(PreparedStatementCreator psc, PreparedStatementCallback action, String additiveSql)
/*     */     throws DataAccessException
/*     */   {
/*  52 */     Assert.notNull(psc, "PreparedStatementCreator must not be null");
/*  53 */     Assert.notNull(action, "Callback object must not be null");
/*  54 */     if (this.logger.isDebugEnabled()) {
/*  55 */       String sql = getSql(psc);
/*  56 */       this.logger.debug("Executing prepared SQL statement" + 
/*  57 */         ((sql != null) ? " [" + sql + "]" : ""));
/*     */     }
/*     */ 
/*  60 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  61 */     boolean _restore = false;
/*  62 */     boolean _autoCommit = true;
/*     */     try {
/*  64 */       _autoCommit = con.getAutoCommit(); } catch (SQLException localSQLException1) {
/*     */     }
/*  66 */     PreparedStatement ps = null;
/*     */     try {
/*  68 */       Connection conToUse = con;
/*  69 */       if ((this.nativeJdbcExtractor != null) && 
/*  71 */         (this.nativeJdbcExtractor
/*  71 */         .isNativeConnectionNecessaryForNativePreparedStatements())) {
/*  72 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*     */       }
/*     */ 
/*  75 */       conToUse.setAutoCommit(false);
/*  76 */       ps = psc.createPreparedStatement(conToUse);
/*  77 */       applyStatementSettings(ps);
/*  78 */       PreparedStatement psToUse = ps;
/*  79 */       if (this.nativeJdbcExtractor != null) {
/*  80 */         psToUse = this.nativeJdbcExtractor
/*  81 */           .getNativePreparedStatement(ps);
/*     */       }
/*  83 */       Object result = action.doInPreparedStatement(psToUse);
/*  84 */       handleWarnings(ps.getWarnings());
/*     */ 
/*  86 */       PreparedStatement aps = null;
/*     */       try
/*     */       {
/*  90 */         if ((additiveSql != null) && (additiveSql.length() > 5)) {
/*  91 */           aps = conToUse.prepareStatement(additiveSql);
/*  92 */           aps.execute(additiveSql);
/*     */         }
/*  94 */         conToUse.commit();
/*     */       } catch (SQLException ex) {
/*  96 */         if (aps != null)
/*  97 */           JdbcUtils.closeStatement(aps);
/*  98 */         this.logger.error("批量保存执行附加语句错误，sql=" + additiveSql, ex);
/*     */       }
/*     */ 
/* 101 */       return result;
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 107 */       if (psc instanceof ParameterDisposer) {
/* 108 */         ((ParameterDisposer)psc).cleanupParameters();
/*     */       }
/* 110 */       String sql = getSql(psc);
/*     */ 
/* 120 */       throw getExceptionTranslator().translate(
/* 121 */         "PreparedStatementCallback", sql, ex);
/*     */     } finally {
/* 123 */       if (psc instanceof ParameterDisposer) {
/* 124 */         ((ParameterDisposer)psc).cleanupParameters();
/*     */       }
/* 126 */       JdbcUtils.closeStatement(ps);
/* 127 */       if ((con != null) && (!(_restore)))
/*     */         try {
/* 129 */           con.setAutoCommit(_autoCommit);
/*     */         } catch (SQLException localSQLException4) {
/*     */         }
/* 132 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object execute(String sql, PreparedStatementCallback action, String additiveSql) throws DataAccessException
/*     */   {
/* 138 */     return execute(new SimplePreparedStatementCreator(sql), action, additiveSql);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, BatchPreparedStatementSetter pss, String additiveSql) throws DataAccessException
/*     */   {
/* 143 */     if (this.logger.isDebugEnabled()) {
/* 144 */       this.logger.debug("Executing SQL batch update [" + sql + "]");
/*     */     }
/*     */ 
/* 147 */     return ((int[])execute(sql, new PreparedStatementCallback(pss)
/*     */     {
/*     */       public Object doInPreparedStatement(PreparedStatement ps)
/*     */         throws SQLException
/*     */       {
/*     */         try
/*     */         {
/*     */           int[] arrayOfInt1;
/* 150 */           int batchSize = this.val$pss.getBatchSize();
/* 151 */           InterruptibleBatchPreparedStatementSetter ipss = 
/* 152 */             (this.val$pss instanceof InterruptibleBatchPreparedStatementSetter) ? 
/* 153 */             (InterruptibleBatchPreparedStatementSetter)this.val$pss : null;
/* 154 */           if (JdbcUtils.supportsBatchUpdates(ps.getConnection())) {
/* 155 */             for (int i = 0; i < batchSize; ++i) {
/* 156 */               this.val$pss.setValues(ps, i);
/* 157 */               if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*     */                 break;
/*     */               }
/* 160 */               ps.addBatch();
/*     */             }
/* 162 */             arrayOfInt1 = ps.executeBatch();
/*     */             return arrayOfInt1;
/*     */           }
/*     */ 
/* 165 */           List rowsAffected = new ArrayList();
/* 166 */           for (int i = 0; i < batchSize; ++i) {
/* 167 */             this.val$pss.setValues(ps, i);
/* 168 */             if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*     */               break;
/*     */             }
/* 171 */             rowsAffected.add(new Integer(ps.executeUpdate()));
/*     */           }
/* 173 */           int[] rowsAffectedArray = new int[rowsAffected.size()];
/* 174 */           for (int i = 0; i < rowsAffectedArray.length; ++i) {
/* 175 */             rowsAffectedArray[i] = ((Integer)rowsAffected.get(i)).intValue();
/*     */           }
/* 177 */           return rowsAffectedArray;
/*     */         }
/*     */         finally
/*     */         {
/* 181 */           if (this.val$pss instanceof ParameterDisposer)
/* 182 */             ((ParameterDisposer)this.val$pss).cleanupParameters();
/*     */         }
/*     */       }
/*     */     }
/*     */     , additiveSql));
/*     */   }
/*     */ 
/*     */   private static String getSql(Object sqlProvider) {
/* 190 */     if (sqlProvider instanceof SqlProvider) {
/* 191 */       return ((SqlProvider)sqlProvider).getSql();
/*     */     }
/*     */ 
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */   private static class SimplePreparedStatementCreator
/*     */     implements PreparedStatementCreator, SqlProvider
/*     */   {
/*     */     private final String sql;
/*     */ 
/*     */     public SimplePreparedStatementCreator(String sql)
/*     */     {
/* 206 */       Assert.notNull(sql, "SQL must not be null");
/* 207 */       this.sql = sql;
/*     */     }
/*     */ 
/*     */     public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/* 211 */       return con.prepareStatement(this.sql);
/*     */     }
/*     */ 
/*     */     public String getSql() {
/* 215 */       return this.sql;
/*     */     }
/*     */   }
/*     */ }