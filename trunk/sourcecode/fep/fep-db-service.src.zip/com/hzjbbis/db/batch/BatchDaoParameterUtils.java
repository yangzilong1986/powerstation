/*    */ package com.hzjbbis.db.batch;
/*    */ 
/*    */ import com.hzjbbis.db.batch.dao.IBatchDao;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BatchDaoParameterUtils
/*    */ {
/*    */   private static BatchDaoParameterUtils instance;
/* 17 */   private List<IBatchDao> batchDaoList = new ArrayList();
/*    */   private Object additiveParameter;
/*    */ 
/*    */   private BatchDaoParameterUtils()
/*    */   {
/* 21 */     instance = this;
/*    */   }
/*    */ 
/*    */   public static BatchDaoParameterUtils getInstance() {
/* 25 */     if (instance == null)
/* 26 */       instance = new BatchDaoParameterUtils();
/* 27 */     return instance;
/*    */   }
/*    */ 
/*    */   public void setBatchDaoList(List<IBatchDao> batchDaoList) {
/* 31 */     this.batchDaoList = batchDaoList;
/* 32 */     if (this.additiveParameter != null)
/* 33 */       for (IBatchDao dao : batchDaoList)
/* 34 */         dao.setAdditiveParameter(this.additiveParameter);
/*    */   }
/*    */ 
/*    */   public void setAdditiveParameter(Object additiveParameter)
/*    */   {
/* 39 */     this.additiveParameter = additiveParameter;
/* 40 */     for (IBatchDao dao : this.batchDaoList)
/* 41 */       dao.setAdditiveParameter(additiveParameter);
/*    */   }
/*    */ }