/*     */ package com.hzjbbis.db.batch.dao.jdbc.springwrap;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class NamedParameterUtils2
/*     */ {
/*  25 */   private static final char[] PARAMETER_SEPARATORS = { '"', '\'', ':', '&', ',', ';', '(', ')', '|', '=', '+', '-', '*', '%', '/', '\\', '<', '>', '^' };
/*     */ 
/*     */   public static ParsedSql2 parseSqlStatement(String sql) {
/*  28 */     Assert.notNull(sql, "SQL must not be null");
/*     */ 
/*  30 */     Set namedParameters = new HashSet();
/*  31 */     ParsedSql2 parsedSql = new ParsedSql2(sql);
/*     */ 
/*  33 */     char[] statement = sql.toCharArray();
/*  34 */     boolean withinQuotes = false;
/*  35 */     char currentQuote = '-';
/*  36 */     int namedParameterCount = 0;
/*  37 */     int unnamedParameterCount = 0;
/*  38 */     int totalParameterCount = 0;
/*     */ 
/*  40 */     int i = 0;
/*  41 */     while (i < statement.length) {
/*  42 */       char c = statement[i];
/*  43 */       if (withinQuotes) {
/*  44 */         if (c == currentQuote) {
/*  45 */           withinQuotes = false;
/*  46 */           currentQuote = '-';
/*     */         }
/*     */ 
/*     */       }
/*  50 */       else if ((c == '"') || (c == '\'')) {
/*  51 */         withinQuotes = true;
/*  52 */         currentQuote = c;
/*     */       }
/*  55 */       else if ((c == ':') || (c == '&')) {
/*  56 */         int j = i + 1;
/*  57 */         if ((j < statement.length) && (statement[j] == ':') && (c == ':'))
/*     */         {
/*  59 */           i += 2;
/*  60 */           continue;
/*     */         }
/*     */         do
/*  63 */           ++j;
/*  62 */         while ((j < statement.length) && (!(isParameterSeparator(statement[j]))));
/*     */ 
/*  65 */         if (j - i > 1) {
/*  66 */           String parameter = sql.substring(i + 1, j);
/*  67 */           if (!(namedParameters.contains(parameter))) {
/*  68 */             namedParameters.add(parameter);
/*  69 */             ++namedParameterCount;
/*     */           }
/*  71 */           parsedSql.addNamedParameter(parameter, i, j);
/*  72 */           ++totalParameterCount;
/*     */         }
/*  74 */         i = j - 1;
/*     */       }
/*  77 */       else if (c == '?') {
/*  78 */         ++unnamedParameterCount;
/*  79 */         ++totalParameterCount;
/*     */       }
/*     */ 
/*  84 */       ++i;
/*     */     }
/*  86 */     parsedSql.setNamedParameterCount(namedParameterCount);
/*  87 */     parsedSql.setUnnamedParameterCount(unnamedParameterCount);
/*  88 */     parsedSql.setTotalParameterCount(totalParameterCount);
/*  89 */     return parsedSql;
/*     */   }
/*     */ 
/*     */   private static boolean isParameterSeparator(char c)
/*     */   {
/*  97 */     if (Character.isWhitespace(c)) {
/*  98 */       return true;
/*     */     }
/* 100 */     for (int i = 0; i < PARAMETER_SEPARATORS.length; ++i) {
/* 101 */       if (c == PARAMETER_SEPARATORS[i]) {
/* 102 */         return true;
/*     */       }
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public static String substituteNamedParameters(String sql, SqlParameterSource paramSource) {
/* 109 */     ParsedSql2 parsedSql = parseSqlStatement(sql);
/* 110 */     return substituteNamedParameters(parsedSql, paramSource);
/*     */   }
/*     */ 
/*     */   public static String substituteNamedParameters(ParsedSql2 parsedSql, SqlParameterSource paramSource)
/*     */   {
/* 115 */     String originalSql = parsedSql.getOriginalSql();
/* 116 */     StringBuffer actualSql = new StringBuffer();
/* 117 */     List paramNames = parsedSql.getParameterNames();
/* 118 */     int lastIndex = 0;
/* 119 */     for (int i = 0; i < paramNames.size(); ++i) {
/* 120 */       String paramName = (String)paramNames.get(i);
/* 121 */       int[] indexes = parsedSql.getParameterIndexes(i);
/* 122 */       int startIndex = indexes[0];
/* 123 */       int endIndex = indexes[1];
/* 124 */       actualSql.append(originalSql.substring(lastIndex, startIndex));
/* 125 */       Object value = paramSource.getValue(paramName);
/* 126 */       if (value instanceof Collection) {
/* 127 */         Iterator entryIter = ((Collection)value).iterator();
/* 128 */         int k = 0;
/* 129 */         while (entryIter.hasNext()) {
/* 130 */           if (k > 0) {
/* 131 */             actualSql.append(", ");
/*     */           }
/* 133 */           ++k;
/* 134 */           Object entryItem = entryIter.next();
/* 135 */           if (entryItem instanceof Object[]) {
/* 136 */             Object[] expressionList = (Object[])entryItem;
/* 137 */             actualSql.append("(");
/* 138 */             for (int m = 0; m < expressionList.length; ++m) {
/* 139 */               if (m > 0) {
/* 140 */                 actualSql.append(", ");
/*     */               }
/*     */ 
/* 143 */               actualSql.append(expressionList[m].toString());
/*     */             }
/* 145 */             actualSql.append(")");
/*     */           }
/*     */           else
/*     */           {
/* 149 */             actualSql.append(entryItem.toString());
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 155 */         actualSql.append(value.toString());
/*     */       }
/* 157 */       lastIndex = endIndex;
/*     */     }
/* 159 */     actualSql.append(originalSql.substring(lastIndex, originalSql.length()));
/* 160 */     return actualSql.toString();
/*     */   }
/*     */ }