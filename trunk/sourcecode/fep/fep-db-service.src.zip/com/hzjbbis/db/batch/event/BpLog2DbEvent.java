/*    */ package com.hzjbbis.db.batch.event;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class BpLog2DbEvent
/*    */   implements IEvent
/*    */ {
/*  9 */   private static final EventType type = EventType.BP_LOG_DB;
/*    */   private IMessage message;
/*    */   private AsyncService service;
/*    */ 
/*    */   public BpLog2DbEvent(AsyncService service, IMessage msg)
/*    */   {
/* 14 */     this.service = service;
/* 15 */     this.message = msg;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 19 */     return this.message;
/*    */   }
/*    */ 
/*    */   public AsyncService getService() {
/* 23 */     return this.service;
/*    */   }
/*    */ 
/*    */   public AsyncService getSource() {
/* 27 */     return this.service;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 31 */     return type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src)
/*    */   {
/*    */   }
/*    */ }