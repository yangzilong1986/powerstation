/*     */ package com.hzjbbis.db.batch.dao.jdbc.springwrap;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ParsedSql2
/*     */ {
/*     */   private String originalSql;
/*  12 */   private List<String> parameterNames = new ArrayList();
/*     */ 
/*  14 */   private List<int[]> parameterIndexes = new ArrayList();
/*     */   private int namedParameterCount;
/*     */   private int unnamedParameterCount;
/*     */   private int totalParameterCount;
/*     */ 
/*     */   ParsedSql2(String originalSql)
/*     */   {
/*  28 */     this.originalSql = originalSql;
/*     */   }
/*     */ 
/*     */   String getOriginalSql()
/*     */   {
/*  35 */     return this.originalSql;
/*     */   }
/*     */ 
/*     */   void addNamedParameter(String parameterName, int startIndex, int endIndex)
/*     */   {
/*  46 */     this.parameterNames.add(parameterName);
/*  47 */     this.parameterIndexes.add(new int[] { startIndex, endIndex });
/*     */   }
/*     */ 
/*     */   List<String> getParameterNames()
/*     */   {
/*  55 */     return this.parameterNames;
/*     */   }
/*     */ 
/*     */   int[] getParameterIndexes(int parameterPosition)
/*     */   {
/*  66 */     return ((int[])this.parameterIndexes.get(parameterPosition));
/*     */   }
/*     */ 
/*     */   void setNamedParameterCount(int namedParameterCount)
/*     */   {
/*  74 */     this.namedParameterCount = namedParameterCount;
/*     */   }
/*     */ 
/*     */   int getNamedParameterCount()
/*     */   {
/*  82 */     return this.namedParameterCount;
/*     */   }
/*     */ 
/*     */   void setUnnamedParameterCount(int unnamedParameterCount)
/*     */   {
/*  89 */     this.unnamedParameterCount = unnamedParameterCount;
/*     */   }
/*     */ 
/*     */   int getUnnamedParameterCount()
/*     */   {
/*  96 */     return this.unnamedParameterCount;
/*     */   }
/*     */ 
/*     */   void setTotalParameterCount(int totalParameterCount)
/*     */   {
/* 104 */     this.totalParameterCount = totalParameterCount;
/*     */   }
/*     */ 
/*     */   int getTotalParameterCount()
/*     */   {
/* 112 */     return this.totalParameterCount;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 120 */     return this.originalSql;
/*     */   }
/*     */ }