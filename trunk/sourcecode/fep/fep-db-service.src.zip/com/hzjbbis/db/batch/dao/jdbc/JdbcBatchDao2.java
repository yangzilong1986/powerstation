/*     */ package com.hzjbbis.db.batch.dao.jdbc;
/*     */ 
/*     */ import com.hzjbbis.db.DbMonitor;
/*     */ import com.hzjbbis.db.batch.dao.IBatchDao;
/*     */ import com.hzjbbis.db.batch.dao.jdbc.springwrap.NamedParameterUtils2;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ 
/*     */ public class JdbcBatchDao2
/*     */   implements IBatchDao
/*     */ {
/*  31 */   private static final Logger log = Logger.getLogger(JdbcBatchDao2.class);
/*  32 */   private static final TraceLog tracer = TraceLog.getTracer("jdbcBatchdao2");
/*     */   private BatchSimpleJdbcTemplate simpleJdbcTemplate;
/*     */   private DataSource dataSource;
/*     */   private String sql;
/*     */   private String sqlAlt;
/*     */   private String additiveSql;
/*     */   private Object additiveParameter;
/*     */   private int key;
/*  39 */   private int batchSize = 2000;
/*  40 */   private long delay = 5000L;
/*     */ 
/*  42 */   private List<Object> objList = new ArrayList();
/*  43 */   private List<Object[]> paramArrayList = new ArrayList();
/*  44 */   private Object batchDaoLock = new Object();
/*  45 */   private long lastIoTime = System.currentTimeMillis();
/*  46 */   private String executeThreadName = null;
/*  47 */   private boolean executing = false;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource) {
/*  50 */     this.dataSource = dataSource;
/*  51 */     this.simpleJdbcTemplate = new BatchSimpleJdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   private int[] batchUpdateByPojo(String sqlStr, List<Object> pojoList)
/*     */   {
/*     */     int[] updateCounts;
/*  55 */     SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(pojoList.toArray());
/*     */ 
/*  57 */     if (this.additiveSql != null)
/*  58 */       if (this.additiveParameter != null) {
/*  59 */         SqlParameterSource sqlParaSource = new BeanPropertySqlParameterSource(this.additiveParameter);
/*  60 */         String sqlToUse = NamedParameterUtils2.substituteNamedParameters(this.additiveSql, sqlParaSource);
/*  61 */         updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, batch, sqlToUse);
/*     */       }
/*     */       else {
/*  64 */         updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, batch, this.additiveSql);
/*     */       }
/*     */     else
/*  67 */       updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, batch);
/*  68 */     return updateCounts;
/*     */   }
/*     */ 
/*     */   private int[] batchUpdateByParams(String sqlStr, List<Object[]> arrayList)
/*     */   {
/*     */     int[] updateCounts;
/*  73 */     if (this.additiveSql != null)
/*  74 */       updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, arrayList, this.additiveSql);
/*     */     else
/*  76 */       updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, arrayList);
/*  77 */     return updateCounts;
/*     */   }
/*     */ 
/*     */   private void _doBatchUpdate()
/*     */   {
/*     */     long timeTake;
/*  81 */     if (log.isDebugEnabled())
/*  82 */       log.debug("开始执行Dao，key=" + this.key + ",sql=" + this.sql);
/*  83 */     int[] result = (int[])null;
/*  84 */     long time0 = System.currentTimeMillis();
/*  85 */     if (this.objList.size() > 0) {
/*  86 */       result = batchUpdateByPojo(this.sql, this.objList);
/*  87 */       if (log.isInfoEnabled())
/*     */       {
/*  93 */         timeTake = System.currentTimeMillis() - time0;
/*  94 */         if (timeTake > 1000L)
/*  95 */           log.info("key=" + this.key + ",成功条数=" + result.length + ",花费毫秒=" + timeTake);
/*  96 */         tracer.trace("batchUpdate takes(milliseconds):" + timeTake);
/*     */       }
/*     */ 
/* 109 */       this.lastIoTime = System.currentTimeMillis();
/*     */     }
/* 111 */     else if (this.paramArrayList.size() > 0) {
/* 112 */       result = batchUpdateByParams(this.sql, this.paramArrayList);
/* 113 */       if (log.isInfoEnabled()) {
/* 114 */         timeTake = System.currentTimeMillis() - time0;
/* 115 */         if (timeTake > 1000L)
/* 116 */           log.info("key=" + this.key + ",成功条数=" + result.length + ",花费毫秒=" + timeTake);
/* 117 */         tracer.trace("batchUpdate takes(milliseconds):" + timeTake);
/*     */       }
/* 119 */       this.lastIoTime = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void batchUpdate() {
/* 124 */     if (this.executing)
/* 125 */       return;
/* 126 */     synchronized (this.batchDaoLock) {
/* 127 */       DbMonitor dm = DbMonitor.getMonitor(this.dataSource);
/* 128 */       if ((dm != null) && (!(dm.isAvailable())))
/* 129 */         return;
/* 130 */       if (this.executeThreadName != null) {
/* 131 */         log.error("BatchDao2[key=" + this.key + "] has already been executed by : " + this.executeThreadName);
/*     */       }
/* 133 */       this.executeThreadName = Thread.currentThread().getName();
/*     */       try
/*     */       {
/* 137 */         this.executing = true;
/* 138 */         _doBatchUpdate();
/*     */       }
/*     */       catch (CannotGetJdbcConnectionException e)
/*     */       {
/* 143 */         if (dm != null)
/* 144 */           dm.setAvailable(false);
/*     */       }
/*     */       catch (BadSqlGrammarException e) {
/* 147 */         tracer.trace(e.getLocalizedMessage(), e);
/*     */       }
/*     */       catch (Exception e) {
/* 150 */         tracer.trace("batch dao exception:" + e.getLocalizedMessage(), e);
/* 151 */         log.warn("batch dao exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 154 */         this.executing = false;
/*     */ 
/* 156 */         this.objList.clear();
/* 157 */         this.paramArrayList.clear();
/*     */       }
/*     */ 
/* 160 */       this.executeThreadName = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getKey() {
/* 165 */     return this.key;
/*     */   }
/*     */ 
/*     */   public void setKey(int k) {
/* 169 */     this.key = k;
/*     */   }
/*     */ 
/*     */   public boolean add(Object pojo) {
/* 173 */     if (pojo != null) {
/* 174 */       synchronized (this.batchDaoLock) {
/* 175 */         int above = size() - this.batchSize;
/* 176 */         if ((above > this.batchSize) || (above > 3000)) {
/* 177 */           tracer.trace("batchDao can not add object,size=" + size() + ",batchSize=" + this.batchSize);
/* 178 */           return false;
/*     */         }
/* 180 */         this.objList.add(pojo);
/*     */       }
/* 182 */       if (size() >= this.batchSize)
/* 183 */         batchUpdate();
/*     */     }
/*     */     else {
/* 186 */       delayExec();
/*     */     }
/* 188 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean add(Object[] params)
/*     */   {
/* 195 */     if (params != null) {
/* 196 */       synchronized (this.batchDaoLock) {
/* 197 */         int above = size() - this.batchSize;
/* 198 */         if ((above > this.batchSize) || (above > 3000)) {
/* 199 */           tracer.trace("batchDao can not add object,size=" + size() + ",batchSize=" + this.batchSize);
/* 200 */           return false;
/*     */         }
/* 202 */         this.paramArrayList.add(params);
/*     */       }
/* 204 */       if (size() >= this.batchSize)
/* 205 */         batchUpdate();
/*     */     }
/*     */     else {
/* 208 */       delayExec();
/*     */     }
/* 210 */     return true;
/*     */   }
/*     */ 
/*     */   public void setSql(String sql) {
/* 214 */     this.sql = sql.trim();
/*     */   }
/*     */ 
/*     */   public void setSqlAlt(String sqlAlt) {
/* 218 */     this.sqlAlt = sqlAlt.trim();
/*     */   }
/*     */ 
/*     */   public void setAdditiveSql(String adSql) {
/* 222 */     adSql = StringUtils.strip(adSql);
/* 223 */     adSql = StringUtils.remove(adSql, '\t');
/* 224 */     adSql = StringUtils.replaceChars(adSql, '\n', ' ');
/* 225 */     this.additiveSql = adSql;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 229 */     return Math.max(this.objList.size(), this.paramArrayList.size());
/*     */   }
/*     */ 
/*     */   public void setBatchSize(int batchSize) {
/* 233 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */   public long getLastIoTime() {
/* 237 */     return this.lastIoTime;
/*     */   }
/*     */ 
/*     */   public void setDelaySecond(int delaySec) {
/* 241 */     this.delay = (delaySec * 1000);
/*     */   }
/*     */ 
/*     */   public long getDelayMilliSeconds() {
/* 245 */     return this.delay;
/*     */   }
/*     */ 
/*     */   public boolean hasDelayData() {
/* 249 */     DbMonitor dm = DbMonitor.getMonitor(this.dataSource);
/* 250 */     boolean result = (System.currentTimeMillis() - this.lastIoTime >= this.delay) && (size() > 0);
/* 251 */     if (dm != null)
/* 252 */       result = (result) && (dm.isAvailable());
/* 253 */     return result;
/*     */   }
/*     */ 
/*     */   private void delayExec() {
/* 257 */     if (hasDelayData())
/* 258 */       batchUpdate();
/*     */   }
/*     */ 
/*     */   public void setAdditiveParameter(Object additiveParameter)
/*     */   {
/* 263 */     this.additiveParameter = additiveParameter;
/*     */   }
/*     */ }