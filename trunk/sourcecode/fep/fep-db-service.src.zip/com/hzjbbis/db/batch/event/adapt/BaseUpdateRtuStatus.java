/*    */ package com.hzjbbis.db.batch.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.db.batch.BaseBpEventHandler;
/*    */ import com.hzjbbis.db.batch.event.FeUpdateRtuStatus;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ 
/*    */ public class BaseUpdateRtuStatus extends BaseBpEventHandler
/*    */ {
/*    */   private static final EventType type;
/*    */ 
/*    */   static
/*    */   {
/*  9 */     type = EventType.FE_RTU_CHANNEL;
/*    */   }
/*    */ 
/*    */   public void handleEvent(IEvent event) {
/* 13 */     if ((!($assertionsDisabled)) && (event.getType() != type)) throw new AssertionError();
/* 14 */     FeUpdateRtuStatus ev = (FeUpdateRtuStatus)event;
/* 15 */     this.service.addToDao(ev.getRtu(), this.key);
/*    */   }
/*    */ 
/*    */   public EventType type()
/*    */   {
/* 20 */     return type;
/*    */   }
/*    */ }