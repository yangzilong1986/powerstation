/*    */ package com.hzjbbis.db.batch.event;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class FeUpdateRtuStatus
/*    */   implements IEvent
/*    */ {
/* 14 */   private static final EventType type = EventType.FE_RTU_CHANNEL;
/*    */   private AsyncService service;
/*    */   private Object rtu;
/*    */ 
/*    */   public FeUpdateRtuStatus(AsyncService service, Object rtu)
/*    */   {
/* 19 */     this.service = service;
/* 20 */     this.rtu = rtu;
/*    */   }
/*    */ 
/*    */   public AsyncService getService() {
/* 24 */     return this.service;
/*    */   }
/*    */ 
/*    */   public Object getRtu() {
/* 28 */     return this.rtu;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   public AsyncService getSource() {
/* 36 */     return this.service;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 40 */     return type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src)
/*    */   {
/*    */   }
/*    */ }