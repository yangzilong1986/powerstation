/*    */ package com.hzjbbis.db.batch.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.db.batch.BaseBpEventHandler;
/*    */ import com.hzjbbis.db.batch.event.BpExpAlarmEvent;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class BaseExpAlarmHandler extends BaseBpEventHandler
/*    */ {
/*    */   protected static final EventType type;
/*    */ 
/*    */   static
/*    */   {
/* 11 */     type = EventType.BP_EXP_ALARM; }
/*    */ 
/*    */   public EventType type() {
/* 14 */     return type;
/*    */   }
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 19 */     if ((!($assertionsDisabled)) && (event.getType() != type)) throw new AssertionError();
/* 20 */     BpExpAlarmEvent e = (BpExpAlarmEvent)event;
/* 21 */     handleExpAlarm(e.getService(), e.getMessage());
/*    */   }
/*    */ 
/*    */   public void handleExpAlarm(AsyncService service, IMessage msg)
/*    */   {
/*    */   }
/*    */ }