/*    */ package com.hzjbbis.db.batch.event;
/*    */ 
/*    */ import com.hzjbbis.db.batch.AsyncService;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class BpReadTaskEvent
/*    */   implements IEvent
/*    */ {
/* 16 */   private static final EventType type = EventType.BP_READ_TASK;
/*    */   private IMessage message;
/*    */   private AsyncService service;
/*    */ 
/*    */   public BpReadTaskEvent(AsyncService service, IMessage msg)
/*    */   {
/* 21 */     this.service = service;
/* 22 */     this.message = msg;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 26 */     return this.message;
/*    */   }
/*    */ 
/*    */   public AsyncService getService() {
/* 30 */     return this.service;
/*    */   }
/*    */ 
/*    */   public AsyncService getSource() {
/* 34 */     return this.service;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 38 */     return type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src)
/*    */   {
/*    */   }
/*    */ }