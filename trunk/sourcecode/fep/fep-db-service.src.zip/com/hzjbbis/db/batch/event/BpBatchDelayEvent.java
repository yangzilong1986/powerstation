/*    */ package com.hzjbbis.db.batch.event;
/*    */ 
/*    */ import com.hzjbbis.db.batch.dao.IBatchDao;
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class BpBatchDelayEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private static final EventType type = EventType.BP_BATCH_DELAY;
/*    */   private IBatchDao dao;
/*    */ 
/*    */   public BpBatchDelayEvent(IBatchDao dao)
/*    */   {
/* 21 */     this.dao = dao;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 25 */     return null;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 33 */     return type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public IBatchDao getDao() {
/* 40 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IBatchDao dao) {
/* 44 */     this.dao = dao;
/*    */   }
/*    */ }