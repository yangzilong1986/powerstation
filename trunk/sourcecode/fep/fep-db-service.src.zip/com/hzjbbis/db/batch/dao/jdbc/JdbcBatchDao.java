/*     */ package com.hzjbbis.db.batch.dao.jdbc;
/*     */ 
/*     */ import com.hzjbbis.db.DbMonitor;
/*     */ import com.hzjbbis.db.batch.dao.IBatchDao;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*     */ 
/*     */ public class JdbcBatchDao
/*     */   implements IBatchDao
/*     */ {
/*  29 */   private static final Logger log = Logger.getLogger(JdbcBatchDao.class);
/*     */ 
/*  31 */   private static final TraceLog tracer = TraceLog.getTracer("jdbcBatchdao");
/*     */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*     */   private DataSource dataSource;
/*     */   private String sql;
/*     */   private String sqlAlt;
/*     */   private String additiveSql;
/*     */   private Object additiveParameter;
/*  37 */   private int key = 0;
/*  38 */   private int batchSize = 2000;
/*  39 */   private long delay = 5000L;
/*     */ 
/*  41 */   private List<Object> objList = new ArrayList();
/*  42 */   private List<Object[]> paramArrayList = new ArrayList();
/*  43 */   private Object batchDaoLock = new Object();
/*  44 */   private long lastIoTime = System.currentTimeMillis();
/*  45 */   private String executeThreadName = null;
/*  46 */   private boolean executing = false;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource) {
/*  49 */     this.dataSource = dataSource;
/*  50 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(this.dataSource);
/*     */   }
/*     */ 
/*     */   private int[] batchUpdateByPojo(String sqlStr, List<Object> pojoList) {
/*  54 */     SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(pojoList.toArray());
/*  55 */     int[] updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, batch);
/*  56 */     if (this.additiveSql != null)
/*  57 */       this.simpleJdbcTemplate.update(this.additiveSql, new Object[0]);
/*  58 */     return updateCounts;
/*     */   }
/*     */ 
/*     */   private int[] batchUpdateByParams(String sqlStr, List<Object[]> arrayList) {
/*  62 */     int[] updateCounts = this.simpleJdbcTemplate.batchUpdate(sqlStr, arrayList);
/*  63 */     if (this.additiveSql != null)
/*  64 */       this.simpleJdbcTemplate.update(this.additiveSql, new Object[0]);
/*  65 */     return updateCounts;
/*     */   }
/*     */ 
/*     */   private void _doBatchUpdate()
/*     */   {
/*     */     long timeTake;
/*     */     List listAlt;
/*     */     int i;
/*  69 */     if (log.isDebugEnabled())
/*  70 */       log.debug("开始执行Dao，key=" + this.key + ",sql=" + this.sql);
/*  71 */     int[] result = (int[])null;
/*  72 */     long time0 = System.currentTimeMillis();
/*  73 */     if (this.objList.size() > 0) {
/*  74 */       result = batchUpdateByPojo(this.sql, this.objList);
/*  75 */       timeTake = System.currentTimeMillis() - time0;
/*  76 */       if (timeTake > 1000L)
/*  77 */         tracer.trace("batchUpdate takes(milliseconds):" + timeTake);
/*  78 */       if (log.isDebugEnabled()) {
/*  79 */         log.debug("key=" + this.key + ",成功条数=" + result.length + ",花费毫秒=" + timeTake);
/*     */       }
/*  81 */       if (this.sqlAlt != null) {
/*  82 */         listAlt = new ArrayList();
/*  83 */         for (i = 0; i < result.length; ++i) {
/*  84 */           if (result[i] <= 0) {
/*  85 */             listAlt.add(this.objList.get(i));
/*     */           }
/*     */         }
/*  88 */         if (listAlt.size() > 0)
/*  89 */           batchUpdateByPojo(this.sqlAlt, listAlt);
/*     */       }
/*  91 */       this.lastIoTime = System.currentTimeMillis();
/*     */     }
/*  93 */     else if (this.paramArrayList.size() > 0) {
/*  94 */       result = batchUpdateByParams(this.sql, this.paramArrayList);
/*  95 */       timeTake = System.currentTimeMillis() - time0;
/*  96 */       if (log.isDebugEnabled()) {
/*  97 */         log.debug("key=" + this.key + ",成功条数=" + result.length + ",花费毫秒=" + timeTake);
/*     */       }
/*  99 */       if (this.sqlAlt != null) {
/* 100 */         listAlt = new ArrayList();
/* 101 */         for (i = 0; i < result.length; ++i) {
/* 102 */           if (result[i] <= 0) {
/* 103 */             listAlt.add((Object[])this.paramArrayList.get(i));
/*     */           }
/*     */         }
/* 106 */         if (listAlt.size() > 0)
/* 107 */           batchUpdateByParams(this.sqlAlt, listAlt);
/*     */       }
/* 109 */       this.lastIoTime = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void batchUpdate() {
/* 114 */     if (this.executing)
/* 115 */       return;
/* 116 */     synchronized (this.batchDaoLock)
/*     */     {
/* 118 */       DbMonitor dm = DbMonitor.getMonitor(this.dataSource);
/* 119 */       if ((dm != null) && (!(dm.isAvailable())))
/* 120 */         return;
/* 121 */       if (this.executeThreadName != null) {
/* 122 */         log.error("BatchDao[key=" + this.key + "] has already been executed by : " + this.executeThreadName);
/*     */       }
/* 124 */       this.executeThreadName = Thread.currentThread().getName();
/*     */       try
/*     */       {
/* 128 */         this.executing = true;
/* 129 */         _doBatchUpdate();
/*     */       }
/*     */       catch (CannotGetJdbcConnectionException e)
/*     */       {
/* 134 */         if (dm != null)
/* 135 */           dm.setAvailable(false);
/*     */       }
/*     */       catch (BadSqlGrammarException e)
/*     */       {
/* 139 */         tracer.trace(e.getLocalizedMessage(), e);
/*     */       }
/*     */       catch (Exception e) {
/* 142 */         tracer.trace("batch dao exception:" + e.getLocalizedMessage(), e);
/* 143 */         log.warn("batch dao exception:" + e.getLocalizedMessage(), e);
/*     */       }
/*     */       finally {
/* 146 */         this.executing = false;
/*     */ 
/* 148 */         this.objList.clear();
/* 149 */         this.paramArrayList.clear();
/*     */       }
/*     */ 
/* 152 */       this.executeThreadName = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getKey() {
/* 157 */     return this.key;
/*     */   }
/*     */ 
/*     */   public void setKey(int k) {
/* 161 */     this.key = k;
/*     */   }
/*     */ 
/*     */   public boolean add(Object pojo) {
/* 165 */     if (pojo != null) {
/* 166 */       synchronized (this.batchDaoLock) {
/* 167 */         int above = size() - this.batchSize;
/* 168 */         if ((above > this.batchSize) || (above > 3000)) {
/* 169 */           tracer.trace("batchDao can not add object,size=" + size() + ",batchSize=" + this.batchSize);
/* 170 */           return false;
/*     */         }
/* 172 */         this.objList.add(pojo);
/*     */       }
/* 174 */       if (size() >= this.batchSize)
/* 175 */         batchUpdate();
/*     */     }
/*     */     else {
/* 178 */       delayExec();
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean add(Object[] params)
/*     */   {
/* 187 */     if (params != null) {
/* 188 */       synchronized (this.batchDaoLock) {
/* 189 */         int above = size() - this.batchSize;
/* 190 */         if ((above > this.batchSize) || (above > 3000)) {
/* 191 */           tracer.trace("batchDao can not add object,size=" + size() + ",batchSize=" + this.batchSize);
/* 192 */           return false;
/*     */         }
/* 194 */         this.paramArrayList.add(params);
/*     */       }
/* 196 */       if (size() >= this.batchSize)
/* 197 */         batchUpdate();
/*     */     }
/*     */     else {
/* 200 */       delayExec();
/*     */     }
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   public void setSql(String sql) {
/* 206 */     this.sql = sql.trim();
/*     */   }
/*     */ 
/*     */   public void setSqlAlt(String sqlAlt) {
/* 210 */     this.sqlAlt = sqlAlt.trim();
/*     */   }
/*     */ 
/*     */   public void setAdditiveSql(String adSql) {
/* 214 */     this.additiveSql = adSql;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 218 */     return Math.max(this.objList.size(), this.paramArrayList.size());
/*     */   }
/*     */ 
/*     */   public void setBatchSize(int batchSize) {
/* 222 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */   public long getLastIoTime() {
/* 226 */     return this.lastIoTime;
/*     */   }
/*     */ 
/*     */   public void setDelaySecond(int delaySec) {
/* 230 */     this.delay = (delaySec * 1000);
/*     */   }
/*     */ 
/*     */   public long getDelayMilliSeconds() {
/* 234 */     return this.delay;
/*     */   }
/*     */ 
/*     */   public boolean hasDelayData() {
/* 238 */     DbMonitor dm = DbMonitor.getMonitor(this.dataSource);
/* 239 */     boolean result = (System.currentTimeMillis() - this.lastIoTime >= this.delay) && (size() > 0);
/* 240 */     if (dm != null)
/* 241 */       result = (result) && (dm.isAvailable());
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   private void delayExec() {
/* 246 */     if (hasDelayData())
/* 247 */       batchUpdate();
/*     */   }
/*     */ 
/*     */   public void setAdditiveParameter(Object additiveParameter)
/*     */   {
/* 252 */     this.additiveParameter = additiveParameter;
/*     */   }
/*     */ 
/*     */   public Object getAdditiveParameter() {
/* 256 */     return this.additiveParameter;
/*     */   }
/*     */ }