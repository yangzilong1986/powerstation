/*    */ package com.hzjbbis.db.procedure;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Time;
/*    */ import java.sql.Timestamp;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ 
/*    */ public class ProcParam
/*    */ {
/*    */   public static final int MODE_IN = 0;
/*    */   public static final int MODE_OUT = 1;
/*    */   public static final int MODE_INOUT = 2;
/* 25 */   private static final Map<String, Integer> typeMap = new HashMap();
/*    */   private String pname;
/* 44 */   private int jdbcType = 12;
/*    */   private int index;
/* 46 */   private int mode = 0;
/*    */ 
/*    */   static
/*    */   {
/* 27 */     typeMap.put("CHAR", Integer.valueOf(1));
/* 28 */     typeMap.put("NUMERIC", Integer.valueOf(2));
/* 29 */     typeMap.put("DECIMAL", Integer.valueOf(3));
/* 30 */     typeMap.put("INTEGER", Integer.valueOf(4));
/* 31 */     typeMap.put("SMALLINT", Integer.valueOf(5));
/* 32 */     typeMap.put("FLOAT", Integer.valueOf(6));
/* 33 */     typeMap.put("REAL", Integer.valueOf(7));
/* 34 */     typeMap.put("DOUBLE", Integer.valueOf(8));
/* 35 */     typeMap.put("VARCHAR", Integer.valueOf(12));
/* 36 */     typeMap.put("TINYINT", Integer.valueOf(-6));
/* 37 */     typeMap.put("BIGINT", Integer.valueOf(-5));
/* 38 */     typeMap.put("DATE", Integer.valueOf(91));
/* 39 */     typeMap.put("TIME", Integer.valueOf(92));
/* 40 */     typeMap.put("TIMESTAMP", Integer.valueOf(93));
/* 41 */     typeMap.put("BOOLEAN", Integer.valueOf(16));
/*    */   }
/*    */ 
/*    */   public ProcParam(String paramName, String jtype, String pmode, int index)
/*    */   {
/* 49 */     this.pname = paramName;
/* 50 */     Integer t = (Integer)typeMap.get(jtype.toUpperCase());
/* 51 */     if (t != null)
/* 52 */       this.jdbcType = t.intValue();
/* 53 */     pmode = pmode.toUpperCase();
/* 54 */     if (pmode.equals("IN"))
/* 55 */       this.mode = 0;
/* 56 */     else if (pmode.equals("OUT"))
/* 57 */       this.mode = 1;
/* 58 */     else if (pmode.equals("INOUT"))
/* 59 */       this.mode = 2;
/* 60 */     this.index = index;
/*    */   }
/*    */ 
/*    */   public String getParamName() {
/* 64 */     return this.pname;
/*    */   }
/*    */ 
/*    */   public int getJdbcType() {
/* 68 */     return this.jdbcType;
/*    */   }
/*    */ 
/*    */   public int getParamIndex() {
/* 72 */     return this.index;
/*    */   }
/*    */ 
/*    */   public void setParamIndex(int i) {
/* 76 */     this.index = i;
/*    */   }
/*    */ 
/*    */   public int getParamMode() {
/* 80 */     return this.mode;
/*    */   }
/*    */ 
/*    */   public void setInputValueByBean(CallableStatement stmt, Object bean) throws SQLException {
/*    */     try {
/* 85 */       Object pval = PropertyUtils.getProperty(bean, this.pname);
/* 86 */       setInputValue(stmt, pval);
/*    */     } catch (Exception e) {
/* 88 */       throw new RuntimeException(e.getLocalizedMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setInputValue(CallableStatement stmt, Object val)
/*    */     throws SQLException
/*    */   {
/*    */     Calendar cal;
/*    */     long lo;
/*    */     SimpleDateFormat sdf;
/*    */     java.util.Date udate;
/*    */     String err;
/* 93 */     switch (this.jdbcType)
/*    */     {
/*    */     case 1:
/*    */     case 12:
/* 96 */       stmt.setString(this.index, val.toString());
/* 97 */       break;
/*    */     case 2:
/*    */     case 3:
/*    */     case 4:
/*    */     case 5:
/* 102 */       if (val instanceof Integer) {
/* 103 */         stmt.setInt(this.index, ((Integer)val).intValue()); return; }
/* 104 */       if (val instanceof Long) {
/* 105 */         stmt.setLong(this.index, ((Long)val).longValue()); return; }
/* 106 */       if (val instanceof Short) {
/* 107 */         stmt.setShort(this.index, ((Short)val).shortValue()); return; }
/* 108 */       if (val instanceof Byte) {
/* 109 */         stmt.setByte(this.index, ((Byte)val).byteValue()); return; }
/* 110 */       if (val instanceof String) {
/* 111 */         stmt.setInt(this.index, Long.valueOf((String)val).intValue()); return;
/*    */       }
/* 113 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     case 6:
/*    */     case 7:
/*    */     case 8:
/* 118 */       if (val instanceof Float) {
/* 119 */         stmt.setFloat(this.index, ((Float)val).floatValue()); return; }
/* 120 */       if (val instanceof Double) {
/* 121 */         stmt.setDouble(this.index, ((Double)val).doubleValue()); return; }
/* 122 */       if (val instanceof Integer) {
/* 123 */         int v = ((Integer)val).intValue();
/* 124 */         stmt.setDouble(this.index, v); return;
/*    */       }
/* 126 */       if (val instanceof Long) {
/* 127 */         long v = ((Long)val).longValue();
/* 128 */         stmt.setDouble(this.index, v); return;
/*    */       }
/* 130 */       if (val instanceof String) {
/* 131 */         double d = Double.parseDouble((String)val);
/* 132 */         stmt.setDouble(this.index, d); return;
/*    */       }
/*    */ 
/* 135 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     case -6:
/* 138 */       if (val instanceof Byte) {
/* 139 */         stmt.setByte(this.index, ((Byte)val).byteValue()); return; }
/* 140 */       if (val instanceof Integer) {
/* 141 */         stmt.setByte(this.index, ((Integer)val).byteValue()); return; }
/* 142 */       if (val instanceof Short) {
/* 143 */         stmt.setByte(this.index, ((Short)val).byteValue()); return; }
/* 144 */       if (val instanceof String) {
/* 145 */         Integer ib = Integer.valueOf(Integer.parseInt((String)val));
/* 146 */         stmt.setByte(this.index, ib.byteValue()); return;
/*    */       }
/*    */ 
/* 149 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     case -5:
/* 152 */       if (val instanceof Integer) {
/* 153 */         stmt.setInt(this.index, ((Integer)val).intValue()); return; }
/* 154 */       if (val instanceof Long) {
/* 155 */         stmt.setLong(this.index, ((Long)val).longValue()); return; }
/* 156 */       if (val instanceof String) {
/* 157 */         Long l = Long.valueOf(Long.parseLong((String)val));
/* 158 */         stmt.setLong(this.index, l.longValue()); return;
/*    */       }
/*    */ 
/* 161 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     case 91:
/* 164 */       if (val instanceof java.util.Date) {
/* 165 */         if (val instanceof java.sql.Date) {
/* 166 */           stmt.setDate(this.index, (java.sql.Date)val); return;
/*    */         }
/* 168 */         stmt.setDate(this.index, new java.sql.Date(((java.util.Date)val).getTime())); return;
/*    */       }
/* 170 */       if (val instanceof Calendar) {
/* 171 */         cal = (Calendar)val;
/* 172 */         stmt.setDate(this.index, new java.sql.Date(cal.getTimeInMillis())); return;
/*    */       }
/* 174 */       if ((val instanceof Long) || (val.getClass() == Long.TYPE)) {
/* 175 */         lo = ((Long)val).longValue();
/* 176 */         stmt.setDate(this.index, new java.sql.Date(lo)); return;
/*    */       }
/* 178 */       if (!(val instanceof String)) return;
/* 179 */       sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*    */       try {
/* 181 */         udate = sdf.parse((String)val);
/* 182 */         java.sql.Date sqlDate = new java.sql.Date(udate.getTime());
/* 183 */         stmt.setDate(this.index, sqlDate);
/*    */       } catch (ParseException e) {
/* 185 */         err = "字符串[" + ((String)val) + "]转换为Date错误。参数字段:name=" + this.pname + ",index=" + this.index;
/* 186 */         throw new RuntimeException(err);
/*    */       }
/*    */     case 92:
/* 191 */       if (val instanceof java.util.Date) {
/* 192 */         if (val instanceof Time) {
/* 193 */           stmt.setTime(this.index, (Time)val); return;
/*    */         }
/* 195 */         stmt.setTime(this.index, new Time(((java.util.Date)val).getTime())); return;
/*    */       }
/* 197 */       if (val instanceof Calendar) {
/* 198 */         sdf = (Calendar)val;
/* 199 */         stmt.setTime(this.index, new Time(sdf.getTimeInMillis())); return;
/*    */       }
/* 201 */       if ((val instanceof Long) || (val.getClass() == Long.TYPE)) {
/* 202 */         sdf = ((Long)val).longValue();
/* 203 */         stmt.setTime(this.index, new Time(sdf)); return;
/*    */       }
/* 205 */       if (!(val instanceof String)) return;
/* 206 */       sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*    */       try {
/* 208 */         e = sdf.parse((String)val);
/* 209 */         Time sqlDate = new Time(e.getTime());
/* 210 */         stmt.setTime(this.index, sqlDate);
/*    */       } catch (ParseException e) {
/* 212 */         err = "字符串[" + ((String)val) + "]转换为Date错误。参数字段:name=" + this.pname + ",index=" + this.index;
/* 213 */         throw new RuntimeException(err);
/*    */       }
/*    */     case 93:
/* 218 */       if (val instanceof java.util.Date) {
/* 219 */         if (val instanceof Timestamp) {
/* 220 */           stmt.setTimestamp(this.index, (Timestamp)val); return;
/*    */         }
/* 222 */         stmt.setTimestamp(this.index, new Timestamp(((java.util.Date)val).getTime())); return;
/*    */       }
/* 224 */       if (val instanceof Calendar) {
/* 225 */         sdf = (Calendar)val;
/* 226 */         stmt.setTimestamp(this.index, new Timestamp(sdf.getTimeInMillis())); return;
/*    */       }
/* 228 */       if ((val instanceof Long) || (val.getClass() == Long.TYPE)) {
/* 229 */         sdf = ((Long)val).longValue();
/* 230 */         stmt.setTimestamp(this.index, new Timestamp(sdf)); return;
/*    */       }
/* 232 */       if (val instanceof String) {
/* 233 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*    */         try {
/* 235 */           e = sdf.parse((String)val);
/* 236 */           Timestamp sqlDate = new Timestamp(e.getTime());
/* 237 */           stmt.setTimestamp(this.index, sqlDate);
/*    */         } catch (ParseException e) {
/* 239 */           err = "字符串[" + ((String)val) + "]转换为Date错误。参数字段:name=" + this.pname + ",index=" + this.index;
/* 240 */           throw new RuntimeException(err);
/*    */         }
/*    */       }
/*    */ 
/* 244 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     case 16:
/* 247 */       if (val instanceof Boolean) {
/* 248 */         stmt.setBoolean(this.index, ((Boolean)val).booleanValue()); return; }
/* 249 */       if (val instanceof Integer) {
/* 250 */         int i = ((Integer)val).intValue();
/* 251 */         stmt.setBoolean(this.index, i != 0); return;
/*    */       }
/* 253 */       if (val instanceof String) {
/* 254 */         String s = ((String)val).toLowerCase();
/* 255 */         stmt.setBoolean(this.index, s == "true"); return;
/*    */       }
/*    */ 
/* 258 */       throw new RuntimeException("传入的参数，与配置不兼容。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     default:
/* 261 */       throw new RuntimeException("传入的参数，没有对应的jdbcType。参数名称[name=" + this.pname + ",index=" + this.index + "],value type=" + val.getClass().getName());
/*    */     }
/*    */   }
/*    */ }