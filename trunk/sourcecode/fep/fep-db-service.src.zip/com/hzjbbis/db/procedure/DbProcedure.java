/*     */ package com.hzjbbis.db.procedure;
/*     */ 
/*     */ import com.hzjbbis.db.resultmap.ResultMapper;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ 
/*     */ public class DbProcedure
/*     */ {
/*  27 */   private static final Logger log = Logger.getLogger(DbProcedure.class);
/*     */   private DataSource dataSource;
/*  30 */   private List<ProcParam> outParams = new ArrayList();
/*  31 */   private List<ProcParam> inParams = new ArrayList();
/*     */   private String callString;
/*  34 */   private boolean initialized = false;
/*  35 */   private final Object lock = new Object();
/*     */ 
/*     */   public DbProcedure()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DbProcedure(DataSource ds, String sqlConfig)
/*     */   {
/*  43 */     this.dataSource = ds;
/*  44 */     this.callString = sqlConfig;
/*  45 */     checkInitialize();
/*     */   }
/*     */ 
/*     */   private void initialize(String sqlConfig)
/*     */   {
/*     */     try
/*     */     {
/*  52 */       this.callString = compile(sqlConfig);
/*  53 */       if (log.isDebugEnabled())
/*  54 */         log.debug("call string=" + this.callString);
/*     */     } catch (Exception e) {
/*  56 */       log.error("sql编译错误:" + sqlConfig, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkInitialize() {
/*  61 */     synchronized (this.lock) {
/*  62 */       if (!(this.initialized)) {
/*  63 */         this.initialized = true;
/*  64 */         initialize(this.callString);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isPrimitive(Object obj) {
/*  70 */     Class clz = obj.getClass();
/*  71 */     if (clz.isPrimitive())
/*  72 */       return true;
/*  73 */     if ((clz == String.class) || (clz == Integer.class) || (clz == Long.class) || (clz == Short.class) || 
/*  74 */       (clz == Character.class) || (clz == Byte.class) || (clz == Double.class) || (clz == Float.class)) {
/*  75 */       return true;
/*     */     }
/*  77 */     return (!(obj instanceof Date));
/*     */   }
/*     */ 
/*     */   public Object executeFunction(Object[] args)
/*     */     throws SQLException
/*     */   {
/*  82 */     checkInitialize();
/*  83 */     long time = System.currentTimeMillis();
/*  84 */     Connection con = DataSourceUtils.getConnection(this.dataSource);
/*  85 */     long time1 = System.currentTimeMillis();
/*  86 */     if (log.isDebugEnabled())
/*  87 */       log.debug("executeFunction取连接时间=" + (time1 - time));
/*     */     try
/*     */     {
/*     */       int i;
/*  89 */       CallableStatement procStmt = con.prepareCall(this.callString);
/*  90 */       for (ProcParam pout : this.outParams) {
/*  91 */         procStmt.registerOutParameter(pout.getParamIndex(), pout.getJdbcType());
/*     */       }
/*     */ 
/*  94 */       int i = 0;
/*  95 */       if (args.length == 1) {
/*  96 */         i = (isPrimitive(args[0])) ? 0 : 1;
/*     */       }
/*  98 */       if ((i == 0) && 
/*  99 */         (this.inParams.size() > args.length)) {
/* 100 */         String msg = "存储过程需要参数个数=" + this.inParams.size() + ",实际传入个数=" + args.length;
/* 101 */         log.error(msg);
/* 102 */         throw new RuntimeException(msg);
/*     */       }
/*     */ 
/* 105 */       for (int i = 0; i < this.inParams.size(); ++i) {
/* 106 */         ProcParam pin = (ProcParam)this.inParams.get(i);
/* 107 */         if (i != 0)
/* 108 */           pin.setInputValueByBean(procStmt, args[0]);
/*     */         else
/* 110 */           pin.setInputValue(procStmt, args[i]);
/*     */       }
/* 112 */       procStmt.execute();
/* 113 */       Object ret = procStmt.getObject(1);
/* 114 */       procStmt.close();
/* 115 */       return ret;
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 119 */       throw e;
/*     */     }
/*     */     finally {
/* 122 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean execute(Object[] args)
/*     */     throws SQLException
/*     */   {
/* 133 */     checkInitialize();
/* 134 */     long time = System.currentTimeMillis();
/* 135 */     Connection con = DataSourceUtils.getConnection(this.dataSource);
/* 136 */     long time1 = System.currentTimeMillis();
/* 137 */     if (log.isDebugEnabled())
/* 138 */       log.debug("execute取连接时间=" + (time1 - time));
/*     */     try
/*     */     {
/*     */       int i;
/* 140 */       CallableStatement procStmt = con.prepareCall(this.callString);
/* 141 */       for (ProcParam pout : this.outParams) {
/* 142 */         procStmt.registerOutParameter(pout.getParamIndex(), pout.getJdbcType());
/*     */       }
/*     */ 
/* 145 */       int i = 0;
/* 146 */       if (args.length == 1) {
/* 147 */         i = (isPrimitive(args[0])) ? 0 : 1;
/*     */       }
/* 149 */       if ((i == 0) && 
/* 150 */         (this.inParams.size() > args.length)) {
/* 151 */         String msg = "存储过程需要参数个数=" + this.inParams.size() + ",实际传入个数=" + args.length;
/* 152 */         log.error(msg);
/* 153 */         throw new RuntimeException(msg);
/*     */       }
/*     */ 
/* 156 */       for (int i = 0; i < this.inParams.size(); ++i) {
/* 157 */         ProcParam pin = (ProcParam)this.inParams.get(i);
/* 158 */         if (i != 0)
/* 159 */           pin.setInputValueByBean(procStmt, args[0]);
/*     */         else
/* 161 */           pin.setInputValue(procStmt, args[i]);
/*     */       }
/* 163 */       boolean ret = procStmt.execute();
/* 164 */       procStmt.close();
/* 165 */       return ret;
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 172 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/* 173 */       if (log.isDebugEnabled())
/* 174 */         log.debug("存储过程执行完毕");
/*     */     }
/*     */   }
/*     */ 
/*     */   private ResultSet executeResultSet(Object[] args)
/*     */     throws SQLException
/*     */   {
/* 185 */     checkInitialize();
/* 186 */     long time = System.currentTimeMillis();
/* 187 */     Connection con = DataSourceUtils.getConnection(this.dataSource);
/* 188 */     long time1 = System.currentTimeMillis();
/* 189 */     if (log.isDebugEnabled())
/* 190 */       log.debug("executeResultSet取连接时间=" + (time1 - time));
/*     */     try
/*     */     {
/*     */       int i;
/* 192 */       CallableStatement procStmt = con.prepareCall(this.callString);
/* 193 */       for (ProcParam pout : this.outParams) {
/* 194 */         procStmt.registerOutParameter(pout.getParamIndex(), pout.getJdbcType());
/*     */       }
/*     */ 
/* 197 */       int i = 0;
/* 198 */       if (args.length == 1) {
/* 199 */         i = (isPrimitive(args[0])) ? 0 : 1;
/*     */       }
/* 201 */       if ((i == 0) && 
/* 202 */         (this.inParams.size() > args.length)) {
/* 203 */         String msg = "存储过程需要参数个数=" + this.inParams.size() + ",实际传入个数=" + args.length;
/* 204 */         log.error(msg);
/* 205 */         throw new RuntimeException(msg);
/*     */       }
/*     */ 
/* 208 */       for (int i = 0; i < this.inParams.size(); ++i) {
/* 209 */         ProcParam pin = (ProcParam)this.inParams.get(i);
/* 210 */         pin.setInputValue(procStmt, args[i]);
/*     */       }
/* 212 */       procStmt.execute();
/* 213 */       ResultSet rs = procStmt.getResultSet();
/* 214 */       return rs;
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 218 */       throw e;
/*     */     }
/*     */     finally {
/* 221 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<?> executeList(ResultMapper<?> rm, Object[] args)
/*     */     throws SQLException
/*     */   {
/* 232 */     ResultSet rs = executeResultSet(args);
/* 233 */     return rm.mapAllRows(rs);
/*     */   }
/*     */ 
/*     */   public int executeFunctionInt(Object[] args) throws SQLException {
/* 237 */     Object ret = executeFunction(args);
/* 238 */     if (ret instanceof String) {
/* 239 */       Long lv = Long.valueOf(Long.parseLong((String)ret));
/* 240 */       return lv.intValue();
/*     */     }
/* 242 */     if (ret instanceof Integer)
/* 243 */       return ((Integer)ret).intValue();
/* 244 */     if (ret instanceof Long)
/* 245 */       return ((Long)ret).intValue();
/* 246 */     if (ret instanceof Short) {
/* 247 */       return ((Short)ret).shortValue();
/*     */     }
/* 249 */     throw new RuntimeException("返回类型不能转换到int");
/*     */   }
/*     */ 
/*     */   public long executeFunctionLong(Object[] args) throws SQLException {
/* 253 */     Object ret = executeFunction(args);
/* 254 */     if (ret instanceof String)
/* 255 */       return Long.parseLong((String)ret);
/* 256 */     if (ret instanceof Integer)
/* 257 */       return ((Integer)ret).intValue();
/* 258 */     if (ret instanceof Long)
/* 259 */       return ((Long)ret).longValue();
/* 260 */     if (ret instanceof Short) {
/* 261 */       return ((Short)ret).shortValue();
/*     */     }
/* 263 */     throw new RuntimeException("返回类型不能转换到long");
/*     */   }
/*     */ 
/*     */   public String executeFunctionString(Object[] args) throws SQLException {
/* 267 */     Object ret = executeFunction(args);
/* 268 */     if (ret instanceof String) {
/* 269 */       return ((String)ret);
/*     */     }
/* 271 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   private String compile(String sqlConfig)
/*     */   {
/* 276 */     sqlConfig = StringUtils.strip(sqlConfig);
/* 277 */     int index = sqlConfig.indexOf("{");
/* 278 */     if (index > 0)
/* 279 */       sqlConfig = sqlConfig.substring(index);
/* 280 */     index = sqlConfig.indexOf("#");
/* 281 */     if (index > 0) {
/* 282 */       int lp = sqlConfig.indexOf("(");
/* 283 */       int rp = sqlConfig.indexOf(")");
/* 284 */       StringBuffer sb = new StringBuffer();
/*     */ 
/* 286 */       String lsql = sqlConfig.substring(0, lp + 1);
/* 287 */       String sparam = sqlConfig.substring(lp + 1, rp);
/*     */ 
/* 289 */       int iq = lsql.indexOf("?");
/* 290 */       int pindex = 1;
/* 291 */       if (iq > 0)
/*     */       {
/* 293 */         sb.append("{?");
/* 294 */         int ieq = lsql.indexOf("=");
/* 295 */         sb.append(lsql.substring(ieq));
/* 296 */         String jtype = lsql.substring(iq + 1, ieq);
/* 297 */         int escapteIndex = 0;
/* 298 */         for (escapteIndex = 0; escapteIndex < jtype.length(); ++escapteIndex) {
/* 299 */           char c = lsql.charAt(escapteIndex);
/* 300 */           if ((c != ':') && (c != '#')) {
/* 301 */             jtype = jtype.substring(escapteIndex);
/* 302 */             break;
/*     */           }
/*     */         }
/* 305 */         ProcParam retParam = new ProcParam("", jtype, "OUT", pindex++);
/* 306 */         this.outParams.add(retParam);
/*     */       }
/*     */       else {
/* 309 */         sb.append(lsql);
/*     */       }
/* 311 */       String[] parts = sparam.split(",");
/* 312 */       for (int i = 0; i < parts.length; i += 3) {
/* 313 */         String name = parts[i].substring(1);
/* 314 */         String jtype = parts[(i + 1)].substring("jdbcType=".length());
/* 315 */         String pmode = parts[(i + 2)].substring(0, parts[(i + 2)].length() - 1);
/* 316 */         ProcParam param = new ProcParam(name, jtype, pmode, pindex++);
/* 317 */         if (param.getParamMode() == 0) {
/* 318 */           if (this.inParams.size() > 0)
/* 319 */             sb.append(",?");
/*     */           else
/* 321 */             sb.append("?");
/* 322 */           this.inParams.add(param);
/*     */         }
/* 324 */         else if (param.getParamMode() == 1) {
/* 325 */           this.outParams.add(param);
/*     */         }
/* 327 */         else if (param.getParamMode() == 2) {
/* 328 */           if (this.inParams.size() > 0)
/* 329 */             sb.append(",?");
/*     */           else
/* 331 */             sb.append("?");
/* 332 */           this.inParams.add(param);
/* 333 */           ProcParam paramOut = new ProcParam(name, jtype, pmode, param.getParamIndex());
/* 334 */           this.outParams.add(paramOut);
/*     */         }
/*     */         else {
/* 337 */           String errinfo = "Ibatis格式存储过程配置错误，mode=" + pmode;
/* 338 */           log.error(errinfo);
/* 339 */           throw new RuntimeException(errinfo);
/*     */         }
/*     */       }
/*     */ 
/* 343 */       sb.append(")}");
/* 344 */       return sb.toString();
/*     */     }
/* 346 */     return sqlConfig;
/*     */   }
/*     */ 
/*     */   public void setOutParams(List<ProcParam> outParams) {
/* 350 */     this.outParams = outParams;
/*     */   }
/*     */ 
/*     */   public void setInParams(List<ProcParam> inParams) {
/* 354 */     this.inParams = inParams;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource) {
/* 358 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public void setCallString(String callString) {
/* 362 */     this.callString = callString;
/*     */   }
/*     */ }