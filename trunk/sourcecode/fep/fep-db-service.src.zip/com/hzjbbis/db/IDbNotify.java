package com.hzjbbis.db;

public abstract interface IDbNotify
{
}