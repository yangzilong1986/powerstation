/*     */ package com.hzjbbis.db.managertu;
/*     */ 
/*     */ import com.hzjbbis.db.batch.BatchDaoParameterUtils;
/*     */ import com.hzjbbis.db.initrtu.dao.BizRtuDao;
/*     */ import com.hzjbbis.db.initrtu.dao.ComRtuDao;
/*     */ import com.hzjbbis.db.rtu.RtuRefreshDao;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuAlertCode;
/*     */ import com.hzjbbis.fk.model.RtuManage;
/*     */ import com.hzjbbis.fk.model.RtuTask;
/*     */ import com.hzjbbis.fk.model.SysConfig;
/*     */ import com.hzjbbis.fk.model.TaskDbConfig;
/*     */ import com.hzjbbis.fk.model.TaskTemplate;
/*     */ import com.hzjbbis.fk.model.TaskTemplateItem;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ManageRtu
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger(ManageRtu.class);
/*     */   private ComRtuDao comRtuDao;
/*     */   private BizRtuDao bizRtuDao;
/*     */   private RtuRefreshDao rtuRefreshDao;
/*  36 */   public RtuManage rtuManage = RtuManage.getInstance();
/*     */ 
/*     */   public void loadComRtu() {
/*  39 */     log.info("start initializeComRtu");
/*     */     try
/*     */     {
/*  42 */       List comRtus = this.comRtuDao.loadComRtu();
/*  43 */       log.info("ComRtus size:" + comRtus.size());
/*  44 */       for (ComRtu rtu : comRtus)
/*  45 */         this.rtuManage.putComRtuToCache(rtu);
/*     */     }
/*     */     catch (Exception ex) {
/*  48 */       log.error("loadComRtus" + ex);
/*     */     }
/*  50 */     log.info("end initializeComRtu");
/*     */   }
/*     */ 
/*     */   public void loadBizRtu() {
/*  54 */     int size = 0;
/*  55 */     long startTime = System.currentTimeMillis();
/*  56 */     log.info("start initializeBizRtu");
/*  57 */     size = initializeBizRtu();
/*  58 */     log.info("end initializeBizRtu");
/*  59 */     long endTime = System.currentTimeMillis();
/*  60 */     long timeConsume = endTime - startTime;
/*  61 */     long speed = size * 1000 / timeConsume;
/*  62 */     log.info(size + "个终端加载时间=" + timeConsume + "ms;效率=" + speed + "/s");
/*     */ 
/*  64 */     startTime = System.currentTimeMillis();
/*  65 */     log.info("start initializeTaskTemplate");
/*  66 */     size = initializeTaskTemplate();
/*  67 */     log.info("end initializeTaskTemplate");
/*  68 */     endTime = System.currentTimeMillis();
/*  69 */     timeConsume = endTime - startTime;
/*  70 */     speed = size * 1000 / timeConsume;
/*  71 */     log.info(size + "个任务模版加载时间=" + timeConsume + "ms;效率=" + speed + "/s");
/*     */ 
/*  73 */     startTime = System.currentTimeMillis();
/*  74 */     log.info("start initializeTaskDbConfig");
/*  75 */     size = initializeTaskDbConfig();
/*  76 */     log.info("end initializeTaskDbConfig");
/*  77 */     endTime = System.currentTimeMillis();
/*  78 */     timeConsume = endTime - startTime;
/*  79 */     speed = size * 1000 / timeConsume;
/*  80 */     log.info(size + "个任务数据项数据库表映射关系加载时间=" + timeConsume + "ms;效率=" + speed + "/s");
/*     */ 
/*  82 */     startTime = System.currentTimeMillis();
/*  83 */     log.info("start initializeAlertCode");
/*  84 */     size = initializeAlertCode();
/*  85 */     log.info("end initializeAlertCode");
/*  86 */     endTime = System.currentTimeMillis();
/*  87 */     timeConsume = endTime - startTime;
/*  88 */     speed = size * 1000 / timeConsume;
/*  89 */     log.info(size + "个异常数据项加载时间=" + timeConsume + "ms;效率=" + speed + "/s");
/*     */ 
/*  91 */     log.info("start initializeSysConfig");
/*  92 */     size = initializeSysConfig();
/*  93 */     log.info("end initializeSysConfig");
/*     */   }
/*     */ 
/*     */   public boolean refreshBizRtu(String zdjh)
/*     */   {
/*     */     try
/*     */     {
/* 104 */       BizRtu bizRtu = this.rtuRefreshDao.getRtu(zdjh);
/* 105 */       if (bizRtu != null) {
/* 106 */         this.rtuManage.putBizRtuToCache(bizRtu);
/* 107 */         return true;
/*     */       }
/* 109 */       return false;
/*     */     } catch (Exception ex) {
/* 111 */       log.error("find not rtuId:" + zdjh); }
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean refreshBizRtu(int rtua)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       BizRtu bizRtu = this.rtuRefreshDao.getRtu(rtua);
/* 125 */       if (bizRtu != null) {
/* 126 */         this.rtuManage.putBizRtuToCache(bizRtu);
/* 127 */         return true;
/*     */       }
/*     */ 
/* 130 */       return false;
/*     */     } catch (Exception ex) {
/* 132 */       log.error("find not rtuAdd:" + HexDump.toHex(rtua)); }
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean refreshComRtu(int rtua)
/*     */   {
/*     */     try
/*     */     {
/* 145 */       ComRtu comRtu = this.rtuRefreshDao.getComRtu(rtua);
/* 146 */       if (comRtu != null) {
/* 147 */         this.rtuManage.putComRtuToCache(comRtu);
/* 148 */         return true;
/*     */       }
/*     */ 
/* 151 */       return false;
/*     */     } catch (Exception ex) {
/* 153 */       log.error("find not comRtuAdd:" + HexDump.toHex(rtua)); }
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */   public void refreshMeasurePoints(String zdjh)
/*     */   {
/* 164 */     List mps = this.rtuRefreshDao.getMeasurePoints(zdjh);
/* 165 */     for (MeasuredPoint mp : mps)
/* 166 */       this.rtuManage.putMeasuredPointToCache(mp);
/*     */   }
/*     */ 
/*     */   public void refreshGwMeasurePoints(String zdjh)
/*     */   {
/* 176 */     List mps = this.rtuRefreshDao.getGwMeasurePoints(zdjh);
/* 177 */     for (MeasuredPoint mp : mps)
/* 178 */       this.rtuManage.putMeasuredPointToCache(mp);
/*     */   }
/*     */ 
/*     */   public void refreshRtuTasks(String zdjh)
/*     */   {
/* 188 */     List rts = this.rtuRefreshDao.getRtuTasks(zdjh);
/* 189 */     if (rts == null)
/* 190 */       rts = this.rtuRefreshDao.getGwRtuTasks(zdjh);
/* 191 */     for (RtuTask rt : rts)
/* 192 */       this.rtuManage.putRtuTaskToCache(rt);
/*     */   }
/*     */ 
/*     */   public void refreshTaskTemplate(String templID)
/*     */   {
/*     */     try
/*     */     {
/* 204 */       TaskTemplate tt = this.rtuRefreshDao.getTaskTemplate(templID);
/* 205 */       this.rtuManage.putTaskTemplateToCache(tt);
/* 206 */       List ttis = this.rtuRefreshDao.getTaskTemplateItems(templID);
/* 207 */       for (TaskTemplateItem tti : ttis)
/* 208 */         this.rtuManage.putTaskTemplateItemToCache(tti);
/*     */     }
/*     */     catch (Exception ex) {
/* 211 */       log.error("find not templID:" + templID);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int initializeBizRtu()
/*     */   {
/*     */     Iterator localIterator;
/* 219 */     int size = 0;
/*     */     try
/*     */     {
/*     */       BizRtu rtu;
/* 222 */       List bizRtus = this.bizRtuDao.loadBizRtu();
/* 223 */       size = bizRtus.size();
/* 224 */       log.info("BizRtuList size:" + bizRtus.size());
/* 225 */       for (localIterator = bizRtus.iterator(); localIterator.hasNext(); ) { rtu = (BizRtu)localIterator.next();
/* 226 */         rtu.setRtuType("01");
/* 227 */         if (rtu.getRtuProtocol() == null)
/* 228 */           rtu.setRtuProtocol("01");
/* 229 */         this.rtuManage.putBizRtuToCache(rtu);
/*     */       }
/*     */ 
/* 232 */       bizRtus = this.bizRtuDao.loadBizGwRtu();
/* 233 */       size = bizRtus.size();
/* 234 */       log.info("BizGwRtuList size:" + bizRtus.size());
/* 235 */       for (localIterator = bizRtus.iterator(); localIterator.hasNext(); ) { rtu = (BizRtu)localIterator.next();
/* 236 */         rtu.setRtuType("02");
/* 237 */         if (rtu.getRtuProtocol() == null)
/* 238 */           rtu.setRtuProtocol("02");
/* 239 */         this.rtuManage.putBizRtuToCache(rtu);
/*     */       }
/*     */     } catch (Exception ex) {
/* 242 */       log.error("loadBizRtus" + ex);
/* 243 */       return size;
/*     */     }
/*     */     try
/*     */     {
/*     */       MeasuredPoint mp;
/* 247 */       List mps = this.bizRtuDao.loadMeasuredPoints();
/* 248 */       log.info("MeasuredPointList size:" + mps.size());
/* 249 */       for (localIterator = mps.iterator(); localIterator.hasNext(); ) { mp = (MeasuredPoint)localIterator.next();
/* 250 */         this.rtuManage.putMeasuredPointToCache(mp);
/*     */       }
/* 252 */       mps = this.bizRtuDao.loadGwMeasuredPoints();
/* 253 */       log.info("GwMeasuredPointList size:" + mps.size());
/* 254 */       for (localIterator = mps.iterator(); localIterator.hasNext(); ) { mp = (MeasuredPoint)localIterator.next();
/* 255 */         this.rtuManage.putMeasuredPointToCache(mp);
/*     */       }
/*     */     } catch (Exception mps) {
/* 258 */       log.error("loadMeasuredPoints" + ex);
/*     */     }
/*     */     try
/*     */     {
/*     */       RtuTask rt;
/* 264 */       List rts = this.bizRtuDao.loadRtuTasks();
/* 265 */       log.info("RtuTaskList size:" + rts.size());
/* 266 */       for (localIterator = rts.iterator(); localIterator.hasNext(); ) { rt = (RtuTask)localIterator.next();
/* 267 */         this.rtuManage.putRtuTaskToCache(rt);
/*     */       }
/* 269 */       rts = this.bizRtuDao.loadGwRtuTasks();
/* 270 */       log.info("GwRtuTaskList size:" + rts.size());
/* 271 */       for (localIterator = rts.iterator(); localIterator.hasNext(); ) { rt = (RtuTask)localIterator.next();
/* 272 */         this.rtuManage.putRtuTaskToCache(rt);
/*     */       }
/*     */     } catch (Exception rts) {
/* 275 */       log.error("loadRtuTasks" + ex);
/*     */     }
/* 277 */     return size;
/*     */   }
/*     */ 
/*     */   private int initializeTaskTemplate()
/*     */   {
/* 284 */     int size = 0;
/*     */     try
/*     */     {
/* 287 */       List tts = this.bizRtuDao.loadTaskTemplate();
/* 288 */       size = tts.size();
/* 289 */       log.info("TaskTemplateList size:" + tts.size());
/* 290 */       for (TaskTemplate tt : tts)
/* 291 */         this.rtuManage.putTaskTemplateToCache(tt);
/*     */     }
/*     */     catch (Exception ex) {
/* 294 */       log.error("loadTaskTemplate" + ex);
/* 295 */       return size;
/*     */     }
/* 297 */     return size;
/*     */   }
/*     */ 
/*     */   public int initializeSysConfig()
/*     */   {
/* 304 */     int size = 0;
/*     */     try
/*     */     {
/* 307 */       List sc = this.bizRtuDao.loadSysConfig();
/* 308 */       size = sc.size();
/* 309 */       log.info("SysConfig size:" + sc.size());
/* 310 */       if (size == 2) {
/* 311 */         SysConfig sysConfig = new SysConfig();
/* 312 */         sysConfig.setBj10(((SysConfig)sc.get(0)).getPzz());
/* 313 */         sysConfig.setBj11(((SysConfig)sc.get(1)).getPzz());
/* 314 */         this.rtuManage.setSysConfig(sysConfig);
/* 315 */         BatchDaoParameterUtils.getInstance().setAdditiveParameter(RtuManage.getInstance().getSysConfig());
/*     */       }
/*     */     } catch (Exception ex) {
/* 318 */       log.error("loadSysConfig" + ex);
/* 319 */       return size;
/*     */     }
/* 321 */     return size;
/*     */   }
/*     */ 
/*     */   public int initializeTaskDbConfig()
/*     */   {
/* 328 */     int size = 0;
/*     */     try
/*     */     {
/* 331 */       List rdcs = this.bizRtuDao.loadTaskDbConfig();
/* 332 */       size = rdcs.size();
/* 333 */       log.info("TaskDbConfigList size:" + rdcs.size());
/* 334 */       for (TaskDbConfig rdc : rdcs)
/* 335 */         this.rtuManage.putTaskDbConfigToCache(rdc);
/*     */     }
/*     */     catch (Exception ex) {
/* 338 */       log.error("loadTaskDbConfig" + ex);
/*     */     }
/* 340 */     return size;
/*     */   }
/*     */ 
/*     */   private int initializeAlertCode()
/*     */   {
/* 347 */     int size = 0;
/*     */     try
/*     */     {
/* 350 */       List racs = this.bizRtuDao.loadRtuAlertCodes();
/* 351 */       size = racs.size();
/* 352 */       log.info("RtuAlertCodeList size:" + racs.size());
/* 353 */       for (RtuAlertCode rac : racs)
/* 354 */         this.rtuManage.putAlertCodeToCache(rac);
/*     */     }
/*     */     catch (Exception ex) {
/* 357 */       log.error("loadRtuAlertCodes" + ex);
/*     */     }
/* 359 */     return size; }
/*     */ 
/*     */   public void setComRtuDao(ComRtuDao comRtuDao) {
/* 362 */     this.comRtuDao = comRtuDao; }
/*     */ 
/*     */   public void setBizRtuDao(BizRtuDao bizRtuDao) {
/* 365 */     this.bizRtuDao = bizRtuDao; }
/*     */ 
/*     */   public void setRtuRefreshDao(RtuRefreshDao rtuRefreshDao) {
/* 368 */     this.rtuRefreshDao = rtuRefreshDao;
/*     */   }
/*     */ }