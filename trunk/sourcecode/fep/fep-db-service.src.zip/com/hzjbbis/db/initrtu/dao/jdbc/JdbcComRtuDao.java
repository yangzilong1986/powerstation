/*    */ package com.hzjbbis.db.initrtu.dao.jdbc;
/*    */ 
/*    */ import com.hzjbbis.db.initrtu.dao.ComRtuDao;
/*    */ import com.hzjbbis.db.resultmap.ResultMapper;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
/*    */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*    */ 
/*    */ public class JdbcComRtuDao
/*    */   implements ComRtuDao
/*    */ {
/*    */   private String sqlLoadRtu;
/*    */   private String sqlLoadGwRtu;
/*    */   private ResultMapper<ComRtu> mapperLoadRtu;
/*    */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*    */ 
/*    */   public void setDataSource(DataSource dataSource)
/*    */   {
/* 27 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
/*    */   }
/*    */ 
/*    */   public List<ComRtu> loadComRtu() {
/* 31 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*    */       public ComRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 33 */         return ((ComRtu)JdbcComRtuDao.this.mapperLoadRtu.mapOneRow(rs));
/*    */       }
/*    */     };
/* 36 */     return this.simpleJdbcTemplate.query(this.sqlLoadRtu, rowMap, new Object[0]);
/*    */   }
/*    */ 
/*    */   public List<ComRtu> loadComGwRtu() {
/* 40 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*    */       public ComRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 42 */         return ((ComRtu)JdbcComRtuDao.this.mapperLoadRtu.mapOneRow(rs));
/*    */       }
/*    */     };
/* 45 */     return this.simpleJdbcTemplate.query(this.sqlLoadGwRtu, rowMap, new Object[0]);
/*    */   }
/*    */ 
/*    */   public void setSqlLoadRtu(String sqlLoadRtu) {
/* 49 */     this.sqlLoadRtu = sqlLoadRtu.trim();
/*    */   }
/*    */ 
/*    */   public void setMapperLoadRtu(ResultMapper<ComRtu> resultMap) {
/* 53 */     this.mapperLoadRtu = resultMap;
/*    */   }
/*    */ 
/*    */   public void setSqlLoadGwRtu(String sqlLoadGwRtu) {
/* 57 */     this.sqlLoadGwRtu = sqlLoadGwRtu;
/*    */   }
/*    */ }