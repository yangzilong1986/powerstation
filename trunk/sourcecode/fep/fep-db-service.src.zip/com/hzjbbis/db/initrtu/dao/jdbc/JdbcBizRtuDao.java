/*     */ package com.hzjbbis.db.initrtu.dao.jdbc;
/*     */ 
/*     */ import com.hzjbbis.db.initrtu.dao.BizRtuDao;
/*     */ import com.hzjbbis.db.resultmap.ResultMapper;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuAlertCode;
/*     */ import com.hzjbbis.fk.model.RtuAlertCodeArg;
/*     */ import com.hzjbbis.fk.model.RtuTask;
/*     */ import com.hzjbbis.fk.model.SysConfig;
/*     */ import com.hzjbbis.fk.model.TaskDbConfig;
/*     */ import com.hzjbbis.fk.model.TaskTemplate;
/*     */ import com.hzjbbis.fk.model.TaskTemplateItem;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
/*     */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*     */ 
/*     */ public class JdbcBizRtuDao
/*     */   implements BizRtuDao
/*     */ {
/*     */   private String sqlLoadRtu;
/*     */   private String sqlLoadGwRtu;
/*     */   private ResultMapper<BizRtu> mapperLoadRtu;
/*     */   private String sqlLoadMeasurePoints;
/*     */   private ResultMapper<MeasuredPoint> mapperLoadMeasurePoints;
/*     */   private String sqlLoadGwMeasurePoints;
/*     */   private ResultMapper<MeasuredPoint> mapperLoadGwMeasurePoints;
/*     */   private String sqlLoadAlertCode;
/*     */   private ResultMapper<RtuAlertCode> mapperLoadAlertCode;
/*     */   private String sqlLoadAlertCodeArgs;
/*     */   private ResultMapper<RtuAlertCodeArg> mapperLoadAlertCodeArgs;
/*     */   private String sqlLoadRtuTask;
/*     */   private String sqlLoadGwRtuTask;
/*     */   private ResultMapper<RtuTask> mapperLoadRtuTask;
/*     */   private String sqlLoadTaskDbConfig;
/*     */   private ResultMapper<TaskDbConfig> mapperLoadTaskDbConfig;
/*     */   private String sqlLoadTaskTemplate;
/*     */   private ResultMapper<TaskTemplate> mapperLoadTaskTemplate;
/*     */   private String sqlLoadTaskTemplateItem;
/*     */   private ResultMapper<TaskTemplateItem> mapperLoadTaskTemplateItem;
/*     */   private String sqlLoadSysConfig;
/*     */   private ResultMapper<SysConfig> mapperLoadSysConfig;
/*     */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  62 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public List<BizRtu> loadBizRtu() {
/*  66 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public BizRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  68 */         return ((BizRtu)JdbcBizRtuDao.this.mapperLoadRtu.mapOneRow(rs));
/*     */       }
/*     */     };
/*  71 */     return this.simpleJdbcTemplate.query(this.sqlLoadRtu, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<BizRtu> loadBizGwRtu() {
/*  75 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public BizRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  77 */         return ((BizRtu)JdbcBizRtuDao.this.mapperLoadRtu.mapOneRow(rs));
/*     */       }
/*     */     };
/*  80 */     return this.simpleJdbcTemplate.query(this.sqlLoadGwRtu, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<MeasuredPoint> loadMeasuredPoints() {
/*  84 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public MeasuredPoint mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  86 */         return ((MeasuredPoint)JdbcBizRtuDao.this.mapperLoadMeasurePoints.mapOneRow(rs));
/*     */       }
/*     */     };
/*  89 */     return this.simpleJdbcTemplate.query(this.sqlLoadMeasurePoints, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<MeasuredPoint> loadGwMeasuredPoints() {
/*  93 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public MeasuredPoint mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  95 */         return ((MeasuredPoint)JdbcBizRtuDao.this.mapperLoadGwMeasurePoints.mapOneRow(rs));
/*     */       }
/*     */     };
/*  98 */     return this.simpleJdbcTemplate.query(this.sqlLoadGwMeasurePoints, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   private List<RtuAlertCodeArg> loadRtuAlertCodeArgs() {
/* 102 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public RtuAlertCodeArg mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 104 */         return ((RtuAlertCodeArg)JdbcBizRtuDao.this.mapperLoadAlertCodeArgs.mapOneRow(rs));
/*     */       }
/*     */     };
/* 107 */     return this.simpleJdbcTemplate.query(this.sqlLoadAlertCodeArgs, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<RtuAlertCode> loadRtuAlertCodes() {
/* 111 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public RtuAlertCode mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 113 */         return ((RtuAlertCode)JdbcBizRtuDao.this.mapperLoadAlertCode.mapOneRow(rs));
/*     */       }
/*     */     };
/* 116 */     List alertCodeList = this.simpleJdbcTemplate.query(this.sqlLoadAlertCode, rowMap, new Object[0]);
/* 117 */     HashMap map = new HashMap();
/* 118 */     for (RtuAlertCode acode : alertCodeList) {
/* 119 */       map.put(acode.getCode(), acode);
/*     */     }
/* 121 */     List args = loadRtuAlertCodeArgs();
/* 122 */     for (RtuAlertCodeArg arg : args) {
/* 123 */       RtuAlertCode acode = (RtuAlertCode)map.get(arg.getCode());
/* 124 */       if (acode != null)
/* 125 */         acode.getArgs().add(arg.getSjx());
/*     */     }
/* 127 */     map.clear();
/* 128 */     args.clear();
/* 129 */     return alertCodeList;
/*     */   }
/*     */ 
/*     */   public List<RtuTask> loadRtuTasks() {
/* 133 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public RtuTask mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 135 */         return ((RtuTask)JdbcBizRtuDao.this.mapperLoadRtuTask.mapOneRow(rs));
/*     */       }
/*     */     };
/* 138 */     return this.simpleJdbcTemplate.query(this.sqlLoadRtuTask, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<RtuTask> loadGwRtuTasks() {
/* 142 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public RtuTask mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 144 */         return ((RtuTask)JdbcBizRtuDao.this.mapperLoadRtuTask.mapOneRow(rs));
/*     */       }
/*     */     };
/* 147 */     return this.simpleJdbcTemplate.query(this.sqlLoadGwRtuTask, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<TaskDbConfig> loadTaskDbConfig() {
/* 151 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public TaskDbConfig mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 153 */         return ((TaskDbConfig)JdbcBizRtuDao.this.mapperLoadTaskDbConfig.mapOneRow(rs));
/*     */       }
/*     */     };
/* 156 */     return this.simpleJdbcTemplate.query(this.sqlLoadTaskDbConfig, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<TaskTemplate> loadTaskTemplate() {
/* 160 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public TaskTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 162 */         return ((TaskTemplate)JdbcBizRtuDao.this.mapperLoadTaskTemplate.mapOneRow(rs));
/*     */       }
/*     */     };
/* 165 */     List taskTemps = this.simpleJdbcTemplate.query(this.sqlLoadTaskTemplate, rowMap, new Object[0]);
/* 166 */     Map map = new HashMap();
/* 167 */     for (TaskTemplate tt : taskTemps) {
/* 168 */       map.put(tt.getTaskTemplateID(), tt);
/*     */     }
/* 170 */     List taskTempItems = loadTaskTemplateItem();
/* 171 */     for (TaskTemplateItem ttItem : taskTempItems) {
/* 172 */       TaskTemplate tt = (TaskTemplate)map.get(ttItem.getTaskTemplateID());
/* 173 */       if (tt != null)
/* 174 */         tt.addDataCode(ttItem.getCode());
/*     */     }
/* 176 */     return taskTemps;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadSysConfig(ResultMapper<SysConfig> mapperLoadSysConfig) {
/* 180 */     this.mapperLoadSysConfig = mapperLoadSysConfig;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadSysConfig(String sqlLoadSysConfig) {
/* 184 */     this.sqlLoadSysConfig = sqlLoadSysConfig;
/*     */   }
/*     */ 
/*     */   private List<TaskTemplateItem> loadTaskTemplateItem() {
/* 188 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public TaskTemplateItem mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 190 */         return ((TaskTemplateItem)JdbcBizRtuDao.this.mapperLoadTaskTemplateItem.mapOneRow(rs));
/*     */       }
/*     */     };
/* 193 */     return this.simpleJdbcTemplate.query(this.sqlLoadTaskTemplateItem, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public List<SysConfig> loadSysConfig() {
/* 197 */     ParameterizedRowMapper rowMap = new ParameterizedRowMapper() {
/*     */       public SysConfig mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 199 */         return ((SysConfig)JdbcBizRtuDao.this.mapperLoadSysConfig.mapOneRow(rs));
/*     */       }
/*     */     };
/* 202 */     return this.simpleJdbcTemplate.query(this.sqlLoadSysConfig, rowMap, new Object[0]);
/*     */   }
/*     */ 
/*     */   public void setSqlLoadRtu(String sqlLoadRtu) {
/* 206 */     this.sqlLoadRtu = sqlLoadRtu;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadMeasurePoints(String sqlLoadMeasurePoints) {
/* 210 */     this.sqlLoadMeasurePoints = sqlLoadMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadAlertCode(String sqlLoadAlertCode) {
/* 214 */     this.sqlLoadAlertCode = sqlLoadAlertCode;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadRtuTask(String sqlLoadRtuTask) {
/* 218 */     this.sqlLoadRtuTask = sqlLoadRtuTask;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadTaskDbConfig(String sqlLoadTaskDbConfig) {
/* 222 */     this.sqlLoadTaskDbConfig = sqlLoadTaskDbConfig;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadTaskTemplate(String sqlLoadTaskTemplate) {
/* 226 */     this.sqlLoadTaskTemplate = sqlLoadTaskTemplate;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadTaskTemplateItem(String sqlLoadTaskTemplateItem) {
/* 230 */     this.sqlLoadTaskTemplateItem = sqlLoadTaskTemplateItem;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadAlertCodeArgs(String sqlLoadAlertCodeArgs) {
/* 234 */     this.sqlLoadAlertCodeArgs = sqlLoadAlertCodeArgs;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadRtu(ResultMapper<BizRtu> mapperLoadRtu) {
/* 238 */     this.mapperLoadRtu = mapperLoadRtu;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadMeasurePoints(ResultMapper<MeasuredPoint> mapperLoadMeasurePoints)
/*     */   {
/* 243 */     this.mapperLoadMeasurePoints = mapperLoadMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadAlertCode(ResultMapper<RtuAlertCode> mapperLoadAlertCode)
/*     */   {
/* 248 */     this.mapperLoadAlertCode = mapperLoadAlertCode;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadAlertCodeArgs(ResultMapper<RtuAlertCodeArg> mapperLoadAlertCodeArgs)
/*     */   {
/* 253 */     this.mapperLoadAlertCodeArgs = mapperLoadAlertCodeArgs;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadRtuTask(ResultMapper<RtuTask> mapperLoadRtuTask) {
/* 257 */     this.mapperLoadRtuTask = mapperLoadRtuTask;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadTaskDbConfig(ResultMapper<TaskDbConfig> mapperLoadTaskDbConfig)
/*     */   {
/* 262 */     this.mapperLoadTaskDbConfig = mapperLoadTaskDbConfig;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadTaskTemplate(ResultMapper<TaskTemplate> mapperLoadTaskTemplate)
/*     */   {
/* 267 */     this.mapperLoadTaskTemplate = mapperLoadTaskTemplate;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadTaskTemplateItem(ResultMapper<TaskTemplateItem> mapperLoadTaskTemplateItem)
/*     */   {
/* 272 */     this.mapperLoadTaskTemplateItem = mapperLoadTaskTemplateItem;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadGwRtu(String sqlLoadGwRtu) {
/* 276 */     this.sqlLoadGwRtu = sqlLoadGwRtu;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadGwRtuTask(String sqlLoadGwRtuTask) {
/* 280 */     this.sqlLoadGwRtuTask = sqlLoadGwRtuTask;
/*     */   }
/*     */ 
/*     */   public void setSqlLoadGwMeasurePoints(String sqlLoadGwMeasurePoints) {
/* 284 */     this.sqlLoadGwMeasurePoints = sqlLoadGwMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setMapperLoadGwMeasurePoints(ResultMapper<MeasuredPoint> mapperLoadGwMeasurePoints)
/*     */   {
/* 289 */     this.mapperLoadGwMeasurePoints = mapperLoadGwMeasurePoints;
/*     */   }
/*     */ }