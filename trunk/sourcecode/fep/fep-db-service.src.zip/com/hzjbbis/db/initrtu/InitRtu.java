/*    */ package com.hzjbbis.db.initrtu;
/*    */ 
/*    */ import com.hzjbbis.db.initrtu.dao.ComRtuDao;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class InitRtu
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(InitRtu.class);
/*    */   private ComRtuDao comRtuDao;
/*    */ 
/*    */   public List<ComRtu> loadComRtu()
/*    */   {
/*    */     try
/*    */     {
/* 24 */       return this.comRtuDao.loadComRtu();
/*    */     } catch (Exception exp) {
/* 26 */       log.error("初始化终端通信参数异常：" + exp.getLocalizedMessage(), exp); }
/* 27 */     return null;
/*    */   }
/*    */ 
/*    */   public void setComRtuDao(ComRtuDao comRtuDao)
/*    */   {
/* 32 */     this.comRtuDao = comRtuDao;
/*    */   }
/*    */ }