/*    */ package com.hzjbbis.db.heartbeat;
/*    */ 
/*    */ public class HeartBeatLog
/*    */ {
/*    */   private int id;
/*    */   private int weekno;
/*    */   private boolean issuccess;
/*    */   private long startime;
/*    */   private long endtime;
/*    */ 
/*    */   public long getEndtime()
/*    */   {
/* 11 */     return this.endtime; }
/*    */ 
/*    */   public void setEndtime(long endtime) {
/* 14 */     this.endtime = endtime; }
/*    */ 
/*    */   public int getId() {
/* 17 */     return this.id; }
/*    */ 
/*    */   public void setId(int id) {
/* 20 */     this.id = id; }
/*    */ 
/*    */   public boolean getIssuccess() {
/* 23 */     return this.issuccess; }
/*    */ 
/*    */   public void setIssuccess(boolean issuccess) {
/* 26 */     this.issuccess = issuccess; }
/*    */ 
/*    */   public long getStartime() {
/* 29 */     return this.startime; }
/*    */ 
/*    */   public void setStartime(long startime) {
/* 32 */     this.startime = startime; }
/*    */ 
/*    */   public int getWeekno() {
/* 35 */     return this.weekno; }
/*    */ 
/*    */   public void setWeekno(int weekno) {
/* 38 */     this.weekno = weekno;
/*    */   }
/*    */ }