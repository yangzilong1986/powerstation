/*    */ package com.hzjbbis.db.heartbeat;
/*    */ 
/*    */ public class HeartBeat
/*    */ {
/*    */   private static final long FIRST_BEAT_DAY = -9223372036854775808L;
/*    */   private String rtua;
/*    */   private String deptCode;
/*    */   private int columnIndex;
/*    */   private String valueOrigin;
/*    */   private long value;
/*    */   private int weekTag;
/*    */   private int weekOfYear;
/*    */   private String valueTime;
/*    */ 
/*    */   public String getValueTime()
/*    */   {
/* 15 */     return this.valueTime;
/*    */   }
/*    */ 
/*    */   public void setValueTime(String valueTime) {
/* 19 */     this.valueTime = valueTime;
/*    */   }
/*    */ 
/*    */   public String getKey() {
/* 23 */     return this.rtua + this.weekTag;
/*    */   }
/*    */ 
/*    */   public boolean isFirstOfDay() {
/* 27 */     return (this.value != -9223372036854775808L); }
/*    */ 
/*    */   public int getColumnIndex() {
/* 30 */     return this.columnIndex; }
/*    */ 
/*    */   public void setColumnIndex(int columnIndex) {
/* 33 */     this.columnIndex = columnIndex; }
/*    */ 
/*    */   public String getRtua() {
/* 36 */     return this.rtua; }
/*    */ 
/*    */   public void setRtua(String rtua) {
/* 39 */     this.rtua = rtua; }
/*    */ 
/*    */   public long getValue() {
/* 42 */     return this.value; }
/*    */ 
/*    */   public void setValue(long value) {
/* 45 */     this.value = value; }
/*    */ 
/*    */   public int getWeekTag() {
/* 48 */     return this.weekTag; }
/*    */ 
/*    */   public void setWeekTag(int weekFlag) {
/* 51 */     this.weekTag = weekFlag; }
/*    */ 
/*    */   public int getWeekOfYear() {
/* 54 */     return this.weekOfYear; }
/*    */ 
/*    */   public void setWeekOfYear(int weekOfYear) {
/* 57 */     this.weekOfYear = weekOfYear; }
/*    */ 
/*    */   public String getValueOrigin() {
/* 60 */     return this.valueOrigin; }
/*    */ 
/*    */   public void setValueOrigin(String valueOrigin) {
/* 63 */     this.valueOrigin = valueOrigin;
/*    */   }
/*    */ 
/*    */   public String getDeptCode() {
/* 67 */     return this.deptCode;
/*    */   }
/*    */ 
/*    */   public void setDeptCode(String deptCode) {
/* 71 */     this.deptCode = deptCode;
/*    */   }
/*    */ }