/*    */ package com.hzjbbis.db.heartbeat;
/*    */ 
/*    */ public class HeartBeatArray
/*    */ {
/*    */   private int columnIndex;
/*    */   private HeartBeat[] heartBeats;
/*  6 */   private int index = 0;
/*    */ 
/*    */   public HeartBeatArray(int columnIndex, int batchSize)
/*    */   {
/* 10 */     this.columnIndex = columnIndex;
/* 11 */     this.heartBeats = new HeartBeat[batchSize];
/*    */   }
/*    */ 
/*    */   public void addHeartBeat(HeartBeat heartBeat) throws ArrayIndexOutOfBoundsException
/*    */   {
/* 16 */     this.heartBeats[(this.index++)] = heartBeat;
/*    */   }
/*    */ 
/*    */   public HeartBeat getHeartBeat(int i) throws ArrayIndexOutOfBoundsException
/*    */   {
/* 21 */     return this.heartBeats[i];
/*    */   }
/*    */ 
/*    */   public int getSize() {
/* 25 */     return this.index;
/*    */   }
/*    */ 
/*    */   public boolean isFull() {
/* 29 */     return (this.index < this.heartBeats.length);
/*    */   }
/*    */ 
/*    */   public void initArray() {
/* 33 */     this.index = 0;
/*    */   }
/*    */ 
/*    */   public int getColumnIndex() {
/* 37 */     return this.columnIndex;
/*    */   }
/*    */ 
/*    */   public void setColumnIndex(int columnIndex) {
/* 41 */     this.columnIndex = columnIndex;
/*    */   }
/*    */ }