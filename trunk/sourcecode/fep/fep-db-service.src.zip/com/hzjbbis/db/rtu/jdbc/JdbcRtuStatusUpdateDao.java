/*    */ package com.hzjbbis.db.rtu.jdbc;
/*    */ 
/*    */ import com.hzjbbis.db.rtu.RtuStatusUpdateDao;
/*    */ import com.hzjbbis.fk.model.ComRtu;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*    */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*    */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*    */ 
/*    */ public class JdbcRtuStatusUpdateDao
/*    */   implements RtuStatusUpdateDao
/*    */ {
/* 18 */   private static final Logger log = Logger.getLogger(JdbcRtuStatusUpdateDao.class);
/*    */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*    */   private String sqlInsert;
/*    */   private String sqlUpdate;
/* 21 */   private int batchSize = 10000;
/*    */ 
/*    */   public void setDataSource(DataSource dataSource) {
/* 24 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
/*    */   }
/*    */ 
/*    */   public void update(Collection<ComRtu> rtus)
/*    */   {
/*    */     int count;
/* 28 */     ArrayList ulist = new ArrayList(this.batchSize);
/*    */ 
/* 30 */     for (ComRtu rtu : rtus) {
/* 31 */       if (ulist.size() < this.batchSize) {
/* 32 */         ulist.add(rtu);
/*    */       }
/*    */       else {
/* 35 */         count = batchUpdate(ulist.toArray());
/* 36 */         log.info("终端工况批量更新，成功条数=" + count);
/* 37 */         ulist.clear();
/*    */       }
/*    */     }
/* 40 */     if (ulist.size() > 0) {
/* 41 */       count = batchUpdate(ulist.toArray());
/* 42 */       log.info("终端工况批量更新，成功条数=" + count);
/*    */     }
/*    */   }
/*    */ 
/*    */   private int batchUpdate(Object[] pojoArray)
/*    */   {
/* 52 */     SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(pojoArray);
/* 53 */     int[] updateCounts = this.simpleJdbcTemplate.batchUpdate(this.sqlUpdate, batch);
/* 54 */     ArrayList ulist = new ArrayList(pojoArray.length);
/* 55 */     for (int i = 0; i < updateCounts.length; ++i)
/* 56 */       ulist.add(pojoArray[i]);
/* 57 */     batch = SqlParameterSourceUtils.createBatch(ulist.toArray());
/* 58 */     updateCounts = this.simpleJdbcTemplate.batchUpdate(this.sqlInsert, batch);
/* 59 */     int totalCount = 0;
/* 60 */     for (int i = 0; i < updateCounts.length; ++i)
/* 61 */       totalCount += updateCounts[i];
/* 62 */     return totalCount;
/*    */   }
/*    */ 
/*    */   public void setSqlInsert(String sqlInsert) {
/* 66 */     sqlInsert = StringUtils.strip(sqlInsert);
/* 67 */     this.sqlInsert = sqlInsert;
/*    */   }
/*    */ 
/*    */   public void setSqlUpdate(String sqlUpdate) {
/* 71 */     sqlUpdate = StringUtils.strip(sqlUpdate);
/* 72 */     this.sqlUpdate = sqlUpdate;
/*    */   }
/*    */ 
/*    */   public void setBatchSize(int batchSize) {
/* 76 */     this.batchSize = batchSize;
/*    */   }
/*    */ }