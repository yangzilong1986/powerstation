/*     */ package com.hzjbbis.db.rtu.jdbc;
/*     */ 
/*     */ import com.hzjbbis.db.resultmap.ResultMapper;
/*     */ import com.hzjbbis.db.rtu.RtuRefreshDao;
/*     */ import com.hzjbbis.fk.model.BizRtu;
/*     */ import com.hzjbbis.fk.model.ComRtu;
/*     */ import com.hzjbbis.fk.model.MeasuredPoint;
/*     */ import com.hzjbbis.fk.model.RtuTask;
/*     */ import com.hzjbbis.fk.model.TaskTemplate;
/*     */ import com.hzjbbis.fk.model.TaskTemplateItem;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
/*     */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*     */ 
/*     */ public class JdbcRtuRefreshDao
/*     */   implements RtuRefreshDao
/*     */ {
/*     */   private String sqlGetRtuByRtuId;
/*     */   private String sqlGetRtuByRtua;
/*     */   private String sqlGetGwRtuByRtuId;
/*     */   private String sqlGetGwRtuByRtua;
/*     */   private ResultMapper<BizRtu> mapperGetRtu;
/*     */   private String sqlGetMeasurePoints;
/*     */   private ResultMapper<MeasuredPoint> mapperGetMeasurePoints;
/*     */   private String sqlGetGwMeasurePoints;
/*     */   private ResultMapper<MeasuredPoint> mapperGetGwMeasurePoints;
/*     */   private String sqlGetComRtuByRtua;
/*     */   private String sqlGetComGwRtuByRtua;
/*     */   private ResultMapper<ComRtu> mapperGetComRtu;
/*     */   private String sqlGetRtuTask;
/*     */   private String sqlGetGwRtuTask;
/*     */   private ResultMapper<RtuTask> mapperGetRtuTask;
/*     */   private String sqlGetTaskTemplate;
/*     */   private ResultMapper<TaskTemplate> mapperGetTaskTemplate;
/*     */   private String sqlGetTaskTemplateItem;
/*     */   private ResultMapper<TaskTemplateItem> mapperGetTaskTemplateItem;
/*     */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  51 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public List<MeasuredPoint> getMeasurePoints(String zdjh) {
/*  55 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public MeasuredPoint mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  57 */         return ((MeasuredPoint)JdbcRtuRefreshDao.this.mapperGetMeasurePoints.mapOneRow(rs));
/*     */       }
/*     */     };
/*  60 */     return this.simpleJdbcTemplate.query(this.sqlGetMeasurePoints, rm, new Object[] { zdjh });
/*     */   }
/*     */ 
/*     */   public List<MeasuredPoint> getGwMeasurePoints(String zdjh) {
/*  64 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public MeasuredPoint mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  66 */         return ((MeasuredPoint)JdbcRtuRefreshDao.this.mapperGetGwMeasurePoints.mapOneRow(rs));
/*     */       }
/*     */     };
/*  69 */     return this.simpleJdbcTemplate.query(this.sqlGetGwMeasurePoints, rm, new Object[] { zdjh });
/*     */   }
/*     */ 
/*     */   public BizRtu getRtu(String zdjh)
/*     */   {
/*     */     List mps;
/*     */     Iterator i$;
/*     */     MeasuredPoint mp;
/*  73 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public BizRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  75 */         return ((BizRtu)JdbcRtuRefreshDao.this.mapperGetRtu.mapOneRow(rs));
/*     */       }
/*     */     };
/*  78 */     BizRtu rtu = null;
/*     */     try {
/*  80 */       rtu = (BizRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetRtuByRtuId, rm, new Object[] { zdjh });
/*     */     } catch (Exception ex) {
/*     */     }
/*  83 */     if (rtu == null) {
/*  84 */       rtu = (BizRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetGwRtuByRtuId, rm, new Object[] { zdjh });
/*  85 */       if (rtu != null) {
/*  86 */         rtu.setRtuType("02");
/*     */ 
/*  88 */         mps = getGwMeasurePoints(zdjh);
/*  89 */         for (i$ = mps.iterator(); i$.hasNext(); ) { mp = (MeasuredPoint)i$.next();
/*  90 */           rtu.addMeasuredPoint(mp);
/*     */         }
/*     */       }
/*  93 */       List tasks = getGwRtuTasks(zdjh);
/*  94 */       for (RtuTask task : tasks)
/*  95 */         rtu.addRtuTask(task);
/*     */     }
/*     */     else {
/*  98 */       rtu.setRtuType("01");
/*     */ 
/* 100 */       mps = getMeasurePoints(zdjh);
/* 101 */       for (i$ = mps.iterator(); i$.hasNext(); ) { mp = (MeasuredPoint)i$.next();
/* 102 */         rtu.addMeasuredPoint(mp);
/*     */       }
/* 104 */       List tasks = getRtuTasks(zdjh);
/* 105 */       for (RtuTask task : tasks)
/* 106 */         rtu.addRtuTask(task);
/*     */     }
/* 108 */     if ((rtu != null) && (rtu.getRtuProtocol() == null))
/* 109 */       rtu.setRtuProtocol("01");
/* 110 */     return rtu;
/*     */   }
/*     */ 
/*     */   public BizRtu getRtu(int rtua)
/*     */   {
/*     */     List mps;
/*     */     Iterator i$;
/*     */     List tasks;
/*     */     MeasuredPoint mp;
/*     */     Iterator i$;
/*     */     RtuTask task;
/* 114 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public BizRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 116 */         return ((BizRtu)JdbcRtuRefreshDao.this.mapperGetRtu.mapOneRow(rs));
/*     */       }
/*     */     };
/* 119 */     BizRtu rtu = null;
/*     */     try {
/* 121 */       rtu = (BizRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetRtuByRtua, rm, new Object[] { HexDump.toHex(rtua) });
/*     */     } catch (Exception ex) {
/*     */     }
/* 124 */     if (rtu == null) {
/* 125 */       rtu = (BizRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetGwRtuByRtua, rm, new Object[] { HexDump.toHex(rtua) });
/* 126 */       if (rtu != null) {
/* 127 */         rtu.setRtuType("02");
/*     */ 
/* 129 */         mps = getMeasurePoints(rtu.getRtuId());
/* 130 */         for (i$ = mps.iterator(); i$.hasNext(); ) { mp = (MeasuredPoint)i$.next();
/* 131 */           rtu.addMeasuredPoint(mp);
/*     */         }
/* 133 */         tasks = getGwRtuTasks(rtu.getRtuId());
/* 134 */         for (i$ = tasks.iterator(); i$.hasNext(); ) { task = (RtuTask)i$.next();
/* 135 */           rtu.addRtuTask(task);
/*     */         }
/*     */       }
/*     */     } else {
/* 139 */       rtu.setRtuType("01");
/*     */ 
/* 141 */       mps = getMeasurePoints(rtu.getRtuId());
/* 142 */       for (tasks = mps.iterator(); tasks.hasNext(); ) { i$ = (MeasuredPoint)tasks.next();
/* 143 */         rtu.addMeasuredPoint(i$);
/*     */       }
/* 145 */       tasks = getRtuTasks(rtu.getRtuId());
/* 146 */       for (i$ = tasks.iterator(); i$.hasNext(); ) { task = (RtuTask)i$.next();
/* 147 */         rtu.addRtuTask(task); }
/*     */     }
/* 149 */     if ((rtu != null) && (rtu.getRtuProtocol() == null))
/* 150 */       rtu.setRtuProtocol("01");
/* 151 */     return rtu;
/*     */   }
/*     */ 
/*     */   public ComRtu getComRtu(int rtua) {
/* 155 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public ComRtu mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 157 */         return ((ComRtu)JdbcRtuRefreshDao.this.mapperGetComRtu.mapOneRow(rs));
/*     */       }
/*     */     };
/* 160 */     ComRtu rtu = null;
/*     */     try {
/* 162 */       rtu = (ComRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetComRtuByRtua, rm, new Object[] { HexDump.toHex(rtua) });
/*     */     } catch (Exception ex) {
/*     */     }
/* 165 */     if (rtu == null)
/* 166 */       rtu = (ComRtu)this.simpleJdbcTemplate.queryForObject(this.sqlGetComGwRtuByRtua, rm, new Object[] { HexDump.toHex(rtua) });
/* 167 */     return rtu;
/*     */   }
/*     */ 
/*     */   public List<RtuTask> getRtuTasks(String zdjh) {
/* 171 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public RtuTask mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 173 */         return ((RtuTask)JdbcRtuRefreshDao.this.mapperGetRtuTask.mapOneRow(rs));
/*     */       }
/*     */     };
/* 176 */     return this.simpleJdbcTemplate.query(this.sqlGetRtuTask, rm, new Object[] { zdjh }); }
/*     */ 
/*     */   public List<RtuTask> getGwRtuTasks(String zdjh) {
/* 179 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public RtuTask mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 181 */         return ((RtuTask)JdbcRtuRefreshDao.this.mapperGetRtuTask.mapOneRow(rs));
/*     */       }
/*     */     };
/* 184 */     return this.simpleJdbcTemplate.query(this.sqlGetGwRtuTask, rm, new Object[] { zdjh });
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplate(String templID) {
/* 188 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public TaskTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 190 */         return ((TaskTemplate)JdbcRtuRefreshDao.this.mapperGetTaskTemplate.mapOneRow(rs));
/*     */       }
/*     */     };
/* 193 */     return ((TaskTemplate)this.simpleJdbcTemplate.queryForObject(this.sqlGetTaskTemplate, rm, new Object[] { templID }));
/*     */   }
/*     */ 
/*     */   public List<TaskTemplateItem> getTaskTemplateItems(String templID) {
/* 197 */     ParameterizedRowMapper rm = new ParameterizedRowMapper() {
/*     */       public TaskTemplateItem mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 199 */         return ((TaskTemplateItem)JdbcRtuRefreshDao.this.mapperGetTaskTemplateItem.mapOneRow(rs));
/*     */       }
/*     */     };
/* 202 */     return this.simpleJdbcTemplate.query(this.sqlGetTaskTemplateItem, rm, new Object[] { templID });
/*     */   }
/*     */ 
/*     */   public void setMapperGetRtu(ResultMapper<BizRtu> mapperGetRtu)
/*     */   {
/* 208 */     this.mapperGetRtu = mapperGetRtu;
/*     */   }
/*     */ 
/*     */   public void setSqlGetMeasurePoints(String sqlGetMeasurePoints) {
/* 212 */     this.sqlGetMeasurePoints = sqlGetMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setMapperGetMeasurePoints(ResultMapper<MeasuredPoint> mapperGetMeasurePoints)
/*     */   {
/* 217 */     this.mapperGetMeasurePoints = mapperGetMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setSqlGetRtuTask(String sqlGetRtuTask) {
/* 221 */     this.sqlGetRtuTask = sqlGetRtuTask;
/*     */   }
/*     */ 
/*     */   public void setMapperGetRtuTask(ResultMapper<RtuTask> mapperGetRtuTask) {
/* 225 */     this.mapperGetRtuTask = mapperGetRtuTask;
/*     */   }
/*     */ 
/*     */   public void setSqlGetTaskTemplate(String sqlGetTaskTemplate) {
/* 229 */     this.sqlGetTaskTemplate = sqlGetTaskTemplate;
/*     */   }
/*     */ 
/*     */   public void setMapperGetTaskTemplate(ResultMapper<TaskTemplate> mapperGetTaskTemplate)
/*     */   {
/* 234 */     this.mapperGetTaskTemplate = mapperGetTaskTemplate;
/*     */   }
/*     */ 
/*     */   public void setSqlGetTaskTemplateItem(String sqlGetTaskTemplateItem) {
/* 238 */     this.sqlGetTaskTemplateItem = sqlGetTaskTemplateItem;
/*     */   }
/*     */ 
/*     */   public void setMapperGetTaskTemplateItem(ResultMapper<TaskTemplateItem> mapperGetTaskTemplateItem)
/*     */   {
/* 243 */     this.mapperGetTaskTemplateItem = mapperGetTaskTemplateItem;
/*     */   }
/*     */ 
/*     */   public void setSimpleJdbcTemplate(SimpleJdbcTemplate simpleJdbcTemplate) {
/* 247 */     this.simpleJdbcTemplate = simpleJdbcTemplate;
/*     */   }
/*     */ 
/*     */   public void setSqlGetRtuByRtuId(String sqlGetRtuByRtuId) {
/* 251 */     this.sqlGetRtuByRtuId = sqlGetRtuByRtuId;
/*     */   }
/*     */ 
/*     */   public void setSqlGetRtuByRtua(String sqlGetRtuByRtua) {
/* 255 */     this.sqlGetRtuByRtua = sqlGetRtuByRtua;
/*     */   }
/*     */ 
/*     */   public void setSqlGetComRtuByRtua(String sqlGetComRtuByRtua) {
/* 259 */     this.sqlGetComRtuByRtua = sqlGetComRtuByRtua;
/*     */   }
/*     */ 
/*     */   public void setMapperGetComRtu(ResultMapper<ComRtu> mapperGetComRtu) {
/* 263 */     this.mapperGetComRtu = mapperGetComRtu;
/*     */   }
/*     */ 
/*     */   public void setSqlGetGwRtuByRtuId(String sqlGetGwRtuByRtuId) {
/* 267 */     this.sqlGetGwRtuByRtuId = sqlGetGwRtuByRtuId;
/*     */   }
/*     */ 
/*     */   public void setSqlGetGwRtuByRtua(String sqlGetGwRtuByRtua) {
/* 271 */     this.sqlGetGwRtuByRtua = sqlGetGwRtuByRtua;
/*     */   }
/*     */ 
/*     */   public void setSqlGetGwRtuTask(String sqlGetGwRtuTask) {
/* 275 */     this.sqlGetGwRtuTask = sqlGetGwRtuTask;
/*     */   }
/*     */ 
/*     */   public void setSqlGetComGwRtuByRtua(String sqlGetComGwRtuByRtua) {
/* 279 */     this.sqlGetComGwRtuByRtua = sqlGetComGwRtuByRtua;
/*     */   }
/*     */ 
/*     */   public void setSqlGetGwMeasurePoints(String sqlGetGwMeasurePoints) {
/* 283 */     this.sqlGetGwMeasurePoints = sqlGetGwMeasurePoints;
/*     */   }
/*     */ 
/*     */   public void setMapperGetGwMeasurePoints(ResultMapper<MeasuredPoint> mapperGetGwMeasurePoints)
/*     */   {
/* 288 */     this.mapperGetGwMeasurePoints = mapperGetGwMeasurePoints;
/*     */   }
/*     */ }