/*    */ package com.hzjbbis.db.resultmap;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class ColumnMapper
/*    */ {
/*    */   private String property;
/*    */   private String column;
/*    */   private int index;
/*    */   public Method method;
/*    */ 
/*    */   public String getProperty()
/*    */   {
/* 19 */     return this.property; }
/*    */ 
/*    */   public void setProperty(String property) {
/* 22 */     this.property = property; }
/*    */ 
/*    */   public String getColumn() {
/* 25 */     return this.column; }
/*    */ 
/*    */   public void setColumn(String column) {
/* 28 */     this.column = column; }
/*    */ 
/*    */   public int getIndex() {
/* 31 */     return this.index; }
/*    */ 
/*    */   public void setIndex(int index) {
/* 34 */     this.index = index;
/*    */   }
/*    */ }