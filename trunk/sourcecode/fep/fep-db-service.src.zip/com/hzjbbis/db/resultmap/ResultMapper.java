/*     */ package com.hzjbbis.db.resultmap;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ResultMapper<T>
/*     */ {
/*  23 */   private static final Logger log = Logger.getLogger(ResultMapper.class);
/*     */   private String resultClass;
/*  26 */   private List<ColumnMapper> columnMapper = new ArrayList();
/*     */   private String columnSequence;
/*     */   private Class<T> resultClassObject;
/*     */ 
/*     */   public T mapOneRow(ResultSet rs)
/*     */   {
/*     */     try
/*     */     {
/*  33 */       Object dest = this.resultClassObject.newInstance();
/*  34 */       mapRow2Object(rs, dest);
/*  35 */       return dest;
/*     */     } catch (Exception exp) {
/*  37 */       log.error("把记录集行映射到对象异常：" + exp.getLocalizedMessage(), exp);
/*     */     }
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */   public List<T> mapAllRows(ResultSet rs)
/*     */   {
/*  49 */     List objList = new ArrayList();
/*     */     try {
/*  51 */       while (rs.next()) {
/*  52 */         Object result = mapOneRow(rs);
/*  53 */         if (result != null)
/*  54 */           objList.add(result);
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {
/*  58 */       log.error(e.getLocalizedMessage(), e);
/*     */     }
/*  60 */     return objList;
/*     */   }
/*     */ 
/*     */   private void mapRow2Object(ResultSet rs, T dest) throws SQLException, IllegalArgumentException, IllegalAccessException
/*     */   {
/*     */     try {
/*  66 */       for (Iterator localIterator = this.columnMapper.iterator(); localIterator.hasNext(); )
/*     */       {
/*     */         Class clz;
/*  66 */         ColumnMapper item = (ColumnMapper)localIterator.next();
/*  67 */         int index = item.getIndex();
/*  68 */         if (index > 0) {
/*  69 */           clz = item.method.getParameterTypes()[0];
/*  70 */           if (clz == String.class) {
/*  71 */             item.method.invoke(dest, new Object[] { rs.getString(index) });
/*     */           }
/*  73 */           else if ((clz == Integer.TYPE) || (clz == Integer.class)) {
/*  74 */             item.method.invoke(dest, new Object[] { Integer.valueOf(rs.getInt(index)) });
/*     */           }
/*  76 */           else if ((clz == Long.TYPE) || (clz == Long.class)) {
/*  77 */             item.method.invoke(dest, new Object[] { Long.valueOf(rs.getLong(index)) });
/*     */           }
/*  79 */           else if (clz == Date.class) {
/*  80 */             item.method.invoke(dest, new Object[] { rs.getDate(index) });
/*     */           }
/*  82 */           else if ((clz == Short.TYPE) || (clz == Short.class)) {
/*  83 */             item.method.invoke(dest, new Object[] { Short.valueOf(rs.getShort(index)) });
/*     */           }
/*  85 */           else if ((clz == Byte.TYPE) || (clz == Byte.class)) {
/*  86 */             item.method.invoke(dest, new Object[] { Byte.valueOf(rs.getByte(index)) });
/*     */           }
/*  88 */           else if ((clz == Character.TYPE) || (clz == Character.class)) {
/*  89 */             item.method.invoke(dest, new Object[] { Character.valueOf((char)rs.getByte(index)) });
/*     */           }
/*  91 */           else if ((clz == Boolean.TYPE) || (clz == Boolean.class)) {
/*  92 */             item.method.invoke(dest, new Object[] { Boolean.valueOf(rs.getBoolean(index)) });
/*     */           }
/*  94 */           else if ((clz == Double.TYPE) || (clz == Double.class))
/*  95 */             item.method.invoke(dest, new Object[] { Double.valueOf(rs.getDouble(index)) });
/*     */           else
/*     */             try
/*     */             {
/*  99 */               item.method.invoke(dest, new Object[] { rs.getString(index) });
/*     */             } catch (Exception exp) {
/* 101 */               log.warn("对象属性不能设置[" + item.getProperty() + "]，转换类型错误:" + exp.getLocalizedMessage(), exp);
/*     */             }
/*     */         }
/*     */         else
/*     */         {
/* 106 */           clz = item.method.getParameterTypes()[0];
/* 107 */           String column = item.getColumn();
/* 108 */           if (clz == String.class) {
/* 109 */             item.method.invoke(dest, new Object[] { rs.getString(column) });
/*     */           }
/* 111 */           else if ((clz == Integer.TYPE) || (clz == Integer.class)) {
/* 112 */             item.method.invoke(dest, new Object[] { Integer.valueOf(rs.getInt(column)) });
/*     */           }
/* 114 */           else if ((clz == Long.TYPE) || (clz == Long.class)) {
/* 115 */             item.method.invoke(dest, new Object[] { Long.valueOf(rs.getLong(column)) });
/*     */           }
/* 117 */           else if (clz == Date.class) {
/* 118 */             item.method.invoke(dest, new Object[] { rs.getDate(column) });
/*     */           }
/* 120 */           else if ((clz == Short.TYPE) || (clz == Short.class)) {
/* 121 */             item.method.invoke(dest, new Object[] { Short.valueOf(rs.getShort(column)) });
/*     */           }
/* 123 */           else if ((clz == Byte.TYPE) || (clz == Byte.class)) {
/* 124 */             item.method.invoke(dest, new Object[] { Byte.valueOf(rs.getByte(column)) });
/*     */           }
/* 126 */           else if ((clz == Character.TYPE) || (clz == Character.class)) {
/* 127 */             item.method.invoke(dest, new Object[] { Character.valueOf((char)rs.getByte(column)) });
/*     */           }
/* 129 */           else if ((clz == Boolean.TYPE) || (clz == Boolean.class)) {
/* 130 */             item.method.invoke(dest, new Object[] { Boolean.valueOf(rs.getBoolean(column)) });
/*     */           }
/* 132 */           else if ((clz == Double.TYPE) || (clz == Double.class))
/* 133 */             item.method.invoke(dest, new Object[] { Double.valueOf(rs.getDouble(column)) });
/*     */           else
/*     */             try
/*     */             {
/* 137 */               item.method.invoke(dest, new Object[] { rs.getString(column) });
/*     */             } catch (Exception exp) {
/* 139 */               log.warn("对象属性不能设置[" + item.getProperty() + "]，转换类型错误:" + exp.getLocalizedMessage(), exp);
/*     */             }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (InvocationTargetException exp)
/*     */     {
/* 146 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getResultClass() {
/* 151 */     return this.resultClass;
/*     */   }
/*     */ 
/*     */   public void setResultClass(String resultClass) {
/* 155 */     this.resultClass = resultClass;
/* 156 */     if (this.columnMapper != null)
/* 157 */       populateMethod();
/*     */   }
/*     */ 
/*     */   public List<ColumnMapper> getColumnMapper()
/*     */   {
/* 162 */     return this.columnMapper;
/*     */   }
/*     */ 
/*     */   public void setColumnMapper(List<ColumnMapper> columnMapper) {
/* 166 */     this.columnMapper = columnMapper;
/* 167 */     if ((this.resultClass != null) && (this.resultClass.length() > 1))
/* 168 */       populateMethod();
/*     */   }
/*     */ 
/*     */   private void populateMethod()
/*     */   {
/*     */     try
/*     */     {
/* 178 */       this.resultClassObject = Class.forName(this.resultClass);
/* 179 */       Method[] allMethods = this.resultClassObject.getMethods();
/* 180 */       Map methods = new HashMap();
/* 181 */       for (Method m : allMethods) {
/* 182 */         if (m.getName().startsWith("set"))
/* 183 */           methods.put(m.getName(), m);
/*     */       }
/* 185 */       for (ColumnMapper column : this.columnMapper) {
/* 186 */         String name = column.getProperty();
/* 187 */         name = "set" + name.substring(0, 1).toUpperCase() + name.substring(1);
/* 188 */         Method method = (Method)methods.get(name);
/* 189 */         if (method == null) {
/* 190 */           String errInfo = "JdbcBaseDao的对象属性与记录集对应关系配置项错误，属性不存在:" + column.getProperty();
/* 191 */           log.error(errInfo);
/* 192 */           throw new RuntimeException(errInfo);
/*     */         }
/* 194 */         column.method = method;
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException exp) {
/* 198 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */     catch (LinkageError exp) {
/* 201 */       log.error(exp.getLocalizedMessage(), exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setColumnSequence(String columnSequence) {
/* 206 */     this.columnSequence = columnSequence;
/* 207 */     this.columnSequence.trim();
/* 208 */     String[] cols = this.columnSequence.split(",");
/* 209 */     int index = 1;
/* 210 */     for (String cstr : cols) {
/* 211 */       cstr = StringUtils.strip(cstr);
/* 212 */       if (cstr.length() == 0)
/*     */         continue;
/* 214 */       ColumnMapper cm = new ColumnMapper();
/* 215 */       cm.setProperty(cstr);
/* 216 */       cm.setIndex(index++);
/* 217 */       this.columnMapper.add(cm);
/*     */     }
/*     */ 
/* 220 */     if ((this.resultClass != null) && (this.resultClass.length() > 1))
/* 221 */       populateMethod();
/*     */   }
/*     */ }