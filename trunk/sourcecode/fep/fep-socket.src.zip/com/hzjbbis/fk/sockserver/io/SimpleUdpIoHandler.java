/*     */ package com.hzjbbis.fk.sockserver.io;
/*     */ 
/*     */ import com.hzjbbis.fk.FasSystem;
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.exception.MessageParseException;
/*     */ import com.hzjbbis.fk.exception.SocketClientCloseException;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SimpleUdpIoHandler
/*     */   implements IClientIO
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(SimpleUdpIoHandler.class);
/*     */ 
/*     */   public boolean onSend(IServerSideChannel client) throws SocketClientCloseException
/*     */   {
/*  32 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean onReceive(IServerSideChannel client)
/*     */     throws SocketClientCloseException
/*     */   {
/*  41 */     ByteBuffer buf = client.getBufRead();
/*  42 */     while (buf.hasRemaining()) {
/*  43 */       IMessage msg = client.getCurReadingMsg();
/*  44 */       if (msg == null)
/*     */       {
/*  46 */         int rem1 = buf.remaining();
/*  47 */         msg = client.getServer().createMessage(buf);
/*  48 */         int rem2 = buf.remaining();
/*  49 */         if (msg == null) {
/*  50 */           if ((rem1 > 13) && (rem1 == rem2))
/*     */           {
/*  53 */             String info = "消息对象类型配置错误,UDP server port=" + client.getServer().getPort();
/*  54 */             log.fatal(info);
/*  55 */             buf.clear();
/*  56 */             throw new SocketClientCloseException(info);
/*     */           }
/*     */ 
/*  59 */           if (buf.hasRemaining())
/*  60 */             buf.compact();
/*     */           else
/*  62 */             buf.clear();
/*  63 */           return true;
/*     */         }
/*     */ 
/*  67 */         client.setCurReadingMsg(msg);
/*  68 */         msg.setSource(client);
/*  69 */         msg.setServerAddress(client.getServer().getServerAddress());
/*     */       }
/*  71 */       boolean down = false;
/*     */       try {
/*  73 */         down = msg.read(buf);
/*     */       } catch (MessageParseException mpe) {
/*  75 */         String expInfo = mpe.getLocalizedMessage();
/*     */ 
/*  77 */         if (FasSystem.getFasSystem().isTestMode()) {
/*  78 */           SocketAddress sa = client.getSocketAddress();
/*  79 */           if (sa == null)
/*  80 */             return false;
/*  81 */           byte[] expBytes = expInfo.getBytes();
/*     */           try {
/*  83 */             DatagramSocket ds = new DatagramSocket();
/*  84 */             DatagramPacket dp = new DatagramPacket(expBytes, expBytes.length, sa);
/*  85 */             ds.send(dp);
/*     */           } catch (Exception e) {
/*  87 */             log.warn("测试模式下UDP应答异常:" + e.getLocalizedMessage(), e);
/*     */           }
/*     */         }
/*     */ 
/*  91 */         client.setCurReadingMsg(null);
/*  92 */         return false;
/*     */       }
/*  94 */       if (!(down)) break;
/*  95 */       client.setCurReadingMsg(null);
/*  96 */       msg.setIoTime(System.currentTimeMillis());
/*  97 */       msg.setPeerAddr(client.getPeerAddr());
/*  98 */       msg.setTxfs(client.getServer().getTxfs());
/*  99 */       ReceiveMessageEvent ev = new ReceiveMessageEvent(msg, client);
/* 100 */       GlobalEventHandler.postEvent(ev);
/*     */     }
/*     */ 
/* 107 */     if (buf.hasRemaining())
/* 108 */       buf.compact();
/*     */     else
/* 110 */       buf.clear();
/* 111 */     return true;
/*     */   }
/*     */ }