/*     */ package com.hzjbbis.fk.sockserver;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.sockserver.event.MessageSendFailEvent;
/*     */ import com.hzjbbis.fk.sockserver.io.SocketIoThread;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class AsyncSocketClient
/*     */   implements IServerSideChannel
/*     */ {
/*     */   protected SocketChannel channel;
/*     */   protected String peerIp;
/*     */   protected int peerPort;
/*     */   protected String peerAddr;
/*     */   protected String localIp;
/*     */   protected int localPort;
/*     */   protected String localAddr;
/*     */   protected ByteBuffer bufRead;
/*     */   protected ByteBuffer bufWrite;
/*     */   protected IMessage curReadingMsg;
/*     */   protected IMessage curWritingMsg;
/*  43 */   protected List<IMessage> sendList = new LinkedList();
/*     */ 
/*  46 */   private int lastingWrite = 0;
/*     */ 
/*  49 */   private static final Logger log = Logger.getLogger(AsyncSocketClient.class);
/*     */   protected ISocketServer server;
/*     */   protected SocketIoThread ioThread;
/*  52 */   private int intKey = 0;
/*  53 */   private int maxSendQueueSize = 20;
/*     */ 
/*  56 */   private long lastIoTime = System.currentTimeMillis();
/*  57 */   private long lastReadTime = System.currentTimeMillis();
/*  58 */   private boolean bufferHasRemaining = false;
/*     */ 
/*  61 */   private int requestNum = -1;
/*     */ 
/*     */   public AsyncSocketClient() { }
/*     */ 
/*     */   public AsyncSocketClient(SocketChannel c, ISocketServer s) {
/*  66 */     this.channel = c;
/*  67 */     this.server = s;
/*     */     try {
/*  69 */       this.peerIp = this.channel.socket().getInetAddress().getHostAddress();
/*  70 */       this.peerPort = this.channel.socket().getPort();
/*  71 */       this.peerAddr = this.peerIp + ":" + this.peerPort + ":T";
/*  72 */       this.localIp = this.channel.socket().getLocalAddress().getHostAddress();
/*  73 */       this.localPort = this.channel.socket().getLocalPort();
/*  74 */       this.localAddr = this.localIp + ":" + 
/*  75 */         HexDump.toHex((short)this.localPort); } catch (Exception localException) {
/*     */     }
/*  77 */     this.bufRead = ByteBuffer.allocateDirect(s.getBufLength());
/*  78 */     this.bufWrite = ByteBuffer.allocateDirect(s.getBufLength());
/*     */   }
/*     */ 
/*     */   public boolean send(IMessage msg) {
/*  82 */     if (this.sendList.size() >= this.maxSendQueueSize) {
/*  83 */       log.warn(toString() + "-发送队列长度>maxSendQueueSize，本消息被丢弃");
/*     */ 
/*  85 */       GlobalEventHandler.postEvent(new MessageSendFailEvent(msg, this));
/*  86 */       return false;
/*     */     }
/*  88 */     synchronized (this.sendList) {
/*  89 */       if (this.requestNum > 0) {
/*  90 */         synchronized (this) {
/*  91 */           this.requestNum -= 1;
/*     */         }
/*     */       }
/*  94 */       this.sendList.add(msg);
/*     */     }
/*  96 */     this.ioThread.clientWriteRequest(this);
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   public int sendQueueSize() {
/* 101 */     synchronized (this.sendList) {
/* 102 */       return this.sendList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxSendQueueSize(int maxSendQueueSize) {
/* 107 */     this.maxSendQueueSize = maxSendQueueSize;
/*     */   }
/*     */ 
/*     */   public IMessage getNewSendMessage() {
/* 111 */     synchronized (this.sendList) {
/* 112 */       if (this.sendList.size() == 0)
/* 113 */         return null;
/* 114 */       return ((IMessage)this.sendList.remove(0));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */     try
/*     */     {
/* 123 */       this.channel.socket().shutdownInput();
/* 124 */       this.channel.socket().shutdownOutput();
/*     */     } catch (Exception localException) {
/*     */     }
/*     */     try {
/* 128 */       this.channel.close();
/* 129 */       this.channel = null;
/*     */     }
/*     */     catch (Exception localException1) {
/*     */     }
/* 133 */     if (log.isInfoEnabled()) {
/* 134 */       log.info("客户端关闭[" + this.peerIp + ":" + this.peerPort + ",localport:" + this.localPort + "]");
/*     */     }
/*     */ 
/* 137 */     synchronized (this.sendList) {
/* 138 */       for (IMessage msg : this.sendList) {
/* 139 */         GlobalEventHandler.postEvent(new MessageSendFailEvent(msg, this));
/*     */       }
/* 141 */       this.sendList.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public SocketChannel getChannel() {
/* 146 */     return this.channel;
/*     */   }
/*     */ 
/*     */   public SocketAddress getSocketAddress() {
/* 150 */     return this.channel.socket().getRemoteSocketAddress();
/*     */   }
/*     */ 
/*     */   public void setChannel(SocketChannel channel) {
/* 154 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   public String getPeerIp() {
/* 158 */     return this.peerIp;
/*     */   }
/*     */ 
/*     */   public void setPeerIp(String peerIp) {
/* 162 */     this.peerIp = peerIp;
/*     */   }
/*     */ 
/*     */   public int getPeerPort() {
/* 166 */     return this.peerPort;
/*     */   }
/*     */ 
/*     */   public void setPeerPort(int peerPort) {
/* 170 */     this.peerPort = peerPort;
/*     */   }
/*     */ 
/*     */   public String getLocalIp() {
/* 174 */     return this.localIp;
/*     */   }
/*     */ 
/*     */   public void setLocalIp(String localIp) {
/* 178 */     this.localIp = localIp;
/*     */   }
/*     */ 
/*     */   public String getLocalAddr() {
/* 182 */     return this.localAddr;
/*     */   }
/*     */ 
/*     */   public void setLocalAddr(String localAddr) {
/* 186 */     this.localAddr = localAddr;
/*     */   }
/*     */ 
/*     */   public final SocketIoThread getIoThread() {
/* 190 */     return this.ioThread;
/*     */   }
/*     */ 
/*     */   public void setIoThread(Object ioThread) {
/* 194 */     this.ioThread = ((SocketIoThread)ioThread);
/*     */   }
/*     */ 
/*     */   public ISocketServer getServer() {
/* 198 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(TcpSocketServer server) {
/* 202 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void closeRequest() {
/* 206 */     this.ioThread.closeClientRequest(this);
/*     */   }
/*     */ 
/*     */   public IMessage getCurReadingMsg() {
/* 210 */     return this.curReadingMsg;
/*     */   }
/*     */ 
/*     */   public void setCurReadingMsg(IMessage curReadingMsg) {
/* 214 */     this.curReadingMsg = curReadingMsg;
/* 215 */     if (curReadingMsg != null)
/* 216 */       this.server.incRecvMessage();
/*     */   }
/*     */ 
/*     */   public IMessage getCurWritingMsg() {
/* 220 */     return this.curWritingMsg;
/*     */   }
/*     */ 
/*     */   public void setCurWritingMsg(IMessage curWritingMsg) {
/* 224 */     this.curWritingMsg = curWritingMsg;
/* 225 */     if (curWritingMsg != null)
/* 226 */       this.server.incSendMessage();
/*     */   }
/*     */ 
/*     */   public ByteBuffer getBufRead() {
/* 230 */     return this.bufRead;
/*     */   }
/*     */ 
/*     */   public ByteBuffer getBufWrite() {
/* 234 */     return this.bufWrite;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 238 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public int getIntKey() {
/* 242 */     return this.intKey;
/*     */   }
/*     */ 
/*     */   public void setIntKey(int intKey) {
/* 246 */     this.intKey = intKey;
/*     */   }
/*     */ 
/*     */   public final String getPeerAddr() {
/* 250 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public long getLastIoTime() {
/* 254 */     return this.lastIoTime;
/*     */   }
/*     */ 
/*     */   public long getLastReadTime() {
/* 258 */     return this.lastReadTime;
/*     */   }
/*     */ 
/*     */   public void setLastIoTime() {
/* 262 */     this.lastIoTime = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public void setLastReadTime() {
/* 266 */     this.lastReadTime = System.currentTimeMillis();
/* 267 */     this.lastIoTime = this.lastReadTime;
/*     */   }
/*     */ 
/*     */   public int getLastingWrite() {
/* 271 */     return this.lastingWrite;
/*     */   }
/*     */ 
/*     */   public void setLastingWrite(int lastingWrite) {
/* 275 */     this.lastingWrite = lastingWrite;
/*     */   }
/*     */ 
/*     */   public int getLocalPort() {
/* 279 */     return this.localPort;
/*     */   }
/*     */ 
/*     */   public void setLocalPort(int localPort) {
/* 283 */     this.localPort = localPort;
/*     */   }
/*     */ 
/*     */   public int getRequestNum() {
/* 287 */     return this.requestNum;
/*     */   }
/*     */ 
/*     */   public void setRequestNum(int requestNum) {
/* 291 */     synchronized (this) {
/* 292 */       this.requestNum = requestNum;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean bufferHasRemaining() {
/* 297 */     return this.bufferHasRemaining;
/*     */   }
/*     */ 
/*     */   public void setBufferHasRemaining(boolean hasRemaining) {
/* 301 */     this.bufferHasRemaining = hasRemaining;
/*     */   }
/*     */ }