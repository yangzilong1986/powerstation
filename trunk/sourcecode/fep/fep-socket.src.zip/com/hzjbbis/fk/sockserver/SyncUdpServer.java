/*     */ package com.hzjbbis.fk.sockserver;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IModule;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseSocketServer;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.sockserver.event.ModuleProfileEvent;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.AsynchronousCloseException;
/*     */ import java.nio.channels.ClosedByInterruptException;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SyncUdpServer extends BaseSocketServer
/*     */   implements IModule, ITimerFunctor
/*     */ {
/*  36 */   private static final Logger log = Logger.getLogger(SyncUdpServer.class);
/*     */ 
/*  39 */   private boolean oneIpLimit = false;
/*     */ 
/*  42 */   private volatile State state = State.STOPPED;
/*     */   private DatagramChannel dgc;
/*  44 */   private Object channelLock = new Object();
/*  45 */   private boolean channelReady = false;
/*     */   private UdpIoThread ioThread;
/*  47 */   private ByteBuffer readBuffer = null; private ByteBuffer writeBuffer = null;
/*     */ 
/*  50 */   private final HashMap<String, UdpClient> clients = new HashMap(5120);
/*     */ 
/*     */   public String getModuleType()
/*     */   {
/*  56 */     return "socketServer";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  60 */     return this.state.isActive();
/*     */   }
/*     */ 
/*     */   public boolean send(IMessage msg, UdpClient client)
/*     */   {
/*     */     Object Ljava/lang/Object;;
/*  70 */     monitorenter;
/*     */     try {
/*  72 */       SocketAddress sa = client.getSocketAddress();
/*  73 */       this.writeBuffer.clear();
/*  74 */       msg.write(this.writeBuffer);
/*  75 */       this.writeBuffer.flip();
/*  76 */       this.dgc.send(this.writeBuffer, sa);
/*  77 */       client.setLastIoTime();
/*  78 */       return true;
/*     */     } catch (Exception e) {
/*  80 */       log.error("UDP[" + this.port + "]发送报文异常:" + e.getLocalizedMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/*  70 */       monitorexit;
/*     */     }
/*     */ 
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean start() {
/*  87 */     if (this.state.isActive())
/*  88 */       return false;
/*  89 */     this.state = State.STARTING;
/*  90 */     this.readBuffer = ByteBuffer.allocateDirect(this.bufLength);
/*  91 */     this.writeBuffer = ByteBuffer.allocateDirect(this.bufLength);
/*     */ 
/*  94 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 60L));
/*  95 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 1, this.timeout));
/*     */     try
/*     */     {
/*  99 */       this.ioThread = new UdpIoThread();
/* 100 */       this.ioThread.start();
/* 101 */       while (this.state != State.RUNNING)
/*     */       {
/* 103 */         Thread.yield();
/* 104 */         Thread.sleep(10L);
/*     */       }
/*     */     } catch (Exception exp) {
/* 107 */       log.fatal(exp.getLocalizedMessage());
/* 108 */       return false;
/*     */     }
/* 110 */     if (log.isInfoEnabled())
/* 111 */       log.info("UDP服务【" + this.port + "】已经启动!");
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   public void onTimer(int timerID) {
/* 116 */     if (timerID == 0) {
/* 117 */       long now = System.currentTimeMillis();
/* 118 */       if ((now - this.lastReceiveTime < 60000L) || (now - this.lastSendTime < 60000L))
/* 119 */         GlobalEventHandler.postEvent(new ModuleProfileEvent(this));
/* 120 */       this.msgRecvPerMinute = 0; this.msgSendPerMinute = 0;
/*     */     }
/* 122 */     else if (1 == timerID) {
/* 123 */       ArrayList list = new ArrayList(this.clients.values());
/* 124 */       long now = System.currentTimeMillis();
/* 125 */       for (UdpClient client : list)
/* 126 */         if (now - client.getLastReadTime() > this.timeout * 1000)
/* 127 */           synchronized (this.clients) {
/* 128 */             String clientKey = client.getPeerIp() + ":" + client.getPeerPort();
/* 129 */             if (this.oneIpLimit)
/* 130 */               clientKey = client.getPeerIp();
/* 131 */             this.clients.remove(clientKey);
/*     */           }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean openChannel()
/*     */   {
/* 139 */     synchronized (this.channelLock) {
/*     */       try {
/* 141 */         this.dgc = DatagramChannel.open();
/* 142 */         this.dgc.socket().setReceiveBufferSize(this.bufLength);
/* 143 */         this.dgc.socket().setSendBufferSize(this.bufLength);
/* 144 */         this.dgc.socket().setReuseAddress(true);
/* 145 */         this.dgc.configureBlocking(true);
/* 146 */         InetSocketAddress addr = null;
/* 147 */         if (this.ip == null)
/* 148 */           addr = new InetSocketAddress(this.port);
/*     */         else
/* 150 */           addr = new InetSocketAddress(this.ip, this.port);
/* 151 */         this.dgc.socket().bind(addr);
/*     */       } catch (Exception exp) {
/* 153 */         log.fatal("UDP服务器启动失败[" + this.port + "]", exp);
/* 154 */         this.channelReady = false;
/*     */       }
/* 156 */       this.channelReady = true;
/* 157 */       return this.channelReady;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void closeChannel() {
/* 162 */     synchronized (this.channelLock) {
/*     */       try {
/* 164 */         if (this.dgc == null) break label22;
/* 165 */         label22: this.dgc.close();
/*     */       } catch (IOException e) {
/* 167 */         log.warn(e.getMessage());
/*     */       } finally {
/* 169 */         this.dgc = null;
/*     */       }
/* 171 */       this.channelReady = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 176 */     this.state = State.STOPPING;
/* 177 */     if (this.ioThread != null) {
/* 178 */       this.ioThread.interrupt();
/*     */       try {
/* 180 */         if (this.ioThread.isAlive())
/* 181 */           this.ioThread.join(200L); 
/*     */       } catch (InterruptedException localInterruptedException) {
/*     */       }
/* 183 */       this.ioThread = null;
/*     */     }
/*     */ 
/* 186 */     this.readBuffer = null; this.writeBuffer = null;
/*     */ 
/* 188 */     TimerScheduler.getScheduler().removeTimer(this, 0);
/* 189 */     TimerScheduler.getScheduler().removeTimer(this, 1);
/*     */ 
/* 191 */     if (log.isInfoEnabled())
/* 192 */       log.info("UDP服务器[" + this.port + "] 停止运行！");
/* 193 */     this.state = State.STOPPED;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 291 */     StringBuffer sb = new StringBuffer();
/* 292 */     sb.append("S-UDP[").append(this.port).append("]");
/* 293 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isOneIpLimit() {
/* 297 */     return this.oneIpLimit;
/*     */   }
/*     */ 
/*     */   public void setOneIpLimit(boolean oneIpLimit) {
/* 301 */     this.oneIpLimit = oneIpLimit;
/*     */   }
/*     */ 
/*     */   public int getClientSize() {
/* 305 */     synchronized (this.clients) {
/* 306 */       return this.clients.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IServerSideChannel[] getClients()
/*     */   {
/* 314 */     synchronized (this.clients) {
/* 315 */       return ((IServerSideChannel[])this.clients.values().toArray(new IServerSideChannel[this.clients.size()]));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeClient(IServerSideChannel client) {
/* 320 */     synchronized (this.clients) {
/* 321 */       String clientKey = client.getPeerIp() + ":" + client.getPeerPort();
/* 322 */       if (this.oneIpLimit)
/* 323 */         clientKey = client.getPeerIp();
/* 324 */       this.clients.remove(clientKey);
/*     */     }
/* 326 */     super.removeClient(client);
/*     */   }
/*     */ 
/*     */   private class UdpIoThread extends Thread
/*     */   {
/*     */     public UdpIoThread()
/*     */     {
/* 198 */       super("UDP[" + SyncUdpServer.access$0(SyncUdpServer.this) + "]-IO-Thread");
/*     */     }
/*     */ 
/*     */     public void run() {
/* 202 */       if (SyncUdpServer.log.isDebugEnabled())
/* 203 */         SyncUdpServer.log.debug(getName() + "运行...");
/* 204 */       SyncUdpServer.this.state = State.RUNNING;
/* 205 */       while (SyncUdpServer.this.state != State.STOPPING)
/*     */       {
/* 208 */         if ((!(SyncUdpServer.this.channelReady)) && 
/* 209 */           (SyncUdpServer.this.openChannel() == 0))
/*     */         {
/* 211 */           SyncUdpServer.this.closeChannel();
/*     */           try {
/* 213 */             Thread.sleep(60000L);
/*     */           } catch (Exception localException1) {
/*     */           }
/*     */         }
/*     */         else {
/*     */           try {
/* 219 */             drainChannel();
/*     */           }
/*     */           catch (ClosedByInterruptException exp) {
/* 222 */             SyncUdpServer.log.error("UDP服务器[" + SyncUdpServer.access$0(SyncUdpServer.this) + "]接收数据异常:" + exp.getLocalizedMessage(), exp);
/* 223 */             Thread.interrupted();
/* 224 */             SyncUdpServer.this.closeChannel();
/*     */           }
/*     */           catch (AsynchronousCloseException exp)
/*     */           {
/* 228 */             SyncUdpServer.log.error("UDP服务器[" + SyncUdpServer.access$0(SyncUdpServer.this) + "]接收数据异常:" + exp.getLocalizedMessage(), exp);
/* 229 */             Thread.interrupted();
/* 230 */             SyncUdpServer.this.closeChannel();
/*     */           }
/*     */           catch (ClosedChannelException exp)
/*     */           {
/* 234 */             SyncUdpServer.log.error("UDP服务器[" + SyncUdpServer.access$0(SyncUdpServer.this) + "]接收数据异常:" + exp.getLocalizedMessage(), exp);
/* 235 */             Thread.interrupted();
/* 236 */             SyncUdpServer.this.closeChannel();
/*     */           }
/*     */           catch (Exception exp) {
/* 239 */             SyncUdpServer.log.error("UDP服务器[" + SyncUdpServer.access$0(SyncUdpServer.this) + "]接收数据异常:" + exp.getLocalizedMessage(), exp); }
/*     */         }
/*     */       }
/* 242 */       SyncUdpServer.this.closeChannel();
/* 243 */       SyncUdpServer.this.state = State.STOPPED;
/*     */     }
/*     */ 
/*     */     void drainChannel() throws Exception
/*     */     {
/* 248 */       SyncUdpServer.this.readBuffer.clear();
/* 249 */       SocketAddress sa = SyncUdpServer.this.dgc.receive(SyncUdpServer.this.readBuffer);
/* 250 */       if (sa == null) {
/* 251 */         SyncUdpServer.log.error("UDP服务器接收数据异常，dgc.receive(readBuffer)返回NULL");
/* 252 */         return;
/*     */       }
/* 254 */       if (SyncUdpServer.this.readBuffer.position() == 0) {
/* 255 */         return;
/*     */       }
/*     */ 
/* 258 */       SyncUdpServer.this.readBuffer.flip();
/*     */ 
/* 264 */       String peerip = ((InetSocketAddress)sa).getAddress().getHostAddress();
/* 265 */       int port = ((InetSocketAddress)sa).getPort();
/* 266 */       String key = peerip;
/* 267 */       if (!(SyncUdpServer.this.oneIpLimit))
/* 268 */         key = key + ":" + port;
/* 269 */       UdpClient client = (UdpClient)SyncUdpServer.this.clients.get(key);
/* 270 */       if (client == null) {
/* 271 */         client = new UdpClient(sa, SyncUdpServer.this);
/* 272 */         synchronized (SyncUdpServer.this.clients) {
/* 273 */           SyncUdpServer.this.clients.put(key, client);
/*     */         }
/*     */       }
/* 276 */       if (SyncUdpServer.log.isDebugEnabled()) {
/* 277 */         SyncUdpServer.log.debug("UDP-" + port + "-收到[" + sa.toString() + "]上行报文:" + HexDump.hexDump(SyncUdpServer.this.readBuffer));
/*     */       }
/*     */ 
/* 280 */       if (client.getBufRead().remaining() < SyncUdpServer.this.readBuffer.remaining())
/* 281 */         client.getBufRead().clear();
/* 282 */       client.getBufRead().put(SyncUdpServer.this.readBuffer);
/* 283 */       client.getBufRead().flip();
/* 284 */       client.setLastReadTime();
/* 285 */       client.getServer().setLastReceiveTime(System.currentTimeMillis());
/* 286 */       SyncUdpServer.access$11(SyncUdpServer.this).onReceive(client);
/*     */     }
/*     */   }
/*     */ }