/*    */ package com.hzjbbis.fk.sockserver.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.sockserver.event.AcceptEvent;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class AcceptEventAdapt
/*    */   implements IEventHandler
/*    */ {
/* 17 */   private static final Logger log = Logger.getLogger(AcceptEventAdapt.class);
/*    */   private AcceptEvent event;
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 21 */     this.event = ((AcceptEvent)event);
/* 22 */     process();
/*    */   }
/*    */ 
/*    */   protected void process() {
/* 26 */     if (log.isInfoEnabled())
/* 27 */       log.info("server[" + this.event.getServer().getPort() + "] accept client[" + this.event.getClient().getPeerIp() + "]");
/*    */   }
/*    */ }