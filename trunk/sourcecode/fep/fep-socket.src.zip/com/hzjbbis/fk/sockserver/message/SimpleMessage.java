/*     */ package com.hzjbbis.fk.sockserver.message;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.sockserver.AsyncSocketClient;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class SimpleMessage
/*     */   implements IMessage
/*     */ {
/*  19 */   private MessageType type = MessageType.MSG_SAMPLE;
/*     */   private AsyncSocketClient client;
/*  21 */   private int priority = 0;
/*     */   private byte[] input;
/*     */   private byte[] output;
/*  23 */   private int offset = 0;
/*     */   private long ioTime;
/*     */   private String peerAddr;
/*     */   private String serverAddress;
/*  27 */   private String txfs = "";
/*     */ 
/*     */   public MessageType getMessageType() {
/*  30 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean read(ByteBuffer readBuffer) {
/*  34 */     if (!(readBuffer.hasRemaining()))
/*  35 */       return false;
/*  36 */     this.input = new byte[readBuffer.remaining()];
/*  37 */     readBuffer.get(this.input);
/*  38 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer writeBuffer) {
/*  42 */     if ((this.output == null) || (this.output.length == 0))
/*  43 */       return true;
/*  44 */     int minLength = Math.min(this.output.length - this.offset, writeBuffer.remaining());
/*  45 */     writeBuffer.put(this.output, this.offset, minLength);
/*  46 */     this.offset += minLength;
/*  47 */     return (this.offset != this.output.length);
/*     */   }
/*     */ 
/*     */   public byte[] getOutput() {
/*  51 */     return this.output;
/*     */   }
/*     */ 
/*     */   public void setOutput(byte[] output) {
/*  55 */     this.output = output;
/*     */   }
/*     */ 
/*     */   public byte[] getInput() {
/*  59 */     return this.input;
/*     */   }
/*     */ 
/*     */   public IChannel getSource() {
/*  63 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setSource(IChannel src) {
/*  67 */     this.client = ((AsyncSocketClient)src);
/*     */   }
/*     */ 
/*     */   public long getIoTime() {
/*  71 */     return this.ioTime;
/*     */   }
/*     */ 
/*     */   public void setIoTime(long ioTime) {
/*  75 */     this.ioTime = ioTime;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/*  79 */     return this.peerAddr;
/*     */   }
/*     */ 
/*     */   public void setPeerAddr(String peerAddr) {
/*  83 */     this.peerAddr = peerAddr;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  87 */     StringBuffer sb = new StringBuffer(1024);
/*  88 */     boolean empty = true;
/*  89 */     if (this.output != null) {
/*  90 */       sb.append("下行消息:");
/*  91 */       sb.append(HexDump.hexDumpCompact(this.output, 0, this.output.length));
/*  92 */       empty = false;
/*     */     }
/*  94 */     else if (this.input != null) {
/*  95 */       sb.append("上行消息:");
/*  96 */       sb.append(HexDump.hexDumpCompact(this.input, 0, this.input.length));
/*     */ 
/*  98 */       empty = false;
/*     */     }
/* 100 */     if (empty)
/* 101 */       sb.append("空消息");
/* 102 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/* 106 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority) {
/* 110 */     if (priority > 5)
/* 111 */       priority = 5;
/* 112 */     else if (priority < 0)
/* 113 */       priority = 0;
/* 114 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public String getRawPacketString()
/*     */   {
/* 119 */     return HexDump.hexDumpCompact(this.input, 0, this.input.length);
/*     */   }
/*     */ 
/*     */   public byte[] getRawPacket() {
/* 123 */     return this.input;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 127 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String fs) {
/* 131 */     this.txfs = fs;
/*     */   }
/*     */ 
/*     */   public Long getCmdId() {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 143 */     return this.serverAddress;
/*     */   }
/*     */ 
/*     */   public void setServerAddress(String serverAddress) {
/* 147 */     this.serverAddress = serverAddress;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public int getRtua() {
/* 155 */     return 0;
/*     */   }
/*     */ 
/*     */   public int length() {
/* 159 */     return 0;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isTask() {
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   public void setTask(boolean isTask)
/*     */   {
/*     */   }
/*     */ }