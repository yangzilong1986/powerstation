/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ClientWriteReqEvent
/*    */   implements IEvent
/*    */ {
/* 18 */   private final EventType type = EventType.CLIENT_WRITE_REQ;
/*    */   private IServerSideChannel client;
/*    */ 
/*    */   public ClientWriteReqEvent(IServerSideChannel c)
/*    */   {
/* 22 */     this.client = c;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 26 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public final IServerSideChannel getClient() {
/* 33 */     return this.client;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 37 */     return this.client.getServer();
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 44 */     return null;
/*    */   }
/*    */ }