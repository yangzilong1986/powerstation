/*     */ package com.hzjbbis.fk.sockserver.io;
/*     */ 
/*     */ import com.hzjbbis.fk.common.EventType;
/*     */ import com.hzjbbis.fk.common.events.EventQueue;
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.IEvent;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.exception.SocketClientCloseException;
/*     */ import com.hzjbbis.fk.sockclient.async.event.ClientConnectedEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.AcceptEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ClientCloseEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ClientWriteReqEvent;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SocketIoThread extends Thread
/*     */ {
/*  41 */   private static final Logger log = Logger.getLogger(SocketIoThread.class);
/*  42 */   private static final TraceLog tracer = TraceLog.getTracer();
/*  43 */   private volatile State state = State.STOPPED;
/*     */   private IClientIO ioHandler;
/*     */   private Selector selector;
/*  47 */   private List<IServerSideChannel> list = Collections.synchronizedList(new LinkedList());
/*  48 */   private EventQueue queue = new EventQueue();
/*     */ 
/*     */   public SocketIoThread(int port, IClientIO ioHandler, int index) {
/*  51 */     super("io-" + port + "-" + index);
/*  52 */     this.ioHandler = ioHandler;
/*  53 */     super.start();
/*     */   }
/*     */ 
/*     */   public void stopThread() {
/*  57 */     this.state = State.STOPPING;
/*  58 */     interrupt();
/*     */   }
/*     */ 
/*     */   public boolean isRunning() {
/*  62 */     return (this.state != State.RUNNING);
/*     */   }
/*     */ 
/*     */   public void acceptClient(IServerSideChannel client) {
/*  66 */     client.setIoThread(this);
/*  67 */     this.list.add(client);
/*     */ 
/*  71 */     IEvent event = new AcceptEvent(client);
/*  72 */     int cnt = 20;
/*  73 */     while (cnt-- > 0)
/*     */       try {
/*  75 */         this.queue.offer(event);
/*     */       }
/*     */       catch (Exception exp) {
/*  78 */         String info = "SocketIoThread can not offer event. reason is " + exp.getLocalizedMessage() + ". event is" + event.toString();
/*  79 */         log.fatal(info, exp);
/*  80 */         tracer.trace(info, exp);
/*     */         try {
/*  82 */           Thread.sleep(50L);
/*     */         }
/*     */         catch (Exception localException1) {
/*     */         }
/*     */       }
/*  87 */     this.selector.wakeup();
/*     */   }
/*     */ 
/*     */   public void addConnectedClient(IServerSideChannel client) {
/*  91 */     client.setIoThread(this);
/*  92 */     this.list.add(client);
/*     */ 
/*  94 */     IEvent event = new ClientConnectedEvent(client.getServer(), client);
/*  95 */     int cnt = 20;
/*  96 */     while (cnt-- > 0)
/*     */       try {
/*  98 */         this.queue.offer(event);
/*     */       }
/*     */       catch (Exception exp) {
/* 101 */         String info = "SocketIoThread can not offer event. reason is " + exp.getLocalizedMessage() + ". event is" + event.toString();
/* 102 */         log.fatal(info, exp);
/* 103 */         tracer.trace(info, exp);
/*     */         try {
/* 105 */           Thread.sleep(50L);
/*     */         }
/*     */         catch (Exception localException1) {
/*     */         }
/*     */       }
/* 110 */     this.selector.wakeup();
/*     */   }
/*     */ 
/*     */   public void closeClientRequest(IServerSideChannel client) {
/* 114 */     this.list.remove(client);
/*     */ 
/* 116 */     IEvent event = new ClientCloseEvent(client);
/* 117 */     int cnt = 20;
/* 118 */     while (cnt-- > 0)
/*     */       try {
/* 120 */         this.queue.offer(event);
/*     */       }
/*     */       catch (Exception exp) {
/* 123 */         String info = "SocketIoThread can not offer event. reason is " + exp.getLocalizedMessage() + ". event is" + event.toString();
/* 124 */         log.fatal(info, exp);
/* 125 */         tracer.trace(info, exp);
/*     */         try {
/* 127 */           Thread.sleep(50L);
/*     */         }
/*     */         catch (Exception localException1) {
/*     */         }
/*     */       }
/* 132 */     this.selector.wakeup();
/*     */   }
/*     */ 
/*     */   public void clientWriteRequest(IServerSideChannel client) {
/*     */     try {
/* 137 */       this.queue.offer(new ClientWriteReqEvent(client));
/* 138 */       this.selector.wakeup();
/*     */     } catch (Exception e) {
/* 140 */       log.error(e.getLocalizedMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getClientSize() {
/* 145 */     return this.list.size();
/*     */   }
/*     */ 
/*     */   public void run() {
/*     */     try {
/* 150 */       this.selector = Selector.open();
/*     */     }
/*     */     catch (IOException e) {
/* 153 */       log.error("Selector.open()", e);
/* 154 */       return;
/*     */     }
/* 156 */     this.state = State.RUNNING;
/* 157 */     while (this.state != State.STOPPING)
/*     */       try
/*     */       {
/* 160 */         int n = this.selector.select(100L);
/* 161 */         if (this.state == State.STOPPING) {
/*     */           break label613;
/*     */         }
/* 164 */         if (!(handleEvent()))
/*     */         {
/* 167 */           set = this.selector.selectedKeys();
/* 168 */           if (set != null)
/*     */           {
/* 170 */             if ((n != 0) || (set.size() > 0))
/*     */             {
/* 172 */               Iterator it = set.iterator();
/* 173 */               while (it.hasNext()) {
/* 174 */                 SelectionKey key = (SelectionKey)it.next();
/* 175 */                 it.remove();
/* 176 */                 IServerSideChannel client = (IServerSideChannel)key.attachment();
/* 177 */                 if (client == null) {
/* 178 */                   key.cancel(); key.attach(null);
/* 179 */                   label412: label566: log.warn("null==key.attachment()");
/*     */                 }
/* 182 */                 else if (!(key.isValid())) {
/* 183 */                   key.cancel(); key.attach(null);
/* 184 */                   log.warn("!key.isValid()");
/*     */                 }
/*     */                 else {
/* 187 */                   if (key.isReadable()) {
/* 188 */                     client.setLastReadTime();
/*     */                   }
/*     */ 
/*     */                   try
/*     */                   {
/* 195 */                     boolean readDone = this.ioHandler.onReceive(client);
/* 196 */                     client.getServer().setLastReceiveTime(System.currentTimeMillis());
/*     */ 
/* 198 */                     if (readDone) {
/* 199 */                       this.ioHandler.onReceive(client);
/*     */ 
/* 201 */                       if (client.sendQueueSize() > 1) {
/* 202 */                         interest = key.interestOps();
/* 203 */                         interest &= -2;
/* 204 */                         interest |= 4;
/* 205 */                         key.interestOps(interest); break label412:
/*     */                       }
/*     */                     }
/*     */ 
/* 209 */                     int interest = key.interestOps();
/* 210 */                     interest &= -2;
/* 211 */                     interest |= 4;
/* 212 */                     key.interestOps(interest);
/*     */                   }
/*     */                   catch (SocketClientCloseException cce)
/*     */                   {
/* 216 */                     client.getServer().removeClient(client);
/* 217 */                     key.cancel();
/* 218 */                     client.close();
/* 219 */                     this.list.remove(client);
/* 220 */                     GlobalEventHandler.postEvent(new ClientCloseEvent(client));
/* 221 */                     break label566:
/*     */                   }
/*     */                   catch (Exception exp)
/*     */                   {
/* 225 */                     log.warn("server.getIoHandler().onReceive(client):" + exp.getLocalizedMessage(), exp);
/*     */ 
/* 228 */                     if (key.isWritable())
/*     */                       try
/*     */                       {
/* 231 */                         doWrite(client);
/*     */                       }
/*     */                       catch (SocketClientCloseException exp) {
/* 234 */                         client.getServer().removeClient(client);
/* 235 */                         key.cancel();
/* 236 */                         client.close();
/* 237 */                         this.list.remove(client);
/* 238 */                         GlobalEventHandler.postEvent(new ClientCloseEvent(client));
/* 239 */                         if (log.isDebugEnabled()) {
/* 240 */                           log.debug("server[" + client.getServer().getPort() + "]doWrite exp. client closed.", exp);
/*     */                         }
/*     */                       }
/*     */                       catch (Exception exp)
/*     */                       {
/* 245 */                         log.warn("server.getIoHandler().onSend(client):" + exp.getLocalizedMessage(), exp); }  }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/* 251 */         log.error("select(500) exception:" + e, e);
/*     */       }
/*     */     try
/*     */     {
/* 255 */       label613: this.selector.close();
/*     */     }
/*     */     catch (IOException e) {
/* 258 */       log.error("Selector.close()", e);
/*     */     }
/*     */     finally {
/* 261 */       this.selector = null;
/* 262 */       this.state = State.STOPPED;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doWrite(IServerSideChannel client) throws SocketClientCloseException {
/* 267 */     client.setLastIoTime();
/* 268 */     boolean finishWrite = false;
/* 269 */     finishWrite = this.ioHandler.onSend(client);
/* 270 */     SelectionKey key = client.getChannel().keyFor(this.selector);
/* 271 */     int interest = key.interestOps();
/*     */ 
/* 274 */     if ((finishWrite) && (client.sendQueueSize() == 0)) {
/* 275 */       client.setLastingWrite(0);
/* 276 */       interest &= -5;
/* 277 */       interest |= 1;
/* 278 */       client.getServer().setLastSendTime(System.currentTimeMillis());
/*     */ 
/* 280 */       this.ioHandler.onReceive(client);
/*     */     }
/*     */     else {
/* 283 */       client.setLastingWrite(client.getLastingWrite() + 1); }
/* 284 */     if (client.getLastingWrite() > client.getServer().getWriteFirstCount()) {
/* 285 */       interest |= 1;
/* 286 */       client.setLastingWrite(0);
/*     */     }
/* 288 */     key.interestOps(interest);
/*     */   }
/*     */ 
/*     */   private boolean handleEvent() {
/* 292 */     IEvent ee = null;
/* 293 */     boolean processed = false;
/* 294 */     while ((ee = this.queue.poll()) != null)
/*     */     {
/*     */       IServerSideChannel client;
/* 295 */       processed = true;
/* 296 */       if (ee.getType() == EventType.ACCEPTCLIENT)
/*     */       {
/*     */         try {
/* 299 */           AcceptEvent e = (AcceptEvent)ee;
/* 300 */           client = e.getClient();
/* 301 */           client.getChannel().configureBlocking(false);
/* 302 */           client.getChannel().register(this.selector, 1, client);
/*     */         }
/*     */         catch (Exception exp) {
/* 305 */           log.error("accept client后处理异常:" + exp.getLocalizedMessage(), exp);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         SelectionKey key;
/* 308 */         if (ee.getType() == EventType.CLIENTCLOSE) {
/*     */           try {
/* 310 */             ClientCloseEvent e = (ClientCloseEvent)ee;
/* 311 */             client = e.getClient();
/* 312 */             if (client.getChannel() != null)
/*     */             {
/* 314 */               key = client.getChannel().keyFor(this.selector);
/* 315 */               if (key != null)
/* 316 */                 key.cancel();
/* 317 */               client.close();
/*     */ 
/* 319 */               GlobalEventHandler.postEvent(ee); }
/*     */           } catch (Exception e) {
/* 321 */             log.error("外部调用关闭client处理异常:" + exp.getLocalizedMessage(), exp);
/*     */           }
/*     */         }
/* 324 */         else if (ee.getType() == EventType.CLIENT_WRITE_REQ) {
/*     */           try {
/* 326 */             ClientWriteReqEvent e = (ClientWriteReqEvent)ee;
/* 327 */             client = e.getClient();
/*     */ 
/* 329 */             if (client.getChannel() != null)
/*     */             {
/* 331 */               key = client.getChannel().keyFor(this.selector);
/* 332 */               int interest = key.interestOps();
/* 333 */               interest |= 4;
/* 334 */               key.interestOps(interest); }
/*     */           } catch (Exception e) {
/* 336 */             log.error("client写请求处理异常:" + exp.getLocalizedMessage(), exp);
/*     */           }
/*     */         }
/* 339 */         else if (ee.getType() == EventType.CLIENT_CONNECTED) {
/* 340 */           ClientConnectedEvent e = (ClientConnectedEvent)ee;
/* 341 */           client = (IServerSideChannel)e.getClient();
/*     */           try {
/* 343 */             client.getChannel().configureBlocking(false);
/* 344 */             client.getChannel().register(this.selector, 1, client);
/*     */           } catch (Exception exp) {
/* 346 */             log.error("connected client后处理异常:" + exp.getLocalizedMessage(), exp); }
/*     */         }
/*     */       }
/*     */     }
/* 350 */     return processed;
/*     */   }
/*     */ }