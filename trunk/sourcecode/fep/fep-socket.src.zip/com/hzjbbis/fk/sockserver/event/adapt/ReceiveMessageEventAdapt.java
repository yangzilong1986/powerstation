/*    */ package com.hzjbbis.fk.sockserver.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ReceiveMessageEventAdapt
/*    */   implements IEventHandler
/*    */ {
/* 10 */   private static final Logger log = Logger.getLogger(ReceiveMessageEventAdapt.class);
/*    */ 
/*    */   public void handleEvent(IEvent ev) {
/* 13 */     ReceiveMessageEvent event = (ReceiveMessageEvent)ev;
/*    */     try {
/* 15 */       process(event);
/*    */     } catch (Exception exp) {
/* 17 */       log.error("接收消息事件处理异常：" + exp.getLocalizedMessage(), exp);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void process(ReceiveMessageEvent event) {
/* 22 */     if (log.isInfoEnabled())
/* 23 */       log.debug(event);
/*    */   }
/*    */ }