/*     */ package com.hzjbbis.fk.sockserver.io;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.exception.MessageParseException;
/*     */ import com.hzjbbis.fk.exception.SocketClientCloseException;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SimpleIoHandler
/*     */   implements IClientIO
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(SimpleIoHandler.class);
/*  29 */   private static final TraceLog trace = TraceLog.getTracer(SimpleIoHandler.class);
/*     */ 
/*     */   public boolean onReceive(IServerSideChannel client)
/*     */     throws SocketClientCloseException
/*     */   {
/*  36 */     int msgCount = 0;
/*  37 */     ByteBuffer readBuf = client.getBufRead();
/*  38 */     int bytesRead = 0; int n = 0;
/*  39 */     if (readBuf.remaining() == 0) {
/*  40 */       log.info("SimpleIoHandler.onReceive error. readBuf empty:pos=" + readBuf.position() + ",limit=" + readBuf.limit() + ",capacity=" + readBuf.capacity());
/*  41 */       readBuf.clear(); }
/*     */     do {
/*     */       do {
/*     */         try {
/*  45 */           n = client.getChannel().read(readBuf);
/*     */         } catch (IOException e) {
/*  47 */           log.warn("client.getChannel().read(readBuf)异常:" + e.getLocalizedMessage());
/*  48 */           throw new SocketClientCloseException(e);
/*     */         }
/*  50 */         if (n < 0) {
/*  51 */           String info = "client close socket:" + client.toString();
/*  52 */           log.info(info);
/*  53 */           throw new SocketClientCloseException(info);
/*     */         }
/*  55 */         bytesRead += n; }
/*  56 */       while (n != 0);
/*  57 */       if (readBuf.hasRemaining())
/*     */         break label228;
/*  59 */       readBuf.flip();
/*     */ 
/*  61 */       msgCount = processBuffer(readBuf, client, msgCount); }
/*  62 */     while (msgCount >= 0);
/*     */ 
/*  64 */     if (log.isDebugEnabled())
/*  65 */       log.debug("过度读取。暂时放弃读取数据");
/*  66 */     return false;
/*     */ 
/*  75 */     if (bytesRead == 0)
/*     */     {
/*  77 */       label228: return true;
/*     */     }
/*  79 */     readBuf.flip();
/*     */ 
/*  81 */     msgCount = processBuffer(readBuf, client, msgCount);
/*  82 */     return (msgCount < 0);
/*     */   }
/*     */ 
/*     */   private int processBuffer(ByteBuffer buf, IServerSideChannel client, int count)
/*     */     throws SocketClientCloseException
/*     */   {
/*  95 */     while (buf.hasRemaining()) {
/*  96 */       IMessage msg = client.getCurReadingMsg();
/*  97 */       if (msg == null)
/*     */       {
/*  99 */         int rem1 = buf.remaining();
/* 100 */         msg = client.getServer().createMessage(buf);
/* 101 */         int rem2 = buf.remaining();
/* 102 */         if (msg == null) {
/* 103 */           if ((rem1 > 13) && (rem1 == rem2))
/*     */           {
/* 106 */             String info = "消息对象类型配置错误,server port=" + client.getServer().getPort();
/* 107 */             log.fatal(info);
/* 108 */             buf.clear();
/* 109 */             throw new SocketClientCloseException(info);
/*     */           }
/*     */ 
/* 112 */           if (buf.hasRemaining())
/* 113 */             buf.compact();
/*     */           else
/* 115 */             buf.clear();
/* 116 */           return 0;
/*     */         }
/*     */ 
/* 119 */         client.setCurReadingMsg(msg);
/* 120 */         msg.setSource(client);
/* 121 */         msg.setServerAddress(client.getServer().getServerAddress());
/*     */       }
/* 123 */       boolean down = false;
/*     */       try {
/* 125 */         down = msg.read(buf);
/*     */       } catch (MessageParseException mpe) {
/* 127 */         String expInfo = mpe.getLocalizedMessage();
/* 128 */         log.warn("读消息异常：" + expInfo, mpe);
/*     */ 
/* 151 */         client.setCurReadingMsg(null);
/* 152 */         if (buf.hasRemaining())
/* 153 */           buf.compact();
/*     */         else
/* 155 */           buf.clear();
/* 156 */         return 0;
/*     */       }
/* 158 */       if (!(down)) break;
/* 159 */       ++count;
/* 160 */       client.setCurReadingMsg(null);
/* 161 */       ReceiveMessageEvent ev = new ReceiveMessageEvent(msg, client);
/* 162 */       msg.setIoTime(System.currentTimeMillis());
/* 163 */       msg.setPeerAddr(client.getPeerAddr());
/* 164 */       msg.setTxfs(client.getServer().getTxfs());
/* 165 */       GlobalEventHandler.postEvent(ev);
/*     */ 
/* 167 */       int maxCanRead = client.getServer().getMaxContinueRead();
/* 168 */       int sendReqCount = client.sendQueueSize();
/* 169 */       if ((maxCanRead <= 0) || (sendReqCount <= 0) || (count < maxCanRead))
/*     */         continue;
/* 171 */       if (buf.hasRemaining())
/* 172 */         buf.compact();
/*     */       else
/* 174 */         buf.clear();
/* 175 */       return -1;
/*     */     }
/*     */ 
/* 183 */     if (buf.hasRemaining())
/* 184 */       buf.compact();
/*     */     else
/* 186 */       buf.clear();
/* 187 */     return count;
/*     */   }
/*     */ 
/*     */   public boolean onSend(IServerSideChannel client)
/*     */     throws SocketClientCloseException
/*     */   {
/* 196 */     ByteBuffer writeBuf = client.getBufWrite();
/* 197 */     IMessage msg = client.getCurWritingMsg();
/* 198 */     boolean sent = false;
/*     */ 
/* 200 */     if (client.bufferHasRemaining()) {
/* 201 */       sent = flush(client.getChannel(), writeBuf);
/* 202 */       if (!(sent)) {
/* 203 */         log.debug("flush(client.getChannel(),writeBuf),缓冲区数据没有发送完毕:msg=" + msg.getRawPacketString());
/* 204 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 209 */     if (msg != null)
/*     */     {
/* 211 */       sent = sendMessage(msg, client);
/* 212 */       if (!(sent)) {
/* 213 */         log.debug("sendMessage(msg,client),消息没有发送完，剩余数据在缓冲区：msg=" + msg.getRawPacketString());
/* 214 */         return false;
/*     */       }
/*     */     }
/*     */     do
/*     */     {
/* 219 */       client.setCurWritingMsg(msg);
/* 220 */       sent = sendMessage(msg, client);
/* 221 */       if (!(sent)) {
/* 222 */         log.debug("sendMessage(msg,client),消息没有发送完，剩余数据在缓冲区:msg=" + msg.getRawPacketString());
/* 223 */         return false;
/*     */       }
/*     */     }
/* 218 */     while ((msg = client.getNewSendMessage()) != null);
/*     */ 
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean sendMessage(IMessage msg, IServerSideChannel client)
/*     */     throws SocketClientCloseException
/*     */   {
/* 236 */     ByteBuffer writeBuf = client.getBufWrite();
/* 237 */     boolean done = false; boolean sent = false;
/*     */ 
/* 239 */     int deadloop = 0;
/* 240 */     while (!(done)) {
/* 241 */       done = msg.write(writeBuf);
/* 242 */       writeBuf.flip();
/* 243 */       sent = flush(client.getChannel(), writeBuf);
/*     */ 
/* 246 */       if (done) {
/* 247 */         client.setCurWritingMsg(null);
/* 248 */         msg.setIoTime(System.currentTimeMillis());
/* 249 */         msg.setPeerAddr(client.getPeerAddr());
/* 250 */         msg.setSource(client);
/* 251 */         msg.setTxfs(client.getServer().getTxfs());
/*     */ 
/* 253 */         GlobalEventHandler.postEvent(new SendMessageEvent(msg, client));
/* 254 */         if (client.getServer().getClientSize() <= 100) {
/* 255 */           StringBuffer sb = new StringBuffer();
/* 256 */           sb.append("server port=" + client.getServer().getPort()).append(",clients=");
/* 257 */           for (IServerSideChannel c : client.getServer().getClients()) {
/* 258 */             sb.append(c.toString()).append(",");
/*     */           }
/* 260 */           trace.trace(sb.toString());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 265 */       if (!(sent))
/*     */       {
/* 267 */         client.setBufferHasRemaining(true);
/* 268 */         return false;
/*     */       }
/* 270 */       client.setBufferHasRemaining(false);
/* 271 */       if (++deadloop > 1000) {
/* 272 */         log.fatal("Message.write方法死循环错误：" + msg.getClass().getName());
/* 273 */         return true;
/*     */       }
/*     */     }
/* 276 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean flush(SocketChannel channel, ByteBuffer buf) throws SocketClientCloseException {
/* 280 */     int bytesWritten = 0;
/* 281 */     while (buf.hasRemaining()) {
/*     */       try {
/* 283 */         bytesWritten = channel.write(buf);
/*     */       } catch (IOException exp) {
/* 285 */         String s = "channel.write()异常，原因" + exp.getLocalizedMessage();
/* 286 */         log.warn(s, exp);
/* 287 */         throw new SocketClientCloseException(exp);
/*     */       }
/* 289 */       if (bytesWritten == 0) {
/* 290 */         return false;
/*     */       }
/*     */     }
/* 293 */     buf.clear();
/* 294 */     return true;
/*     */   }
/*     */ }