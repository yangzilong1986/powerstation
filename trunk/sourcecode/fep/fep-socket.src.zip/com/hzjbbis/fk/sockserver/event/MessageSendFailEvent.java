/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class MessageSendFailEvent
/*    */   implements IEvent
/*    */ {
/* 16 */   private final EventType type = EventType.MSG_SEND_FAIL;
/*    */   private IChannel client;
/*    */   private IMessage message;
/*    */ 
/*    */   public MessageSendFailEvent(IMessage msg, IChannel c)
/*    */   {
/* 21 */     this.message = msg;
/* 22 */     this.client = c;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 26 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public IChannel getClient() {
/* 33 */     return this.client;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 37 */     return this.message;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 41 */     return this.client.getServer();
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 48 */     StringBuffer sb = new StringBuffer(1024);
/* 49 */     sb.append("message send failed event. client=");
/* 50 */     sb.append(this.client).append(",server=").append(this.client.getServer().getPort());
/* 51 */     sb.append(",messge=").append(this.message);
/* 52 */     return sb.toString();
/*    */   }
/*    */ }