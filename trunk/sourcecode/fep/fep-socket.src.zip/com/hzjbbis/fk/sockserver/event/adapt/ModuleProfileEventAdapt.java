/*    */ package com.hzjbbis.fk.sockserver.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ModuleProfileEventAdapt
/*    */   implements IEventHandler
/*    */ {
/* 16 */   private static final Logger log = Logger.getLogger(ModuleProfileEventAdapt.class);
/*    */   private IEvent event;
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 20 */     this.event = event;
/* 21 */     process();
/*    */   }
/*    */ 
/*    */   protected void process() {
/* 25 */     if (log.isInfoEnabled())
/* 26 */       log.info(this.event);
/*    */   }
/*    */ }