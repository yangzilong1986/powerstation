/*     */ package com.hzjbbis.fk.sockserver;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IModule;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseSocketServer;
/*     */ import com.hzjbbis.fk.sockserver.event.AcceptEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ModuleProfileEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ServerStartedEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.ServerStoppedEvent;
/*     */ import com.hzjbbis.fk.sockserver.io.SocketIoThread;
/*     */ import com.hzjbbis.fk.sockserver.io.SocketIoThreadPool;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.nio.channels.ClosedSelectorException;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TcpSocketServer extends BaseSocketServer
/*     */   implements IModule, ITimerFunctor
/*     */ {
/*  44 */   private static final Logger log = Logger.getLogger(TcpSocketServer.class);
/*     */ 
/*  47 */   private boolean oneIpLimit = false;
/*     */   protected ServerSocketChannel ssc;
/*     */   protected Selector selector;
/*  52 */   private volatile State state = State.STOPPED;
/*  53 */   protected Map<String, AsyncSocketClient> map = Collections.synchronizedMap(new HashMap(51200));
/*  54 */   private AcceptThread acceptThread = null;
/*  55 */   private SocketIoThreadPool ioPool = null;
/*     */ 
/*     */   public String getModuleType()
/*     */   {
/*  62 */     return "socketServer";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  66 */     return this.state.isActive();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  70 */     StringBuffer sb = new StringBuffer();
/*  71 */     sb.append("A-TCP(").append(this.port).append(")");
/*  72 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean start()
/*     */   {
/*  79 */     if (!(this.state.isStopped())) {
/*  80 */       log.warn("socket server[" + this.port + "]非停止状态，不能启动服务。");
/*  81 */       return false;
/*     */     }
/*  83 */     if (this.ioThreadSize <= 0)
/*  84 */       this.ioThreadSize = (Runtime.getRuntime().availableProcessors() * 2);
/*  85 */     this.state = State.STARTING;
/*     */ 
/*  87 */     this.ioPool = new SocketIoThreadPool(this.port, this.ioThreadSize, this.ioHandler);
/*  88 */     this.ioPool.start();
/*     */ 
/*  90 */     this.acceptThread = new AcceptThread();
/*  91 */     this.acceptThread.start();
/*  92 */     int cnt = 1000;
/*  93 */     while ((this.state.isStarting()) && (cnt-- > 0))
/*     */     {
/*  95 */       Thread.yield();
/*     */       try {
/*  97 */         Thread.sleep(10L);
/*     */       } catch (InterruptedException localInterruptedException) {
/*     */       }
/*     */     }
/* 101 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 60L));
/* 102 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 1, this.timeout));
/*     */ 
/* 104 */     log.info("TCP服务启动成功【" + this.port + "】");
/* 105 */     GlobalEventHandler.postEvent(new ServerStartedEvent(this));
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */   public void onTimer(int timerID) {
/* 110 */     if (timerID == 0) {
/* 111 */       long now = System.currentTimeMillis();
/* 112 */       if ((now - this.lastReceiveTime < 60000L) || (now - this.lastSendTime < 60000L))
/* 113 */         GlobalEventHandler.postEvent(new ModuleProfileEvent(this));
/* 114 */       synchronized (this.statisticsRecv) {
/* 115 */         this.msgRecvPerMinute = 0;
/*     */       }
/* 117 */       synchronized (this.statisticsSend) {
/* 118 */         this.msgSendPerMinute = 0;
/*     */       }
/*     */     } else {
/* 121 */       if (1 != timerID)
/*     */         return;
/* 123 */       ArrayList list = new ArrayList(this.map.values());
/* 124 */       long now = System.currentTimeMillis();
/* 125 */       int closedCount = 0;
/* 126 */       for (AsyncSocketClient client : list) {
/* 127 */         if (now - client.getLastReadTime() > this.timeout * 1000) {
/* 128 */           forceCloseClient(client);
/* 129 */           ++closedCount;
/*     */         }
/*     */       }
/* 132 */       if (closedCount > 0)
/* 133 */         log.warn("TCP服务[" + this.name + "]超时关闭客户端连接数=" + closedCount);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 141 */     if (!(this.state.isRunning()))
/* 142 */       return;
/* 143 */     this.state = State.STOPPING;
/*     */ 
/* 146 */     this.acceptThread.interrupt();
/* 147 */     int cnt = 500;
/* 148 */     while ((this.acceptThread.isAlive()) && (cnt-- > 0)) {
/* 149 */       Thread.yield();
/*     */       try {
/* 151 */         this.acceptThread.join(20L); } catch (InterruptedException localInterruptedException) {
/*     */       }
/*     */     }
/* 154 */     this.acceptThread = null;
/*     */ 
/* 157 */     this.ioPool.stop();
/*     */ 
/* 159 */     TimerScheduler.getScheduler().removeTimer(this, 0);
/* 160 */     TimerScheduler.getScheduler().removeTimer(this, 1);
/*     */ 
/* 162 */     this.state = State.STOPPED;
/* 163 */     log.info("TCP服务停止【" + this.port + "】");
/* 164 */     GlobalEventHandler.postEvent(new ServerStoppedEvent(this));
/*     */   }
/*     */ 
/*     */   public void removeClient(IServerSideChannel client)
/*     */   {
/* 298 */     String clientKey = client.getPeerAddr();
/* 299 */     if (this.oneIpLimit)
/* 300 */       clientKey = client.getPeerIp();
/* 301 */     this.map.remove(clientKey);
/* 302 */     super.removeClient(client);
/*     */   }
/*     */ 
/*     */   public void forceCloseClient(AsyncSocketClient client)
/*     */   {
/* 311 */     removeClient(client);
/* 312 */     client.getIoThread().closeClientRequest(client);
/*     */   }
/*     */ 
/*     */   private void checkTimeout()
/*     */   {
/* 317 */     ArrayList list = new ArrayList(this.map.values());
/* 318 */     long now = System.currentTimeMillis();
/* 319 */     for (AsyncSocketClient client : list)
/* 320 */       if (now - client.getLastReadTime() > this.timeout * 1000)
/* 321 */         forceCloseClient(client);
/*     */   }
/*     */ 
/*     */   public int getClientSize()
/*     */   {
/* 327 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   public IServerSideChannel[] getClients()
/*     */   {
/* 334 */     return ((IServerSideChannel[])this.map.values().toArray(new IServerSideChannel[0]));
/*     */   }
/*     */ 
/*     */   public boolean isOneIpLimit() {
/* 338 */     return this.oneIpLimit; }
/*     */ 
/*     */   public void setOneIpLimit(boolean oneIpLimit) {
/* 341 */     this.oneIpLimit = oneIpLimit;
/*     */   }
/*     */ 
/*     */   private class AcceptThread extends Thread
/*     */   {
/*     */     public AcceptThread()
/*     */     {
/* 169 */       super("TcpServer-" + TcpSocketServer.access$0(TcpSocketServer.this) + "-AcceptThread");
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 174 */         TcpSocketServer.this.ssc = ServerSocketChannel.open();
/* 175 */         TcpSocketServer.this.ssc.socket().setReuseAddress(true);
/* 176 */         InetSocketAddress addr = null;
/* 177 */         if (TcpSocketServer.access$1(TcpSocketServer.this) == null)
/* 178 */           addr = new InetSocketAddress(TcpSocketServer.access$0(TcpSocketServer.this));
/*     */         else
/* 180 */           addr = new InetSocketAddress(TcpSocketServer.access$1(TcpSocketServer.this), TcpSocketServer.access$0(TcpSocketServer.this));
/* 181 */         TcpSocketServer.this.ssc.socket().bind(addr);
/* 182 */         TcpSocketServer.this.ssc.configureBlocking(false);
/*     */       }
/*     */       catch (Exception exp) {
/* 185 */         TcpSocketServer.log.fatal("TCPServer start failed. " + exp.getLocalizedMessage() + ",port=" + TcpSocketServer.access$0(TcpSocketServer.this));
/* 186 */         return;
/*     */       }
/*     */ 
/* 189 */       TcpSocketServer.log.info("server[" + TcpSocketServer.access$0(TcpSocketServer.this) + "]listen thread is running");
/*     */       try
/*     */       {
/* 192 */         TcpSocketServer.this.selector = Selector.open();
/* 193 */         TcpSocketServer.this.ssc.register(TcpSocketServer.this.selector, 16);
/*     */       }
/*     */       catch (Exception e) {
/* 196 */         TcpSocketServer.log.error("socketserver 侦听线程异常（selectorOpen)" + e.getMessage());
/* 197 */         TcpSocketServer.this.state = State.STOPPED;
/* 198 */         return;
/*     */       }
/* 200 */       TcpSocketServer.this.state = State.RUNNING;
/*     */ 
/* 202 */       long sign = System.currentTimeMillis();
/* 203 */       int cnt = 0;
/* 204 */       int times = 0;
/*     */ 
/* 206 */       while (TcpSocketServer.this.state != State.STOPPING)
/*     */         try {
/* 208 */           tryAccept();
/*     */ 
/* 211 */           ++cnt;
/* 212 */           if (cnt >= 200) {
/* 213 */             long now = System.currentTimeMillis();
/* 214 */             if (now - sign < 1000L) {
/* 215 */               TcpSocketServer.log.warn("server[" + TcpSocketServer.access$0(TcpSocketServer.this) + "]Accept thread可能进入死循环。");
/*     */             }
/* 217 */             cnt = 0;
/* 218 */             sign = System.currentTimeMillis();
/*     */           }
/*     */ 
/* 222 */           if (times++ >= 10)
/* 223 */             TcpSocketServer.this.checkTimeout();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 227 */           TcpSocketServer.log.error("server[" + TcpSocketServer.access$0(TcpSocketServer.this) + "]AcceptThread异常:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       try
/*     */       {
/* 231 */         TcpSocketServer.this.ssc.close();
/*     */       }
/*     */       catch (IOException ioe) {
/* 234 */         TcpSocketServer.log.warn("ssc.close异常：" + ioe.getLocalizedMessage());
/*     */       }
/* 236 */       TcpSocketServer.this.ssc = null;
/*     */       try {
/* 238 */         TcpSocketServer.this.selector.close();
/*     */       }
/*     */       catch (IOException ioe) {
/* 241 */         TcpSocketServer.log.warn("selector.close异常：" + ioe.getLocalizedMessage());
/*     */       }
/* 243 */       TcpSocketServer.this.selector = null;
/* 244 */       TcpSocketServer.log.info("server[" + TcpSocketServer.access$0(TcpSocketServer.this) + "]listen thread is stopping");
/*     */     }
/*     */ 
/*     */     private void tryAccept()
/*     */       throws IOException, ClosedSelectorException
/*     */     {
/* 250 */       int n = TcpSocketServer.this.selector.select(50L);
/*     */ 
/* 254 */       Set set = TcpSocketServer.this.selector.selectedKeys();
/* 255 */       for (SelectionKey key : set) {
/* 256 */         if (key.isAcceptable()) {
/*     */           try {
/* 258 */             doAccept();
/*     */           } catch (Exception e) {
/* 260 */             TcpSocketServer.log.warn("doAccept()异常：" + e.getLocalizedMessage(), e);
/* 261 */             key.cancel();
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 266 */           TcpSocketServer.log.warn("在Accept时候，SelectionKey非法：" + key);
/* 267 */           key.cancel();
/*     */         }
/*     */       }
/* 270 */       set.clear();
/*     */     }
/*     */ 
/*     */     private void doAccept() throws IOException {
/* 274 */       SocketChannel channel = TcpSocketServer.this.ssc.accept();
/* 275 */       channel.socket().setReceiveBufferSize(TcpSocketServer.access$6(TcpSocketServer.this));
/* 276 */       channel.socket().setSendBufferSize(TcpSocketServer.access$6(TcpSocketServer.this));
/* 277 */       channel.configureBlocking(false);
/* 278 */       AsyncSocketClient client = new AsyncSocketClient(channel, TcpSocketServer.this);
/* 279 */       String clientKey = client.getPeerAddr();
/* 280 */       if (TcpSocketServer.this.oneIpLimit)
/* 281 */         clientKey = client.getPeerIp();
/* 282 */       TcpSocketServer.this.map.put(clientKey, client);
/*     */ 
/* 285 */       TcpSocketServer.this.ioPool.acceptNewClient(client);
/*     */ 
/* 288 */       GlobalEventHandler.postEvent(new AcceptEvent(client));
/*     */     }
/*     */   }
/*     */ }