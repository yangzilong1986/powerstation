/*    */ package com.hzjbbis.fk.sockserver.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class RecvSimpleMessageEventAdapt
/*    */   implements IEventHandler
/*    */ {
/* 17 */   private static final Logger log = Logger.getLogger(RecvSimpleMessageEventAdapt.class);
/*    */   private ReceiveMessageEvent event;
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 21 */     this.event = ((ReceiveMessageEvent)event);
/* 22 */     process();
/*    */   }
/*    */ 
/*    */   protected void process() {
/* 26 */     if (log.isInfoEnabled())
/* 27 */       log.info(this.event);
/*    */   }
/*    */ }