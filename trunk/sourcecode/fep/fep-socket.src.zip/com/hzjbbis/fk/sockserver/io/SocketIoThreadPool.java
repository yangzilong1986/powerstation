/*    */ package com.hzjbbis.fk.sockserver.io;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*    */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*    */ import java.util.ArrayList;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class SocketIoThreadPool
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(SocketIoThreadPool.class);
/*    */   private int ioThreadSize;
/*    */   private int port;
/*    */   private IClientIO ioHandler;
/* 23 */   private ArrayList<SocketIoThread> threads = new ArrayList();
/*    */ 
/*    */   public SocketIoThreadPool(int port, int ioSize, IClientIO ioHandler) {
/* 26 */     this.port = port;
/* 27 */     this.ioThreadSize = ioSize;
/* 28 */     this.ioHandler = ioHandler;
/*    */   }
/*    */ 
/*    */   public void start() {
/* 32 */     for (int i = 0; i < this.ioThreadSize; ++i) {
/* 33 */       this.threads.add(new SocketIoThread(this.port, this.ioHandler, i));
/*    */     }
/* 35 */     Thread.yield();
/*    */   }
/*    */ 
/*    */   public void stop() {
/* 39 */     for (int i = 0; i < this.ioThreadSize; ++i) {
/* 40 */       ((SocketIoThread)this.threads.get(i)).stopThread();
/*    */     }
/* 42 */     this.threads.clear();
/*    */   }
/*    */ 
/*    */   public void acceptNewClient(IServerSideChannel client)
/*    */   {
/* 50 */     scheduleClient(client, true);
/*    */   }
/*    */ 
/*    */   public void addConnectedClient(IServerSideChannel client) {
/* 54 */     scheduleClient(client, false);
/*    */   }
/*    */ 
/*    */   private void scheduleClient(IServerSideChannel client, boolean acceptMode)
/*    */   {
/* 59 */     SocketIoThread cur = null; SocketIoThread q = null;
/* 60 */     int min = 2147483647;
/* 61 */     for (int i = 0; i < this.ioThreadSize; ++i) {
/* 62 */       q = (SocketIoThread)this.threads.get(i);
/* 63 */       if (q.getClientSize() < min) {
/* 64 */         cur = q;
/* 65 */         min = cur.getClientSize();
/*    */       }
/*    */     }
/* 68 */     if (cur == null) {
/* 69 */       log.error("scheduleClient failed. cur thread == null.");
/* 70 */       return;
/*    */     }
/* 72 */     if (acceptMode)
/* 73 */       cur.acceptClient(client);
/*    */     else
/* 75 */       cur.addConnectedClient(client);
/*    */   }
/*    */ }