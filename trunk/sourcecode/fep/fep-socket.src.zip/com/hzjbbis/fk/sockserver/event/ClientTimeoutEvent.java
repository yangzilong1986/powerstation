/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ClientTimeoutEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private final EventType type = EventType.CLIENTTIMEOUT;
/*    */   private ISocketServer server;
/*    */   private IChannel client;
/*    */ 
/*    */   public ClientTimeoutEvent(IChannel c)
/*    */   {
/* 22 */     this.client = c;
/* 23 */     this.server = c.getServer();
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 27 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public final ISocketServer getServer() {
/* 34 */     return this.server;
/*    */   }
/*    */ 
/*    */   public final IChannel getClient() {
/* 38 */     return this.client;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 42 */     return this.server;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 53 */     StringBuffer sb = new StringBuffer(128);
/* 54 */     sb.append("client timeout event. client=").append(this.client);
/* 55 */     sb.append(",server=").append(this.server.getPort());
/* 56 */     return sb.toString();
/*    */   }
/*    */ }