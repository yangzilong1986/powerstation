/*    */ package com.hzjbbis.fk.sockserver.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class SendMessageEventAdapt
/*    */   implements IEventHandler
/*    */ {
/* 10 */   private static final Logger log = Logger.getLogger(SendMessageEventAdapt.class);
/*    */   private SendMessageEvent event;
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 14 */     this.event = ((SendMessageEvent)event);
/* 15 */     process();
/*    */   }
/*    */ 
/*    */   protected void process() {
/* 19 */     if (log.isInfoEnabled())
/* 20 */       log.debug(this.event);
/*    */   }
/*    */ }