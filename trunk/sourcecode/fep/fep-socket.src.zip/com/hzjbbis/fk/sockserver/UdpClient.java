/*     */ package com.hzjbbis.fk.sockserver;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ 
/*     */ public class UdpClient
/*     */   implements IServerSideChannel
/*     */ {
/*     */   private SocketAddress socketAddress;
/*     */   private SyncUdpServer server;
/*  21 */   private String peerIp = "0.0.0.0";
/*  22 */   private int peerPort = 0;
/*     */ 
/*  24 */   private ByteBuffer bufRead = null;
/*     */   private IMessage curReadingMsg;
/*  27 */   private long lastIoTime = System.currentTimeMillis();
/*  28 */   private long lastReadTime = System.currentTimeMillis();
/*  29 */   private boolean bufferHasRemaining = false;
/*     */ 
/*  31 */   private int lastingWrite = 0;
/*     */ 
/*  34 */   private int requestNum = -1;
/*     */ 
/*     */   public int getRequestNum() {
/*  37 */     return this.requestNum;
/*     */   }
/*     */ 
/*     */   public void setRequestNum(int requestNum) {
/*  41 */     this.requestNum = requestNum;
/*     */   }
/*     */ 
/*     */   public int getLastingWrite() {
/*  45 */     return this.lastingWrite;
/*     */   }
/*     */ 
/*     */   public void setLastingWrite(int lastingWrite) {
/*  49 */     this.lastingWrite = lastingWrite;
/*     */   }
/*     */ 
/*     */   public UdpClient(SocketAddress sa, SyncUdpServer udpServer) {
/*  53 */     this.socketAddress = sa;
/*  54 */     this.server = udpServer;
/*  55 */     this.bufRead = ByteBuffer.allocate(this.server.getBufLength());
/*  56 */     if (sa instanceof InetSocketAddress) {
/*  57 */       this.peerIp = ((InetSocketAddress)sa).getAddress().getHostAddress();
/*  58 */       this.peerPort = ((InetSocketAddress)sa).getPort();
/*     */     } else {
/*  60 */       String connstr = sa.toString();
/*  61 */       if (connstr != null) {
/*  62 */         if (connstr.charAt(0) == '/') {
/*  63 */           connstr = connstr.substring(1);
/*     */         }
/*  65 */         String[] parts = connstr.split(":");
/*  66 */         if (parts.length >= 2) {
/*  67 */           this.peerIp = parts[0];
/*  68 */           this.peerPort = Integer.parseInt(parts[1]);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean send(IMessage msg)
/*     */   {
/*  76 */     this.server.incSendMessage();
/*  77 */     this.server.setLastSendTime(System.currentTimeMillis());
/*  78 */     return this.server.send(msg, this);
/*     */   }
/*     */ 
/*     */   public int sendQueueSize() {
/*  82 */     return 0;
/*     */   }
/*     */ 
/*     */   public void setMaxSendQueueSize(int maxSize)
/*     */   {
/*     */   }
/*     */ 
/*     */   public IMessage getCurReadingMsg() {
/*  90 */     return this.curReadingMsg;
/*     */   }
/*     */ 
/*     */   public void setCurReadingMsg(IMessage curReadingMsg) {
/*  94 */     this.curReadingMsg = curReadingMsg;
/*  95 */     if (curReadingMsg != null)
/*  96 */       this.server.incRecvMessage();
/*     */   }
/*     */ 
/*     */   public SyncUdpServer getServer() {
/* 100 */     return this.server;
/*     */   }
/*     */ 
/*     */   public String getPeerIp() {
/* 104 */     return this.peerIp;
/*     */   }
/*     */ 
/*     */   public int getPeerPort() {
/* 108 */     return this.peerPort;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/* 112 */     return this.peerIp + ":" + this.peerPort + ":U";
/*     */   }
/*     */ 
/*     */   public ByteBuffer getBufRead() {
/* 116 */     return this.bufRead;
/*     */   }
/*     */ 
/*     */   public SocketChannel getChannel() {
/* 120 */     return null; }
/*     */ 
/*     */   public void setIoThread(Object ioThread) {
/*     */   }
/*     */ 
/*     */   public SocketAddress getSocketAddress() {
/* 126 */     return this.socketAddress;
/*     */   }
/*     */ 
/*     */   public long getLastIoTime() {
/* 130 */     return this.lastIoTime;
/*     */   }
/*     */ 
/*     */   public long getLastReadTime() {
/* 134 */     return this.lastReadTime;
/*     */   }
/*     */ 
/*     */   public void setLastIoTime() {
/* 138 */     this.lastIoTime = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public void setLastReadTime() {
/* 142 */     this.lastReadTime = System.currentTimeMillis();
/* 143 */     this.lastIoTime = this.lastReadTime;
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */   }
/*     */ 
/*     */   public ByteBuffer getBufWrite() {
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   public IMessage getCurWritingMsg() {
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   public IMessage getNewSendMessage() {
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   public void setCurWritingMsg(IMessage curWritingMsg) {
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 165 */     StringBuffer sb = new StringBuffer();
/* 166 */     sb.append("UDP client,peer=").append(this.peerIp);
/* 167 */     sb.append(":").append(this.peerPort);
/* 168 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean bufferHasRemaining() {
/* 172 */     return this.bufferHasRemaining;
/*     */   }
/*     */ 
/*     */   public void setBufferHasRemaining(boolean hasRemaining) {
/* 176 */     this.bufferHasRemaining = hasRemaining;
/*     */   }
/*     */ }