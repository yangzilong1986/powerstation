/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ReceiveMessageEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private final EventType type = EventType.MSG_RECV;
/*    */   private IMessage message;
/*    */   private IChannel client;
/*    */   private ISocketServer server;
/*    */ 
/*    */   public ReceiveMessageEvent(IMessage m, IChannel c)
/*    */   {
/* 23 */     this.message = m;
/* 24 */     this.client = c;
/* 25 */     this.server = c.getServer();
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 29 */     return ((this.server != null) ? this.server : this.client);
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 33 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public final IMessage getMessage() {
/* 40 */     return this.message;
/*    */   }
/*    */ 
/*    */   public final void setMessage(IMessage msg) {
/* 44 */     this.message = msg;
/*    */   }
/*    */ 
/*    */   public final IChannel getClient() {
/* 48 */     return this.client;
/*    */   }
/*    */ 
/*    */   public final ISocketServer getServer() {
/* 52 */     return this.server;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 56 */     StringBuffer sb = new StringBuffer(1024);
/* 57 */     if (this.server != null)
/* 58 */       sb.append("recv event. server=").append(this.server.getPort()).append(",client=");
/*    */     else
/* 60 */       sb.append("recv event. client=");
/* 61 */     sb.append(this.client).append(",接收:");
/* 62 */     sb.append(this.message);
/* 63 */     return sb.toString();
/*    */   }
/*    */ }