/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IModule;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ModuleProfileEvent
/*    */   implements IEvent
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(ModuleProfileEvent.class);
/* 20 */   private EventType type = EventType.MODULE_PROFILE;
/* 21 */   private IModule module = null;
/* 22 */   private long lastReceiveTime = 0L; private long lastSendTime = 0L;
/* 23 */   private long totalRecvMessages = 0L; private long totalSendMessages = 0L;
/* 24 */   private int msgRecvPerMinute = 0; private int msgSendPerMinute = 0;
/* 25 */   private int clientSize = 0;
/*    */ 
/*    */   public ModuleProfileEvent(IModule m) {
/* 28 */     this.module = m;
/* 29 */     this.lastReceiveTime = m.getLastReceiveTime();
/* 30 */     this.lastSendTime = m.getLastSendTime();
/* 31 */     this.totalRecvMessages = m.getTotalRecvMessages();
/* 32 */     this.totalSendMessages = m.getTotalSendMessages();
/* 33 */     this.msgRecvPerMinute = m.getMsgRecvPerMinute();
/* 34 */     this.msgSendPerMinute = m.getMsgSendPerMinute();
/* 35 */     if (m instanceof ISocketServer)
/* 36 */       this.clientSize = ((ISocketServer)m).getClientSize();
/*    */   }
/*    */ 
/*    */   public Object getSource()
/*    */   {
/* 41 */     return this.module;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 45 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public final long getLastReceiveTime() {
/* 55 */     return this.lastReceiveTime;
/*    */   }
/*    */ 
/*    */   public final long getLastSendTime() {
/* 59 */     return this.lastSendTime;
/*    */   }
/*    */ 
/*    */   public final long getTotalRecvMessages() {
/* 63 */     return this.totalRecvMessages;
/*    */   }
/*    */ 
/*    */   public final long getTotalSendMessages() {
/* 67 */     return this.totalSendMessages;
/*    */   }
/*    */ 
/*    */   public final int getMsgRecvPerMinute() {
/* 71 */     return this.msgRecvPerMinute;
/*    */   }
/*    */ 
/*    */   public final int getMsgSendPerMinute() {
/* 75 */     return this.msgSendPerMinute;
/*    */   }
/*    */ 
/*    */   public final int getClientSize() {
/* 79 */     return this.clientSize;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 83 */     return null;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 87 */     String ret = this.module.profile();
/* 88 */     if (log.isDebugEnabled())
/* 89 */       log.debug(ret);
/* 90 */     return ret;
/*    */   }
/*    */ }