/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ClientCloseEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private final EventType type = EventType.CLIENTCLOSE;
/*    */   private ISocketServer server;
/*    */   private IServerSideChannel client;
/*    */ 
/*    */   public ClientCloseEvent(IServerSideChannel c)
/*    */   {
/* 22 */     this.server = c.getServer();
/* 23 */     this.client = c;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 27 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public final ISocketServer getServer() {
/* 34 */     return this.server;
/*    */   }
/*    */ 
/*    */   public final IServerSideChannel getClient() {
/* 38 */     return this.client;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 42 */     return this.server;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 49 */     return null;
/*    */   }
/*    */ }