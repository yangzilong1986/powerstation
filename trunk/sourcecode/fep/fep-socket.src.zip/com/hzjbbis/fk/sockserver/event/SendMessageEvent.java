/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class SendMessageEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private final EventType type = EventType.MSG_SENT;
/*    */   private IMessage message;
/*    */   private IChannel client;
/*    */   private ISocketServer server;
/*    */ 
/*    */   public SendMessageEvent(IMessage m, IChannel c)
/*    */   {
/* 23 */     this.message = m;
/* 24 */     this.client = c;
/* 25 */     this.server = c.getServer();
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 29 */     return this.server;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 33 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public final IMessage getMessage() {
/* 40 */     return this.message;
/*    */   }
/*    */ 
/*    */   public final IChannel getClient() {
/* 44 */     return this.client;
/*    */   }
/*    */ 
/*    */   public final ISocketServer getServer() {
/* 48 */     return this.server;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 52 */     StringBuffer sb = new StringBuffer(1024);
/* 53 */     sb.append("send event. server=").append(this.server.getPort()).append(",client=");
/* 54 */     sb.append(this.client).append(",发送:");
/* 55 */     sb.append(this.message);
/* 56 */     return sb.toString();
/*    */   }
/*    */ }