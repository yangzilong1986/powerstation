/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.sockserver.AsyncSocketClient;
/*    */ import com.hzjbbis.fk.sockserver.message.SimpleMessage;
/*    */ 
/*    */ public class RecvSimpleMessageEvent
/*    */   implements IEvent
/*    */ {
/* 17 */   private EventType type = EventType.MSG_SIMPLE_RECV;
/*    */   private SimpleMessage message;
/*    */   private AsyncSocketClient client;
/*    */ 
/*    */   public RecvSimpleMessageEvent(IMessage m)
/*    */   {
/* 22 */     this.message = ((SimpleMessage)m);
/* 23 */     this.client = ((AsyncSocketClient)m.getSource());
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 27 */     return this.client.getServer();
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 31 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public SimpleMessage getMessage() {
/* 41 */     return this.message;
/*    */   }
/*    */ 
/*    */   public void setMessage(SimpleMessage message) {
/* 45 */     this.message = message;
/*    */   }
/*    */ 
/*    */   public AsyncSocketClient getClient() {
/* 49 */     return this.client;
/*    */   }
/*    */ 
/*    */   public void setClient(AsyncSocketClient client) {
/* 53 */     this.client = client;
/*    */   }
/*    */ }