/*    */ package com.hzjbbis.fk.sockserver.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ServerStartedEvent
/*    */   implements IEvent
/*    */ {
/* 16 */   private final EventType type = EventType.SERVERSTARTED;
/* 17 */   private ISocketServer server = null;
/*    */ 
/*    */   public ServerStartedEvent(ISocketServer s) {
/* 20 */     this.server = s;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 24 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(EventType type) {
/*    */   }
/*    */ 
/*    */   public final ISocketServer getServer() {
/* 31 */     return this.server;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 35 */     return this.server;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 42 */     return null;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 46 */     StringBuffer sb = new StringBuffer(128);
/* 47 */     sb.append("server started event. server=").append(this.server);
/* 48 */     return sb.toString();
/*    */   }
/*    */ }