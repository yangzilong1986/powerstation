/*    */ package com.hzjbbis.fk.sockclient.async;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.sockserver.AsyncSocketClient;
/*    */ import com.hzjbbis.fk.utils.HexDump;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.SocketChannel;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class JAsyncSocket extends AsyncSocketClient
/*    */ {
/* 14 */   private static final Logger log = Logger.getLogger(JAsyncSocket.class);
/* 15 */   private long lastConnectTime = System.currentTimeMillis() - 600000L;
/*    */   private Object attachment;
/*    */ 
/*    */   public JAsyncSocket(ISocketServer s)
/*    */   {
/* 19 */     AsyncSocketPool sp = (AsyncSocketPool)s;
/* 20 */     this.server = s;
/* 21 */     this.peerIp = sp.getPeerIp();
/* 22 */     this.peerPort = sp.getPeerPort();
/* 23 */     this.peerAddr = this.peerIp + ":" + HexDump.toHex((short)this.peerPort) + ":A";
/* 24 */     this.bufRead = ByteBuffer.allocateDirect(s.getBufLength());
/* 25 */     this.bufWrite = ByteBuffer.allocateDirect(s.getBufLength());
/*    */   }
/*    */ 
/*    */   public Object attachment()
/*    */   {
/* 30 */     return this.attachment;
/*    */   }
/*    */ 
/*    */   public void attach(Object attach) {
/* 34 */     this.attachment = attach;
/*    */   }
/*    */ 
/*    */   public void createChannel() {
/*    */     try {
/* 39 */       this.channel = SocketChannel.open();
/*    */     }
/*    */     catch (IOException e) {
/* 42 */       log.error(e.getLocalizedMessage(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isConnected() {
/* 47 */     synchronized (this) {
/* 48 */       return ((this.channel != null) ? this.channel.isConnected() : false);
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getLastConnectTime() {
/* 53 */     return this.lastConnectTime;
/*    */   }
/*    */ 
/*    */   public void setLastConnectTime(long lastConnectTime) {
/* 57 */     this.lastConnectTime = lastConnectTime;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 61 */     return "async socket:peer=" + this.peerIp + ",localport=" + this.localPort;
/*    */   }
/*    */ }