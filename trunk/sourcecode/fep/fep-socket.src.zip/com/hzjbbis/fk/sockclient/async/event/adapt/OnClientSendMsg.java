/*    */ package com.hzjbbis.fk.sockclient.async.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ import com.hzjbbis.fk.sockclient.async.JAsyncSocket;
/*    */ import com.hzjbbis.fk.sockclient.async.simulator.SimulatorManager;
/*    */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*    */ 
/*    */ public class OnClientSendMsg
/*    */   implements IEventHandler
/*    */ {
/*    */   public void handleEvent(IEvent evt)
/*    */   {
/* 13 */     SendMessageEvent event = (SendMessageEvent)evt;
/* 14 */     JAsyncSocket client = (JAsyncSocket)event.getClient();
/* 15 */     IMessage msg = event.getMessage();
/* 16 */     SimulatorManager.onChannelSend(client, msg);
/*    */   }
/*    */ }