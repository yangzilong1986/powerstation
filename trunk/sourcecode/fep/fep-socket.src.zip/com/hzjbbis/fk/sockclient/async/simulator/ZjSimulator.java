/*     */ package com.hzjbbis.fk.sockclient.async.simulator;
/*     */ 
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.zj.MessageZj;
/*     */ import com.hzjbbis.fk.sockclient.async.JAsyncSocket;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ZjSimulator
/*     */   implements IRtuSimulator
/*     */ {
/*  12 */   public static final Logger log = Logger.getLogger(ZjSimulator.class);
/*     */   private JAsyncSocket client;
/*  14 */   private String strTask = "6899053806C11668811000010000000000000030805520211205047616";
/*     */   private MessageZj taskTemplate;
/*  16 */   private int rtua = 0;
/*  17 */   private String pwd = "123456";
/*  18 */   private byte fseq = 0;
/*     */ 
/*     */   private byte getFseq() { synchronized (this)
/*     */     {
/*     */       ZjSimulator tmp5_4 = this; tmp5_4.fseq = (byte)(tmp5_4.fseq + 1);
/*  22 */       if ((((this.fseq > 127) ? 1 : 0) | ((this.fseq <= 0) ? 1 : 0)) != 0)
/*  23 */         this.fseq = 1;
/*  24 */       return this.fseq;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ZjSimulator() {
/*  29 */     this.taskTemplate = new MessageZj();
/*     */     try {
/*  31 */       this.taskTemplate.read(HexDump.toByteBuffer(this.strTask)); } catch (Exception localException) {
/*     */     }
/*     */   }
/*     */ 
/*     */   private MessageZj createHeart() {
/*  36 */     MessageZj msg = new MessageZj();
/*  37 */     msg.head.rtua = this.rtua;
/*  38 */     msg.head.c_func = 36;
/*  39 */     msg.head.c_dir = 1;
/*  40 */     msg.head.fseq = getFseq();
/*  41 */     return msg;
/*     */   }
/*     */ 
/*     */   private MessageZj createLogin() {
/*  45 */     MessageZj msg = new MessageZj();
/*  46 */     msg.head.rtua = this.rtua;
/*  47 */     msg.head.c_func = 33;
/*  48 */     msg.head.c_dir = 1;
/*  49 */     msg.head.fseq = getFseq();
/*  50 */     msg.data = HexDump.toByteBuffer(this.pwd);
/*  51 */     return msg;
/*     */   }
/*     */ 
/*     */   private MessageZj createTask() {
/*  55 */     MessageZj msg = new MessageZj();
/*  56 */     msg.head.rtua = this.rtua;
/*  57 */     msg.head.c_func = 2;
/*  58 */     msg.head.c_dir = 1;
/*  59 */     msg.head.fseq = getFseq();
/*  60 */     msg.data = this.taskTemplate.data;
/*  61 */     return msg;
/*     */   }
/*     */ 
/*     */   public void onClose(JAsyncSocket client) {
/*  65 */     log.info("client closed. " + client);
/*  66 */     this.client = null;
/*     */   }
/*     */ 
/*     */   public void onConnect(JAsyncSocket client) {
/*  70 */     this.client = client;
/*  71 */     sendLogin();
/*  72 */     log.info("client connected. " + client);
/*     */   }
/*     */ 
/*     */   public void onReceive(JAsyncSocket client, IMessage message) {
/*  76 */     log.info("recv msg: " + message + " ,client:" + client);
/*     */   }
/*     */ 
/*     */   public void onSend(JAsyncSocket client, IMessage message) {
/*  80 */     log.info("send msg: " + message + " ,client:" + client);
/*     */   }
/*     */ 
/*     */   public void sendLogin() {
/*  84 */     if ((this.client != null) && (this.client.isConnected()))
/*  85 */       this.client.send(createLogin());
/*     */   }
/*     */ 
/*     */   public void sendHeart() {
/*  89 */     if ((this.client != null) && (this.client.isConnected()))
/*  90 */       this.client.send(createHeart());
/*     */   }
/*     */ 
/*     */   public void sendTask() {
/*  94 */     if ((this.client != null) && (this.client.isConnected()))
/*  95 */       this.client.send(createTask());
/*     */   }
/*     */ 
/*     */   public int getRtua() {
/*  99 */     return this.rtua;
/*     */   }
/*     */ 
/*     */   public void setRtua(int rtua) {
/* 103 */     this.rtua = rtua;
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 107 */     return ((this.client.isConnected()) ? "在线" : "断开");
/*     */   }
/*     */ }