/*     */ package com.hzjbbis.fk.sockclient.async;
/*     */ 
/*     */ import com.hzjbbis.fk.common.events.GlobalEventHandler;
/*     */ import com.hzjbbis.fk.common.spi.socket.IClientIO;
/*     */ import com.hzjbbis.fk.common.spi.socket.IServerSideChannel;
/*     */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.message.MultiProtoRecognizer;
/*     */ import com.hzjbbis.fk.sockclient.async.event.ClientConnectedEvent;
/*     */ import com.hzjbbis.fk.sockserver.io.SocketIoThreadPool;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class AsyncSocketPool
/*     */   implements ISocketServer
/*     */ {
/*  36 */   private static final Logger log = Logger.getLogger(AsyncSocketPool.class);
/*  37 */   private static int sequence = 1;
/*     */ 
/*  39 */   private String name = "异步socket连接池";
/*     */   private String peerIp;
/*     */   private int peerPort;
/*  42 */   private int clientSize = 1;
/*  43 */   private int ioThreadSize = 2;
/*  44 */   private int bufLength = 256;
/*     */ 
/*  46 */   private IClientIO ioHandler = null;
/*     */ 
/*  48 */   private String messageClass = "com.hzjbbis.fk.sockserver.message.SimpleMessage";
/*     */   private IMessageCreator messageCreator;
/*  50 */   private int timeout = 1800;
/*     */ 
/*  57 */   private String txfs = "02";
/*     */   private Class<IMessage> msgClassObject;
/*  62 */   private long lastReceiveTime = 0L; private long lastSendTime = 0L;
/*  63 */   private long totalRecvMessages = 0L; private long totalSendMessages = 0L;
/*  64 */   private int msgRecvPerMinute = 0; private int msgSendPerMinute = 0;
/*     */ 
/*  67 */   private volatile State state = State.STOPPED;
/*  68 */   protected List<JAsyncSocket> clients = Collections.synchronizedList(new ArrayList(1024));
/*  69 */   private SocketIoThreadPool ioPool = null;
/*     */   private AsyncSocketConnectThread connectThread;
/*     */ 
/*     */   public boolean start()
/*     */   {
/*     */     try
/*     */     {
/*  75 */       if (this.messageCreator == null) {
/*  76 */         this.msgClassObject = Class.forName(this.messageClass);
/*  77 */         this.msgClassObject.newInstance(); break label129:
/*     */       }
/*     */ 
/*  80 */       if ((this.messageClass != null) && (this.messageClass.length() > 0)) {
/*     */         try {
/*  82 */           this.msgClassObject = Class.forName(this.messageClass);
/*  83 */           this.msgClassObject.newInstance();
/*     */         } catch (Exception e) {
/*  85 */           log.error("AsyncSocketPool对象创建错误,检查配置文件：" + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception exp)
/*     */     {
/*  91 */       log.error("AsyncSocketPool对象创建错误,检查配置文件：" + exp.getLocalizedMessage(), exp);
/*  92 */       System.exit(-1);
/*     */     }
/*  94 */     if (!(this.state.isStopped())) {
/*  95 */       label129: log.warn("AsyncSocketPool 非停止状态，不能启动服务。");
/*  96 */       return false;
/*     */     }
/*  98 */     if (this.ioThreadSize <= 0)
/*  99 */       this.ioThreadSize = (Runtime.getRuntime().availableProcessors() * 2);
/* 100 */     this.state = State.STARTING;
/*     */ 
/* 102 */     this.ioPool = new SocketIoThreadPool(this.peerPort, this.ioThreadSize, this.ioHandler);
/* 103 */     this.ioPool.start();
/*     */ 
/* 105 */     this.connectThread = new AsyncSocketConnectThread();
/* 106 */     this.connectThread.start();
/* 107 */     int cnt = 1000;
/* 108 */     while ((!(this.state.isRunning())) && (cnt-- > 0))
/*     */     {
/* 110 */       Thread.yield();
/*     */       try {
/* 112 */         Thread.sleep(10L);
/*     */       } catch (InterruptedException localInterruptedException) {
/*     */       }
/*     */     }
/* 116 */     for (int i = 0; i < this.clientSize; ++i) {
/* 117 */       this.clients.add(new JAsyncSocket(this));
/*     */     }
/* 119 */     log.info("AsyncSocketPool启动成功");
/*     */ 
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 125 */     if (!(this.state.isRunning()))
/* 126 */       return;
/* 127 */     this.state = State.STOPPING;
/*     */ 
/* 130 */     this.connectThread.interrupt();
/* 131 */     int cnt = 500;
/* 132 */     while ((this.connectThread.isAlive()) && (cnt-- > 0)) {
/* 133 */       Thread.yield();
/*     */       try {
/* 135 */         this.connectThread.join(20L); } catch (InterruptedException localInterruptedException) {
/*     */       }
/*     */     }
/* 138 */     this.connectThread = null;
/*     */ 
/* 141 */     this.ioPool.stop();
/* 142 */     this.ioPool = null;
/*     */ 
/* 144 */     this.clients.clear();
/* 145 */     this.state = State.STOPPED;
/* 146 */     log.info("AsyncSocketPool 停止");
/*     */   }
/*     */ 
/*     */   public IMessage createMessage(ByteBuffer buf) {
/* 150 */     if (this.messageCreator != null) {
/* 151 */       IMessage msg = this.messageCreator.create();
/* 152 */       if (msg == null)
/* 153 */         msg = MultiProtoRecognizer.recognize(buf);
/* 154 */       return msg;
/*     */     }
/*     */     try {
/* 157 */       return ((IMessage)this.msgClassObject.newInstance());
/*     */     } catch (Exception exp) {
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public int getBufLength()
/*     */   {
/* 165 */     return this.bufLength;
/*     */   }
/*     */ 
/*     */   public int getClientSize() {
/* 169 */     return this.clientSize;
/*     */   }
/*     */ 
/*     */   public IServerSideChannel[] getClients()
/*     */   {
/* 176 */     return ((IServerSideChannel[])this.clients.toArray(new IServerSideChannel[0]));
/*     */   }
/*     */ 
/*     */   public long getLastReceiveTime() {
/* 180 */     return this.lastReceiveTime;
/*     */   }
/*     */ 
/*     */   public long getLastSendTime() {
/* 184 */     return this.lastSendTime;
/*     */   }
/*     */ 
/*     */   public int getMaxContinueRead() {
/* 188 */     return 10;
/*     */   }
/*     */ 
/*     */   public int getMsgRecvPerMinute() {
/* 192 */     return this.msgRecvPerMinute;
/*     */   }
/*     */ 
/*     */   public int getMsgSendPerMinute() {
/* 196 */     return this.msgSendPerMinute;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/* 200 */     return 0;
/*     */   }
/*     */ 
/*     */   public long getTotalRecvMessages() {
/* 204 */     return this.totalRecvMessages;
/*     */   }
/*     */ 
/*     */   public long getTotalSendMessages() {
/* 208 */     return this.totalSendMessages;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 212 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void incRecvMessage() {
/* 216 */     this.totalRecvMessages += 1L;
/*     */   }
/*     */ 
/*     */   public void incSendMessage() {
/* 220 */     this.totalSendMessages += 1L;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 224 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public IClientIO getIoHandler() {
/* 228 */     return this.ioHandler;
/*     */   }
/*     */ 
/*     */   public int getWriteFirstCount() {
/* 232 */     return 0;
/*     */   }
/*     */ 
/*     */   public void removeClient(IServerSideChannel client) {
/* 236 */     boolean found = false;
/* 237 */     for (JAsyncSocket sock : this.clients) {
/* 238 */       if (sock.isConnected()) {
/* 239 */         found = true;
/* 240 */         break;
/*     */       }
/*     */     }
/* 243 */     if (!(found)) {
/* 244 */       this.totalRecvMessages = 0L;
/* 245 */       this.totalSendMessages = 0L;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLastReceiveTime(long lastRecv) {
/* 250 */     this.lastReceiveTime = lastRecv;
/*     */   }
/*     */ 
/*     */   public void setLastSendTime(long lastSend) {
/* 254 */     this.lastSendTime = lastSend;
/*     */   }
/*     */ 
/*     */   public int getIoThreadSize() {
/* 258 */     return this.ioThreadSize;
/*     */   }
/*     */ 
/*     */   public void setIoThreadSize(int ioThreadSize) {
/* 262 */     this.ioThreadSize = ioThreadSize;
/*     */   }
/*     */ 
/*     */   public String getMessageClass() {
/* 266 */     return this.messageClass;
/*     */   }
/*     */ 
/*     */   public void setMessageClass(String messageClass) {
/* 270 */     this.messageClass = messageClass;
/*     */   }
/*     */ 
/*     */   public IMessageCreator getMessageCreator() {
/* 274 */     return this.messageCreator;
/*     */   }
/*     */ 
/*     */   public void setMessageCreator(IMessageCreator messageCreator) {
/* 278 */     this.messageCreator = messageCreator;
/*     */   }
/*     */ 
/*     */   public int getTimeout() {
/* 282 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 286 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public void setClientSize(int clientSize) {
/* 290 */     this.clientSize = clientSize;
/*     */   }
/*     */ 
/*     */   public void setBufLength(int bufLength) {
/* 294 */     this.bufLength = bufLength;
/*     */   }
/*     */ 
/*     */   public void setIoHandler(IClientIO ioHandler) {
/* 298 */     this.ioHandler = ioHandler;
/*     */   }
/*     */ 
/*     */   public String getPeerIp()
/*     */   {
/* 435 */     return this.peerIp;
/*     */   }
/*     */ 
/*     */   public void setPeerIp(String peerIp) {
/* 439 */     this.peerIp = peerIp;
/*     */   }
/*     */ 
/*     */   public int getPeerPort() {
/* 443 */     return this.peerPort;
/*     */   }
/*     */ 
/*     */   public void setPeerPort(int peerPort) {
/* 447 */     this.peerPort = peerPort;
/*     */   }
/*     */ 
/*     */   public boolean isRunning() {
/* 451 */     return this.state.isRunning();
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 455 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 459 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getModuleType() {
/* 463 */     return "socketClient";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/* 467 */     return false;
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 471 */     return "";
/*     */   }
/*     */ 
/*     */   public String getServerAddress() {
/* 475 */     return "";
/*     */   }
/*     */ 
/*     */   class AsyncSocketConnectThread extends Thread
/*     */   {
/*     */     private Selector selector;
/* 303 */     private long lastCheckReConnect = System.currentTimeMillis();
/* 304 */     private long lastCheckTimeout = System.currentTimeMillis();
/* 305 */     private long now = 0L;
/*     */ 
/*     */     public AsyncSocketConnectThread() { super("AsyncSockConnect-" + (AsyncSocketPool.sequence++));
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 312 */         this.selector = Selector.open();
/*     */       }
/*     */       catch (Exception e) {
/* 315 */         AsyncSocketPool.log.error("AsyncSocketPool 连接线程异常（selector.open)" + e.getMessage());
/* 316 */         return;
/*     */       }
/* 318 */       long time1 = System.currentTimeMillis();
/* 319 */       for (JAsyncSocket client : AsyncSocketPool.this.clients) {
/* 320 */         toConnect(client);
/*     */       }
/* 322 */       long milli = System.currentTimeMillis() - time1;
/* 323 */       AsyncSocketPool.log.info(getName() + ",开始侦听异步连接事件...[socket创建时间=" + milli + "]");
/* 324 */       AsyncSocketPool.this.state = State.RUNNING;
/* 325 */       while (AsyncSocketPool.this.state != State.STOPPING) {
/* 326 */         this.now = System.currentTimeMillis();
/*     */         try
/*     */         {
/* 329 */           tryConnect();
/*     */         }
/*     */         catch (Exception e) {
/* 332 */           AsyncSocketPool.log.error("AsyncSocketPool ConnectThread异常:" + e.getLocalizedMessage(), e);
/*     */         }
/*     */ 
/* 335 */         if (this.now - this.lastCheckTimeout > 60000L) {
/* 336 */           checkTimeout();
/* 337 */           this.lastCheckTimeout = this.now;
/*     */         }
/*     */       }
/*     */       try {
/* 341 */         this.selector.close();
/*     */       }
/*     */       catch (IOException ioe) {
/* 344 */         AsyncSocketPool.log.warn("selector.close异常：" + ioe.getLocalizedMessage());
/*     */       }
/* 346 */       this.selector = null;
/* 347 */       AsyncSocketPool.this.state = State.STOPPED;
/*     */     }
/*     */ 
/*     */     private void tryConnect()
/*     */       throws IOException
/*     */     {
/*     */       SocketChannel channel;
/* 351 */       this.selector.select(100L);
/*     */ 
/* 353 */       if (this.now - this.lastCheckReConnect > 1000L) {
/* 354 */         this.lastCheckReConnect = this.now;
/* 355 */         for (JAsyncSocket client : AsyncSocketPool.this.clients) {
/* 356 */           channel = client.getChannel();
/* 357 */           if (channel == null) {
/* 358 */             toConnect(client); } else {
/* 359 */             if (channel.isConnectionPending()) continue; if (channel.isConnected()) {
/*     */               continue;
/*     */             }
/* 362 */             toConnect(client); }
/*     */         }
/*     */       }
/* 365 */       Set set = this.selector.selectedKeys();
/* 366 */       if (set.size() > 0)
/* 367 */         AsyncSocketPool.log.debug("发现连接成功事件");
/* 368 */       for (SelectionKey key : set) {
/* 369 */         if (key.isConnectable()) {
/* 370 */           doConnect(key);
/*     */         }
/*     */         else
/*     */         {
/* 374 */           AsyncSocketPool.log.warn("在Connect时候，SelectionKey非法：" + key);
/* 375 */           key.cancel();
/*     */         }
/*     */       }
/* 378 */       set.clear();
/*     */     }
/*     */ 
/*     */     private void doConnect(SelectionKey key) {
/* 382 */       JAsyncSocket client = (JAsyncSocket)key.attachment();
/*     */       try {
/* 384 */         if (!(client.getChannel().finishConnect()))
/*     */           return;
/* 386 */         AsyncSocketPool.this.ioPool.addConnectedClient(client);
/* 387 */         GlobalEventHandler.postEvent(new ClientConnectedEvent(AsyncSocketPool.this, client));
/* 388 */         if (AsyncSocketPool.log.isDebugEnabled())
/* 389 */           AsyncSocketPool.log.debug("异步连接成功:" + client);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 393 */         toConnect(client);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void toConnect(JAsyncSocket client) {
/*     */       try {
/* 399 */         long now = System.currentTimeMillis();
/* 400 */         if (now - client.getLastConnectTime() < 15000L) {
/* 401 */           return;
/*     */         }
/* 403 */         client.createChannel();
/* 404 */         client.setLastConnectTime(now);
/* 405 */         SocketChannel channel = client.getChannel();
/* 406 */         channel.configureBlocking(false);
/* 407 */         channel.register(this.selector, 8, client);
/* 408 */         if (!(channel.connect(new InetSocketAddress(AsyncSocketPool.this.peerIp, AsyncSocketPool.this.peerPort)))) return;
/*     */         try {
/* 410 */           if (!(client.getChannel().finishConnect()))
/*     */             return;
/* 412 */           AsyncSocketPool.this.ioPool.addConnectedClient(client);
/* 413 */           GlobalEventHandler.postEvent(new ClientConnectedEvent(AsyncSocketPool.this, client));
/* 414 */           if (AsyncSocketPool.log.isDebugEnabled())
/* 415 */             AsyncSocketPool.log.debug("异步连接成功:" + client);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 419 */           AsyncSocketPool.log.error(e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 424 */         AsyncSocketPool.log.error(e.getLocalizedMessage(), e);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void checkTimeout()
/*     */     {
/*     */     }
/*     */   }
/*     */ }