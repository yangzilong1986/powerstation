/*     */ package com.hzjbbis.fk.sockclient;
/*     */ 
/*     */ import com.hzjbbis.fk.common.spi.socket.abstra.BaseClientChannel;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.message.gate.MessageGateCreator;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.HexDump;
/*     */ import com.hzjbbis.fk.utils.State;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.ConnectException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class JSocket extends BaseClientChannel
/*     */ {
/*  29 */   private static final Logger log = Logger.getLogger(JSocket.class);
/*  30 */   private static final TraceLog trace = TraceLog.getTracer(JSocket.class);
/*     */ 
/*  32 */   private String hostIp = "127.0.0.1";
/*  33 */   private int hostPort = 10001;
/*  34 */   private int bufLength = 256;
/*  35 */   private IMessageCreator messageCreator = new MessageGateCreator();
/*  36 */   private int timeout = 10;
/*  37 */   private JSocketListener listener = new DumyJSocketListener();
/*     */   private String txfs;
/*     */   private volatile Socket socket;
/*  42 */   private final Object sendLock = new Object();
/*     */   private ByteBuffer sendBuffer;
/*     */   private ByteBuffer readBuffer;
/*  44 */   private volatile State _state = State.STOPPED;
/*     */   private ReadThread reader;
/*  48 */   private long lastReadTime = System.currentTimeMillis();
/*  49 */   private int connectWaitTime = 2;
/*  50 */   private long lastConnectTime = System.currentTimeMillis() - 10000L;
/*     */   private String peerAddr;
/*     */ 
/*     */   public void init()
/*     */   {
/*  54 */     if (State.STOPPED != this._state)
/*  55 */       return;
/*  56 */     this._state = State.STARTING;
/*  57 */     this.readBuffer = ByteBuffer.allocate(this.bufLength);
/*  58 */     this.sendBuffer = ByteBuffer.allocate(this.bufLength);
/*  59 */     this.peerAddr = this.hostIp + ":" + this.hostPort;
/*  60 */     this.reader = new ReadThread();
/*  61 */     this.reader.start();
/*     */   }
/*     */ 
/*     */   public void close() {
/*  65 */     this._state = State.STOPPING;
/*  66 */     this.reader.interrupt();
/*  67 */     int cnt = 100;
/*  68 */     while ((State.STOPPED != this._state) && (cnt-- > 0)) {
/*  69 */       Thread.yield();
/*     */       try {
/*  71 */         Thread.sleep(10L); } catch (Exception localException) {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reConnect() {
/*     */     try {
/*  78 */       if (trace.isEnabled())
/*  79 */         trace.trace("do reConnect. " + getPeerAddr());
/*  80 */       _closeSocket();
/*     */     } catch (Exception e) {
/*  82 */       log.warn("reConnect exception:" + e.getLocalizedMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  87 */     return this._state.isRunning();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/*  91 */     return ((!(isActive())) || (this.socket == null) || (!(this.socket.isConnected())));
/*     */   }
/*     */ 
/*     */   private boolean _connect() {
/*     */     try {
/*  96 */       trace.trace("client socket is connecting to server :" + getPeerAddr());
/*  97 */       this.lastConnectTime = System.currentTimeMillis();
/*  98 */       this.socket = new Socket();
/*  99 */       InetSocketAddress ar = new InetSocketAddress(this.hostIp, this.hostPort);
/* 100 */       this.socket.setSoTimeout(this.timeout * 1000);
/* 101 */       this.socket.connect(ar, this.timeout * 1000);
/* 102 */       this.connectWaitTime = 2;
/*     */     } catch (ConnectException e) {
/* 104 */       log.error("不能连接到:" + this.hostIp + "@" + this.hostPort + ",reason=" + e.getLocalizedMessage(), e);
/* 105 */       this.socket = null;
/* 106 */       return false;
/*     */     }
/*     */     catch (Exception e) {
/* 109 */       log.error("不能连接到:" + this.hostIp + "@" + this.hostPort, e);
/* 110 */       if (this.socket != null)
/*     */         try {
/* 112 */           this.socket.close();
/*     */         } catch (Exception localException1) {
/*     */         }
/* 115 */       this.socket = null;
/* 116 */       return false;
/*     */     }
/* 118 */     log.info("client socket connect to server successfully:" + getPeerAddr());
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   private void _closeSocket() {
/* 123 */     synchronized (this.sendLock) {
/* 124 */       long interval = System.currentTimeMillis() - this.lastConnectTime;
/* 125 */       if (interval < this.connectWaitTime * 1000) {
/* 126 */         trace.trace("can not close socket within " + this.connectWaitTime + " sec");
/* 127 */         return;
/*     */       }
/*     */       try {
/*     */         try {
/* 131 */           this.socket.shutdownInput();
/* 132 */           this.socket.shutdownOutput(); } catch (Exception localException) {
/*     */         }
/* 134 */         this.socket.close();
/*     */       } catch (Exception localException1) {
/*     */       } finally {
/* 137 */         this.socket = null;
/* 138 */         this.listener.onClose(this);
/* 139 */         this.readBuffer.clear();
/* 140 */         this.sendBuffer.clear();
/* 141 */         if ((State.STOPPING == this._state) || (State.STOPPED == this._state)) {
/* 142 */           this.reader = null;
/* 143 */           monitorexit; return;
/*     */         }
/* 145 */         this._state = State.STARTING; }  }  } 
/*     */   // ERROR //
/*     */   public boolean send(byte[] output) { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ifnull +10 -> 11
/*     */     //   4: aload_0
/*     */     //   5: invokevirtual 280	com/hzjbbis/fk/sockclient/JSocket:isConnected	()Z
/*     */     //   8: ifne +5 -> 13
/*     */     //   11: iconst_0
/*     */     //   12: ireturn
/*     */     //   13: aload_0
/*     */     //   14: getfield 83	com/hzjbbis/fk/sockclient/JSocket:sendLock	Ljava/lang/Object;
/*     */     //   17: dup
/*     */     //   18: astore_2
/*     */     //   19: monitorenter
/*     */     //   20: aload_0
/*     */     //   21: getfield 212	com/hzjbbis/fk/sockclient/JSocket:socket	Ljava/net/Socket;
/*     */     //   24: invokevirtual 281	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
/*     */     //   27: aload_1
/*     */     //   28: iconst_0
/*     */     //   29: aload_1
/*     */     //   30: arraylength
/*     */     //   31: invokevirtual 285	java/io/OutputStream:write	([BII)V
/*     */     //   34: aload_0
/*     */     //   35: getfield 212	com/hzjbbis/fk/sockclient/JSocket:socket	Ljava/net/Socket;
/*     */     //   38: invokevirtual 281	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
/*     */     //   41: invokevirtual 291	java/io/OutputStream:flush	()V
/*     */     //   44: goto +65 -> 109
/*     */     //   47: astore_3
/*     */     //   48: new 122	java/lang/StringBuilder
/*     */     //   51: dup
/*     */     //   52: ldc_w 294
/*     */     //   55: invokespecial 130	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   58: aload_3
/*     */     //   59: invokevirtual 196	java/lang/Exception:getLocalizedMessage	()Ljava/lang/String;
/*     */     //   62: invokevirtual 135	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   65: ldc_w 296
/*     */     //   68: invokevirtual 135	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   71: aload_0
/*     */     //   72: invokevirtual 186	com/hzjbbis/fk/sockclient/JSocket:getPeerAddr	()Ljava/lang/String;
/*     */     //   75: invokevirtual 135	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   78: invokevirtual 142	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   81: astore 4
/*     */     //   83: getstatic 45	com/hzjbbis/fk/sockclient/JSocket:log	Lorg/apache/log4j/Logger;
/*     */     //   86: aload 4
/*     */     //   88: aload_3
/*     */     //   89: invokevirtual 244	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   92: getstatic 53	com/hzjbbis/fk/sockclient/JSocket:trace	Lcom/hzjbbis/fk/tracelog/TraceLog;
/*     */     //   95: aload 4
/*     */     //   97: aload_3
/*     */     //   98: invokevirtual 298	com/hzjbbis/fk/tracelog/TraceLog:trace	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   101: aload_0
/*     */     //   102: invokespecial 191	com/hzjbbis/fk/sockclient/JSocket:_closeSocket	()V
/*     */     //   105: aload_2
/*     */     //   106: monitorexit
/*     */     //   107: iconst_0
/*     */     //   108: ireturn
/*     */     //   109: aload_2
/*     */     //   110: monitorexit
/*     */     //   111: goto +6 -> 117
/*     */     //   114: aload_2
/*     */     //   115: monitorexit
/*     */     //   116: athrow
/*     */     //   117: iconst_1
/*     */     //   118: ireturn
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   20	44	47	java/lang/Exception
/*     */     //   20	107	114	finally
/*     */     //   109	111	114	finally
/*     */     //   114	116	114	finally } 
/*     */   public boolean sendMessage(IMessage msg) { boolean ret = false;
/* 171 */     synchronized (this.sendLock) {
/* 172 */       ret = _send(msg);
/*     */     }
/* 174 */     if (ret) {
/* 175 */       msg.setSource(this);
/* 176 */       msg.setIoTime(System.currentTimeMillis());
/* 177 */       msg.setTxfs(this.txfs);
/* 178 */       this.listener.onSend(this, msg);
/*     */     }
/* 180 */     return ret;
/*     */   }
/*     */ 
/*     */   private boolean _send(IMessage msg) {
/* 184 */     if (this.socket == null)
/* 185 */       return false;
/* 186 */     boolean done = false;
/* 187 */     this.sendBuffer.clear();
/* 188 */     int cnt = 100;
/* 189 */     while ((!(done)) && (--cnt > 0)) {
/* 190 */       done = msg.write(this.sendBuffer);
/* 191 */       this.sendBuffer.flip();
/* 192 */       byte[] out = this.sendBuffer.array();
/* 193 */       int len = this.sendBuffer.remaining();
/* 194 */       int off = this.sendBuffer.position();
/*     */       try {
/* 196 */         this.socket.getOutputStream().write(out, off, len);
/* 197 */         this.socket.getOutputStream().flush();
/*     */       } catch (Exception e) {
/* 199 */         String info = "client closed in '_send' reason is" + e.getLocalizedMessage() + ", peer=" + getPeerAddr();
/* 200 */         log.error(info, e);
/* 201 */         trace.trace(info, e);
/* 202 */         _closeSocket();
/* 203 */         return false;
/*     */       }
/*     */     }
/* 206 */     return true;
/*     */   }
/*     */ 
/*     */   public IMessageCreator getMessageCreator()
/*     */   {
/* 342 */     return this.messageCreator;
/*     */   }
/*     */ 
/*     */   public void setMessageCreator(IMessageCreator messageCreator) {
/* 346 */     this.messageCreator = messageCreator;
/*     */   }
/*     */ 
/*     */   public String getHostIp() {
/* 350 */     return this.hostIp;
/*     */   }
/*     */ 
/*     */   public void setHostIp(String hostIp) {
/* 354 */     this.hostIp = hostIp;
/*     */   }
/*     */ 
/*     */   public int getHostPort() {
/* 358 */     return this.hostPort;
/*     */   }
/*     */ 
/*     */   public void setHostPort(int hostPort) {
/* 362 */     this.hostPort = hostPort;
/*     */   }
/*     */ 
/*     */   public int getBufLength() {
/* 366 */     return this.bufLength;
/*     */   }
/*     */ 
/*     */   public void setBufLength(int bufLength) {
/* 370 */     this.bufLength = bufLength;
/*     */   }
/*     */ 
/*     */   public int getTimeout() {
/* 374 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 378 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public JSocketListener getListener() {
/* 382 */     return this.listener;
/*     */   }
/*     */ 
/*     */   public void setListener(JSocketListener listener) {
/* 386 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */   public long getLastReadTime() {
/* 390 */     return this.lastReadTime;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 394 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 398 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public String getPeerAddr() {
/* 402 */     if (this.peerAddr != null) {
/* 403 */       return this.peerAddr;
/*     */     }
/* 405 */     return this.hostIp + ":" + this.hostPort;
/*     */   }
/*     */ 
/*     */   public String getPeerIp() {
/* 409 */     return this.hostIp;
/*     */   }
/*     */ 
/*     */   public int getPeerPort() {
/* 413 */     return this.hostPort;
/*     */   }
/*     */ 
/*     */   public SocketAddress getSocketAddress() {
/* 417 */     return new InetSocketAddress(this.hostIp, this.hostPort);
/*     */   }
/*     */ 
/*     */   public boolean send(IMessage msg) {
/* 421 */     return sendMessage(msg);
/*     */   }
/*     */ 
/*     */   public long getLastIoTime() {
/* 425 */     return this.lastReadTime;
/*     */   }
/*     */ 
/*     */   class ReadThread extends Thread
/*     */   {
/* 210 */     IMessage message = null;
/*     */ 
/*     */     public ReadThread() {
/* 213 */       super("sock-" + JSocket.this.hostIp + "@" + JSocket.this.hostPort);
/*     */     }
/*     */ 
/*     */     public void run() {
/* 217 */       break label278:
/*     */ 
/* 220 */       if (System.currentTimeMillis() - JSocket.this.lastConnectTime < JSocket.this.connectWaitTime * 1000);
/*     */       try
/*     */       {
/* 222 */         Thread.sleep(1000L);
/*     */       } catch (InterruptedException e) {
/* 224 */         JSocket.trace.trace("thread sleep interrupted");
/* 225 */         break label216:
/*     */ 
/* 229 */         if (JSocket.this._connect() != 0) {
/* 230 */           if (JSocket.trace.isEnabled())
/* 231 */             JSocket.trace.trace("connect to server ok. " + JSocket.this.getPeerAddr());
/* 232 */           JSocket.this._state = State.RUNNING;
/*     */ 
/* 235 */           JSocket.this.listener.onConnected(JSocket.this);
/*     */         }
/*     */         else
/*     */         {
/* 239 */           JSocket.this.connectWaitTime *= 2;
/* 240 */           if (JSocket.this.connectWaitTime > 300)
/* 241 */             JSocket.this.connectWaitTime = 300;
/* 242 */           JSocket.trace.trace("client socket cannot connected to server :" + JSocket.this.hostIp + "@" + JSocket.this.hostPort);
/*     */         }
/*     */       }
/*     */       do
/*     */       {
/* 219 */         if (JSocket.this.socket != null);
/* 246 */         label216: int ret = _doReceive();
/* 247 */         if (ret >= 0)
/*     */           continue;
/* 249 */         if (JSocket.trace.isEnabled())
/* 250 */           JSocket.trace.trace("client closed by _doReceive return=" + ret + ",peer=" + JSocket.this.getPeerAddr());
/* 251 */         label278: JSocket.this._closeSocket();
/*     */       }
/* 217 */       while ((State.STOPPING != JSocket.this._state) && 
/* 218 */         (State.STOPPED != JSocket.this._state));
/*     */       try
/*     */       {
/* 255 */         if (JSocket.this.socket != null)
/* 256 */           JSocket.this._closeSocket(); 
/*     */       } catch (Exception localException) {
/*     */       }
/* 258 */       JSocket.this._state = State.STOPPED;
/* 259 */       JSocket.trace.trace("client socket stoped :" + JSocket.this.hostIp + "@" + JSocket.this.hostPort);
/*     */     }
/*     */ 
/*     */     private int _doReceive() {
/*     */       try {
/* 264 */         int len = JSocket.this.readBuffer.remaining();
/* 265 */         if (len == 0) {
/* 266 */           JSocket.this.readBuffer.position(0);
/* 267 */           JSocket.log.warn("缓冲区满，不能接收数据。dump=" + HexDump.hexDumpCompact(JSocket.this.readBuffer));
/* 268 */           JSocket.this.readBuffer.clear();
/* 269 */           len = JSocket.this.readBuffer.remaining();
/*     */         }
/* 271 */         byte[] in = JSocket.this.readBuffer.array();
/* 272 */         int off = JSocket.this.readBuffer.position();
/* 273 */         int n = JSocket.this.socket.getInputStream().read(in, off, len);
/* 274 */         if (n <= 0)
/* 275 */           return -1;
/* 276 */         JSocket.this.lastReadTime = System.currentTimeMillis();
/* 277 */         JSocket.this.readBuffer.position(off + n);
/* 278 */         JSocket.this.readBuffer.flip();
/*     */       }
/*     */       catch (SocketTimeoutException te) {
/* 281 */         return 0;
/*     */       }
/*     */       catch (IOException ioe) {
/* 284 */         JSocket.log.warn("client IO exception," + ioe.getLocalizedMessage() + ",peer=" + JSocket.this.getPeerAddr());
/* 285 */         return -2;
/*     */       }
/*     */       catch (Exception e) {
/* 288 */         JSocket.log.warn("client socket[" + JSocket.this.getPeerAddr() + "] _doReceive:" + e.getLocalizedMessage(), e);
/* 289 */         return -3;
/*     */       }
/*     */       try {
/* 292 */         _handleBuffer();
/*     */       }
/*     */       catch (Exception e) {
/* 295 */         JSocket.log.error(e.getLocalizedMessage(), e);
/* 296 */         return 0;
/*     */       }
/* 298 */       return 0;
/*     */     }
/*     */ 
/*     */     private void _handleBuffer()
/*     */     {
/* 303 */       while (JSocket.this.readBuffer.hasRemaining()) {
/* 304 */         if (this.message == null) {
/* 305 */           this.message = JSocket.this.messageCreator.create();
/*     */         }
/* 307 */         boolean down = false;
/*     */         try {
/* 309 */           down = this.message.read(JSocket.this.readBuffer);
/*     */         } catch (Exception e) {
/* 311 */           JSocket.log.warn("消息对象读取数据异常:" + e.getLocalizedMessage(), e);
/* 312 */           this.message = null;
/* 313 */           break label225:
/*     */         }
/* 315 */         if (!(down)) break;
/*     */         try {
/* 317 */           this.message.setSource(JSocket.this);
/* 318 */           this.message.setIoTime(System.currentTimeMillis());
/* 319 */           this.message.setTxfs(JSocket.this.txfs);
/*     */ 
/* 322 */           if ((this.message.getPeerAddr() == null) || (this.message.getPeerAddr().length() == 0)) {
/* 323 */             this.message.setPeerAddr(JSocket.this.peerAddr);
/*     */           }
/* 325 */           JSocket.this.listener.onReceive(JSocket.this, this.message);
/*     */         } catch (Exception e) {
/* 327 */           JSocket.log.error(e.getLocalizedMessage(), e);
/*     */         }
/* 329 */         this.message = null;
/*     */       }
/*     */ 
/* 334 */       if (JSocket.this.readBuffer.hasRemaining())
/* 335 */         label225: JSocket.this.readBuffer.compact();
/*     */       else
/* 337 */         JSocket.this.readBuffer.clear();
/*     */     }
/*     */   }
/*     */ }