/*     */ package com.hzjbbis.fk.sockclient.async.simulator;
/*     */ 
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.sockclient.async.JAsyncSocket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ public class SimulatorManager
/*     */ {
/*  12 */   private static ArrayList<IRtuSimulator> simulators = new ArrayList();
/*  13 */   public static int rtua = 92010001;
/*  14 */   public static int heartInterval = 5;
/*  15 */   public static int taskInterval = 15;
/*  16 */   private static Timer timerHeart = null; private static Timer timerTask = null;
/*  17 */   public static int totalSend = 0; public static int totalRecv = 0;
/*  18 */   private static LinkedList<IMessage> sendMsg = new LinkedList();
/*  19 */   private static LinkedList<IMessage> recvMsg = new LinkedList();
/*  20 */   private static Object lockRecv = new Object(); private static Object lockSend = new Object();
/*     */ 
/*     */   public static void startHeart() {
/*  23 */     stopHeart();
/*  24 */     timerHeart = new Timer("simul.heart");
/*  25 */     timerHeart.schedule(new TimerTask()
/*     */     {
/*     */       public void run() {
/*  28 */         synchronized (SimulatorManager.simulators) {
/*  29 */           for (IRtuSimulator simu : SimulatorManager.simulators)
/*  30 */             simu.sendHeart();
/*     */         }
/*     */       }
/*     */     }
/*     */     , 0L, heartInterval * 1000);
/*     */   }
/*     */ 
/*     */   public static void stopHeart() {
/*  38 */     if (timerHeart != null) {
/*  39 */       timerHeart.cancel();
/*  40 */       timerHeart = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isHeartRunning() {
/*  45 */     return (timerHeart == null);
/*     */   }
/*     */ 
/*     */   public static void startTask() {
/*  49 */     stopTask();
/*  50 */     timerTask = new Timer("simul.task");
/*  51 */     timerTask.schedule(new TimerTask()
/*     */     {
/*     */       public void run() {
/*  54 */         synchronized (SimulatorManager.simulators) {
/*  55 */           for (IRtuSimulator simu : SimulatorManager.simulators)
/*  56 */             simu.sendTask();
/*     */         }
/*     */       }
/*     */     }
/*     */     , 0L, taskInterval * 1000);
/*     */   }
/*     */ 
/*     */   public static void stopTask() {
/*  64 */     if (timerTask != null) {
/*  65 */       timerTask.cancel();
/*  66 */       timerTask = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isTaskRunning() {
/*  71 */     return (timerTask == null);
/*     */   }
/*     */ 
/*     */   public static void onChannelConnected(JAsyncSocket channel) {
/*  75 */     IRtuSimulator simulator = (IRtuSimulator)channel.attachment();
/*  76 */     if (simulator.getRtua() == 0) {
/*  77 */       synchronized (simulators) {
/*  78 */         simulator.setRtua(rtua++);
/*  79 */         simulators.add(simulator);
/*     */       }
/*     */     }
/*  82 */     simulator.onConnect(channel);
/*     */   }
/*     */ 
/*     */   public static void onChannelClosed(JAsyncSocket channel) {
/*  86 */     IRtuSimulator simulator = (IRtuSimulator)channel.attachment();
/*  87 */     simulator.onClose(channel);
/*     */   }
/*     */ 
/*     */   public static void onChannelReceive(JAsyncSocket channel, IMessage message) {
/*  91 */     IRtuSimulator simulator = (IRtuSimulator)channel.attachment();
/*  92 */     simulator.onReceive(channel, message);
/*  93 */     synchronized (lockRecv) {
/*  94 */       totalRecv += 1;
/*  95 */       if (recvMsg.size() > 5000)
/*  96 */         recvMsg.removeFirst();
/*  97 */       recvMsg.add(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void onChannelSend(JAsyncSocket channel, IMessage message) {
/* 102 */     IRtuSimulator simulator = (IRtuSimulator)channel.attachment();
/* 103 */     simulator.onSend(channel, message);
/* 104 */     synchronized (lockSend) {
/* 105 */       totalSend += 1;
/* 106 */       if (sendMsg.size() > 5000)
/* 107 */         sendMsg.removeFirst();
/* 108 */       sendMsg.add(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ArrayList<IRtuSimulator> getSimulators() {
/* 113 */     synchronized (simulators) {
/* 114 */       return simulators;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static IMessage[] getSendMsg() {
/* 119 */     synchronized (lockSend) {
/* 120 */       return ((IMessage[])sendMsg.toArray(new IMessage[0]));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static IMessage[] getRecvMsg() {
/* 125 */     synchronized (lockRecv) {
/* 126 */       return ((IMessage[])recvMsg.toArray(new IMessage[0]));
/*     */     }
/*     */   }
/*     */ }