/*    */ package com.hzjbbis.fk.sockclient.async.eventhandler;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.events.BasicEventHook;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.sockclient.async.event.adapt.OnClientClosed;
/*    */ import com.hzjbbis.fk.sockclient.async.event.adapt.OnClientConnected;
/*    */ import com.hzjbbis.fk.sockclient.async.event.adapt.OnClientRecvMsg;
/*    */ import com.hzjbbis.fk.sockclient.async.event.adapt.OnClientSendMsg;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AsyncSocketEventHandler extends BasicEventHook
/*    */ {
/*    */   private IEventHandler listener;
/*    */ 
/*    */   public void init()
/*    */   {
/* 18 */     if (this.include == null) {
/* 19 */       this.include = new HashMap();
/* 20 */       this.include.put(EventType.CLIENT_CONNECTED, new OnClientConnected());
/* 21 */       this.include.put(EventType.CLIENTCLOSE, new OnClientClosed());
/* 22 */       this.include.put(EventType.MSG_RECV, new OnClientRecvMsg());
/* 23 */       this.include.put(EventType.MSG_SENT, new OnClientSendMsg());
/*    */     }
/* 25 */     super.init();
/*    */   }
/*    */ 
/*    */   public void handleEvent(IEvent event)
/*    */   {
/* 30 */     super.handleEvent(event);
/* 31 */     if (this.listener != null)
/* 32 */       this.listener.handleEvent(event);
/*    */   }
/*    */ 
/*    */   public IEventHandler getListener() {
/* 36 */     return this.listener;
/*    */   }
/*    */ 
/*    */   public void setListener(IEventHandler listener) {
/* 40 */     this.listener = listener;
/*    */   }
/*    */ }