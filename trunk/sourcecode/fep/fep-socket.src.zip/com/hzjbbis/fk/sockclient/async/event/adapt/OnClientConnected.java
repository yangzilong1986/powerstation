/*    */ package com.hzjbbis.fk.sockclient.async.event.adapt;
/*    */ 
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*    */ import com.hzjbbis.fk.sockclient.async.JAsyncSocket;
/*    */ import com.hzjbbis.fk.sockclient.async.event.ClientConnectedEvent;
/*    */ import com.hzjbbis.fk.sockclient.async.simulator.SimulatorManager;
/*    */ import com.hzjbbis.fk.sockclient.async.simulator.ZjSimulator;
/*    */ import java.net.InetAddress;
/*    */ import java.net.Socket;
/*    */ import java.nio.channels.SocketChannel;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class OnClientConnected
/*    */   implements IEventHandler
/*    */ {
/* 13 */   private static final Logger log = Logger.getLogger(OnClientConnected.class);
/*    */ 
/*    */   public void handleEvent(IEvent evt) {
/* 16 */     ClientConnectedEvent event = (ClientConnectedEvent)evt;
/* 17 */     JAsyncSocket client = (JAsyncSocket)event.getClient();
/* 18 */     client.setLocalIp(client.getChannel().socket().getLocalAddress().getHostAddress());
/* 19 */     client.setLocalPort(client.getChannel().socket().getLocalPort());
/* 20 */     if (client.attachment() == null) {
/* 21 */       ZjSimulator simulator = new ZjSimulator();
/* 22 */       client.attach(simulator);
/*    */     }
/* 24 */     SimulatorManager.onChannelConnected(client);
/* 25 */     log.info("async socket pool: client=" + client.getPeerAddr() + " connected.");
/*    */   }
/*    */ }