/*     */ package com.hzjbbis.fk.sockclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SimpleSocket
/*     */ {
/*  19 */   private static final Logger log = Logger.getLogger(SimpleSocket.class);
/*     */   private String hostIp;
/*     */   private int hostPort;
/*  23 */   private int ioTimeout = 20000;
/*  24 */   private int readBufferSize = 2048;
/*     */   private Socket socket;
/*  28 */   private byte[] readBuffer = new byte[2048];
/*  29 */   private long lastConnectTime = 0L;
/*  30 */   private long lastIoTime = 0L;
/*     */ 
/*     */   public SimpleSocket(String ip, int port) {
/*  33 */     this.hostIp = ip;
/*  34 */     this.hostPort = port; }
/*     */ 
/*     */   public SimpleSocket() {
/*     */   }
/*     */ 
/*     */   public boolean connect() {
/*  40 */     this.socket = new Socket();
/*  41 */     this.lastConnectTime = System.currentTimeMillis();
/*     */     try {
/*  43 */       this.socket.connect(new InetSocketAddress(this.hostIp, this.hostPort));
/*  44 */       this.socket.setTcpNoDelay(true);
/*  45 */       this.socket.setSoTimeout(this.ioTimeout);
/*  46 */       this.socket.setReceiveBufferSize(this.readBufferSize);
/*  47 */       this.socket.setSendBufferSize(this.readBufferSize);
/*     */     } catch (IOException exp) {
/*  49 */       log.warn("连接到UMS服务器失败：hostIp=" + this.hostIp + ",port=" + this.hostPort + ";原因：" + exp.getLocalizedMessage());
/*  50 */       this.socket = null;
/*  51 */       return false;
/*     */     }
/*     */     finally {
/*  54 */       this.lastConnectTime = System.currentTimeMillis();
/*     */     }
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */   public void close() {
/*  60 */     if (this.socket == null) return;
/*     */     try {
/*  62 */       this.socket.shutdownInput();
/*  63 */       this.socket.shutdownOutput();
/*  64 */       this.socket.close();
/*     */     } catch (IOException exp) {
/*  66 */       log.warn("关闭socket异常，原因：" + exp.getLocalizedMessage());
/*     */     }
/*     */     finally {
/*  69 */       this.socket = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean reConnect()
/*     */   {
/*  75 */     close();
/*  76 */     return connect();
/*     */   }
/*     */ 
/*     */   public boolean isAlive() {
/*  80 */     return ((this.socket == null) || (!(this.socket.isConnected())));
/*     */   }
/*     */ 
/*     */   public int read(byte[] buffer, int offset, int len)
/*     */   {
/*     */     try
/*     */     {
/*  92 */       if (!(isAlive()))
/*  93 */         return -1;
/*  94 */       this.lastIoTime = System.currentTimeMillis();
/*  95 */       return this.socket.getInputStream().read(buffer, offset, len);
/*     */     }
/*     */     catch (SocketTimeoutException timeoutExp) {
/*  98 */       return 0;
/*     */     }
/*     */     catch (IOException ioExp) {
/* 101 */       close();
/* 102 */       log.warn("socket读数据异常:" + ioExp.getLocalizedMessage());
/* 103 */       return -1;
/*     */     }
/*     */     catch (Exception exp) {
/* 106 */       log.warn("socket读数据异常:" + exp.getLocalizedMessage(), exp); }
/* 107 */     return 0;
/*     */   }
/*     */ 
/*     */   public int read(byte[] buffer)
/*     */   {
/* 112 */     return read(buffer, 0, buffer.length);
/*     */   }
/*     */ 
/*     */   public int read(ByteBuffer byteBuffer) {
/* 116 */     byte[] buffer = new byte[byteBuffer.remaining()];
/* 117 */     int n = read(buffer);
/* 118 */     if (n <= 0)
/* 119 */       return n;
/* 120 */     byteBuffer.put(buffer, 0, n).flip();
/* 121 */     return n;
/*     */   }
/*     */ 
/*     */   public int write(byte[] buffer, int offset, int len) {
/*     */     try {
/* 126 */       if (!(isAlive()))
/* 127 */         return -1;
/* 128 */       this.socket.getOutputStream().write(buffer, offset, len);
/* 129 */       this.socket.getOutputStream().flush();
/*     */     }
/*     */     catch (IOException ioExp) {
/* 132 */       close();
/* 133 */       log.warn("socket发送数据异常:" + ioExp.getLocalizedMessage());
/* 134 */       return -1;
/*     */     }
/*     */     catch (Exception exp) {
/* 137 */       close();
/* 138 */       log.warn("socket发送数据异常:" + exp.getLocalizedMessage(), exp);
/* 139 */       return 0;
/*     */     }
/* 141 */     return len;
/*     */   }
/*     */ 
/*     */   public int write(byte[] buffer) {
/* 145 */     return write(buffer, 0, buffer.length);
/*     */   }
/*     */ 
/*     */   public int write(ByteBuffer byteBuffer) {
/* 149 */     byte[] buffer = new byte[byteBuffer.remaining()];
/* 150 */     byteBuffer.get(buffer);
/* 151 */     return write(buffer);
/*     */   }
/*     */ 
/*     */   public int write(String message) {
/*     */     try {
/* 156 */       return write(message.getBytes("GBK"));
/*     */     } catch (Exception e) {
/* 158 */       log.warn("write(message.getBytes(\"GBK\")) exception", e); }
/* 159 */     return -1;
/*     */   }
/*     */ 
/*     */   public String read()
/*     */   {
/* 164 */     int n = read(this.readBuffer);
/* 165 */     if (n <= 0)
/* 166 */       return null;
/*     */     try {
/* 168 */       return new String(this.readBuffer, 0, n);
/*     */     } catch (Exception e) {
/* 170 */       log.warn("read from socket exception.", e); }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   public long getLastConnectTime()
/*     */   {
/* 176 */     return this.lastConnectTime;
/*     */   }
/*     */ 
/*     */   public String getHostIp() {
/* 180 */     return this.hostIp;
/*     */   }
/*     */ 
/*     */   public void setHostIp(String hostIp) {
/* 184 */     this.hostIp = hostIp;
/*     */   }
/*     */ 
/*     */   public int getHostPort() {
/* 188 */     return this.hostPort;
/*     */   }
/*     */ 
/*     */   public void setHostPort(int hostPort) {
/* 192 */     this.hostPort = hostPort;
/*     */   }
/*     */ 
/*     */   public int getIoTimeout() {
/* 196 */     return this.ioTimeout;
/*     */   }
/*     */ 
/*     */   public void setIoTimeout(int ioTimeout) {
/* 200 */     this.ioTimeout = ioTimeout;
/*     */   }
/*     */ 
/*     */   public Socket getSocket() {
/* 204 */     return this.socket;
/*     */   }
/*     */ 
/*     */   public void setReadBufferSize(int readBufferSize) {
/* 208 */     this.readBufferSize = readBufferSize;
/*     */   }
/*     */ 
/*     */   public final long getLastIoTime() {
/* 212 */     return this.lastIoTime;
/*     */   }
/*     */ }