/*    */ package com.hzjbbis.fk.sockclient.async.event;
/*    */ 
/*    */ import com.hzjbbis.fk.common.EventType;
/*    */ import com.hzjbbis.fk.common.spi.IEvent;
/*    */ import com.hzjbbis.fk.common.spi.socket.IChannel;
/*    */ import com.hzjbbis.fk.common.spi.socket.ISocketServer;
/*    */ import com.hzjbbis.fk.message.IMessage;
/*    */ 
/*    */ public class ClientConnectedEvent
/*    */   implements IEvent
/*    */ {
/* 10 */   private final EventType type = EventType.CLIENT_CONNECTED;
/*    */   private ISocketServer server;
/*    */   private IChannel client;
/*    */ 
/*    */   public ClientConnectedEvent(ISocketServer s, IChannel c)
/*    */   {
/* 15 */     this.server = s;
/* 16 */     this.client = c;
/*    */   }
/*    */ 
/*    */   public IMessage getMessage() {
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   public Object getSource() {
/* 24 */     return this.server;
/*    */   }
/*    */ 
/*    */   public EventType getType() {
/* 28 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setSource(Object src) {
/*    */   }
/*    */ 
/*    */   public ISocketServer getServer() {
/* 35 */     return this.server;
/*    */   }
/*    */ 
/*    */   public IChannel getClient() {
/* 39 */     return this.client;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 43 */     return "ClientConnectedEvent,client=" + this.client.getPeerAddr();
/*    */   }
/*    */ }