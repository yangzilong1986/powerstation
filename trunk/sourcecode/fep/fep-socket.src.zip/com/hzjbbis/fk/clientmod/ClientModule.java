/*     */ package com.hzjbbis.fk.clientmod;
/*     */ 
/*     */ import com.hzjbbis.fk.common.simpletimer.ITimerFunctor;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerData;
/*     */ import com.hzjbbis.fk.common.simpletimer.TimerScheduler;
/*     */ import com.hzjbbis.fk.common.spi.IClientModule;
/*     */ import com.hzjbbis.fk.common.spi.IEventHandler;
/*     */ import com.hzjbbis.fk.message.IMessage;
/*     */ import com.hzjbbis.fk.message.IMessageCreator;
/*     */ import com.hzjbbis.fk.message.MessageType;
/*     */ import com.hzjbbis.fk.message.gate.MessageGate;
/*     */ import com.hzjbbis.fk.message.gate.MessageGateCreator;
/*     */ import com.hzjbbis.fk.sockclient.JSocket;
/*     */ import com.hzjbbis.fk.sockclient.JSocketListener;
/*     */ import com.hzjbbis.fk.sockserver.event.ReceiveMessageEvent;
/*     */ import com.hzjbbis.fk.sockserver.event.SendMessageEvent;
/*     */ import com.hzjbbis.fk.tracelog.TraceLog;
/*     */ import com.hzjbbis.fk.utils.CalendarUtil;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ClientModule
/*     */   implements JSocketListener, IClientModule, ITimerFunctor
/*     */ {
/*  34 */   private static final Logger log = Logger.getLogger(ClientModule.class);
/*     */ 
/*  36 */   private String name = "GPRS网关客户端";
/*  37 */   private String moduleType = "socketClient";
/*  38 */   private String hostIp = "127.0.0.1";
/*  39 */   private int hostPort = 10001;
/*  40 */   private int bufLength = 256;
/*  41 */   private IMessageCreator messageCreator = new MessageGateCreator();
/*  42 */   private int timeout = 2;
/*  43 */   private String txfs = "02";
/*     */   private IEventHandler eventHandler;
/*  45 */   private JSocket socket = null;
/*     */ 
/*  47 */   private int heartInterval = 0;
/*  48 */   private int requestNum = 200;
/*  49 */   private long lastHeartbeat = System.currentTimeMillis();
/*     */ 
/*  52 */   private long lastReceiveTime = System.currentTimeMillis();
/*  53 */   private long lastSendTime = 0L;
/*  54 */   private long totalRecvMessages = 0L; private long totalSendMessages = 0L;
/*  55 */   private int msgRecvPerMinute = 0; private int msgSendPerMinute = 0;
/*  56 */   private Object statisticsRecv = new Object(); private Object statisticsSend = new Object();
/*     */ 
/*  59 */   private boolean active = false;
/*  60 */   private IMessage heartMsg = null;
/*  61 */   private int curRecv = 200;
/*     */ 
/*     */   public boolean sendMessage(IMessage msg) {
/*  64 */     if (!(this.active))
/*  65 */       return false;
/*  66 */     boolean result = this.socket.sendMessage(msg);
/*  67 */     if ((result) && (msg.isHeartbeat())) {
/*  68 */       TraceLog _tracer = TraceLog.getTracer(this.socket.getClass());
/*  69 */       if (_tracer.isEnabled()) {
/*  70 */         _tracer.trace("send heart-beat ok.");
/*     */       }
/*     */     }
/*  73 */     return result;
/*     */   }
/*     */ 
/*     */   public void onClose(JSocket client) {
/*  77 */     this.active = false;
/*     */   }
/*     */ 
/*     */   public void onConnected(JSocket client) {
/*  81 */     this.active = true;
/*  82 */     if ((this.heartInterval > 0) && (this.requestNum > 0)) {
/*  83 */       sendMessage(this.heartMsg);
/*  84 */       if (log.isDebugEnabled()) {
/*  85 */         log.debug("连接时，请求报文数量=" + this.requestNum);
/*     */       }
/*  87 */       this.curRecv = this.requestNum;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onReceive(JSocket client, IMessage msg) {
/*  92 */     synchronized (this.statisticsRecv) {
/*  93 */       this.msgRecvPerMinute += 1;
/*  94 */       this.totalRecvMessages += 1L;
/*  95 */       if (this.requestNum > 0) {
/*  96 */         if (msg.isHeartbeat()) {
/*  97 */           this.lastHeartbeat = System.currentTimeMillis();
/*  98 */           TraceLog _tracer = TraceLog.getTracer(this.socket.getClass());
/*  99 */           if (_tracer.isEnabled()) {
/* 100 */             _tracer.trace("receive heart-beat,lastHeartbeat=" + this.lastHeartbeat + ",client=" + this.socket.getPeerAddr());
/*     */           }
/*     */         }
/* 103 */         if (--this.curRecv == 0) {
/* 104 */           sendMessage(this.heartMsg);
/* 105 */           if (log.isDebugEnabled())
/* 106 */             log.debug("onReceive时，server传输数量达到requestNum，重新请求报文数量=" + this.requestNum);
/* 107 */           this.curRecv = this.requestNum;
/*     */         }
/* 110 */         else if (log.isDebugEnabled()) {
/* 111 */           IMessage amsg = msg;
/* 112 */           if (msg.getMessageType() == MessageType.MSG_GATE) {
/* 113 */             amsg = ((MessageGate)msg).getInnerMessage();
/* 114 */             if (amsg != null)
/* 115 */               log.debug("剩余报文数量=" + this.curRecv + ",msg=" + amsg);
/*     */           }
/*     */           else {
/* 118 */             log.debug("剩余报文数量=" + this.curRecv + ",msg=" + amsg);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 123 */     this.lastReceiveTime = System.currentTimeMillis();
/*     */     try {
/* 125 */       this.eventHandler.handleEvent(new ReceiveMessageEvent(msg, client)); } catch (Exception localException) {
/*     */     }
/* 127 */     long timeSpand = System.currentTimeMillis() - this.lastReceiveTime;
/* 128 */     if (timeSpand > 100L) {
/* 129 */       TraceLog _tracer = TraceLog.getTracer(this.socket.getClass());
/* 130 */       if (_tracer.isEnabled())
/* 131 */         _tracer.trace("ClientModule fire onReceive event, it takes " + timeSpand + " milliseconds.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onSend(JSocket client, IMessage msg) {
/* 136 */     synchronized (this.statisticsSend) {
/* 137 */       this.msgSendPerMinute += 1;
/* 138 */       this.totalSendMessages += 1L;
/*     */     }
/* 140 */     this.lastSendTime = System.currentTimeMillis();
/*     */     try {
/* 142 */       this.eventHandler.handleEvent(new SendMessageEvent(msg, client)); } catch (Exception localException) {
/*     */     }
/* 144 */     long timeSpand = System.currentTimeMillis() - this.lastSendTime;
/* 145 */     if (timeSpand > 100L) {
/* 146 */       TraceLog _tracer = TraceLog.getTracer(this.socket.getClass());
/* 147 */       if (_tracer.isEnabled())
/* 148 */         _tracer.trace("ClientModule fire onSend event, it takes " + timeSpand + " milliseconds.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getModuleType() {
/* 153 */     return this.moduleType;
/*     */   }
/*     */ 
/*     */   public void setModuleType(String modType) {
/* 157 */     this.moduleType = modType;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 161 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String nm) {
/* 165 */     this.name = nm;
/*     */   }
/*     */ 
/*     */   public String getTxfs() {
/* 169 */     return this.txfs;
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/* 173 */     return this.active;
/*     */   }
/*     */ 
/*     */   public void init() {
/* 177 */     if (this.socket != null)
/*     */       return;
/* 179 */     this.socket = new JSocket();
/* 180 */     this.socket.setHostIp(this.hostIp);
/* 181 */     this.socket.setHostPort(this.hostPort);
/*     */   }
/*     */ 
/*     */   public boolean start()
/*     */   {
/* 186 */     if ((this.heartInterval > 0) && (this.heartMsg == null)) {
/* 187 */       this.heartMsg = this.messageCreator.createHeartBeat(this.requestNum);
/* 188 */       this.curRecv = this.requestNum;
/*     */     }
/* 190 */     init();
/* 191 */     this.socket.setBufLength(this.bufLength);
/* 192 */     this.socket.setMessageCreator(this.messageCreator);
/* 193 */     this.socket.setTimeout(this.timeout);
/* 194 */     this.socket.setListener(this);
/* 195 */     this.socket.setTxfs(this.txfs);
/* 196 */     this.socket.init();
/*     */ 
/* 198 */     TimerScheduler.getScheduler().addTimer(new TimerData(this, 0, 60L));
/*     */ 
/* 200 */     if (this.heartInterval > 0)
/*     */     {
/* 202 */       TimerScheduler.getScheduler().addTimer(new TimerData(this, 1, 2L));
/*     */     }
/* 204 */     this.lastHeartbeat = System.currentTimeMillis();
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 209 */     TimerScheduler.getScheduler().removeTimer(this, 0);
/* 210 */     if (this.socket != null)
/* 211 */       this.socket.close();
/*     */   }
/*     */ 
/*     */   public String profile() {
/* 215 */     StringBuffer sb = new StringBuffer(1024);
/* 216 */     sb.append("\r\n    <sockclient-profile type=\"").append(getModuleType()).append("\">");
/* 217 */     sb.append("\r\n        ").append("<name>").append(getName()).append("</name>");
/* 218 */     sb.append("\r\n        ").append("<port>").append(this.hostIp + ":" + this.hostPort).append("</port>");
/* 219 */     sb.append("\r\n        ").append("<state>").append(isActive()).append("</state>");
/* 220 */     sb.append("\r\n        ").append("<timeout>").append(this.timeout).append("</timeout>");
/*     */ 
/* 222 */     sb.append("\r\n        ").append("<txfs>").append(this.txfs).append("</txfs>");
/* 223 */     sb.append("\r\n        ").append("<totalRecv>").append(this.totalRecvMessages).append("</totalRecv>");
/* 224 */     sb.append("\r\n        ").append("<totalSend>").append(this.totalSendMessages).append("</totalSend>");
/* 225 */     sb.append("\r\n        ").append("<perMinuteRecv>").append(this.msgRecvPerMinute).append("</perMinuteRecv>");
/* 226 */     sb.append("\r\n        ").append("<perMinuteSend>").append(this.msgSendPerMinute).append("</perMinuteSend>");
/*     */ 
/* 228 */     String stime = CalendarUtil.getTimeString(this.lastReceiveTime);
/* 229 */     sb.append("\r\n        ").append("<lastRecv>").append(stime).append("</lastRecv>");
/* 230 */     stime = CalendarUtil.getTimeString(this.lastSendTime);
/* 231 */     sb.append("\r\n        ").append("<lastSend>").append(stime).append("</lastSend>");
/* 232 */     sb.append("\r\n    </sockclient-profile>");
/* 233 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void onTimer(int id)
/*     */   {
/* 238 */     if ((1 == id) && (this.heartInterval > 0)) {
/* 239 */       long interval = System.currentTimeMillis() - this.lastHeartbeat;
/* 240 */       if (interval >= this.heartInterval) {
/* 241 */         this.curRecv = this.requestNum;
/* 242 */         sendMessage(this.heartMsg);
/*     */       }
/*     */ 
/* 245 */       interval = System.currentTimeMillis() - this.lastReceiveTime;
/* 246 */       if (interval > this.heartInterval << 4) {
/* 247 */         TraceLog _trace = TraceLog.getTracer(this.socket.getClass());
/* 248 */         if (_trace.isEnabled())
/* 249 */           _trace.trace("no up frame within 2 heartbeat intervals，connection will be reset. client=" + this.socket.getPeerAddr() + ",heartInterval=" + this.heartInterval + ",interval=" + interval + ",lastReceiveTime=" + this.lastReceiveTime);
/* 250 */         this.socket.reConnect();
/*     */ 
/* 252 */         this.lastReceiveTime = System.currentTimeMillis();
/*     */       }
/*     */     } else {
/* 255 */       if (id != 0) {
/*     */         return;
/*     */       }
/* 258 */       synchronized (this.statisticsRecv) {
/* 259 */         this.msgRecvPerMinute = 0;
/*     */       }
/* 261 */       synchronized (this.statisticsSend) {
/* 262 */         this.msgSendPerMinute = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLastReceiveTime() {
/* 268 */     return this.lastReceiveTime;
/*     */   }
/*     */ 
/*     */   public long getLastSendTime() {
/* 272 */     return this.lastSendTime;
/*     */   }
/*     */ 
/*     */   public int getMsgRecvPerMinute() {
/* 276 */     return this.msgRecvPerMinute;
/*     */   }
/*     */ 
/*     */   public int getMsgSendPerMinute() {
/* 280 */     return this.msgSendPerMinute;
/*     */   }
/*     */ 
/*     */   public long getTotalRecvMessages() {
/* 284 */     return this.totalRecvMessages;
/*     */   }
/*     */ 
/*     */   public long getTotalSendMessages() {
/* 288 */     return this.totalSendMessages;
/*     */   }
/*     */ 
/*     */   public String getHostIp() {
/* 292 */     return this.hostIp;
/*     */   }
/*     */ 
/*     */   public void setHostIp(String hostIp) {
/* 296 */     this.hostIp = hostIp;
/*     */   }
/*     */ 
/*     */   public int getHostPort() {
/* 300 */     return this.hostPort;
/*     */   }
/*     */ 
/*     */   public void setHostPort(int hostPort) {
/* 304 */     this.hostPort = hostPort;
/*     */   }
/*     */ 
/*     */   public int getBufLength() {
/* 308 */     return this.bufLength;
/*     */   }
/*     */ 
/*     */   public void setBufLength(int bufLength) {
/* 312 */     this.bufLength = bufLength;
/*     */   }
/*     */ 
/*     */   public IMessageCreator getMessageCreator() {
/* 316 */     return this.messageCreator;
/*     */   }
/*     */ 
/*     */   public void setMessageCreator(IMessageCreator messageCreator) {
/* 320 */     this.messageCreator = messageCreator;
/*     */   }
/*     */ 
/*     */   public int getTimeout() {
/* 324 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/* 328 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public JSocket getSocket() {
/* 332 */     return this.socket;
/*     */   }
/*     */ 
/*     */   public void setSocket(JSocket socket) {
/* 336 */     this.socket = socket;
/*     */   }
/*     */ 
/*     */   public void setTxfs(String txfs) {
/* 340 */     this.txfs = txfs;
/*     */   }
/*     */ 
/*     */   public void setEventHandler(IEventHandler eventHandler) {
/* 344 */     this.eventHandler = eventHandler;
/*     */   }
/*     */ 
/*     */   public void setHeartInterval(int heartInterval) {
/* 348 */     this.heartInterval = (heartInterval * 1000);
/*     */   }
/*     */ 
/*     */   public int getRequestNum() {
/* 352 */     return this.requestNum;
/*     */   }
/*     */ 
/*     */   public void setRequestNum(int requestNum) {
/* 356 */     this.requestNum = requestNum;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 361 */     return profile();
/*     */   }
/*     */ 
/*     */   public void setHeartMsg(IMessage heartMsg) {
/* 365 */     this.heartMsg = heartMsg;
/*     */   }
/*     */ }